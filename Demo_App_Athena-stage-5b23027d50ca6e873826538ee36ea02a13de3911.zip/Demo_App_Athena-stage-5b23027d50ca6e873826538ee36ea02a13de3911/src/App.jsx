import { useState } from 'react'
import { Routes, Route, Navigate, useLocation } from "react-router-dom";
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Layout from './Layout';
import AdminDashboard from './Components/Admin/Dashboard/AdminDashboard';
import Login from './Components/Auth/Login/Login'
import Signup from './Components/Auth/Signup/Signup';
import ForgotPass from './Components/Auth/Forgot/ForgotPass';
import ResetPass from './Components/Auth/Reset/ResetPass';
import TicketManagementGrid from './Components/Admin/TicketManagement/TicketManagementGrid'
import NewTicketForm from './Components/Admin/TicketManagement/NewTicketForm';
import TicketDetails from './Components/Admin/TicketManagement/TicketDetails';
import UserManagementLayout from './Components/Admin/UserManagement/UserManagementLayout';
import AssetManagementLayout from './Components/Admin/AssetManagement/AssetManagementLayout';
import AddAssetsForm from './Components/Admin/AssetManagement/AddAssetsForm';
import AssetsDetails from './Components/Admin/AssetManagement/AssetDetails/AssetsDetails'
import CreateAssetsGroup from './Components/Admin/AssetManagement/AssetGroups/CreateAssetsGroup';
import BillingLayout from './Components/Admin/Billing/BillingLayout';
import NewBillingForm from './Components/Admin/Billing/NewBillingForm';
import NewQuoteForm from './Components/Admin/Billing/NewQuoteForm';
import CrmLayout from './Components/Admin/CRM/CrmLayout';
import CustomerAccountLayout from './Components/Admin/CRM/CustomerAccountSetup/CustomerAccountLayout';
import ClientDetails from './Components/Admin/CRM/CustomerAccountSetup/ClientDetails';
import EmailNotification from './Components/Admin/EmailNotification/EmailNotification';
import ContractManagementLayout from './Components/Admin/ContractManagement/ContractManagementLayout';
import KnowledgeBaseLayout from './Components/Admin/KnowledgeBase/KnowledgeBaseLayout';
import ReportLayout from './Components/Admin/Report/ReportLayout';
import SuperAdminAthenaLayout from './Components/Admin/SuperAdminAthena/SuperAdminAthenaLayout';
import UserDetails from './Components/Admin/CRM/CustomerAccountSetup/UsersDetails';
import NewContractForm from './Components/Admin/ContractManagement/NewContractForm';
import CRMNewContractForm from './Components/Admin/CRM/ContractsManagement/CRMNewContractForm';
import CRMContractManagementLayout from './Components/Admin/CRM/ContractsManagement/CRMContractManagementLayout';
import NewArticle from './Components/Admin/KnowledgeBase/NewArticle';
import ViewSelection from './Components/Admin/CRM/ViewSelection/ViewSelection';
import ConfigureListGrid from './Components/Admin/CRM/ViewSelection/ConfigureListGrid';
import ConfigureFilterGrid from './Components/Admin/CRM/ViewSelection/ConfigureFilterGrid';
import ConfigureColumnProfileGrid from './Components/Admin/CRM/ViewSelection/ConfigureColumnProfileGrid';
import Vendors from './Components/Admin/CRM/Vendors/Vendors';
import NewVendors from './Components/Admin/CRM/Vendors/NewVendors';
import OpportunitiesManagementLayout from './Components/Admin/CRM/OpportunitiesManagement/OpportunitiesManagementLayout';
import NewOpportunityForm from './Components/Admin/CRM/OpportunitiesManagement/NewOpportunityForm';
import LeadsManagementLayout from './Components/Admin/CRM/LeadsManagement/LeadsManagementLayout';
import NewLeadsForm from './Components/Admin/CRM/LeadsManagement/NewLeadsForm';
import OpportunityDetails from './Components/Admin/CRM/OpportunitiesManagement/OpportunityDetails';
import LeadsDetails from './Components/Admin/CRM/LeadsManagement/LeadsDetails';
import ProtectedRoutes from './utils/ProtectedRoutes';
import NewUserForm from './Components/Admin/CRM/CustomerAccountSetup/NewUserForm';
import NewClientForm from './Components/Admin/CRM/CustomerAccountSetup/NewClientForm';

function App() {

  const location = useLocation();

  const noLayoutRoutes = ["/login", "/signup", "/", "/forgot", "/reset"];

  const isNoLayoutRoute = noLayoutRoutes.includes(location.pathname);

  return (
    <>
      {isNoLayoutRoute ? (
        <Routes>
          <Route path="/" element={<Navigate to="/login" />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/forgot" element={<ForgotPass />} />
          <Route path="/reset" element={<ResetPass />} />
        </Routes>
      ) : (
        <Layout>
          <Routes>

            <Route element={<ProtectedRoutes />}>

            <Route path="/admin" element={<AdminDashboard />} />
            <Route path='/ticket-management' element={<TicketManagementGrid/>}/>
            <Route path='/new-ticket' element={<NewTicketForm/>}/>
            <Route path='/ticket-details' element={<TicketDetails/>}/>
            <Route path='/user-management' element={<UserManagementLayout/>}/>
            <Route path='/asset-management' element={<AssetManagementLayout/>}/>
            <Route path='/asset-form' element={<AddAssetsForm/>}/>
            <Route path='/asset-details' element={<AssetsDetails/>}/>
            <Route path='/asset-group' element={<CreateAssetsGroup/>}/>
            <Route path='/billing' element={<BillingLayout/>}/>
            <Route path='/billing-form' element={<NewBillingForm/>}/>
            <Route path='/billing-quote' element={<NewQuoteForm/>}/>
            <Route path="/crm" element={<CrmLayout/>}/>
            <Route path='/crm-customer' element={<CustomerAccountLayout/>}/>
            <Route path='/crm-client-details' element={<ClientDetails/>}/>
            <Route path='/crm-user-details' element={<UserDetails/>}/>
            <Route path='/crm-contract-management' element={<CRMContractManagementLayout/>}/>
            <Route path='/crm-new-contract-form' element={<CRMNewContractForm/>}/>
            <Route path='/crm-view' element={<ViewSelection/>}/>
            <Route path='/opportunity-details' element={<OpportunityDetails/>}/>
            <Route path="/configure-list" element={<ConfigureListGrid/>}/>
            <Route path='/configure-filter' element={<ConfigureFilterGrid/>}/>
            <Route path='/configure-column-profile' element={<ConfigureColumnProfileGrid/>}/>
            <Route path='/crm-vendors' element={<Vendors/>}/>
            <Route path='/crm-new-vendors' element={<NewVendors/>}/>
            <Route path='/crm-opportunities' element={<OpportunitiesManagementLayout/>}/>
            <Route path='/new-opportunity-form' element={<NewOpportunityForm/>}/>
            <Route path='/crm-leads' element={<LeadsManagementLayout/>}/>
            <Route path='/crm-leads-form' element={<NewLeadsForm/>}/>
            <Route path='/crm-lead-details' element={<LeadsDetails/>}/>
            <Route path='/crm-new-user' element={<NewUserForm/>}/>
            <Route path='/crm-new-client' element={<NewClientForm/>}/>
            <Route path='/email-notification' element={<EmailNotification/>}/> 
            <Route path='/contract-management' element={<ContractManagementLayout/>}/> 
            <Route path='/new-contract-form' element={<NewContractForm/>}/> 
            <Route path='/knowledge-base' element={<KnowledgeBaseLayout/>}/> 
            <Route path='/new-article' element={<NewArticle/>}/>
            <Route path='/report' element={<ReportLayout/>}/>
            <Route path='/super-admin' element={<SuperAdminAthenaLayout/>}/> 
            </Route>
          </Routes>
        </Layout>
      )}
    </>
  )
}

export default App