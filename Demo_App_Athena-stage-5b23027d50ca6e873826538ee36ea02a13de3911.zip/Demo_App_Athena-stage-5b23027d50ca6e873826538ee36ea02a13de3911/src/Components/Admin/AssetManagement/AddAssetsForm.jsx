import React, { useState } from 'react';
import TitleBreadcrumb from "../../Shared/TitleBreadcrumb";
import { Grid, Box, Typography, Button, TextField, IconButton, MenuItem, Dialog, DialogContent, Select, FormControl, FormHelperText } from "@mui/material";
import { HomeIcon, XMarkIcon, MagnifyingGlassIcon, ChevronDownIcon, CheckCircleIcon } from '@heroicons/react/24/solid';
import { useNavigate, useLocation } from 'react-router-dom';
import { useFormik } from 'formik';
import * as Yup from 'yup';

const AddAssetsForm = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [successDialogOpen, setSuccessDialogOpen] = useState(false);

  // Get edit mode and data from location state
  const editMode = location.state?.editMode || false;
  const assetData = location.state?.assetData || {};

  // ✅ DEFINE DROPDOWN OPTIONS
  const businessOwnerOptions = [
    "John Doe",
    "Jane Smith",
    "Mike Johnson",
    "Sarah Williams",
    "Customer Name",
    "Robert Brown",
    "Emily Davis"
  ];

  const technicalOwnerOptions = [
    "David Brown",
    "Emily Davis",
    "James Wilson",
    "Lisa Anderson",
    "John Smith",
    "Michael Chen",
    "Amanda Rodriguez"
  ];

  // ✅ DYNAMICALLY ADD CURRENT VALUES IF NOT IN OPTIONS
  const getBusinessOwnerOptions = () => {
    if (editMode && assetData.customer && !businessOwnerOptions.includes(assetData.customer)) {
      return [assetData.customer, ...businessOwnerOptions];
    }
    return businessOwnerOptions;
  };

  const getTechnicalOwnerOptions = () => {
    if (editMode && assetData.user && !technicalOwnerOptions.includes(assetData.user)) {
      return [assetData.user, ...technicalOwnerOptions];
    }
    return technicalOwnerOptions;
  };

  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

  const validationSchema = Yup.object({
    assetsType: Yup.string().required("Assets Type is required"),
    site: Yup.string().required("Site is required"),
    assetsTag: Yup.string().required("Assets Tag is required"),
    businessOwner: Yup.string().required("Business Owner is required"),
    technicalOwner: Yup.string().required("Technical Owner is required"),
    priority: Yup.string().required("Priority is required"),
    status: Yup.string().required("Status is required"),
    criticality: Yup.string().required("Criticality is required"),
  });

  const formik = useFormik({
    initialValues: {
      assetsType: editMode ? (assetData.assetsType || "") : "",
      site: editMode ? (assetData.site || "") : "",
      assetsTag: editMode ? (assetData.assetsNumber || assetData.id || "") : "",
      businessOwner: editMode ? (assetData.customer || "") : "",
      technicalOwner: editMode ? (assetData.user || "") : "",
      priority: editMode ? (assetData.priority || "Medium") : "",
      status: editMode ? (assetData.status || "") : "",
      criticality: editMode ? (assetData.criticality || "Medium") : "",
      model: editMode ? (assetData.model || "Dell Latitude 5420") : "",
      serialNumber: editMode ? (assetData.serialNumber || "DL5420-2024-001") : "",
      operatingSystem: editMode ? (assetData.operatingSystem || "Windows 11 Pro") : "",
      discSize: editMode ? (assetData.discSize || "512GB SSD") : "",
      processor: editMode ? (assetData.processor || "Intel Core i7-1185G7") : "",
      ramMemory: editMode ? (assetData.ramMemory || "16GB DDR4") : "",
      connect: editMode ? (assetData.connect || "WiFi 6, Bluetooth 5.2") : "",
      purchaseCost: editMode ? (assetData.purchaseCost || "$1,299.99") : "",
      notes: editMode ? (assetData.notes || "Asset in good condition, regular maintenance scheduled") : "",
    },
    validationSchema,
    onSubmit: (values) => {
      const formData = {
        id: editMode ? assetData.id : `KL-${values.assetsType.substring(0, 3).toUpperCase()}-${Date.now()}`,
        assetsType: values.assetsType,
        site: values.site,
        assetsNumber: values.assetsTag,
        customer: values.businessOwner,
        user: values.technicalOwner,
        priority: values.priority,
        status: values.status,
        criticality: values.criticality,
        model: values.model,
        serialNumber: values.serialNumber,
        operatingSystem: values.operatingSystem,
        discSize: values.discSize,
        processor: values.processor,
        ramMemory: values.ramMemory,
        connect: values.connect,
        purchaseCost: values.purchaseCost,
        notes: values.notes
      };

      console.log(editMode ? "Updating asset:" : "Creating asset:", formData);
      setSuccessDialogOpen(true);
      
      setTimeout(() => {
        if (editMode) {
          navigate('/asset-details', { state: { assetData: formData } });
        } else {
          navigate('/asset-management');
        }
      }, 1000);
    },
  });

  const handleCancel = () => {
    navigate(-1);
  };

  console.log("Edit Mode:", editMode);
  console.log("Asset Data:", assetData);
  console.log("Formik businessOwner:", formik.values.businessOwner);
  console.log("Formik technicalOwner:", formik.values.technicalOwner);

  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <Grid container spacing={{ xs: 1, md: 2 }} columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{ width: "100%", maxWidth: "100vw", m: 0, p: { xs: 0, sm: 1 }, justifyContent: "center", flexGrow: 1 }}>
          
          <Grid item size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
            sx={{ border: "1px solid #E4E4E7", backgroundColor: "#fff", px: { xs: 1, sm: 4, md: 6, xl: 3 }, 
                 py: { xs: 0, sm: 3 }, boxShadow: { xs: "none", sm: "0 2px 14px rgba(116,185,255,.08)" } }}>
            
            {/* Breadcrumb */}
            <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
              <HomeIcon style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8,cursor:"pointer" }} onClick={() => navigate("/admin")}/>
              <TitleBreadcrumb breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin" },
                { type: "link", label: "Asset Management", to: "/asset-management" },
                { type: "text", label: editMode ? "Edit Asset" : "Add New Assets", to: "" }
              ]} />
            </Box>

            {/* Header */}
            <Box sx={{ mt: 2, pt: 1, pb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 2 }}>
              <Typography sx={{ fontFamily: "Open Sans", fontSize: "24px", fontWeight: "700", color: "#111827" }}>
                {editMode ? "Edit Asset" : "Add New Assets"}
              </Typography>

               <Box sx={{ display: 'flex', gap: 2 }}>

                <Button
                  type="submit"
                  variant="contained"
                  sx={{
                    px: 3, py: 1, fontSize: 15, fontWeight: 600, fontFamily: 'Open Sans', textTransform: 'none',
                    backgroundColor: '#409BFF', borderRadius: '16px', boxShadow: 'none',
                    '&:hover': { backgroundColor: '#3380e8', boxShadow: 'none' }
                  }}
                >
                  {editMode ? 'Update' : 'Save'}
                </Button>
              </Box>
            </Box>

            {/* Basic Information Section */}
            <Box sx={{ border: "1px solid #E5E7EB", borderRadius: "8px", p: 3, mb: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
                <Box sx={{ width: 20, height: 20, borderRadius: '50%', backgroundColor: '#409BFF', 
                           display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: '12px', fontWeight: 700 }}>
                  i
                </Box>
                <Typography sx={{ fontSize: 18, fontWeight: 600, color: "#111827", fontFamily: 'Open Sans' }}>
                  Basic Information
                </Typography>
              </Box>

              {/* First Row */}
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item size={{xs:12, sm:6, md:3}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Assets Type<span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <FormControl fullWidth size="small" error={formik.touched.assetsType && Boolean(formik.errors.assetsType)}>
                    <Select
                      name="assetsType"
                      value={formik.values.assetsType}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 14, fontFamily: 'Open Sans', backgroundColor: "#fff", height: 40,
                        "& fieldset": { borderColor: formik.touched.assetsType && formik.errors.assetsType ? "#EF4444" : "#E5E7EB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { color: formik.values.assetsType ? "#111827" : "#9CA3AF" }
                      }}
                    >
                      <MenuItem value="" disabled>Select Assets Type</MenuItem>
                      <MenuItem value="Laptop">Laptop</MenuItem>
                      <MenuItem value="Desktop">Desktop</MenuItem>
                      <MenuItem value="Desktop Computer">Desktop Computer</MenuItem>
                      <MenuItem value="Server">Server</MenuItem>
                      <MenuItem value="Network Device">Network Device</MenuItem>
                      <MenuItem value="Printer">Printer</MenuItem>
                      <MenuItem value="Monitor">Monitor</MenuItem>
                      <MenuItem value="Tablet">Tablet</MenuItem>
                      <MenuItem value="Smartphone">Smartphone</MenuItem>
                      <MenuItem value="Workstation">Workstation</MenuItem>
                    </Select>
                    <FormHelperText sx={{ minHeight: '20px', margin: '3px 0 0 0' }}>
                      {formik.touched.assetsType && formik.errors.assetsType ? formik.errors.assetsType : ' '}
                    </FormHelperText>
                  </FormControl>
                </Grid>

                <Grid item size={{xs:12, sm:6, md:3}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Site<span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    name="site"
                    placeholder="Choose which site this asset is"
                    value={formik.values.site}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    error={formik.touched.site && Boolean(formik.errors.site)}
                    helperText={formik.touched.site && formik.errors.site ? formik.errors.site : ' '}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        fontSize: 14, fontFamily: 'Open Sans', backgroundColor: "#fff", height: 40,
                        "& fieldset": { borderColor: formik.touched.site && formik.errors.site ? "#EF4444" : "#E5E7EB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& input::placeholder": { color: "#9CA3AF", opacity: 1 }
                      },
                      "& .MuiFormHelperText-root": { minHeight: '20px', margin: '3px 0 0 0' }
                    }}
                  />
                </Grid>

                <Grid item size={{xs:12, sm:6, md:3}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Assets Tag<span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    name="assetsTag"
                    placeholder="Search by Name"
                    value={formik.values.assetsTag}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    error={formik.touched.assetsTag && Boolean(formik.errors.assetsTag)}
                    helperText={formik.touched.assetsTag && formik.errors.assetsTag ? formik.errors.assetsTag : ' '}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        fontSize: 14, fontFamily: 'Open Sans', backgroundColor: "#fff", height: 40,
                        "& fieldset": { borderColor: formik.touched.assetsTag && formik.errors.assetsTag ? "#EF4444" : "#E5E7EB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& input::placeholder": { color: "#9CA3AF", opacity: 1 }
                      },
                      "& .MuiFormHelperText-root": { minHeight: '20px', margin: '3px 0 0 0' }
                    }}
                  />
                </Grid>

                {/* ✅ BUSINESS OWNER - FIXED FOR EDIT MODE */}
                <Grid item size={{xs:12, sm:6, md:3}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Business Owner<span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <FormControl fullWidth size="small" error={formik.touched.businessOwner && Boolean(formik.errors.businessOwner)}>
                    <Select
                      name="businessOwner"
                      value={formik.values.businessOwner}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 14, fontFamily: 'Open Sans', backgroundColor: "#fff", height: 40,
                        "& fieldset": { borderColor: formik.touched.businessOwner && formik.errors.businessOwner ? "#EF4444" : "#E5E7EB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { color: formik.values.businessOwner ? "#111827" : "#9CA3AF" }
                      }}
                    >
                      <MenuItem value="" disabled>Select Business Owner</MenuItem>
                      {getBusinessOwnerOptions().map((owner) => (
                        <MenuItem key={owner} value={owner}>{owner}</MenuItem>
                      ))}
                    </Select>
                    <FormHelperText sx={{ minHeight: '20px', margin: '3px 0 0 0' }}>
                      {formik.touched.businessOwner && formik.errors.businessOwner ? formik.errors.businessOwner : ' '}
                    </FormHelperText>
                  </FormControl>
                </Grid>
              </Grid>

              {/* Second Row */}
              <Grid container spacing={2}>
                {/* ✅ TECHNICAL OWNER - FIXED FOR EDIT MODE */}
                <Grid item size={{xs:12, sm:6, md:3}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Technical Owner<span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <FormControl fullWidth size="small" error={formik.touched.technicalOwner && Boolean(formik.errors.technicalOwner)}>
                    <Select
                      name="technicalOwner"
                      value={formik.values.technicalOwner}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 14, fontFamily: 'Open Sans', backgroundColor: "#fff", height: 40,
                        "& fieldset": { borderColor: formik.touched.technicalOwner && formik.errors.technicalOwner ? "#EF4444" : "#E5E7EB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { color: formik.values.technicalOwner ? "#111827" : "#9CA3AF" }
                      }}
                    >
                      <MenuItem value="" disabled>Select Technical Owner</MenuItem>
                      {getTechnicalOwnerOptions().map((owner) => (
                        <MenuItem key={owner} value={owner}>{owner}</MenuItem>
                      ))}
                    </Select>
                    <FormHelperText sx={{ minHeight: '20px', margin: '3px 0 0 0' }}>
                      {formik.touched.technicalOwner && formik.errors.technicalOwner ? formik.errors.technicalOwner : ' '}
                    </FormHelperText>
                  </FormControl>
                </Grid>

                <Grid item size={{xs:12, sm:6, md:3}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Priority<span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <FormControl fullWidth size="small" error={formik.touched.priority && Boolean(formik.errors.priority)}>
                    <Select
                      name="priority"
                      value={formik.values.priority}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 14, fontFamily: 'Open Sans', backgroundColor: "#fff", height: 40,
                        "& fieldset": { borderColor: formik.touched.priority && formik.errors.priority ? "#EF4444" : "#E5E7EB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { color: formik.values.priority ? "#111827" : "#9CA3AF" }
                      }}
                    >
                      <MenuItem value="" disabled>Select your priority</MenuItem>
                      <MenuItem value="Low">Low</MenuItem>
                      <MenuItem value="Medium">Medium</MenuItem>
                      <MenuItem value="High">High</MenuItem>
                      <MenuItem value="Critical">Critical</MenuItem>
                      <MenuItem value="Urgent">Urgent</MenuItem>
                    </Select>
                    <FormHelperText sx={{ minHeight: '20px', margin: '3px 0 0 0' }}>
                      {formik.touched.priority && formik.errors.priority ? formik.errors.priority : ' '}
                    </FormHelperText>
                  </FormControl>
                </Grid>

                <Grid item size={{xs:12, sm:6, md:3}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Status<span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <FormControl fullWidth size="small" error={formik.touched.status && Boolean(formik.errors.status)}>
                    <Select
                      name="status"
                      value={formik.values.status}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 14, fontFamily: 'Open Sans', backgroundColor: "#fff", height: 40,
                        "& fieldset": { borderColor: formik.touched.status && formik.errors.status ? "#EF4444" : "#E5E7EB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { color: formik.values.status ? "#111827" : "#9CA3AF" }
                      }}
                    >
                      <MenuItem value="" disabled>Select Status</MenuItem>
                      <MenuItem value="Active">Active</MenuItem>
                      <MenuItem value="In Stock">In Stock</MenuItem>
                      <MenuItem value="Out of Stock">Out of Stock</MenuItem>
                      <MenuItem value="Damage">Damage</MenuItem>
                    </Select>
                    <FormHelperText sx={{ minHeight: '20px', margin: '3px 0 0 0' }}>
                      {formik.touched.status && formik.errors.status ? formik.errors.status : ' '}
                    </FormHelperText>
                  </FormControl>
                </Grid>

                <Grid item size={{xs:12, sm:6, md:3}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Criticality<span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <FormControl fullWidth size="small" error={formik.touched.criticality && Boolean(formik.errors.criticality)}>
                    <Select
                      name="criticality"
                      value={formik.values.criticality}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 14, fontFamily: 'Open Sans', backgroundColor: "#fff", height: 40,
                        "& fieldset": { borderColor: formik.touched.criticality && formik.errors.criticality ? "#EF4444" : "#E5E7EB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { color: formik.values.criticality ? "#111827" : "#9CA3AF" }
                      }}
                    >
                      <MenuItem value="" disabled>Not set</MenuItem>
                      <MenuItem value="Low">Low</MenuItem>
                      <MenuItem value="Medium">Medium</MenuItem>
                      <MenuItem value="High">High</MenuItem>
                      <MenuItem value="Critical">Critical</MenuItem>
                    </Select>
                    <FormHelperText sx={{ minHeight: '20px', margin: '3px 0 0 0' }}>
                      {formik.touched.criticality && formik.errors.criticality ? formik.errors.criticality : ' '}
                    </FormHelperText>
                  </FormControl>
                </Grid>
              </Grid>
            </Box>

            {/* Technical Specifications Section */}
            <Box sx={{ border: "1px solid #E5E7EB", borderRadius: "8px", p: 3, mb: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
                <Box sx={{ width: 20, height: 20, borderRadius: '50%', backgroundColor: '#409BFF', 
                           display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: '12px', fontWeight: 700 }}>
                  ⚙
                </Box>
                <Typography sx={{ fontSize: 18, fontWeight: 600, color: "#111827", fontFamily: 'Open Sans' }}>
                  Technical Specifications
                </Typography>
              </Box>

              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item size={{xs:12, sm:6, md:3}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Model
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    name="model"
                    placeholder="Enter model"
                    value={formik.values.model}
                    onChange={formik.handleChange}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        fontSize: 14, fontFamily: 'Open Sans', backgroundColor: "#fff", height: 40,
                        "& fieldset": { borderColor: "#E5E7EB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& input::placeholder": { color: "#9CA3AF", opacity: 1 }
                      }
                    }}
                  />
                </Grid>

                <Grid item size={{xs:12, sm:6, md:3}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Serial Number
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    name="serialNumber"
                    placeholder="Enter serial number"
                    value={formik.values.serialNumber}
                    onChange={formik.handleChange}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        fontSize: 14, fontFamily: 'Open Sans', backgroundColor: "#fff", height: 40,
                        "& fieldset": { borderColor: "#E5E7EB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& input::placeholder": { color: "#9CA3AF", opacity: 1 }
                      }
                    }}
                  />
                </Grid>

                <Grid item size={{xs:12, sm:6, md:3}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Operating System
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    name="operatingSystem"
                    placeholder="Enter OS"
                    value={formik.values.operatingSystem}
                    onChange={formik.handleChange}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        fontSize: 14, fontFamily: 'Open Sans', backgroundColor: "#fff", height: 40,
                        "& fieldset": { borderColor: "#E5E7EB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& input::placeholder": { color: "#9CA3AF", opacity: 1 }
                      }
                    }}
                  />
                </Grid>

                <Grid item size={{xs:12, sm:6, md:3}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Disc Size
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    name="discSize"
                    placeholder="Enter disc size"
                    value={formik.values.discSize}
                    onChange={formik.handleChange}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        fontSize: 14, fontFamily: 'Open Sans', backgroundColor: "#fff", height: 40,
                        "& fieldset": { borderColor: "#E5E7EB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& input::placeholder": { color: "#9CA3AF", opacity: 1 }
                      }
                    }}
                  />
                </Grid>
              </Grid>

              <Grid container spacing={2}>
                <Grid item size={{xs:12, sm:6, md:3}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Processor
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    name="processor"
                    placeholder="Enter processor"
                    value={formik.values.processor}
                    onChange={formik.handleChange}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        fontSize: 14, fontFamily: 'Open Sans', backgroundColor: "#fff", height: 40,
                        "& fieldset": { borderColor: "#E5E7EB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& input::placeholder": { color: "#9CA3AF", opacity: 1 }
                      }
                    }}
                  />
                </Grid>

                <Grid item size={{xs:12, sm:6, md:3}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    RAM Memory
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    name="ramMemory"
                    placeholder="Enter RAM"
                    value={formik.values.ramMemory}
                    onChange={formik.handleChange}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        fontSize: 14, fontFamily: 'Open Sans', backgroundColor: "#fff", height: 40,
                        "& fieldset": { borderColor: "#E5E7EB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& input::placeholder": { color: "#9CA3AF", opacity: 1 }
                      }
                    }}
                  />
                </Grid>

                <Grid item size={{xs:12, sm:6, md:3}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Connect
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    name="connect"
                    placeholder="Enter connection type"
                    value={formik.values.connect}
                    onChange={formik.handleChange}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        fontSize: 14, fontFamily: 'Open Sans', backgroundColor: "#fff", height: 40,
                        "& fieldset": { borderColor: "#E5E7EB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& input::placeholder": { color: "#9CA3AF", opacity: 1 }
                      }
                    }}
                  />
                </Grid>

                <Grid item size={{xs:12, sm:6, md:3}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Purchase Cost
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    name="purchaseCost"
                    placeholder="Enter cost"
                    value={formik.values.purchaseCost}
                    onChange={formik.handleChange}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        fontSize: 14, fontFamily: 'Open Sans', backgroundColor: "#fff", height: 40,
                        "& fieldset": { borderColor: "#E5E7EB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& input::placeholder": { color: "#9CA3AF", opacity: 1 }
                      }
                    }}
                  />
                </Grid>
              </Grid>

              <Box sx={{ mt: 3 }}>
                <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                  Notes
                </Typography>
                <TextField
                  fullWidth
                  multiline
                  rows={4}
                  name="notes"
                  placeholder="Add any additional notes or comments..."
                  value={formik.values.notes}
                  onChange={formik.handleChange}
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      fontSize: 14, fontFamily: 'Open Sans', backgroundColor: "#fff",
                      "& fieldset": { borderColor: "#E5E7EB" },
                      "&:hover fieldset": { borderColor: "#D1D5DB" },
                      "& textarea::placeholder": { color: "#9CA3AF", opacity: 1 }
                    }
                  }}
                />
              </Box>
            </Box>

            {/* Footer */}
            <Box sx={{ position: 'sticky', bottom: 0, left: 0, right: 0, bgcolor: '#fff', borderTop: '1px solid #E4E4E7', 
                       pt: 3, pb: 2, display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 2 }}>
              <Typography sx={{ fontSize: 16, fontWeight: 700, color: "#4B5563", fontFamily: 'Open Sans' }}>
                {editMode ? 'Update Asset Information' : 'Save as Draft'}
              </Typography>

              <Box sx={{ display: 'flex', gap: 2 }}>
                <Button
                  variant="contained"
                  onClick={handleCancel}
                  sx={{
                    px: 3, py: 1, fontSize: 15, fontWeight: 500, fontFamily: 'Open Sans', textTransform: 'none',
                    color: '#fff', borderColor: '#D1D5DB', borderRadius: '16px',background:"#FF4141",
                    '&:hover': { borderColor: '#9CA3AF', backgroundColor: 'rgba(212, 39, 8, 1)' }
                  }}
                >
                  Cancel
                </Button>

                <Button
                  type="submit"
                  variant="contained"
                  sx={{
                    px: 3, py: 1, fontSize: 15, fontWeight: 600, fontFamily: 'Open Sans', textTransform: 'none',
                    backgroundColor: '#409BFF', borderRadius: '16px', boxShadow: 'none',
                    '&:hover': { backgroundColor: '#3380e8', boxShadow: 'none' }
                  }}
                >
                  {editMode ? 'Update' : 'Save'}
                </Button>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </form>

      {/* Success Dialog */}
      <Dialog open={successDialogOpen} disableScrollLock PaperProps={{ sx: { borderRadius: "12px", p: 2, minWidth: "400px" } }}>
        <DialogContent>
          <Box sx={{ textAlign: "center", py: 2 }}>
            <CheckCircleIcon style={{ width: 64, height: 64, color: "#409BFF", margin: "0 auto", display: "block" }} />
            <Typography sx={{ fontSize: 20, fontWeight: 700, color: "#111827", mt: 2, fontFamily: 'Open Sans' }}>
              {editMode ? 'Asset Updated Successfully!' : 'Asset Created Successfully!'}
            </Typography>
            <Typography sx={{ fontSize: 14, fontWeight: 400, color: "#6B7280", mt: 1, fontFamily: 'Open Sans' }}>
              {editMode ? 'Redirecting to asset details...' : 'Redirecting to asset management...'}
            </Typography>
          </Box>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default AddAssetsForm;
