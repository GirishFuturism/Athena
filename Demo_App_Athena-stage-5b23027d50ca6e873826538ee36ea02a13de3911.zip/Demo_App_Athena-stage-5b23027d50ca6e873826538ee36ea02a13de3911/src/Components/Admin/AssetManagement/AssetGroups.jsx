import React, { useState } from 'react';
import { Box, Typography, List, ListItem, ListItemButton, ListItemIcon, ListItemText } from '@mui/material';
import { 
  ComputerDesktopIcon,
  DevicePhoneMobileIcon,
  PrinterIcon,
  WifiIcon,
  PlusIcon,
  TrashIcon,
  PencilSquareIcon,
  ArrowUpTrayIcon,
  ArrowDownTrayIcon
} from '@heroicons/react/24/solid';
import { useNavigate } from 'react-router-dom';

const AssetGroups = () => {
  const [selectedAssetGroup, setSelectedAssetGroup] = useState('Laptop');
  const [selectedInventory, setSelectedInventory] = useState(null);
  const navigate = useNavigate();

  const assetGroups = [
    { id: 1, name: 'Laptop', icon: ComputerDesktopIcon },
    { id: 2, name: 'Mobile Device', icon: DevicePhoneMobileIcon },
    { id: 3, name: 'Printer', icon: PrinterIcon },
    { id: 4, name: 'Network Equipment', icon: WifiIcon }
  ];

  const inventoryItems = [
    { id: 1, name: 'Add Asset', icon: PlusIcon },
    { id: 2, name: 'Remove Asset', icon: TrashIcon },
    { id: 3, name: 'Edit Asset', icon: PencilSquareIcon },
    { id: 4, name: 'Import Assets', icon: ArrowUpTrayIcon },
    { id: 5, name: 'Export to CSV', icon: ArrowDownTrayIcon }
  ];

  const handleAssetGroupClick = (groupName) => {
    setSelectedAssetGroup(groupName);
    setSelectedInventory(null);
  };

  const handleInventoryClick = (itemName) => {
    setSelectedInventory(itemName);
    setSelectedAssetGroup(null);
    
    // Navigate to asset-form when Add Asset is clicked
    if (itemName === 'Add Asset') {
      navigate('/asset-form');
    } else {
      console.log(`${itemName} clicked`);
    }
  };

  return (
    <Box
      sx={{
        backgroundColor: '#FFFFFF',
        border: '1px solid #E5E7EB',
        borderRadius: '8px',
        p: 2.5,
        display: 'flex',
        flexDirection: 'column',
        height: '100%'
      }}
    >
      {/* Asset Groups Section */}
      <Typography
        sx={{
          fontFamily: 'Open Sans',
          fontSize: '14px',
          fontWeight: 700,
          color: '#9CA3AF',
          mb: 2,
          letterSpacing: '0.5px'
        }}
      >
        Asset Groups
      </Typography>

      <List sx={{ p: 0, mb: 3 }}>
        {assetGroups.map((group) => {
          const IconComponent = group.icon;
          const isSelected = selectedAssetGroup === group.name;
          
          return (
            <ListItem key={group.id} disablePadding sx={{ mb: 0.5 }}>
              <ListItemButton
                onClick={() => handleAssetGroupClick(group.name)}
                sx={{
                  borderRadius: '6px',
                  py: 1.25,
                  px: 2,
                  backgroundColor: isSelected ? '#EEF2FF' : 'transparent',
                  '&:hover': {
                    backgroundColor: isSelected ? '#EEF2FF' : '#F9FAFB'
                  }
                }}
              >
                <ListItemIcon sx={{ minWidth: 36 }}>
                  <IconComponent
                    style={{
                      width: 20,
                      height: 20,
                      color: isSelected ? '#409BFF' : '#374151',
                      strokeWidth: 2
                    }}
                  />
                </ListItemIcon>
                <ListItemText
                  primary={group.name}
                  primaryTypographyProps={{
                    sx: {
                      fontFamily: 'Open Sans',
                      fontSize: '15px',
                      fontWeight: 600,
                      color: isSelected ? '#409BFF' : '#374151'
                    }
                  }}
                />
              </ListItemButton>
            </ListItem>
          );
        })}
      </List>

      {/* Inventory Section */}
      <Typography
        sx={{
          fontFamily: 'Open Sans',
          fontSize: '14px',
          fontWeight: 700,
          color: '#9CA3AF',
          mb: 2,
          letterSpacing: '0.5px'
        }}
      >
        Inventory
      </Typography>

      <List sx={{ p: 0 }}>
        {inventoryItems.map((item) => {
          const IconComponent = item.icon;
          const isSelected = selectedInventory === item.name;
          
          return (
            <ListItem key={item.id} disablePadding sx={{ mb: 0.5 }}>
              <ListItemButton
                onClick={() => handleInventoryClick(item.name)}
                sx={{
                  borderRadius: '6px',
                  py: 1.25,
                  px: 2,
                  backgroundColor: isSelected ? '#EEF2FF' : 'transparent',
                  '&:hover': {
                    backgroundColor: isSelected ? '#EEF2FF' : '#F9FAFB'
                  }
                }}
              >
                <ListItemIcon sx={{ minWidth: 36 }}>
                  <IconComponent
                    style={{
                      width: 20,
                      height: 20,
                      color: isSelected ? '#409BFF' : '#374151',
                      strokeWidth: 2
                    }}
                  />
                </ListItemIcon>
                <ListItemText
                  primary={item.name}
                  primaryTypographyProps={{
                    sx: {
                      fontFamily: 'Open Sans',
                      fontSize: '15px',
                      fontWeight: 600,
                      color: '#374151'
                    }
                  }}
                />
              </ListItemButton>
            </ListItem>
          );
        })}
      </List>
    </Box>
  );
};

export default AssetGroups;
