import React, { useState, useRef } from 'react';
import TitleBreadcrumb from "../../Shared/TitleBreadcrumb";
import { Grid, Box, Typography, Button, IconButton } from "@mui/material";
import { 
  HomeIcon, 
  PlusIcon, 
  RectangleGroupIcon,
  ArrowPathIcon,
  ArrowDownTrayIcon,
  EllipsisHorizontalIcon
} from '@heroicons/react/24/solid';
import AssetGroups from './AssetGroups';
import AssetListGrid from './AssetListGrid';
import { useNavigate } from 'react-router-dom';

const AssetManagementLayout = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [selectedCount, setSelectedCount] = useState(0);
  const assetListGridRef = useRef();

  // Refresh handler - triggers refresh in child component
  const handleRefresh = async () => {
    setLoading(true);
    
    try {
      setTimeout(() => {
        if (assetListGridRef.current) {
          assetListGridRef.current.handleRefresh();
        }
        setLoading(false);
      }, 300);
    } catch (error) {
      console.error("Error refreshing data:", error);
      setLoading(false);
    }
  };

  // Download handler - triggers download in child component
  const handleDownload = () => {
    if (assetListGridRef.current) {
      assetListGridRef.current.handleDownload();
    }
  };

  return (
    <>
      <Grid
        container
        spacing={{ xs: 1, md: 2 }}
        columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{
          width: "100%",
          maxWidth: "100vw",
          m: 0,
          p: { xs: 0, sm: 1 },
          justifyContent: "center",
          flexGrow: 1,
        }}
      >
        <Grid
          item
          size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{
            border: "1px solid #E4E4E7",
            backgroundColor: "#fff",
            px: { xs: 1, sm: 4, md: 6, xl: 3 },
            py: { xs: 0, sm: 3 },
            boxShadow: { xs: "none", sm: "0 2px 14px rgba(116,185,255,.08)" },
          }}
        >
          {/* Breadcrumb */}
          <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
            <HomeIcon 
              style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8, cursor:"pointer" }} 
              onClick={() => navigate("/admin")}
            />
            <TitleBreadcrumb 
              breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin" }, 
                { type: "text", label: "Asset Management", to: "" }
              ]} 
            />
          </Box>

          {/* Header with Title and Action Buttons */}
          <Box 
            sx={{ 
              mt: 2, 
              pt: 1, 
              pb: 1,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: 2
            }}
          >
            <Typography 
              sx={{ 
                fontFamily: "Open Sans", 
                fontSize: "24px", 
                fontWeight: "700", 
                color: "#111827" 
              }}
            >
              Assets Management
            </Typography>

            {/* Action Buttons */}
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              {/* Add Assets Button */}
              <Button
                startIcon={<PlusIcon style={{ width: 18, height: 18 }} />}
                onClick={() => navigate("/asset-form")}
                sx={{
                  backgroundColor: '#409BFF',
                  color: '#FFFFFF',
                  fontFamily: 'Open Sans',
                  fontSize: '14px',
                  fontWeight: 600,
                  textTransform: 'none',
                  px: 2.5,
                  py: 1,
                  borderRadius: '6px',
                  boxShadow: 'none',
                  '&:hover': {
                    backgroundColor: '#2563EB',
                    boxShadow: 'none'
                  }
                }}
              >
                Add Assets
              </Button>

              {/* Create Assets Group Button */}
              <Button
                startIcon={<PlusIcon style={{ width: 18, height: 18 }} />}
                onClick={() => navigate("/asset-group")}
                sx={{
                  backgroundColor: '#409BFF',
                  color: '#FFFFFF',
                  fontFamily: 'Open Sans',
                  fontSize: '14px',
                  fontWeight: 600,
                  textTransform: 'none',
                  px: 2.5,
                  py: 1,
                  borderRadius: '6px',
                  boxShadow: 'none',
                  '&:hover': {
                    backgroundColor: '#2563EB',
                    boxShadow: 'none'
                  }
                }}
              >
                Create Assets Group
              </Button>

              {/* Refresh Icon Button */}
              <IconButton
                onClick={handleRefresh}
                disabled={loading}
                sx={{
                  backgroundColor: loading ? '#93c5fd' : '#409BFF',
                  color: '#FFFFFF',
                  width: 38,
                  height: 38,
                  borderRadius: '6px',
                  transition: "transform 0.3s ease",
                  animation: loading ? "spin 1s linear infinite" : "none",
                  "@keyframes spin": {
                    "0%": { transform: "rotate(0deg)" },
                    "100%": { transform: "rotate(360deg)" },
                  },
                  '&:hover': {
                    backgroundColor: '#2563EB'
                  }
                }}
              >
                <ArrowPathIcon style={{ width: 18, height: 18 }} />
              </IconButton>

              {/* Download Icon Button - Disabled when no selection */}
              <IconButton
                onClick={handleDownload}
                disabled={selectedCount === 0}
                sx={{
                  backgroundColor: selectedCount === 0 ? '#D1D5DB' : '#409BFF',
                  color: '#FFFFFF',
                  width: 38,
                  height: 38,
                  borderRadius: '6px',
                  cursor: selectedCount === 0 ? 'not-allowed' : 'pointer',
                  '&:hover': {
                    backgroundColor: selectedCount === 0 ? '#D1D5DB' : '#2563EB'
                  },
                  '&:disabled': {
                    backgroundColor: '#D1D5DB',
                    color: '#9CA3AF'
                  }
                }}
              >
                <ArrowDownTrayIcon style={{ width: 18, height: 18 }} />
              </IconButton>

              {/* More Options (Three Dots) Icon Button */}
              <IconButton
                sx={{
                  backgroundColor: '#409BFF',
                  color: '#FFFFFF',
                  width: 38,
                  height: 38,
                  borderRadius: '6px',
                  '&:hover': {
                    backgroundColor: '#2563EB'
                  }
                }}
              >
                <EllipsisHorizontalIcon style={{ width: 18, height: 18 }} />
              </IconButton>
            </Box>
          </Box>

          <Box sx={{ mt: 3, mb: 2, width: "100%" }}>
            {/* First Row */}
            <Grid container spacing={1}>
              <Grid item size={{ xs: 12, sm: 12, md: 2.6 }}>
                <AssetGroups />
              </Grid>
              <Grid item size={{ xs: 12, sm: 12, md: 9.4 }}>
                <AssetListGrid 
                  ref={assetListGridRef} 
                  onSelectionChange={setSelectedCount}
                />
              </Grid>
            </Grid>
          </Box>
        </Grid>
      </Grid>
    </>
  );
};

export default AssetManagementLayout;
