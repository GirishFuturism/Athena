import React from 'react';
import { Box, Typography, Grid } from '@mui/material';

// ✅ ASSET SPECIFICATIONS BY TYPE
const assetSpecifications = {
  'Laptop': {
    basicInfo: [
      { label: 'Asset Type:', value: 'Laptop' },
      { label: 'Manufacturer:', value: 'Dell' },
      { label: 'Model:', value: 'Latitude 7420' },
      { label: 'Serial Number:', value: 'DL7420-2023-001' },
      { label: 'Purchase Date:', value: '2023-03-15' }
    ],
    specifications: [
      { label: 'Processor:', value: 'Intel Core i7-1165G7' },
      { label: 'RAM:', value: '16GB DDR4' },
      { label: 'Storage:', value: '512GB SSD' },
      { label: 'Operating System:', value: 'Windows 11 Pro' },
      { label: 'Display:', value: '14" FHD' },
      { label: 'Battery:', value: '4 Cell 63Wh' }
    ]
  },
  'Desktop Computer': {
    basicInfo: [
      { label: 'Asset Type:', value: 'Desktop Computer' },
      { label: 'Manufacturer:', value: 'HP' },
      { label: 'Model:', value: 'EliteDesk 800 G6' },
      { label: 'Serial Number:', value: 'HP-ED800-2023-001' },
      { label: 'Purchase Date:', value: '2023-02-10' }
    ],
    specifications: [
      { label: 'Processor:', value: 'Intel Core i9-10900K' },
      { label: 'RAM:', value: '32GB DDR4' },
      { label: 'Storage:', value: '1TB NVMe SSD' },
      { label: 'Operating System:', value: 'Windows 11 Pro' },
      { label: 'Display:', value: '27" 4K Monitor' },
      { label: 'Power Supply:', value: '800W' }
    ]
  },
  'Tablet': {
    basicInfo: [
      { label: 'Asset Type:', value: 'Tablet' },
      { label: 'Manufacturer:', value: 'Apple' },
      { label: 'Model:', value: 'iPad Pro 12.9"' },
      { label: 'Serial Number:', value: 'IPAD-PRO-2023-001' },
      { label: 'Purchase Date:', value: '2023-04-20' }
    ],
    specifications: [
      { label: 'Processor:', value: 'Apple M2' },
      { label: 'RAM:', value: '8GB' },
      { label: 'Storage:', value: '256GB' },
      { label: 'Operating System:', value: 'iPadOS 17' },
      { label: 'Display:', value: '12.9" Liquid Retina' },
      { label: 'Battery:', value: '10000mAh' }
    ]
  },
  'Smartphone': {
    basicInfo: [
      { label: 'Asset Type:', value: 'Smartphone' },
      { label: 'Manufacturer:', value: 'Apple' },
      { label: 'Model:', value: 'iPhone 14 Pro' },
      { label: 'Serial Number:', value: 'IPHONE-14P-2023-001' },
      { label: 'Purchase Date:', value: '2023-01-15' }
    ],
    specifications: [
      { label: 'Processor:', value: 'Apple A16 Bionic' },
      { label: 'RAM:', value: '6GB' },
      { label: 'Storage:', value: '128GB' },
      { label: 'Operating System:', value: 'iOS 17' },
      { label: 'Display:', value: '6.1" Super Retina XDR' },
      { label: 'Camera:', value: '12MP + 12MP' }
    ]
  },
  'Workstation': {
    basicInfo: [
      { label: 'Asset Type:', value: 'Workstation' },
      { label: 'Manufacturer:', value: 'Lenovo' },
      { label: 'Model:', value: 'ThinkStation P3' },
      { label: 'Serial Number:', value: 'WORKSTATION-P3-2023' },
      { label: 'Purchase Date:', value: '2023-05-12' }
    ],
    specifications: [
      { label: 'Processor:', value: 'Intel Xeon W5-2435W' },
      { label: 'RAM:', value: '64GB DDR5' },
      { label: 'Storage:', value: '2TB NVMe SSD' },
      { label: 'Operating System:', value: 'Windows 11 Professional' },
    //   { label: 'GPU:', value: 'NVIDIA RTX 6000 Ada' },
      { label: 'Power Supply:', value: '1600W' }
    ]
  }
};

const AssetInformation = ({ 
  warranty = '3 Years',
  assetType = 'Laptop',
  assetId = 'KL-LAP-1',
  customer = 'Customer Name',
  site = 'Location'
}) => {
  // ✅ GET SPECS FOR CURRENT ASSET TYPE
  const specs = assetSpecifications[assetType] || assetSpecifications['Laptop'];

  const assignment = [
    { label: 'Assigned To:', value: "John Smith" },
    { label: 'Department:', value: 'IT Department' },
    { label: 'Location:', value: site },
    { label: 'Assignment Date:', value: '2023-03-20' }
  ];

  const specifications = [...specs.specifications, { label: 'Warranty:', value: warranty }];

  const InfoItem = ({ label, value }) => (
    <Box 
      sx={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        mb: 1.75,
        gap: 4
      }}
    >
      <Typography
        sx={{
          fontFamily: 'Open Sans',
          fontSize: '16px',
          fontWeight: 400,
          color: '#6B7280',
          whiteSpace: 'nowrap'
        }}
      >
        {label}
      </Typography>
      <Typography
        sx={{
          fontFamily: 'Open Sans',
          fontSize: '16px',
          fontWeight: 600,
          color: '#111827',
          textAlign: 'right'
        }}
      >
        {value}
      </Typography>
    </Box>
  );

  return (
    <Box
      sx={{
        backgroundColor: '#fff',
        border: '1px solid #E5E7EB',
        borderRadius: '12px',
        p: 3.5
      }}
    >
      {/* Top Section: Basic Information & Assignment */}
      <Grid container sx={{ display: "flex", justifyContent: "space-between" }}>
        {/* Basic Information Column */}
        <Grid item xs={12} md={6}>
          <Typography
            sx={{
              fontFamily: 'Open Sans',
              fontSize: '18px',
              fontWeight: 700,
              color: '#111827',
              mb: 2.5
            }}
          >
            Basic Information
          </Typography>
          {specs.basicInfo.map((item, index) => (
            <InfoItem key={index} label={item.label} value={item.value} />
          ))}
        </Grid>

        {/* Assignment Column */}
        <Grid item xs={12} md={6}>
          <Typography
            sx={{
              fontFamily: 'Open Sans',
              fontSize: '18px',
              fontWeight: 700,
              color: '#111827',
              mb: 2.5,
            }}
          >
            Assignment
          </Typography>
          {assignment.map((item, index) => (
            <InfoItem key={index} label={item.label} value={item.value} />
          ))}
        </Grid>
      </Grid>

      {/* Specifications Section - Full Width */}
      <Box sx={{ mt: 4 }}>
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '18px',
            fontWeight: 700,
            color: '#111827',
            mb: 2.5
          }}
        >
          Specifications
        </Typography>
        
        <Grid container sx={{ display: "flex", justifyContent: "space-between" }}>
          {/* Left Column of Specifications */}
          <Grid item xs={12} md={6}>
            {specifications.slice(0, 3).map((item, index) => (
              <InfoItem key={index} label={item.label} value={item.value} />
            ))}
          </Grid>

          {/* Right Column of Specifications */}
          <Grid item xs={12} md={6}>
            {specifications.slice(3).map((item, index) => (
              <InfoItem key={index} label={item.label} value={item.value} />
            ))}
          </Grid>
        </Grid>
      </Box>
    </Box>
  );
};

export default AssetInformation;
