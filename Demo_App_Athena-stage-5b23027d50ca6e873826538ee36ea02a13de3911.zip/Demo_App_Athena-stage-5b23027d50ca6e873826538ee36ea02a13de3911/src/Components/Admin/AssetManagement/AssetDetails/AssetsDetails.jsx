import React, { useState, useRef } from 'react';
import TitleBreadcrumb from "../../../Shared/TitleBreadcrumb";
import { Grid, Box, Typography, Button, IconButton } from "@mui/material";
import { 
  HomeIcon,
  PencilSquareIcon,
  DocumentDuplicateIcon,
  BookmarkIcon,
  DocumentTextIcon,
  ShieldCheckIcon,
  TrashIcon,
  ComputerDesktopIcon,
  TicketIcon
} from '@heroicons/react/24/solid';
import { useNavigate, useLocation } from 'react-router-dom';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import StatCard from './StatCard';
import QuickActions from './QuickActions';
import RecentActivity from './RecentActivity';
import AssetInformation from './AssetInformation';
import DeleteAssetDialog from './DeleteAssetDialog';
import WarrantyDialog from './WarrantyDialog';

const AssetsDetails = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [warrantyDialogOpen, setWarrantyDialogOpen] = useState(false); 
  const [warranty, setWarranty] = useState('3 Years');
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  
  // Ref for main content
  const mainContentRef = useRef(null);

  const selectedAsset = location.state?.selectedAsset || {
    id: 'KL-LAP-1',
    assetsNumber: 'LAPTOP-001',
    assetsType: 'Laptop',
    customer: 'John Smith',
    site: 'Office Floor 3',
    user: 'John Smith',
  };

  const handleEdit = () => {
    navigate('/asset-form', { 
      state: { 
        editMode: true,
        assetData: selectedAsset 
      } 
    });
  };

  const handleWarrantySave = (warrantyData) => {
    console.log("Warranty saved:", warrantyData);
    setWarranty(warrantyData.warranty);
  };

  // PDF Generation Function - Creates invisible clone
  const handleGeneratePDF = async () => {
    setIsGeneratingPDF(true);
    
    try {
      // Create a clone of the main content
      const originalElement = mainContentRef.current;
      const clonedElement = originalElement.cloneNode(true);
      
      // Style the clone to be invisible but rendered
      clonedElement.style.position = 'fixed';
      clonedElement.style.left = '-9999px';
      clonedElement.style.top = '0';
      clonedElement.style.width = originalElement.offsetWidth + 'px';
      clonedElement.style.backgroundColor = '#ffffff';
      
      // Remove elements that shouldn't be in PDF from clone
      const elementsToRemove = clonedElement.querySelectorAll('.hide-in-pdf');
      elementsToRemove.forEach(el => el.remove());
      
      // Append clone to body
      document.body.appendChild(clonedElement);
      
      // Wait for rendering
      await new Promise(resolve => setTimeout(resolve, 100));
      
      // Generate canvas from the cloned content
      const canvas = await html2canvas(clonedElement, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
        windowWidth: clonedElement.scrollWidth,
        windowHeight: clonedElement.scrollHeight
      });

      // Remove the clone
      document.body.removeChild(clonedElement);

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const imgWidth = 210; // A4 width in mm
      const pageHeight = 297; // A4 height in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      // Add first page
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      // Add more pages if content exceeds one page
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      // Save the PDF
      pdf.save(`Asset_${selectedAsset.assetsNumber}_${new Date().toISOString().split('T')[0]}.pdf`);

    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Failed to generate PDF. Please try again.');
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  const getAssetIcon = (assetType) => {
    const iconMap = {
      'Laptop': ComputerDesktopIcon,
      'Desktop Computer': ComputerDesktopIcon,
      'Tablet': ComputerDesktopIcon,
      'Smartphone': ComputerDesktopIcon,
      'Workstation': ComputerDesktopIcon,
      'Smartwatch': ComputerDesktopIcon,
      'E-reader': ComputerDesktopIcon,
    };
    return iconMap[assetType] || ComputerDesktopIcon;
  };

  const AssetIcon = getAssetIcon(selectedAsset.assetsType);

  return (
    <>
      <Grid
        container
        spacing={{ xs: 1, md: 2 }}
        columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{
          width: "100%",
          maxWidth: "100vw",
          m: 0,
          p: { xs: 0, sm: 1 },
          justifyContent: "center",
          flexGrow: 1,
        }}
      >
        <Grid
          item
          size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{
            border: "1px solid #E4E4E7",
            backgroundColor: "#fff",
            px: { xs: 1, sm: 4, md: 6, xl: 3 },
            py: { xs: 0, sm: 3 },
            boxShadow: { xs: "none", sm: "0 2px 14px rgba(116,185,255,.08)" },
          }}
        >
          {/* Breadcrumb */}
          <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
            <HomeIcon style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8,cursor:"pointer" }} onClick={() => navigate("/admin")}/>
            <TitleBreadcrumb 
              breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin" }, 
                { type: "link", label: "Asset Management", to: "/asset-management" },
                { type: "text", label: "Assets Details", to: "" }
              ]} 
            />
          </Box>

          {/* Main Content Wrapper - This gets cloned for PDF */}
          <div ref={mainContentRef}>
            {/* Asset Header Section */}
            <Box 
              sx={{ 
                mt: 3, 
                mb: 3,
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                flexWrap: 'wrap',
                gap: 2
              }}
            >
              {/* Left Side - Asset Info */}
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                <Box
                  sx={{
                    width: 48,
                    height: 48,
                    borderRadius: '8px',
                    backgroundColor: '#409BFF',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    mb: 2
                  }}
                >
                  <AssetIcon style={{ width: 24, height: 24, color: '#FFFFFF' }} />
                </Box>
                
                <Box>
                  <Typography 
                    sx={{ 
                      fontFamily: "Open Sans", 
                      fontSize: "24px", 
                      fontWeight: "700", 
                      color: "#111827",
                    }}
                  >
                    {selectedAsset.assetsType}
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: "column" }}>
                    <Typography 
                      sx={{ 
                        fontFamily: "Open Sans", 
                        fontSize: "14px", 
                        fontWeight: "400", 
                        color: "#4B5563"
                      }}
                    >
                      Asset Tag: {selectedAsset.assetsNumber}
                    </Typography>
                    <Typography 
                      sx={{ 
                        fontFamily: "Open Sans", 
                        fontSize: "14px", 
                        fontWeight: "400", 
                        color: "#4B5563"
                      }}
                    >
                      Serial: {selectedAsset.serialNumber || 'DL7420-2023-001'}
                    </Typography>
                  </Box>
                </Box>
              </Box>

              {/* Right Side - Action Buttons - These will be removed in PDF */}
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }} className="hide-in-pdf">
                <Button
                  startIcon={<PencilSquareIcon style={{ width: 16, height: 16 }} />}
                  onClick={handleEdit}
                  sx={{
                    backgroundColor: '#409BFF',
                    color: '#FFFFFF',
                    fontFamily: 'Open Sans',
                    fontSize: '14px',
                    fontWeight: 600,
                    textTransform: 'none',
                    px: 2.5,
                    py: 0.8,
                    borderRadius: '16px',
                    boxShadow: 'none',
                    minHeight: '36px',
                    '&:hover': {
                      backgroundColor: '#2563EB',
                      boxShadow: 'none'
                    }
                  }}
                >
                  Edit
                </Button>

                <Button
                  startIcon={<DocumentDuplicateIcon style={{ width: 16, height: 16 }} />}
                  sx={{
                    backgroundColor: '#409BFF',
                    color: '#FFFFFF',
                    fontFamily: 'Open Sans',
                    fontSize: '14px',
                    fontWeight: 600,
                    textTransform: 'none',
                    px: 2.5,
                    py: 0.8,
                    borderRadius: '16px',
                    boxShadow: 'none',
                    minHeight: '36px',
                    '&:hover': {
                      backgroundColor: '#2563EB',
                      boxShadow: 'none'
                    }
                  }}
                >
                  Clone
                </Button>

                <Button
                  startIcon={<BookmarkIcon style={{ width: 16, height: 16 }} />}
                  sx={{
                    backgroundColor: '#409BFF',
                    color: '#FFFFFF',
                    fontFamily: 'Open Sans',
                    fontSize: '14px',
                    fontWeight: 600,
                    textTransform: 'none',
                    px: 2.5,
                    py: 0.8,
                    borderRadius: '16px',
                    boxShadow: 'none',
                    minHeight: '36px',
                    '&:hover': {
                      backgroundColor: '#2563EB',
                      boxShadow: 'none'
                    }
                  }}
                >
                  Bookmark
                </Button>

                <Button
                  startIcon={<DocumentTextIcon style={{ width: 16, height: 16 }} />}
                  onClick={handleGeneratePDF}
                  disabled={isGeneratingPDF}
                  sx={{
                    backgroundColor: '#409BFF',
                    color: '#FFFFFF',
                    fontFamily: 'Open Sans',
                    fontSize: '14px',
                    fontWeight: 600,
                    textTransform: 'none',
                    px: 2.5,
                    py: 0.8,
                    borderRadius: '16px',
                    boxShadow: 'none',
                    minHeight: '36px',
                    '&:hover': {
                      backgroundColor: '#2563EB',
                      boxShadow: 'none'
                    },
                    '&:disabled': {
                      backgroundColor: '#94A3B8',
                      color: '#FFFFFF'
                    }
                  }}
                >
                  {isGeneratingPDF ? 'Generating...' : 'Generate PDF'}
                </Button>

                <Button
                  startIcon={<ShieldCheckIcon style={{ width: 16, height: 16 }} />}
                  onClick={() => setWarrantyDialogOpen(true)}
                  sx={{
                    backgroundColor: '#409BFF',
                    color: '#FFFFFF',
                    fontFamily: 'Open Sans',
                    fontSize: '14px',
                    fontWeight: 600,
                    textTransform: 'none',
                    px: 2.5,
                    py: 0.8,
                    borderRadius: '16px',
                    boxShadow: 'none',
                    minHeight: '36px',
                    '&:hover': {
                      backgroundColor: '#2563EB',
                      boxShadow: 'none'
                    }
                  }}
                >
                  Start Warranty
                </Button>

                <Button
                  startIcon={<TrashIcon style={{ width: 16, height: 16 }} />}
                  onClick={() => setDeleteDialogOpen(true)}
                  sx={{
                    backgroundColor: '#FFFFFF',
                    color: '#FF0202',
                    border: '1px solid #FF0202',
                    fontFamily: 'Open Sans',
                    fontSize: '14px',
                    fontWeight: 600,
                    textTransform: 'none',
                    px: 2.5,
                    py: 0.8,
                    borderRadius: '16px',
                    boxShadow: 'none',
                    minHeight: '36px',
                    '&:hover': {
                      backgroundColor: '#FEF2F2',
                      border: '1px solid #FF0202',
                      boxShadow: 'none'
                    }
                  }}
                >
                  Unassigned
                </Button>
              </Box>
            </Box>

            {/* Content Area with Proper Grid Layout */}
            <Box sx={{ mt: 3, mb: 2, width: "100%" }}>
              <Grid container spacing={1}>
                {/* Left Column - 9.2 width total */}
                <Grid item size={{ xs: 12, sm: 12, md: 9.2 }}>
                  <Grid container spacing={1}>
                    {/* First 4 stat cards in a row */}
                    <Grid item size={{ xs: 12, sm: 6, md: 3 }}>
                      <StatCard 
                        icon={TicketIcon}
                        label="Active Tickets"
                        count="1"
                        iconBgColor="#409BFF"
                      />
                    </Grid>

                    <Grid item size={{ xs: 12, sm: 6, md: 3 }}>
                      <StatCard 
                        icon={TicketIcon}
                        label="Total Tickets"
                        count="2"
                        iconBgColor="#409BFF"
                      />
                    </Grid>

                    <Grid item size={{ xs: 12, sm: 6, md: 3 }}>
                      <StatCard 
                        icon={TicketIcon}
                        label="Close in last 30 days"
                        count="2"
                        iconBgColor="#409BFF"
                      />
                    </Grid>

                    <Grid item size={{ xs: 12, sm: 6, md: 3 }}>
                      <StatCard 
                        icon={TicketIcon}
                        label="Open in last 30 days"
                        count="4"
                        iconBgColor="#409BFF"
                      />
                    </Grid>

                    {/* Bottom full-width box below the 4 boxes */}
                    <Grid item size={{ xs: 12, sm: 12, md: 12 }}>
                      <AssetInformation 
                        warranty={warranty} 
                        assetType={selectedAsset.assetsType}
                        assetId={selectedAsset.id}
                        customer={selectedAsset.customer}
                        site={selectedAsset.site}
                      />
                    </Grid>
                  </Grid>
                </Grid>

                {/* Right side column - Quick Actions & Recent Activity - Hidden in PDF */}
                <Grid item size={{ xs: 12, sm: 12, md: 2.8 }} className="hide-in-pdf">
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                    <QuickActions />
                    <RecentActivity userName={selectedAsset.user} />
                  </Box>
                </Grid>

                {/* 2 bottom boxes - Ticket/Issue Cards */}
                <Grid item size={{ xs: 12, sm: 12, md: 12 }}>
                  {/* Ticket Card 1 */}
                  <Box
                    sx={{
                      backgroundColor: '#FFFFFF',
                      border: '1px solid #E5E7EB',
                      borderRadius: '12px',
                      p: 3,
                      mb: 2
                    }}
                  >
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 1.5 }}>
                      <Box sx={{ display: "flex", gap: 4 }}>
                        <Typography
                          sx={{
                            fontFamily: 'Open Sans',
                            fontSize: '18px',
                            fontWeight: 700,
                            color: '#111827',
                            mb: 0.5
                          }}
                        >
                          2182
                        </Typography>
                        <Typography
                          sx={{
                            fontFamily: 'Open Sans',
                            fontSize: '14px',
                            fontWeight: 400,
                            color: '#6B7280',
                            mt: 0.5
                          }}
                        >
                          9/17/2025 23:02
                        </Typography>
                      </Box>
                    </Box>

                    <Box sx={{ display: 'flex', gap: 1, mb: 1.5, mr: 1 }}>
                      <Box
                        sx={{
                          backgroundColor: '#FFD8E4',
                          color: '#A20606',
                          px: 2,
                          py: 0.5,
                          borderRadius: '16px'
                        }}
                      >
                        <Typography
                          sx={{
                            fontFamily: 'Open Sans',
                            fontSize: '13px',
                            fontWeight: 600,
                            color: '#A20606'
                          }}
                        >
                          Closed
                        </Typography>
                      </Box>
                    </Box>
                    <Typography
                      sx={{
                        fontFamily: 'Open Sans',
                        fontSize: '16px',
                        fontWeight: 600,
                        color: '#374151',
                        lineHeight: 1.6
                      }}
                    >
                      My laptop just gets to the HP screen when starting and the restarts repeatedly.
                    </Typography>
                  </Box>

                  {/* Ticket Card 2 */}
                  <Box
                    sx={{
                      backgroundColor: '#FFFFFF',
                      border: '1px solid #E5E7EB',
                      borderRadius: '12px',
                      p: 3
                    }}
                  >
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 1.5 }}>
                      <Box sx={{ display: "flex", gap: 4 }}>
                        <Typography
                          sx={{
                            fontFamily: 'Open Sans',
                            fontSize: '18px',
                            fontWeight: 700,
                            color: '#111827',
                            mb: 0.5,
                          }}
                        >
                          2189
                        </Typography>
                        <Typography
                          sx={{
                            fontFamily: 'Open Sans',
                            fontSize: '14px',
                            fontWeight: 400,
                            color: '#6B7280',
                            mt: 0.4
                          }}
                        >
                          10/25/2025 23:02
                        </Typography>
                      </Box>
                    </Box>
                    <Box sx={{ display: 'flex', gap: 1, mb: 1.5, mr: 1 }}>
                      <Box
                        sx={{
                          backgroundColor: '#DCFCE7',
                          color: '#0C4A6E',
                          px: 2,
                          py: 0.5,
                          borderRadius: '16px'
                        }}
                      >
                        <Typography
                          sx={{
                            fontFamily: 'Open Sans',
                            fontSize: '13px',
                            fontWeight: 600,
                            color: '#066A1B'
                          }}
                        >
                          Opened
                        </Typography>
                      </Box>
                      <Box
                        sx={{
                          backgroundColor: '#F3F4F6',
                          color: '#065F46',
                          px: 2,
                          py: 0.5,
                          borderRadius: '16px'
                        }}
                      >
                        <Typography
                          sx={{
                            fontFamily: 'Open Sans',
                            fontSize: '13px',
                            fontWeight: 600,
                            color: '#1F2937'
                          }}
                        >
                          New
                        </Typography>
                      </Box>
                    </Box>

                    <Typography
                      sx={{
                        fontFamily: 'Open Sans',
                        fontSize: '16px',
                        fontWeight: 600,
                        color: '#374151',
                        lineHeight: 1.6
                      }}
                    >
                      My laptop just gets to the HP screen when starting and the restarts repeatedly.
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </div>
        </Grid>
      </Grid>

      <DeleteAssetDialog 
        disableScrollLock
        open={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
        assetName={selectedAsset.id}
      />

      <WarrantyDialog
        disableScrollLock
        open={warrantyDialogOpen}
        onClose={() => setWarrantyDialogOpen(false)}
        onSave={handleWarrantySave}
      />
    </>
  );
};

export default AssetsDetails;
