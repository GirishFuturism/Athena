import React from 'react';
import { Box, Typography, List, ListItem, ListItemText } from '@mui/material';

const RecentActivity = () => {
  const activities = [
    { 
      id: 1, 
      title: 'Asset assigned to John Smith', 
      time: '2 hours ago',
      dotColor: '#409BFF'
    },
    { 
      id: 2, 
      title: 'Maintenance completed', 
      time: '1 day ago',
      dotColor: '#10B981'
    },
    { 
      id: 3, 
      title: 'Status updated to Active', 
      time: '3 days ago',
      dotColor: '#F59E0B'
    }
  ];

  return (
    <Box
      sx={{
        backgroundColor: '#FFFFFF',
        border: '1px solid #E5E7EB',
        borderRadius: '12px',
        p: 2,
        // height: '100%'
      }}
    >
      <Typography
        sx={{
          fontFamily: 'Open Sans',
          fontSize: '18px',
          fontWeight: 700,
          color: '#111827',
          mb: 2
        }}
      >
        Recent Activity
      </Typography>

      <List sx={{ p: 0 }}>
        {activities.map((activity, index) => (
          <ListItem 
            key={activity.id} 
            sx={{ 
              px: 0, 
              py: 1.5,
              borderBottom: index < activities.length - 1 ? '1px solid #F3F4F6' : 'none',
              display: 'flex',
              alignItems: 'flex-start',
              gap: 1.5
            }}
          >
            {/* Colored Dot */}
            <Box
              sx={{
                width: 8,
                height: 8,
                borderRadius: '50%',
                backgroundColor: activity.dotColor,
                mt: 1.5,
                flexShrink: 0
              }}
            />

            {/* Text Content */}
            <ListItemText
              primary={activity.title}
              secondary={activity.time}
              primaryTypographyProps={{
                sx: {
                  fontFamily: 'Open Sans',
                  fontSize: '14px',
                  fontWeight: 600,
                  color: '#111827',
                  mb: 0.3
                }
              }}
              secondaryTypographyProps={{
                sx: {
                  fontFamily: 'Open Sans',
                //   fontSize: '12px',
                  fontWeight: 400,
                  color: '#6B7280'
                }
              }}
            />
          </ListItem>
        ))}
      </List>
    </Box>
  );
};

export default RecentActivity;
