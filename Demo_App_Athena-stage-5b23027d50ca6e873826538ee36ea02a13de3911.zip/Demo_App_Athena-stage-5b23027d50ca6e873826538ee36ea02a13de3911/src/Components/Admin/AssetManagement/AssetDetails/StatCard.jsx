import React from 'react';
import { Box, Typography } from '@mui/material';

const StatCard = ({ icon: Icon, label, count, iconBgColor = '#409BFF' }) => {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        py: 2,
        px: 1.5,
        borderRadius: "12px",
        background: "#fff",
        border: "1px solid #E5E7EB",
        boxSizing: "border-box",
        // minHeight: "90px",
        transition: 'box-shadow 0.3s cubic-bezier(0.4, 0, 0.2, 1), transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.3s cubic-bezier(0.4, 0, 0.2, 1)', // ✅ Smooth transition
        '&:hover': { 
          boxShadow: '0 8px 24px rgba(67, 144, 248, 0.2)',
          transform: 'translateY(-4px)',
          borderColor: '#4390F8',
        }
      }}
    >
      <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 0.5 }}>
        <Box 
          sx={{ 
            color: iconBgColor,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <Icon style={{ width: 24, height: 24 }} />
        </Box>
        <Typography 
          sx={{ 
            fontSize: "15px", 
            fontWeight: "500", 
            color: "#4B5563", 
            fontFamily: "Open Sans" 
          }}
        >
          {label}
        </Typography>
      </Box>
      <Typography 
        sx={{ 
          fontWeight: 700, 
          fontSize: "30px", 
          color: "#111827", 
          fontFamily: "Open Sans" 
        }}
      >
        {count}
      </Typography>
    </Box>
  );
};

export default StatCard;
