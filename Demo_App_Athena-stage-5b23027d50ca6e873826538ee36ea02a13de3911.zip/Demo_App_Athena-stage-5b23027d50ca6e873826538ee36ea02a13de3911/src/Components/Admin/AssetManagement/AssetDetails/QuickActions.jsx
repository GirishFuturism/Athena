import React from 'react';
import { Box, Typography, List, ListItem, ListItemButton, ListItemIcon, ListItemText } from '@mui/material';
import { TicketIcon, UserPlusIcon, WrenchIcon } from '@heroicons/react/24/solid';
import { useNavigate } from 'react-router-dom'; // ✅ Import useNavigate

const QuickActions = () => {
  const navigate = useNavigate(); // ✅ Initialize navigate

  const actions = [
    { id: 1, label: 'Create Ticket', icon: TicketIcon, color: '#409BFF', route: '/new-ticket' }, // ✅ Added route
    { id: 2, label: 'Reassign Asset', icon: UserPlusIcon, color: '#10B981', route: null },
    { id: 3, label: 'Schedule Maintenance', icon: WrenchIcon, color: '#F59E0B', route: null }
  ];

  // ✅ Handle click navigation
  const handleActionClick = (route) => {
    if (route) {
      navigate(route);
    }
  };

  return (
    <Box
      sx={{
        backgroundColor: '#FFFFFF',
        border: '1px solid #E5E7EB',
        borderRadius: '12px',
        p: 2,
        height: '100%'
      }}
    >
      <Typography
        sx={{
          fontFamily: 'Open Sans',
          fontSize: '18px',
          fontWeight: 700,
          color: '#111827',
          mb: 2
        }}
      >
        Quick Actions
      </Typography>

      <List sx={{ p: 0 }}>
        {actions.map((action) => {
          const IconComponent = action.icon;
          return (
            <ListItem key={action.id} disablePadding sx={{ mb: 1 }}>
              <ListItemButton
                onClick={() => handleActionClick(action.route)} // ✅ Added onClick
                sx={{
                  borderRadius: '8px',
                  border: '1px solid #E5E7EB',
                  py: 1.5,
                  px: 2,
                  backgroundColor: '#FFFFFF',
                  cursor: action.route ? 'pointer' : 'default', // ✅ Cursor based on route
                  '&:hover': {
                    backgroundColor: '#F9FAFB',
                    borderColor: '#D1D5DB'
                  }
                }}
              >
                <ListItemIcon sx={{ minWidth: 36 }}>
                  <IconComponent
                    style={{
                      width: 20,
                      height: 20,
                      color: action.color
                    }}
                  />
                </ListItemIcon>
                <ListItemText
                  primary={action.label}
                  primaryTypographyProps={{
                    sx: {
                      fontFamily: 'Open Sans',
                      fontSize: '15px',
                      fontWeight: 600,
                      color: '#111827'
                    }
                  }}
                />
              </ListItemButton>
            </ListItem>
          );
        })}
      </List>
    </Box>
  );
};

export default QuickActions;
