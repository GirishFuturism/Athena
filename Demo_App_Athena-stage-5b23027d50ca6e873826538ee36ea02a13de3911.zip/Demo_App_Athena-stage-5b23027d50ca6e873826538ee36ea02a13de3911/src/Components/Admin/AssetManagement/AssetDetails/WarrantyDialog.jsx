import React from 'react';
import { Dialog, DialogContent, DialogActions, Box, Typography, Button, IconButton, TextField } from '@mui/material';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import dayjs from 'dayjs';

// Validation Schema
const validationSchema = Yup.object({
  startDate: Yup.string()
    .required('Start Date is required'),
  partsWarrantyMonths: Yup.number()
    .required('Parts Warranty Terms is required')
    .positive('Must be a positive number')
    .integer('Must be a whole number')
    .min(1, 'Minimum 1 month required'),
  laborWarrantyMonths: Yup.number()
    .required('Labor Warranty Terms is required')
    .positive('Must be a positive number')
    .integer('Must be a whole number')
    .min(1, 'Minimum 1 month required')
});

const WarrantyDialog = ({ open, onClose, onSave }) => {
  // Calculate warranty years from months
  const calculateYears = (months) => {
    if (!months || isNaN(months) || months <= 0) return '0 Years';
    const years = months / 12;
    return years % 1 === 0 ? `${years} Years` : `${years.toFixed(1)} Years`;
  };

  // Initialize Formik
  const formik = useFormik({
    initialValues: {
      startDate: dayjs().format('YYYY-MM-DD'),
      partsWarrantyMonths: 12,
      laborWarrantyMonths: 0
    },
    validationSchema: validationSchema,
    onSubmit: (values) => {
      // Calculate warranty duration (using parts warranty months)
      const warrantyYears = calculateYears(values.partsWarrantyMonths);
      
      // Create warranty data object
      const warrantyData = {
        startDate: values.startDate,
        partsWarrantyMonths: parseInt(values.partsWarrantyMonths),
        laborWarrantyMonths: parseInt(values.laborWarrantyMonths),
        warranty: warrantyYears
      };

      console.log("✅ Warranty saved:", warrantyData);
      
      // Call parent callback with warranty data
      if (onSave) {
        onSave(warrantyData);
      }

      onClose();
    }
  });

  // Handle dialog close
  const handleDialogClose = () => {
    formik.resetForm();
    onClose();
  };

  return (
    <Dialog
      open={open}
      onClose={handleDialogClose}
      maxWidth="sm"
      disableScrollLock
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: '12px',
          maxWidth: '550px'
        }
      }}
    >
      {/* Header */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          p: 2.5,
          borderBottom: '1px solid #E5E7EB'
        }}
      >
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '22px',
            fontWeight: 600,
            color: '#111827'
          }}
        >
          Start Warranty
        </Typography>
        <IconButton
          onClick={handleDialogClose}
          sx={{
            color: '#000000',
            '&:hover': {
              backgroundColor: 'rgba(0,0,0,0.04)'
            }
          }}
        >
          <span className="material-symbols-outlined" style={{ fontSize: 24 }}>
            close
          </span>
        </IconButton>
      </Box>

      {/* Content */}
      <DialogContent sx={{ p: 3 }}>
        <form onSubmit={formik.handleSubmit}>
          {/* Start Date */}
          <Box sx={{ mb: 3 }}>
            <Typography
              sx={{
                fontFamily: 'Open Sans',
                fontSize: '15px',
                fontWeight: 600,
                color: '#4B5563',
                mb: 1
              }}
            >
              Start Date<span style={{ color: '#4B5563' }}>*</span>
            </Typography>
            <TextField
              fullWidth
              type="date"
              name="startDate"
              value={formik.values.startDate}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              error={formik.touched.startDate && Boolean(formik.errors.startDate)}
              helperText={formik.touched.startDate && formik.errors.startDate}
              sx={{
                '& .MuiOutlinedInput-root': {
                  height: 44,
                  fontSize: 14,
                  fontFamily: 'Open Sans',
                  borderRadius: '8px',
                  '& fieldset': {
                    borderColor: formik.touched.startDate && formik.errors.startDate ? '#DC2626' : '#D1D5DB'
                  },
                  '&:hover fieldset': {
                    borderColor: formik.touched.startDate && formik.errors.startDate ? '#DC2626' : '#9CA3AF'
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: formik.touched.startDate && formik.errors.startDate ? '#DC2626' : '#409BFF'
                  }
                },
                '& .MuiFormHelperText-root': {
                  color: '#DC2626',
                  fontFamily: 'Open Sans',
                  fontSize: '12px'
                }
              }}
              inputProps={{
                readOnly: false
              }}
            />
          </Box>

          {/* Parts Warranty Terms */}
          <Box sx={{ mb: 3 }}>
            <Typography
              sx={{
                fontFamily: 'Open Sans',
                fontSize: '15px',
                fontWeight: 600,
                color: '#4B5563',
                mb: 1
              }}
            >
              Parts Warranty Terms (in months)<span style={{ color: '#4B5563' }}>*</span>
            </Typography>
            <TextField
              fullWidth
              type="text"
              name="partsWarrantyMonths"
              inputMode="numeric"
              placeholder="Enter months (e.g., 12, 36, 18)"
              value={formik.values.partsWarrantyMonths}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              error={formik.touched.partsWarrantyMonths && Boolean(formik.errors.partsWarrantyMonths)}
              helperText={formik.touched.partsWarrantyMonths && formik.errors.partsWarrantyMonths}
              sx={{
                '& .MuiOutlinedInput-root': {
                  height: 44,
                  fontSize: 14,
                  fontFamily: 'Open Sans',
                  borderRadius: '8px',
                  '& fieldset': {
                    borderColor: formik.touched.partsWarrantyMonths && formik.errors.partsWarrantyMonths ? '#DC2626' : '#D1D5DB'
                  },
                  '&:hover fieldset': {
                    borderColor: formik.touched.partsWarrantyMonths && formik.errors.partsWarrantyMonths ? '#DC2626' : '#9CA3AF'
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: formik.touched.partsWarrantyMonths && formik.errors.partsWarrantyMonths ? '#DC2626' : '#409BFF'
                  }
                },
                '& .MuiFormHelperText-root': {
                  color: '#DC2626',
                  fontFamily: 'Open Sans',
                  fontSize: '12px'
                }
              }}
            />
          </Box>

          {/* Labor Warranty Terms */}
          <Box sx={{ mb: 1 }}>
            <Typography
              sx={{
                fontFamily: 'Open Sans',
                fontSize: '15px',
                fontWeight: 600,
                color: '#4B5563',
                mb: 1
              }}
            >
              Labor Warranty Terms (in months)<span style={{ color: '#4B5563' }}>*</span>
            </Typography>
            <TextField
              fullWidth
              type="text"
              name="laborWarrantyMonths"
              inputMode="numeric"
              placeholder="Enter months (e.g., 12, 36, 18)"
              value={formik.values.laborWarrantyMonths}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              error={formik.touched.laborWarrantyMonths && Boolean(formik.errors.laborWarrantyMonths)}
              helperText={formik.touched.laborWarrantyMonths && formik.errors.laborWarrantyMonths}
              sx={{
                '& .MuiOutlinedInput-root': {
                  height: 44,
                  fontSize: 14,
                  fontFamily: 'Open Sans',
                  borderRadius: '8px',
                  '& fieldset': {
                    borderColor: formik.touched.laborWarrantyMonths && formik.errors.laborWarrantyMonths ? '#DC2626' : '#D1D5DB'
                  },
                  '&:hover fieldset': {
                    borderColor: formik.touched.laborWarrantyMonths && formik.errors.laborWarrantyMonths ? '#DC2626' : '#9CA3AF'
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: formik.touched.laborWarrantyMonths && formik.errors.laborWarrantyMonths ? '#DC2626' : '#409BFF'
                  }
                },
                '& .MuiFormHelperText-root': {
                  color: '#DC2626',
                  fontFamily: 'Open Sans',
                  fontSize: '12px'
                }
              }}
            />
          </Box>
        </form>
      </DialogContent>

      {/* Actions */}
      <DialogActions
        sx={{
          p: 3,
          gap: 2,
          justifyContent: 'flex-end',
          borderTop: '1px solid #E5E7EB'
        }}
      >
        <Button
          onClick={() => formik.handleSubmit()}
          variant="contained"
          sx={{
            backgroundColor: '#409BFF',
            color: '#FFFFFF',
            fontFamily: 'Open Sans',
            fontSize: '16px',
            fontWeight: 600,
            textTransform: 'none',
            px: 3,
            py: 1,
            borderRadius: '16px',
            boxShadow: 'none',
            '&:hover': {
              backgroundColor: '#2563EB',
              boxShadow: 'none'
            }
          }}
        >
          Save
        </Button>
        <Button
          onClick={handleDialogClose}
          variant="contained"
          sx={{
            backgroundColor: '#FF4141',
            color: '#FFFFFF',
            fontFamily: 'Open Sans',
            fontSize: '16px',
            fontWeight: 600,
            textTransform: 'none',
            px: 3,
            py: 1,
            borderRadius: '16px',
            boxShadow: 'none',
            '&:hover': {
              backgroundColor: '#DC2626',
              boxShadow: 'none'
            }
          }}
        >
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default WarrantyDialog;
