import React from 'react';
import { Dialog, DialogContent, DialogActions, Box, Typography, Button, IconButton } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const DeleteAssetDialog = ({ open, onClose, assetName = "KL-LAP-1" }) => {
  const navigate = useNavigate();

  const handleDelete = () => {
    // Perform delete operation here (API call, etc.)
    console.log("Asset deleted:", assetName);
    
    // Close dialog
    onClose();
    
    // Navigate to asset management page
    navigate('/asset-management');
  };

  return (
    <Dialog
      open={open}
      disableScrollLock
      onClose={onClose}
      maxWidth="sm"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: '12px',
          maxWidth: '500px'
        }
      }}
    >
      {/* Header */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          p: 2.5,
          borderBottom: '1px solid #E5E7EB'
        }}
      >
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '22px',
            fontWeight: 600,
            color: '#FF0202'
          }}
        >
          Unassigned - {assetName}
        </Typography>
        <IconButton
          onClick={onClose}
          sx={{
            color: '#000000',
            '&:hover': {
              backgroundColor: 'rgba(0,0,0,0.04)'
            }
          }}
        >
          <span className="material-symbols-outlined" style={{ fontSize: 24 }}>
            close
          </span>
        </IconButton>
      </Box>

      {/* Content */}
      <DialogContent sx={{ p: 4, textAlign: 'center' }}>
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '20px',
            fontWeight: 700,
            color: '#FF0202',
            mb: 2
          }}
        >
          Are you sure?
        </Typography>
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '16px',
            fontWeight: 600,
            color: '#000000',
            mb: 1
          }}
        >
         Action is permanent and cannot be undone.
        </Typography>
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '16px',
            fontWeight: 600,
            color: '#000000'
          }}
        >
          Are you sure that you wish to Unassigned this Asset?
        </Typography>
      </DialogContent>

      {/* Actions */}
      <DialogActions
        sx={{
          p: 3,
          pt: 0,
          gap: 2,
          justifyContent: 'flexEnd',
          borderTop: '1px solid #E5E7EB',
          pt:2.5
        }}
      >
        <Button
          onClick={handleDelete}
          variant="contained"
          sx={{
            backgroundColor: '#409BFF',
            color: '#FFFFFF',
            fontFamily: 'Open Sans',
            fontSize: '15px',
            fontWeight: 600,
            textTransform: 'none',
            px: 4,
            py: 1,
            borderRadius: '16px',
            boxShadow: 'none',
            '&:hover': {
              backgroundColor: '#2563EB',
              boxShadow: 'none'
            }
          }}
        >
          Yes
        </Button>
        <Button
          onClick={onClose}
          variant="contained"
          sx={{
            backgroundColor: '#FF4141',
            color: '#FFFFFF',
            fontFamily: 'Open Sans',
            fontSize: '15px',
            fontWeight: 600,
            textTransform: 'none',
            px: 4,
            py: 1,
            borderRadius: '16px',
            boxShadow: 'none',
            '&:hover': {
              backgroundColor: '#DC2626',
              boxShadow: 'none'
            }
          }}
        >
          No
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeleteAssetDialog;
