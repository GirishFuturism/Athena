import React, { useState, forwardRef, useImperativeHandle, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Typography, TextField, Select, MenuItem, FormControl, InputAdornment, Chip, Checkbox } from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import { MagnifyingGlassIcon } from '@heroicons/react/24/solid';
import { assetRows } from '../../../Data/AssetManagementData';

const AssetListGrid = forwardRef(({ onSelectionChange }, ref) => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [assetTypeFilter, setAssetTypeFilter] = useState('Assets Type');
  const [statusFilter, setStatusFilter] = useState('All Status');
  const [selectedRows, setSelectedRows] = useState([]);
  const [gridKey, setGridKey] = useState(0);

  // Notify parent component when selection changes
  useEffect(() => {
    if (onSelectionChange) {
      onSelectionChange(selectedRows.length);
    }
  }, [selectedRows, onSelectionChange]);

  // Expose refresh and download methods to parent
  useImperativeHandle(ref, () => ({
    handleRefresh() {
      setSearchQuery('');
      setAssetTypeFilter('Assets Type');
      setStatusFilter('All Status');
      setSelectedRows([]);
      setGridKey(prev => prev + 1);
    },
    handleDownload() {
      downloadSelectedAssets();
    }
  }));

  // Enhanced filter logic
  const filteredAssets = assetRows.filter((asset) => {
    const searchLower = searchQuery.toLowerCase().trim();
    
    const matchesSearch = !searchQuery || (
      asset.id.toLowerCase().includes(searchLower) ||
      asset.customer.toLowerCase().includes(searchLower) ||
      asset.site.toLowerCase().includes(searchLower) ||
      asset.assetsType.toLowerCase().includes(searchLower) ||
      asset.assetsNumber.toLowerCase().includes(searchLower) ||
      asset.status.toLowerCase().includes(searchLower) ||
      asset.user.toLowerCase().includes(searchLower) ||
      asset.keyField.toLowerCase().includes(searchLower) ||
      asset.keyField2.toLowerCase().includes(searchLower) ||
      asset.keyField3.toLowerCase().includes(searchLower)
    );
    
    const matchesType = assetTypeFilter === 'Assets Type' || asset.assetsType === assetTypeFilter;
    const matchesStatus = statusFilter === 'All Status' || asset.status === statusFilter;
    
    return matchesSearch && matchesType && matchesStatus;
  });

  // Download selected assets as Excel
  const downloadSelectedAssets = () => {
    if (selectedRows.length === 0) {
      return;
    }

    const dataToExport = filteredAssets.filter(asset => selectedRows.includes(asset.id));

    // Create Excel XML format
    const headers = ['ID', 'Customer', 'Site', 'Assets Type', 'Assets Number', 'Status', 'User', 'Key Field', 'Key Field2', 'Key Field3'];
    
    const rows = dataToExport.map(asset => [
      asset.id,
      asset.customer,
      asset.site,
      asset.assetsType,
      asset.assetsNumber,
      asset.status,
      asset.user,
      asset.keyField,
      asset.keyField2,
      asset.keyField3
    ]);

    // Create Excel XML structure
    const excelData = [
      '<?xml version="1.0"?>',
      '<?mso-application progid="Excel.Sheet"?>',
      '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"',
      ' xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">',
      '<Worksheet ss:Name="Assets">',
      '<Table>',
      // Header row
      '<Row>',
      ...headers.map(header => `<Cell><Data ss:Type="String">${header}</Data></Cell>`),
      '</Row>',
      // Data rows
      ...rows.map(row => 
        '<Row>' + 
        row.map(cell => `<Cell><Data ss:Type="String">${cell}</Data></Cell>`).join('') + 
        '</Row>'
      ),
      '</Table>',
      '</Worksheet>',
      '</Workbook>'
    ].join('');

    // Create blob and download
    const blob = new Blob([excelData], { 
      type: 'application/vnd.ms-excel;charset=utf-8;' 
    });
    
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', `assets-export-${new Date().getTime()}.xls`);
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    URL.revokeObjectURL(url);
  };

  const isAllSelected = filteredAssets.length > 0 && selectedRows.length === filteredAssets.length;
  const isSomeSelected = selectedRows.length > 0 && selectedRows.length < filteredAssets.length;

  const handleSelectAll = () => {
    if (isAllSelected) {
      setSelectedRows([]);
    } else {
      setSelectedRows(filteredAssets.map((row) => row.id));
    }
  };

  const handleRowSelect = (id) => {
    setSelectedRows((prev) =>
      prev.includes(id) ? prev.filter((rowId) => rowId !== id) : [...prev, id]
    );
  };

  const handleRowClick = (params, event) => {
    if (params.field === 'select') {
      return;
    }
    navigate('/asset-details', { state: { selectedAsset: params.row } });
  };

  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

  const columns = [
    {
      field: 'select',
      headerName: '',
      width: 60,
      sortable: false,
      disableColumnMenu: true,
      renderHeader: () => (
        <Checkbox
          size="small"
          checked={isAllSelected}
          indeterminate={isSomeSelected}
          onChange={handleSelectAll}
          sx={{
            color: '#D1D5DB',
            '&.Mui-checked': {
              color: '#409BFF',
            },
            '&.MuiCheckbox-indeterminate': {
              color: '#409BFF',
            }
          }}
        />
      ),
      renderCell: (params) => (
        <Checkbox
          size="small"
          checked={selectedRows.includes(params.row.id)}
          onChange={(e) => {
            e.stopPropagation();
            handleRowSelect(params.row.id);
          }}
          sx={{
            color: '#D1D5DB',
            '&.Mui-checked': {
              color: '#409BFF',
            }
          }}
        />
      ),
    },
    {
      field: 'id',
      headerName: 'ID',
      width: 100,
      renderCell: (params) => (
        <Typography sx={{ fontSize: '14px', fontWeight: 500, color: '#111827', fontFamily: 'Open Sans', pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'customer',
      headerName: 'Customer',
      width: 180,
      renderCell: (params) => (
        <Typography sx={{ fontSize: '14px', fontWeight: 500, color: '#111827', fontFamily: 'Open Sans', pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'site',
      headerName: 'Site',
      width: 180,
      renderCell: (params) => (
        <Typography sx={{ fontSize: '14px', fontWeight: 500, color: '#111827', fontFamily: 'Open Sans', pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'assetsType',
      headerName: 'Assets Type',
      width: 150,
      renderCell: (params) => (
        <Typography sx={{ fontSize: '14px', fontWeight: 500, color: '#111827', fontFamily: 'Open Sans', pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'assetsNumber',
      headerName: 'Assets Number',
      width: 150,
      renderCell: (params) => (
        <Typography sx={{ fontSize: '14px', fontWeight: 500, color: '#111827', fontFamily: 'Open Sans', pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'status',
      headerName: 'Status',
      width: 140,
      renderCell: (params) => {
        const statusConfig = {
          'In Stock': { bgColor: '#E3F8E8', textColor: '#066A1B' },
          'Out of Stock': { bgColor: '#F8E3E3', textColor: '#A20606' },
          'Damage': { bgColor: '#FEF3D6', textColor: '#707100' },
          'Active': { bgColor: '#D1FAE5', textColor: '#166534' },
          'Coming Soon': { bgColor: '#FEE2E2', textColor: '#991B1B' }
        };
        const config = statusConfig[params.value] || statusConfig['Active'];
        
        return (
          <Box >
            <Chip
              label={params.value}
              sx={{
                backgroundColor: config.bgColor,
                color: config.textColor,
                fontFamily: 'Open Sans',
                fontSize: '13px',
                fontWeight: 600,
                height: '26px',
                borderRadius: '13px',
                '& .MuiChip-label': {
                  px: 1.5
                }
              }}
            />
          </Box>
        );
      },
    },
    {
      field: 'user',
      headerName: 'User',
      width: 180,
      renderCell: (params) => (
        <Typography sx={{ fontSize: '14px', fontWeight: 500, color: '#111827', fontFamily: 'Open Sans', pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'keyField',
      headerName: 'Key Field',
      width: 150,
      renderCell: (params) => (
        <Typography sx={{ fontSize: '14px', fontWeight: 500, color: '#111827', fontFamily: 'Open Sans', pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'keyField2',
      headerName: 'Key Field2',
      width: 130,
      renderCell: (params) => (
        <Typography sx={{ fontSize: '14px', fontWeight: 500, color: '#111827', fontFamily: 'Open Sans', pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'keyField3',
      headerName: 'Key Field3',
      width: 130,
      renderCell: (params) => (
        <Typography sx={{ fontSize: '14px', fontWeight: 500, color: '#111827', fontFamily: 'Open Sans', pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    }
  ];

  return (
    <Box
      sx={{
        backgroundColor: '#FFFFFF',
        border: '1px solid #E5E7EB',
        borderRadius: '8px',
        p: 2.5,
        display: 'flex',
        flexDirection: 'column',
        height: '100%'
      }}
    >
      {/* Header with Search and Filters */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2.5, flexWrap: 'wrap', gap: 2 }}>
        <Box>
          <Typography
            sx={{
              fontFamily: 'Open Sans',
              fontSize: '18px',
              fontWeight: '700',
              color: '#111827'
            }}
          >
            Assets List 
          </Typography>
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, flexWrap: 'wrap' }}>
          <TextField
            placeholder="Search assets..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            size="small"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <MagnifyingGlassIcon style={{ width: 18, height: 18, color: '#9CA3AF' }} />
                </InputAdornment>
              ),
            }}
            sx={{
              width: 220,
              '& .MuiOutlinedInput-root': {
                height: 36,
                fontSize: '14px',
                fontFamily: 'Open Sans',
                borderRadius: '6px',
                backgroundColor: '#FFFFFF',
                '& fieldset': {
                  borderColor: '#E5E7EB',
                },
                '&:hover fieldset': {
                  borderColor: '#D1D5DB',
                },
                '&.Mui-focused fieldset': {
                  borderColor: '#409BFF',
                }
              }
            }}
          />

          <FormControl size="small" sx={{ minWidth: 140 }}>
            <Select
              value={assetTypeFilter}
              MenuProps={menuProps}
              onChange={(e) => setAssetTypeFilter(e.target.value)}
              sx={{
                height: 36,
                fontSize: '14px',
                fontWeight: 400,
                color: '#111827',
                borderRadius: '6px',
                fontFamily: 'Open Sans',
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: '#E5E7EB',
                },
                '&:hover .MuiOutlinedInput-notchedOutline': {
                  borderColor: '#D1D5DB',
                },
                '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                  borderColor: '#409BFF',
                }
              }}
            >
              <MenuItem value="Assets Type">Assets Type</MenuItem>
              <MenuItem value="Laptop">Laptop</MenuItem>
              <MenuItem value="Workstation">Workstation</MenuItem>
              <MenuItem value="Tablet">Tablet</MenuItem>
              <MenuItem value="Smartphone">Smartphone</MenuItem>
              <MenuItem value="Desktop Computer">Desktop Computer</MenuItem>
              <MenuItem value="Smartwatch">Smartwatch</MenuItem>
              <MenuItem value="E-reader">E-reader</MenuItem>
            </Select>
          </FormControl>

          <FormControl size="small" sx={{ minWidth: 130 }}>
            <Select
              MenuProps={menuProps}
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              sx={{
                height: 36,
                fontSize: '14px',
                fontWeight: 400,
                color: '#111827',
                borderRadius: '6px',
                fontFamily: 'Open Sans',
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: '#E5E7EB',
                },
                '&:hover .MuiOutlinedInput-notchedOutline': {
                  borderColor: '#D1D5DB',
                },
                '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                  borderColor: '#409BFF',
                }
              }}
            >
              <MenuItem value="All Status">All Status</MenuItem>
              <MenuItem value="In Stock">In Stock</MenuItem>
              <MenuItem value="Out of Stock">Out of Stock</MenuItem>
              <MenuItem value="Active">Active</MenuItem>
              <MenuItem value="Damage">Damage</MenuItem>
            </Select>
          </FormControl>
        </Box>
      </Box>

      <Box
        sx={{
          width: '100%',
          overflowX: 'auto',
          '-ms-overflow-style': 'none',
          'scrollbar-width': 'none',
          '&::-webkit-scrollbar': { display: 'none' }
        }}
      >
        <DataGrid
          key={gridKey}
          rows={filteredAssets}
          columns={columns}
          checkboxSelection={false}
          disableRowSelectionOnClick
          disableColumnMenu
          onCellClick={handleRowClick}
          initialState={{
            pagination: {
              paginationModel: { page: 0, pageSize: 10 },
            },
          }}
          // pageSizeOptions={[10, 20, 30]}
          sx={{
            border: 'none',
            fontFamily: 'Open Sans',
            '& .MuiDataGrid-columnHeader': {
              backgroundColor: '#F9FAFB',
              borderBottom: '1px solid #E5E7EB',
            },
            '& .MuiDataGrid-columnHeaderTitle': {
              fontSize: '14px',
              fontWeight: 700,
              color: '#4B4B4B',
              fontFamily: 'Open Sans',
            },
            '& .MuiDataGrid-cell': {
              fontSize: '13px',
              color: '#111827',
              fontFamily: 'Open Sans',
              borderBottom: '1px solid #F3F4F6',
            },
            '& .MuiDataGrid-row': {
              cursor: 'pointer',
              '&:hover': {
                backgroundColor: '#EEF2FF',
              },
            },
            '& .MuiDataGrid-cell[data-field="select"]': {
              cursor: 'default',
            },
            '& .MuiCheckbox-root': {
              color: '#D1D5DB',
              '&.Mui-checked': {
                color: '#409BFF',
              },
            },
            '& .MuiDataGrid-columnSeparator': {
              display: 'none',
            },
            '& .MuiDataGrid-footerContainer': {
              borderTop: '1px solid #E5E7EB',
              backgroundColor: '#F9FAFB',
            },
            '& .MuiTablePagination-root': {
              color: '#6B7280',
              fontSize: '13px',
              fontFamily: 'Open Sans',
            },
            "& .MuiDataGrid-cell:focus": {
              outline: "none",
            },
            "& .MuiDataGrid-cell:focus-within": {
              outline: "none",
            },
            "& .MuiDataGrid-columnHeader:focus": {
              outline: "none",
            },
            "& .MuiDataGrid-columnHeader:focus-within": {
              outline: "none",
            },
          }}
        />
      </Box>
    </Box>
  );
});

export default AssetListGrid;
