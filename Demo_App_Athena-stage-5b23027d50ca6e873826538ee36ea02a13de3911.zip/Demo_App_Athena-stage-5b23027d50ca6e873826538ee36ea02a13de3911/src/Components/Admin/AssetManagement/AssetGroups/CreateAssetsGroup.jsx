import React, { useState } from 'react';
import TitleBreadcrumb from "../../../Shared/TitleBreadcrumb";
import { Grid, Box, Typography, Button, IconButton } from "@mui/material";
import { 
  HomeIcon, 
  PlusIcon, 
  ArrowPathIcon,
  ArrowDownTrayIcon,
  EllipsisHorizontalIcon,
  CheckIcon,
  CameraIcon
} from '@heroicons/react/24/solid';
import GroupInformation from './GroupInformation';
import AssignAssets from './AssignAssets';
import { useNavigate } from 'react-router-dom';

const CreateAssetsGroup = () => {
  const navigate = useNavigate();
  const [selectedAssets, setSelectedAssets] = useState([]);

  const handleCreateGroup = () => {
    console.log("Create Group clicked");
    // Add your create group logic here
    navigate("/asset-management")
  };

  const handleCancel = () => {
    navigate('/asset-management');
  };

  return (
    <>
      <Grid
        container
        spacing={{ xs: 1, md: 2 }}
        columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{
          width: "100%",
          maxWidth: "100vw",
          m: 0,
          p: { xs: 0, sm: 1 },
          justifyContent: "center",
          flexGrow: 1,
        }}
      >
        <Grid
          item
          size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{
            border: "1px solid #E4E4E7",
            backgroundColor: "#fff",
            px: { xs: 1, sm: 4, md: 6, xl: 3 },
            py: { xs: 0, sm: 3 },
            boxShadow: { xs: "none", sm: "0 2px 14px rgba(116,185,255,.08)" },
          }}
        >
          {/* Breadcrumb */}
          <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
            <HomeIcon style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8,cursor:"pointer" }} onClick={() => navigate("/admin")}/>
            <TitleBreadcrumb 
              breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin" }, 
                { type: "link", label: "Asset Management", to: "/asset-management" },
                { type: "text", label: "Create Assets Group", to: "" }
              ]} 
            />
          </Box>

          {/* Header with Title and Action Buttons */}
          <Box 
            sx={{ 
              mt: 2, 
              pt: 1, 
              pb: 1,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: 2
            }}
          >
            <Typography 
              sx={{ 
                fontFamily: "Open Sans", 
                fontSize: "24px", 
                fontWeight: "700", 
                color: "#111827" 
              }}
            >
              Create Assets Group
            </Typography>

            {/* Action Buttons */}
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Button
                startIcon={<PlusIcon style={{ width: 18, height: 18 }} />}
                onClick={() => navigate("/asset-form")}
                sx={{
                  backgroundColor: '#409BFF',
                  color: '#FFFFFF',
                  fontFamily: 'Open Sans',
                  fontSize: '14px',
                  fontWeight: 600,
                  textTransform: 'none',
                  px: 2.5,
                  py: 1,
                  borderRadius: '6px',
                  boxShadow: 'none',
                  '&:hover': {
                    backgroundColor: '#2563EB',
                    boxShadow: 'none'
                  }
                }}
              >
                Add Assets
              </Button>

              <IconButton
                sx={{
                  backgroundColor: '#409BFF',
                  color: '#FFFFFF',
                  width: 38,
                  height: 38,
                  borderRadius: '6px',
                  '&:hover': {
                    backgroundColor: '#2563EB'
                  }
                }}
              >
                <ArrowPathIcon style={{ width: 18, height: 18 }} />
              </IconButton>

              <IconButton
                sx={{
                  backgroundColor: '#409BFF',
                  color: '#FFFFFF',
                  width: 38,
                  height: 38,
                  borderRadius: '6px',
                  '&:hover': {
                    backgroundColor: '#2563EB'
                  }
                }}
              >
                <ArrowDownTrayIcon style={{ width: 18, height: 18 }} />
              </IconButton>

              <IconButton
                sx={{
                  backgroundColor: '#409BFF',
                  color: '#FFFFFF',
                  width: 38,
                  height: 38,
                  borderRadius: '6px',
                  '&:hover': {
                    backgroundColor: '#2563EB'
                  }
                }}
              >
                <EllipsisHorizontalIcon style={{ width: 18, height: 18 }} />
              </IconButton>
            </Box>
          </Box>

          <Box sx={{ mt: 3, mb: 2, width: "100%" }}>
            <Grid container spacing={2}>
              <Grid item size={{ xs: 12, sm: 12, md: 9 }}>
                <GroupInformation />
              </Grid>
              <Grid item size={{ xs: 12, sm: 12, md: 3 }}>
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                  {/* Assign Assets Component */}
                  <AssignAssets 
                    onAssetsSelected={(assets) => setSelectedAssets(assets)}
                  />

                  {/* ✅ BUTTONS SECTION - EXACT DESIGN */}
                  <Box
                    sx={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: 1.5,
                      backgroundColor: '#FFFFFF',
                      border: '1px solid #E5E7EB',
                      borderRadius: '12px',
                      p: 2
                    }}
                  >
                    {/* Create Group Button */}
                    <Button
                      fullWidth
                      onClick={handleCreateGroup}
                      sx={{
                        backgroundColor: '#1976D2',
                        color: '#FFFFFF',
                        fontFamily: 'Open Sans',
                        fontSize: '16px',
                        fontWeight: 600,
                        textTransform: 'none',
                        py: 1.2,
                        height:"36px",
                        borderRadius: '8px',
                        boxShadow: 'none',
                        '&:hover': {
                          backgroundColor: '#2563EB',
                          boxShadow: 'none'
                        }
                      }}
                    >
                      Create Group
                    </Button>

                    {/* Cancel Button */}
                    <Button
                      fullWidth
                      onClick={handleCancel}
                      sx={{
                        backgroundColor: '#FF4141',
                        color: '#FFFFFF',
                        fontFamily: 'Open Sans',
                        fontSize: '16px',
                        fontWeight: 600,
                        textTransform: 'none',
                        py: 1.2,
                        borderRadius: '8px',
                        boxShadow: 'none',
                        height:"36px",
                        '&:hover': {
                          backgroundColor: '#DC2626',
                          boxShadow: 'none'
                        }
                      }}
                    >
                      Cancel
                    </Button>
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </Box>
        </Grid>
      </Grid>
    </>
  );
};

export default CreateAssetsGroup;
