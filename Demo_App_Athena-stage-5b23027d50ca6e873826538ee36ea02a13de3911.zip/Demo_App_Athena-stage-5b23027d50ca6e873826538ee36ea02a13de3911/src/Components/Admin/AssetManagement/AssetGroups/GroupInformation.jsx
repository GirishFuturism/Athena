import React, { useState } from 'react';
import { Box, Typography, TextField, Select, MenuItem, Switch } from '@mui/material';
import { InformationCircleIcon } from '@heroicons/react/24/solid';

const GroupInformation = () => {
  const [groupName, setGroupName] = useState('');
  const [description, setDescription] = useState('');
  const [groupType, setGroupType] = useState('');
  const [isActive, setIsActive] = useState(true);

  const textFieldStyle = {
    '& .MuiOutlinedInput-root': {
      height: 44,
      fontSize: 14,
      fontFamily: 'Open Sans',
      borderRadius: '6px',
      '& fieldset': {
        borderColor: '#D1D5DB'
      },
      '&:hover fieldset': {
        borderColor: '#9CA3AF'
      },
      '&.Mui-focused fieldset': {
        borderColor: '#409BFF'
      }
    },
    '& .MuiInputBase-input::placeholder': {
      color: '#9CA3AF',
      opacity: 1
    }
  };

    const menuProps = {
  disableScrollLock: true,
  PaperProps: {
    sx: {
      maxHeight: 300,
      '&::-webkit-scrollbar': {
        display: 'none',
      },
      '-ms-overflow-style': 'none',
      'scrollbar-width': 'none',
    },
  },
};

  return (
    <Box
      sx={{
        backgroundColor: '#FFFFFF',
        border: '1px solid #E5E7EB',
        borderRadius: '12px',
        p: 3
      }}
    >
      {/* Header with Icon */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 3 }}>
        <InformationCircleIcon style={{ width: 20, height: 20, color: '#1976D2' }} />
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '17px',
            fontWeight: 600,
            color: '#1F2937'
          }}
        >
          Group Information
        </Typography>
      </Box>

      {/* Group Name Field */}
      <Box sx={{ mb: 3 }}>
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '14px',
            fontWeight: 600,
            color: '#374151',
            mb: 1
          }}
        >
          Group Name <span style={{ color: '#374151' }}>*</span>
        </Typography>
        <TextField
          fullWidth
          placeholder="Enter group name"
          value={groupName}
          onChange={(e) => setGroupName(e.target.value)}
          sx={textFieldStyle}
        />
      </Box>

      {/* Description Field */}
      <Box sx={{ mb: 2 }}>
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '14px',
            fontWeight: 600,
            color: '#374151',
            mb: 1
          }}
        >
          Description
        </Typography>
        <TextField
          fullWidth
          multiline
          rows={6}
          placeholder="Describe the purpose of this asset group"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          sx={{
            '& .MuiOutlinedInput-root': {
              fontSize: 14,
              fontFamily: 'Open Sans',
              borderRadius: '6px',
              '& fieldset': {
                borderColor: '#D1D5DB'
              },
              '&:hover fieldset': {
                borderColor: '#9CA3AF'
              },
              '&.Mui-focused fieldset': {
                borderColor: '#409BFF'
              }
            },
            '& .MuiInputBase-input::placeholder': {
              color: '#9CA3AF',
              opacity: 1
            }
          }}
        />
      </Box>

      {/* Group Type and Status Row */}
      <Box
        sx={{
          display: 'flex',
          gap: 2,
          alignItems: 'flex-start'
        }}
      >
        {/* Group Type - Left Side */}
        <Box sx={{ flex: 1 }}>
          <Typography
            sx={{
              fontFamily: 'Open Sans',
              fontSize: '14px',
              fontWeight: 600,
              color: '#374151',
              mb: 1
            }}
          >
            Group Type <span style={{ color: '#374151' }}>*</span>
          </Typography>
          <Select
          MenuProps={menuProps}
            value={groupType}
            onChange={(e) => setGroupType(e.target.value)}
            displayEmpty
            fullWidth
            sx={{
              height: 44,
              fontSize: 14,
              fontFamily: 'Open Sans',
              borderRadius: '6px',
              '& .MuiOutlinedInput-notchedOutline': {
                borderColor: '#D1D5DB'
              },
              '&:hover .MuiOutlinedInput-notchedOutline': {
                borderColor: '#9CA3AF'
              },
              '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                borderColor: '#409BFF'
              }
            }}
          >
            <MenuItem value="">Select type</MenuItem>
            <MenuItem value="type1">Type 1</MenuItem>
            <MenuItem value="type2">Type 2</MenuItem>
            <MenuItem value="type3">Type 3</MenuItem>
          </Select>
        </Box>

        {/* Status - Right Side */}
        <Box sx={{ flex: 1.5}}>
          <Typography
            sx={{
              fontFamily: 'Open Sans',
              fontSize: '14px',
              fontWeight: 600,
              color: '#374151',
              mb: 1
            }}
          >
            Status
          </Typography>
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 1,
              mt: 1.5
            }}
          >
            <Typography
              sx={{
                fontFamily: 'Open Sans',
                fontSize: '14px',
                fontWeight: 500,
                color: isActive ? '#409BFF' : '#9CA3AF'
              }}
            >
              Active
            </Typography>
            <Switch
              checked={isActive}
              onChange={(e) => setIsActive(e.target.checked)}
              sx={{
                '& .MuiSwitch-switchBase.Mui-checked': {
                  color: '#409BFF'
                },
                '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                  backgroundColor: '#409BFF'
                }
              }}
            />
            <Typography
              sx={{
                fontFamily: 'Open Sans',
                fontSize: '14px',
                fontWeight: 500,
                color: !isActive ? '#9CA3AF' : '#999'
              }}
            >
              Inactive
            </Typography>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default GroupInformation;
