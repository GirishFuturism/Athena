import React, { useState } from 'react';
import { Box, Typography, TextField, Button, Paper } from '@mui/material';
import { MagnifyingGlassIcon, LinkIcon } from '@heroicons/react/24/solid';

const AssignAssets = ({ onAssetsSelected }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAssets, setSelectedAssets] = useState([]);

  // Mock data - Replace with actual API call
  const availableAssets = [
    { id: 1, name: 'Laptop - KL-LAP-1', code: 'LAPTOP-001' },
    { id: 2, name: 'Desktop - KL-DES-1', code: 'DESKTOP-001' },
    { id: 3, name: 'Monitor - KL-MON-1', code: 'MONITOR-001' },
    { id: 4, name: 'Printer - KL-PR-1', code: 'PRINTER-001' },
    { id: 5, name: 'Router - KL-RT-1', code: 'ROUTER-001' },
  ];

  // Filter assets based on search
  const filteredAssets = availableAssets.filter(asset =>
    asset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    asset.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddAsset = (asset) => {
    if (!selectedAssets.find(a => a.id === asset.id)) {
      const newSelected = [...selectedAssets, asset];
      setSelectedAssets(newSelected);
      if (onAssetsSelected) {
        onAssetsSelected(newSelected);
      }
    }
  };

  const handleRemoveAsset = (assetId) => {
    const newSelected = selectedAssets.filter(a => a.id !== assetId);
    setSelectedAssets(newSelected);
    if (onAssetsSelected) {
      onAssetsSelected(newSelected);
    }
  };

  return (
    <Box
      sx={{
        backgroundColor: '#FFFFFF',
        border: '1px solid #E5E7EB',
        borderRadius: '12px',
        p: 2,
        display: 'flex',
        flexDirection: 'column'
      }}
    >
      {/* Header with Icon */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2 }}>
        <LinkIcon style={{ width: 20, height: 20, color: '#1976D2' }} />
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '17px',
            fontWeight: 600,
            color: '#1F2937'
          }}
        >
          Assign Assets
        </Typography>
      </Box>

      {/* Search Section */}
      <Box sx={{ mb: 3 }}>
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '14px',
            fontWeight: 600,
            color: '#374151',
            mb: 1.5
          }}
        >
          Search Assets
        </Typography>

        {/* Search Input */}
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 1,
            border: '1px solid #E5E7EB',
            borderRadius: '8px',
            px: 2,
            py: 0.8,
            backgroundColor: '#FFFFFF',
            '&:hover': {
              borderColor: '#D1D5DB'
            },
            '&:focus-within': {
              borderColor: '#409BFF'
            }
          }}
        >
          <MagnifyingGlassIcon style={{ width: 18, height: 18, color: '#9CA3AF' }} />
          <TextField
            fullWidth
            placeholder="Search existing assets..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            variant="standard"
            InputProps={{
              disableUnderline: true,
            }}
            sx={{
              '& .MuiInputBase-input': {
                fontFamily: 'Open Sans',
                fontSize: 14,
                color: '#111827',
                '&::placeholder': {
                  color: '#9CA3AF',
                  opacity: 1
                }
              }
            }}
          />
        </Box>

        {/* Search Results Dropdown */}
        {searchTerm && filteredAssets.length > 0 && (
          <Paper
            elevation={0}
            sx={{
              mt: 1.5,
              border: '1px solid #E5E7EB',
              borderRadius: '8px',
              maxHeight: 200,
              overflowY: 'auto',
              position: 'relative',
              zIndex: 10
            }}
          >
            {filteredAssets.map((asset) => (
              <Box
                key={asset.id}
                sx={{
                  p: 2,
                  borderBottom: '1px solid #E5E7EB',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  '&:hover': {
                    backgroundColor: '#F9FAFB'
                  },
                  '&:last-child': {
                    borderBottom: 'none'
                  }
                }}
              >
                <Box>
                  <Typography
                    sx={{
                      fontFamily: 'Open Sans',
                      fontSize: 13,
                      fontWeight: 500,
                      color: '#111827'
                    }}
                  >
                    {asset.name}
                  </Typography>
                  <Typography
                    sx={{
                      fontFamily: 'Open Sans',
                      fontSize: 12,
                      fontWeight: 400,
                      color: '#9CA3AF',
                      mt: 0.3
                    }}
                  >
                    {asset.code}
                  </Typography>
                </Box>
                <Button
                  onClick={() => handleAddAsset(asset)}
                  disabled={selectedAssets.find(a => a.id === asset.id)}
                  sx={{
                    backgroundColor: '#409BFF',
                    color: '#FFFFFF',
                    fontFamily: 'Open Sans',
                    fontSize: '12px',
                    fontWeight: 600,
                    textTransform: 'none',
                    px: 2,
                    py: 0.5,
                    borderRadius: '6px',
                    '&:hover': {
                      backgroundColor: '#2563EB'
                    },
                    '&:disabled': {
                      backgroundColor: '#D1D5DB',
                      color: '#FFFFFF',
                      cursor: 'not-allowed'
                    }
                  }}
                >
                  Add
                </Button>
              </Box>
            ))}
          </Paper>
        )}

        {/* Add New Asset Button */}
        <Button
          fullWidth
          sx={{
            mt: 2,
            py: 2,
            border: '2px dashed #D1D5DB',
            backgroundColor: '#F9FAFB',
            color: '#4B5563',
            fontFamily: 'Open Sans',
            fontSize: '16px',
            fontWeight: 600,
            textTransform: 'none',
            borderRadius: '8px',
            height:"52px",
            '&:hover': {
              backgroundColor: '#F9FAFB',
              borderColor: '#9CA3AF'
            }
          }}
        >
          <span style={{ fontSize: 20, marginRight: 8 }}>+</span>
          Add New Asset
        </Button>
      </Box>

      {/* Selected Assets Section */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '14px',
            fontWeight: 600,
            color: '#374151',
            mb: 2
          }}
        >
          Selected Assets ({selectedAssets.length})
        </Typography>

        {/* Selected Assets Container */}
        <Box
          sx={{
            flex: 1,
            border: '1px solid #E5E7EB',
            borderRadius: '8px',
            p: 2,
            backgroundColor: '#FAFAFA',
            overflowY: 'auto',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: selectedAssets.length === 0 ? 'center' : 'flex-start',
            alignItems: selectedAssets.length === 0 ? 'center' : 'stretch'
          }}
        >
          {selectedAssets.length === 0 ? (
            <Typography
              sx={{
                fontFamily: 'Open Sans',
                fontSize: 14,
                fontWeight: 400,
                color: '#9CA3AF',
                textAlign: 'center'
              }}
            >
              No assets selected
            </Typography>
          ) : (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              {selectedAssets.map((asset) => (
                <Box
                  key={asset.id}
                  sx={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    p: 1.5,
                    backgroundColor: '#FFFFFF',
                    borderRadius: '6px',
                    border: '1px solid #E5E7EB'
                  }}
                >
                  <Box>
                    <Typography
                      sx={{
                        fontFamily: 'Open Sans',
                        fontSize: 13,
                        fontWeight: 500,
                        color: '#111827'
                      }}
                    >
                      {asset.name}
                    </Typography>
                    <Typography
                      sx={{
                        fontFamily: 'Open Sans',
                        fontSize: 12,
                        fontWeight: 400,
                        color: '#9CA3AF',
                        mt: 0.3
                      }}
                    >
                      {asset.code}
                    </Typography>
                  </Box>
                  <Button
                    onClick={() => handleRemoveAsset(asset.id)}
                    sx={{
                      color: '#DC2626',
                      fontFamily: 'Open Sans',
                      fontSize: '12px',
                      fontWeight: 600,
                      textTransform: 'none',
                      minWidth: 'auto',
                      '&:hover': {
                        backgroundColor: '#FEE2E2'
                      }
                    }}
                  >
                    Remove
                  </Button>
                </Box>
              ))}
            </Box>
          )}
        </Box>
      </Box>
    </Box>
  );
};

export default AssignAssets;
