import React, { useState, useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import {
  Grid,
  Box,
  Typography,
  Tabs,
  Tab,
  Chip,
  Paper,
  Avatar,
  IconButton,
  Divider,
  Button,
  TextField,
  Select,
  MenuItem,
  FormControl,
} from "@mui/material";
import TitleBreadcrumb from "../../Shared/TitleBreadcrumb";
import {
  HomeIcon,
  PencilSquareIcon,
  PlusIcon,
  ExclamationTriangleIcon,
  ArrowUturnLeftIcon,
  CheckCircleIcon,
  
} from "@heroicons/react/24/solid";
import TeamsImg from "../../../assets/Teams.png";
import TeamsDarkImg from "../../../assets/TeamsDark.png";
import LapBackgroundImg from "../../../assets/lap_background.png";
import EditTicketInfoDialog from "./EditTicketInfoDialog";
import AddBillingDialog from "./AddBillingDialog";
import AddExpenseDialog from "./AddExpenseDialog";
import AddAssetsDialog from "./AddAssetsDialog";
import EditBillDialog from "./EditBillDialog";
import EditExpenseDialog from "./EditExpenseDialog";
import DeleteContentDialog from "./DeleteContentDialog";
import EditEndUserDialog from "./EditEndUserDialog";


// Icon Components for Toolbar
const BoldIcon = ({ style }) => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={style}>
    <path
      d="M6 4h8a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M6 12h9a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const UnderlineIcon = ({ style }) => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={style}>
    <path
      d="M6 3v7a6 6 0 0 0 6 6 6 6 0 0 0 6-6V3"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M4 21h16"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

// Billing Table Row Component
const BillingTableRow = ({ item, index, isLast, onEdit, onDelete }) => {
  const [isHovered, setIsHovered] = useState(false);
    const menuProps = {
  disableScrollLock: true,
  PaperProps: {
    sx: {
      maxHeight: 300,
      '&::-webkit-scrollbar': {
        display: 'none',
      },
      '-ms-overflow-style': 'none',
      'scrollbar-width': 'none',
    },
  },
};

  return (
    <tr
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        backgroundColor: isHovered ? "#E2E2E2D4" : "#FFFFFF",
        transition: "background-color 0.2s ease",
      }}
    >
      <td
        style={{
          padding: "12px 16px",
          fontSize: 14,
          color: "#000",
          borderBottom: isLast ? "none" : "1px solid #E5E7EB",
        }}
      >
        {item.chargeType}
      </td>
      <td
        style={{
          padding: "12px 16px",
          fontSize: 14,
          color: "#000",
          borderBottom: isLast ? "none" : "1px solid #E5E7EB",
        }}
      >
        {item.actualTime}
      </td>
      <td
        style={{
          padding: "12px 16px",
          fontSize: 14,
          color: "#000",
          borderBottom: isLast ? "none" : "1px solid #E5E7EB",
        }}
      >
        {item.billableTime}
      </td>
      <td
        style={{
          padding: "12px 16px",
          fontSize: 14,
          color: "#000",
          borderBottom: isLast ? "none" : "1px solid #E5E7EB",
        }}
      >
        {item.overriding}
      </td>
      <td
        style={{
          borderBottom: isLast ? "none" : "1px solid #E5E7EB",
          width: "80px",
        }}
      >
        {isHovered && (
          <Box sx={{ display: "flex", gap: 1 }}>
            <IconButton size="small" onClick={onEdit} sx={{ p: 0.5 }}>
              <PencilSquareIcon
                style={{ width: 18, height: 18, color: "#6B7280" }}
              />
            </IconButton>
            <IconButton size="small" onClick={onDelete} sx={{ p: 0.5 }}>
              <span
                className="material-symbols-outlined"
                style={{ fontSize: 18, color: "#EF4444" }}
              >
                delete
              </span>
            </IconButton>
          </Box>
        )}
      </td>
    </tr>
  );
};

// Expense Table Row Component
const ExpenseTableRow = ({ expense, index, isLast, onEdit, onDelete }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <tr
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        backgroundColor: isHovered ? "#E2E2E2D4" : "#FFFFFF",
        transition: "background-color 0.2s ease",
      }}
    >
      <td
        style={{
          padding: "12px 16px",
          fontSize: 14,
          color: "#000",
          borderBottom: isLast ? "none" : "1px solid #E5E7EB",
        }}
      >
        {expense.agent}
      </td>
      <td
        style={{
          padding: "12px 16px",
          fontSize: 14,
          color: "#000",
          borderBottom: isLast ? "none" : "1px solid #E5E7EB",
        }}
      >
        {expense.description}
      </td>
      <td
        style={{
          padding: "12px 16px",
          fontSize: 14,
          color: "#000",
          borderBottom: isLast ? "none" : "1px solid #E5E7EB",
        }}
      >
        {expense.cost}
      </td>
      <td
        style={{
          padding: "12px 16px",
          fontSize: 14,
          color: "#000",
          borderBottom: isLast ? "none" : "1px solid #E5E7EB",
        }}
      >
        {expense.expenseType}
      </td>
      <td
        style={{
          padding: "12px 16px",
          fontSize: 14,
          color: "#000",
          borderBottom: isLast ? "none" : "1px solid #E5E7EB",
        }}
      >
        {expense.dateAdded}
      </td>
      <td
        style={{
          padding: "12px 16px",
          fontSize: 14,
          color: "#000",
          borderBottom: isLast ? "none" : "1px solid #E5E7EB",
        }}
      >
        {expense.reviewed}
      </td>
      <td
        style={{
          borderBottom: isLast ? "none" : "1px solid #E5E7EB",
          width: "80px",
        }}
      >
        {isHovered && (
          <Box sx={{ display: "flex", gap: 1 }}>
            <IconButton size="small" onClick={onEdit} sx={{ p: 0.5 }}>
              <PencilSquareIcon
                style={{ width: 18, height: 18, color: "#6B7280" }}
              />
            </IconButton>
            <IconButton size="small" onClick={onDelete} sx={{ p: 0.5 }}>
              <span
                className="material-symbols-outlined"
                style={{ fontSize: 18, color: "#EF4444" }}
              >
                delete
              </span>
            </IconButton>
          </Box>
        )}
      </td>
    </tr>
  );
};

const TicketDetails = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const ticketData = location.state?.ticketData || {};

  const [tab, setTab] = useState("progressFeed");
  const [openEditDialog, setOpenEditDialog] = useState(false);
  const [openBillingDialog, setOpenBillingDialog] = useState(false);
  const [openExpenseDialog, setOpenExpenseDialog] = useState(false);
  const [openAssetsDialog, setOpenAssetsDialog] = useState(false);
  const [openEditBillDialog, setOpenEditBillDialog] = useState(false);
  const [openDeleteBillDialog, setOpenDeleteBillDialog] = useState(false);
  const [openEditExpenseDialog, setOpenEditExpenseDialog] = useState(false);
  const [openDeleteExpenseDialog, setOpenDeleteExpenseDialog] = useState(false);
  const [selectedBillItem, setSelectedBillItem] = useState(null);
  const [selectedExpenseItem, setSelectedExpenseItem] = useState(null);
  const [relatedAssets, setRelatedAssets] = useState([]);



  // Add after existing state declarations
const [submittedUpdates, setSubmittedUpdates] = useState([]);
const [ticketClosed, setTicketClosed] = useState(false);

// Timer States - ADD THESE
const [timerSeconds, setTimerSeconds] = useState(0); // 00:09:55 = 595 seconds
const [isTimerRunning, setIsTimerRunning] = useState(true);
const intervalRef = useRef(null);

// SLA Box Visibility State - ADD THIS
const [showSLABox, setShowSLABox] = useState(true);

    const menuProps = {
  disableScrollLock: true,
  PaperProps: {
    sx: {
      maxHeight: 300,
      '&::-webkit-scrollbar': {
        display: 'none',
      },
      '-ms-overflow-style': 'none',
      'scrollbar-width': 'none',
    },
  },
};

const handleOpenEditEndUserDialog = () => {
  setOpenEditEndUserDialog(true);
};

const handleCloseEditEndUserDialog = () => {
  setOpenEditEndUserDialog(false);
};

const handleSaveEndUserDetails = (updatedData) => {
  setEndUserData(updatedData);
  // Also update ticketInfo if accountManager changed
  setTicketInfo(prev => ({
    ...prev,
    accountManager: updatedData.accountManager
  }));
};


  // Resolve Ticket States
  const [showResolveForm, setShowResolveForm] = useState(false);
  const [resolveEmail, setResolveEmail] = useState("email@test.com");
  const [resolveNote, setResolveNote] = useState("");
  const [timeTaken, setTimeTaken] = useState("01:45:55");
  const [chargeType, setChargeType] = useState("No Charge");
  const [resolutionCode, setResolutionCode] = useState("Backup Restored");
  // Add these state declarations after existing ones
const [showReopenForm, setShowReopenForm] = useState({});
const [reopenEmail, setReopenEmail] = useState("email@test.com");
const [reopenNote, setReopenNote] = useState("");
const [reopenTimeTaken, setReopenTimeTaken] = useState("01:45:55");
const [reopenChargeType, setReopenChargeType] = useState("No Charge");
const [reopenStatus, setReopenStatus] = useState("In Progress");


// Timer Effect - ADD THIS ENTIRE BLOCK
useEffect(() => {
  if (isTimerRunning) {
    intervalRef.current = setInterval(() => {
      setTimerSeconds((prev) => prev + 1);
    }, 1000);
  } else {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
  }

  return () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
  };
}, [isTimerRunning]);


// Format seconds to HH:MM:SS - ADD THIS
const formatTime = (seconds) => {
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  return `${String(hrs).padStart(2, "0")}:${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
};

// Toggle Timer - ADD THIS
const handleToggleTimer = () => {
  setIsTimerRunning(!isTimerRunning);
};


const handleReopenUpdate = (updateId) => {
  // Update the specific update's status
  const updatedUpdates = submittedUpdates.map((update) =>
    update.id === updateId
      ? {
          ...update,
          reopened: true,
          reopenData: {
            email: reopenEmail,
            note: reopenNote,
            timeTaken: reopenTimeTaken,
            status: reopenStatus,
            timestamp: new Date().toLocaleString(),
          },
        }
      : update
  );

  setSubmittedUpdates(updatedUpdates);
  setShowReopenForm({ ...showReopenForm, [updateId]: false });
  setReopenNote("");
};

const handleDiscardReopen = (updateId) => {
  setShowReopenForm({ ...showReopenForm, [updateId]: false });
  setReopenNote("");
};


  // Text Formatting States
  const [isBold, setIsBold] = useState(false);
  const [isItalic, setIsItalic] = useState(false);
  const [isUnderline, setIsUnderline] = useState(false);
  const [textAlign, setTextAlign] = useState("left");

  // Initialize ticket info from grid data
  const [ticketInfo, setTicketInfo] = useState({
    id: ticketData.id || "0002187",
    summary: ticketData.summary || "Trackpad stops working randomly",
    dateCreated: ticketData.dateCreated || "9/17/2025 21:47",
    ticketType: ticketData.type || "Incident",
    workflow: "Incident Management",
    status: ticketData.status || "In Progress",
    team: "1st Line Support",
    assignedAgent: ticketData.agent || "Vinay T",
    category: "Laptop",
    source: "Manual",
    timeRecorded: ticketData.timeTaken || "00:00",
    estimatedTime: "00:00",
    urgency: "Not Set",
    billableTime: "08:50",
    accountManager: ticketData.accountManager || "James Brown",
  });

    const [openEditEndUserDialog, setOpenEditEndUserDialog] = useState(false);
  const [endUserData, setEndUserData] = useState({
  name: "Theresa Samuels",
  company: "St Johns High School",
  site: "Leeds",
  email: "Theresa.Samuels@contoso.com",
  accountManager: ticketInfo.accountManager || "James Brown",
});

  const [chargeTypes, setChargeTypes] = useState([
    {
      chargeType: "Travel",
      actualTime: "01:30",
      billableTime: "04:00",
      overriding: "Yes",
    },
    {
      chargeType: "Remote Support",
      actualTime: "00:30",
      billableTime: "04:50",
      overriding: "Yes",
    },
  ]);

  const [expenses, setExpenses] = useState([
    {
      agent: "Travel",
      description: "01:30",
      cost: "04:00",
      expenseType: "Yes",
      dateAdded: "Yes",
      reviewed: "Yes",
    },
  ]);

  // Text formatting handlers
  const handleBold = () => setIsBold(!isBold);
  const handleItalic = () => setIsItalic(!isItalic);
  const handleUnderline = () => setIsUnderline(!isUnderline);
  const handleAlignLeft = () => setTextAlign("left");
  const handleAlignRight = () => setTextAlign("center");

  const handleTabChange = (event, newValue) => {
    setTab(newValue);
  };

  const handleBack = () => {
    navigate("/ticket-management");
  };

  const handleOpenEditDialog = () => {
    setOpenEditDialog(true);
  };

  const handleCloseEditDialog = () => {
    setOpenEditDialog(false);
  };

  const handleSaveTicketInfo = (updatedData) => {
    setTicketInfo(updatedData);
  };

  const handleOpenBillingDialog = () => {
    setOpenBillingDialog(true);
  };

  const handleCloseBillingDialog = () => {
    setOpenBillingDialog(false);
  };

  const handleSaveBilling = (billingData) => {
    const newEntry = {
      chargeType: billingData.chargeType,
      actualTime: billingData.timeTaken,
      billableTime: "00:00",
      overriding: "No",
    };
    setChargeTypes([...chargeTypes, newEntry]);
  };

  const handleOpenExpenseDialog = () => {
    setOpenExpenseDialog(true);
  };

  const handleCloseExpenseDialog = () => {
    setOpenExpenseDialog(false);
  };

  const handleSaveExpense = (expenseData) => {
    const newExpense = {
      agent: "Agent Name",
      description: expenseData.description,
      cost: expenseData.cost,
      expenseType: expenseData.type,
      dateAdded: expenseData.dateAdded,
      reviewed: "No",
    };
    setExpenses([...expenses, newExpense]);
  };

  const handleOpenAssetsDialog = () => {
    setOpenAssetsDialog(true);
  };

  const handleCloseAssetsDialog = () => {
    setOpenAssetsDialog(false);
  };

  const handleSaveAssets = (assets) => {
    setRelatedAssets([...relatedAssets, ...assets]);
  };

// FIND THIS FUNCTION AND ADD ONE LINE
const handleResolveTicket = () => {
  setShowResolveForm(!showResolveForm);
  setShowSLABox(false); // ADD THIS LINE
};


const handleSendUpdate = () => {
  const newUpdate = {
    id: Date.now(),
    email: resolveEmail,
    note: resolveNote,
    timeTaken: timeTaken,
    chargeType: chargeType,
    resolutionCode: resolutionCode,
    timestamp: new Date().toLocaleString(),
  };
  
  setSubmittedUpdates([newUpdate, ...submittedUpdates]);
  setShowResolveForm(false);
  setTicketClosed(true);
  setResolveNote("");
};


// FIND THIS FUNCTION AND ADD ONE LINE
const handleDiscard = () => {
  setShowResolveForm(false);
  setResolveNote("");
  setShowSLABox(true); // ADD THIS LINE
};


  const handleRemoveEmail = () => {
    setResolveEmail("");
  };

  const tabValue = ["progressFeed", "billing"];

  const otherTickets = [
    {
      id: "2195",
      title: "Site Hardware Install",
      date: "9/17/2025",
      status: "On Hold",
      statusColor: "#FEF9C3",
      textColor: "#854D0E",
    },
    {
      id: "2154",
      title: "Can't login to Outlook",
      date: "9/17/2025",
      status: "In Progress",
      statusColor: "#DBEAFE",
      textColor: "#1E40AF",
    },
    {
      id: "2151",
      title: "Initial Scoping",
      date: "9/17/2025",
      status: "Completed",
      statusColor: "#DCFCE7",
      textColor: "#166534",
    },
  ];

  const getStatusColor = (status) => {
    const statusColors = {
      "In Progress": { bg: "#DBEAFE", text: "#1E40AF" },
      New: { bg: "#DCFCE7", text: "#166534" },
      "On Hold": { bg: "#FEF9C3", text: "#854D0E" },
      Completed: { bg: "#DCFCE7", text: "#166534" },
      Closed: { bg: "#F3F4F6", text: "#1F2937" },
    };
    return statusColors[status] || { bg: "#FEF9C3", text: "#854D0E" };
  };

  const statusColor = getStatusColor(ticketInfo.status);

  return (
    <>
      <Grid
        container
        spacing={{ xs: 1, md: 2 }}
        columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{
          width: "100%",
          maxWidth: "100vw",
          m: 0,
          p: { xs: 0, sm: 1 },
          justifyContent: "center",
          flexGrow: 1,
        }}
      >
        <Grid
          size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{
            border: "1px solid #E4E4E7",
            backgroundColor: "#fff",
            px: { xs: 1, sm: 4, md: 6, xl: 3 },
            py: { xs: 0, sm: 3 },
            boxShadow: { xs: "none", sm: "0 2px 14px rgba(116,185,255,.08)" },
          }}
        >
          {/* Breadcrumb */}
          <Box
            sx={{
              mb: { xs: 1, sm: 2 },
              display: "flex",
              alignItems: "center",
            }}
          >
            <HomeIcon style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8,cursor:"pointer" }} onClick={() => navigate("/admin")}/>
            <TitleBreadcrumb
              breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin" },
                { type: "link", label: "Tickets", to: "/ticket-management" },
                { type: "text", label: ticketInfo.summary },
              ]}
            />
          </Box>

        {/* Title and Resolve/Re-Open Button */}
<Box
  sx={{
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    mb: 3,
  }}
>
  <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
    <IconButton
      size="small"
      onClick={handleBack}
      sx={{ color: "#4390F8", p: 0.7, border: "1px solid #409BFF" }}
    >
      <ArrowUturnLeftIcon style={{ width: 20, height: 20 }} />
    </IconButton>

    <Typography
      sx={{
        fontWeight: 700,
        fontFamily: "Open Sans",
        fontSize: "24px",
        color: "#111827",
      }}
    >
      [ID:{ticketInfo.id}] {ticketInfo.summary}
    </Typography>
    |
    <PencilSquareIcon style={{ width: 24, height: 24, color: "#9A9A9A" }} />
  </Box>
 <Box>
  {/* Resolve/Re-Open Button */}
  <button
    onClick={() => {
      if (ticketClosed && !submittedUpdates.some(u => u.reopened)) {
        // If ticket is closed and NOT reopened, show re-open form
        setShowReopenForm({ [submittedUpdates[0]?.id]: true });
      } else if (!ticketClosed) {
        // If ticket is open (initial state), show resolve form
        handleResolveTicket();
      }
      // If reopened (In Progress displayed), do nothing (disabled)
    }}
    disabled={
      showResolveForm || 
      Object.values(showReopenForm).some(val => val) ||
      submittedUpdates.some(u => u.reopened) // Disabled when reopened
    }
    style={{
      backgroundColor: 
        showResolveForm || Object.values(showReopenForm).some(val => val) || submittedUpdates.some(u => u.reopened)
          ? "#9CA3AF"
          : ticketClosed && !submittedUpdates.some(u => u.reopened)
          ? "#F9DEDC"
          : "#10B981",
      color: 
        submittedUpdates.some(u => u.reopened) || (!ticketClosed && !showResolveForm)
          ? "#fff"
          : ticketClosed
          ? "#8A0101"
          : "#fff",
      border: 
        ticketClosed && !submittedUpdates.some(u => u.reopened)
          ? "1px solid #8A0101"
          : "none",
      padding: "8px 20px",
      borderRadius: "6px",
      fontWeight: 700,
      cursor: 
        showResolveForm || 
        Object.values(showReopenForm).some(val => val) ||
        submittedUpdates.some(u => u.reopened)
          ? "not-allowed"
          : "pointer",
      fontFamily: "Open Sans",
      fontSize: "14px",
      opacity: 
        showResolveForm || 
        Object.values(showReopenForm).some(val => val) ||
        submittedUpdates.some(u => u.reopened)
          ? 0.6
          : 1,
      display: "flex",
      alignItems: "center",
      gap: "8px",
    }}
  >
    <svg
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="20 6 9 17 4 12" />
    </svg>
    {submittedUpdates.some(u => u.reopened)
      ? "Resolve Ticket"
      : ticketClosed
      ? "Re-Open Ticket"
      : "Resolve Ticket"}
  </button>
</Box>

</Box>


          {/* Main Content Grid */}
          <Grid container spacing={1.5} sx={{ alignItems: "flex-start" }}>
            {/* Left Section - Progress Feed and Billing */}
            <Grid size={{ xs: 12, sm: 12, md: 12, lg: 12, xl: 9 }}>
              {/* SLA Alert */}
              {showSLABox && (
              <Box
                sx={{
                  backgroundColor: "#FEF2F2",
                  border: "1px solid #FECACA",
                  borderRadius: 1,
                  p: 2,
                  mb: 2,
                  display: "flex",
                  alignItems: "flex-start",
                  justifyContent: "space-between",
                  gap: 2,
                }}
              >
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "flex-start",
                    gap: 1.5,
                    flex: 1,
                  }}
                >
                  <Box sx={{ mt: 2 }}>
                    <ExclamationTriangleIcon
                      style={{ width: 22, height: 22, color: "#DC2626" }}
                    />
                  </Box>
                  <Box>
                    <Typography
                      sx={{
                        fontSize: 16,
                        fontWeight: 700,
                        color: "#991B1B",
                        fontFamily: "Open Sans",
                        lineHeight: 1.5,
                      }}
                    >
                      Service Level Agreement - Critical
                    </Typography>
                    <Typography
                      sx={{
                        fontSize: 14,
                        color: "#991B1B",
                        fontFamily: "Open Sans",
                        lineHeight: 1.5,
                        mt: 0.5,
                      }}
                    >
                      Response Target: 9/17/2025 22:17 | Resolution Target:
                      9/18/2025 14:47
                    </Typography>
                  </Box>
                </Box>

                <Chip
                  label="-48:02"
                  sx={{
                    backgroundColor: "#FFBFB1",
                    color: "#FF0202",
                    fontWeight: 700,
                    fontFamily: "Open Sans",
                    fontSize: 14,
                    height: 28,
                    flexShrink: 0,
                    mt: 0.5,
                  }}
                />
              </Box>
              )}

              {/* Tabs */}
              <Box sx={{ mb: 2 }}>
                <Tabs
                  value={tab}
                  onChange={handleTabChange}
                  TabIndicatorProps={{
                    style: { backgroundColor: "#409BFF" },
                  }}
                  sx={{
                    "& .MuiTab-root": {
                      color: "#6B7280",
                    },
                    "& .Mui-selected": {
                      color: "#409BFF",
                    },
                  }}
                >
                  <Tab
                    label="Progress Feed"
                    value={tabValue[0]}
                    sx={{
                      fontWeight: 600,
                      mr: 2,
                      fontFamily: "Open Sans",
                      textTransform: "none",
                      fontSize: 15,
                      color: tab === tabValue[0] ? "#409BFF" : "#6B7280",
                    }}
                  />
                  <Tab
                    label="Billing"
                    value={tabValue[1]}
                    sx={{
                      fontWeight: 600,
                      mr: 2,
                      fontFamily: "Open Sans",
                      textTransform: "none",
                      fontSize: 15,
                      color: tab === tabValue[1] ? "#409BFF" : "#6B7280",
                    }}
                  />
                </Tabs>
              </Box>

              {/* Tab Content */}
             {tab === tabValue[0] && (
  <>
{/* Display Submitted Updates (Closed Tickets) */}
{submittedUpdates.map((update, index) => (
  <React.Fragment key={update.id}>
    {/* Re-Open Form - Shows FIRST when Re-Open button is clicked */}
    {showReopenForm[update.id] && index === 0 && (
      <Box
        sx={{
          border: "1px solid #E5E7EB",
          borderRadius: "8px",
          backgroundColor: "#FFFFFF",
          boxShadow: "0px 1px 2px 0px #0000000D",
          mb: 2,
        }}
      >
        {/* Header Section */}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 2,
            p: 2,
          }}
        >
          <Avatar  src="https://randomuser.me/api/portraits/men/20.jpg" sx={{ width: 48, height: 48 }}>BW</Avatar>
          <Box>
            <Typography
              sx={{
                fontWeight: 400,
                fontFamily: "Open Sans",
                fontSize: 16,
                color: "#111827",
              }}
            >
              Bruce Wayne
            </Typography>
            <Typography
              sx={{
                fontWeight: 600,
                fontFamily: "Open Sans",
                fontSize: 14,
                color: "#10B981",
                mt: 0.5,
              }}
            >
              | Re-Open Ticket
            </Typography>
          </Box>
        </Box>

        {/* To Email Section */}
        <Box sx={{ p: 3}}>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <Typography
              sx={{
                fontSize: 16,
                fontWeight: 600,
                fontFamily: "Open Sans",
                color: "#000000",
                minWidth: "30px",
              }}
            >
              To:
            </Typography>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 0.5,
                backgroundColor: "#E0E0E0",
                px: 1.5,
                py: 0.5,
                borderRadius: "4px",
              }}
            >
              <Typography
                sx={{
                  fontSize: 14,
                  fontFamily: "Open Sans",
                  color: "#000000",
                }}
              >
                {reopenEmail}
              </Typography>
              <IconButton
                size="small"
                onClick={() => setReopenEmail("")}
                sx={{ p: 0, ml: 0.5 }}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M18 6L6 18M6 6l12 12"
                    stroke="#000000"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </IconButton>
            </Box>
          </Box>
        </Box>

        {/* Text Editor with Toolbar */}
        <Box sx={{ p: 2 }}>
          <Box
            sx={{
              border: "1px solid #D1D5DB",
              borderRadius: "4px",
              overflow: "hidden",
            }}
          >
            {/* Toolbar */}
            <Box
              sx={{
                borderBottom: "1px solid #D1D5DB",
                backgroundColor: "#F2F8FF",
                p: 1.2,
                display: "flex",
                gap: 0.5,
              }}
            >
              <IconButton
                size="small"
                onClick={handleBold}
                sx={{
                  p: 0.5,
                  minWidth: 28,
                  height: 28,
                  backgroundColor: isBold ? "#E5E7EB" : "transparent",
                  borderRadius: "4px",
                  "&:hover": { backgroundColor: "#E5E7EB" },
                }}
              >
                <BoldIcon style={{ width: 16, height: 16, color: "#000000" }} />
              </IconButton>

              <IconButton
                size="small"
                onClick={handleItalic}
                sx={{
                  p: 0.5,
                  minWidth: 28,
                  height: 28,
                  backgroundColor: isItalic ? "#E5E7EB" : "transparent",
                  borderRadius: "4px",
                  "&:hover": { backgroundColor: "#E5E7EB" },
                }}
              >
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="#000000"
                  strokeWidth="2"
                >
                  <path d="M19 4h-9M14 20H5M15 4L9 20" />
                </svg>
              </IconButton>

              <IconButton
                size="small"
                onClick={handleUnderline}
                sx={{
                  p: 0.5,
                  minWidth: 28,
                  height: 28,
                  backgroundColor: isUnderline ? "#E5E7EB" : "transparent",
                  borderRadius: "4px",
                  "&:hover": { backgroundColor: "#E5E7EB" },
                }}
              >
                <UnderlineIcon style={{ width: 16, height: 16, color: "#000000" }} />
              </IconButton>

              <IconButton
                size="small"
                onClick={handleAlignLeft}
                sx={{
                  p: 0.5,
                  minWidth: 28,
                  height: 28,
                  backgroundColor: textAlign === "left" ? "#E5E7EB" : "transparent",
                  borderRadius: "4px",
                  "&:hover": { backgroundColor: "#E5E7EB" },
                }}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"
                    stroke="#000000"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </IconButton>

              <IconButton
                size="small"
                onClick={handleAlignRight}
                sx={{
                  p: 0.5,
                  minWidth: 28,
                  height: 28,
                  backgroundColor: textAlign === "center" ? "#E5E7EB" : "transparent",
                  borderRadius: "4px",
                  "&:hover": { backgroundColor: "#E5E7EB" },
                }}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M3 6h18M3 12h18M3 18h18"
                    stroke="#000000"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </IconButton>
            </Box>

            {/* Text Input */}
            <TextField
              fullWidth
              multiline
              rows={4}
              value={reopenNote}
              onChange={(e) => setReopenNote(e.target.value)}
              placeholder="Type your update/note here..."
              sx={{
                "& .MuiOutlinedInput-root": {
                  fontSize: 14,
                  fontFamily: "Open Sans",
                  fontWeight: isBold ? 700 : 400,
                  fontStyle: isItalic ? "italic" : "normal",
                  textDecoration: isUnderline ? "underline" : "none",
                  textAlign: textAlign,
                  "& fieldset": {
                    border: "none",
                  },
                  "&:hover fieldset": {
                    border: "none",
                  },
                  "&.Mui-focused fieldset": {
                    border: "none",
                  },
                },
              }}
            />
          </Box>
        </Box>

        {/* Form Fields */}
        <Grid container spacing={2} sx={{ px: 2, pb: 2 }}>
          <Grid size={{ xs: 12, sm: 12, md: 12, xl: 4 }}>
            <Typography
              sx={{
                fontSize: 14,
                fontWeight: 600,
                fontFamily: "Open Sans",
                color: "#374151",
                mb: 1,
              }}
            >
              Status*
            </Typography>
            <FormControl fullWidth>
              <Select
                value={reopenStatus}
                onChange={(e) => setReopenStatus(e.target.value)}
                MenuProps={menuProps}
                sx={{
                  height: 44,
                  fontSize: 14,
                  fontFamily: "Open Sans",
                  "& .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#D1D5DB",
                  },
                  "&:hover .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#D1D5DB",
                  },
                }}
              >
                <MenuItem value="In Progress">In Progress</MenuItem>
                <MenuItem value="On Hold">On Hold</MenuItem>
                <MenuItem value="Pending">Pending</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          <Grid size={{ xs: 12, sm: 12, md: 12, xl: 4 }}>
            <Typography
              sx={{
                fontSize: 14,
                fontWeight: 600,
                fontFamily: "Open Sans",
                color: "#374151",
                mb: 1,
              }}
            >
              Team*
            </Typography>
            <FormControl fullWidth>
              <Select
                value={reopenChargeType}
                MenuProps={menuProps}
                onChange={(e) => setReopenChargeType(e.target.value)}
                sx={{
                  height: 44,
                  fontSize: 14,
                  fontFamily: "Open Sans",
                  "& .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#D1D5DB",
                  },
                  "&:hover .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#D1D5DB",
                  },
                }}
              >
                <MenuItem value="No Charge">No Charge</MenuItem>
                <MenuItem value="Standard">Standard</MenuItem>
                <MenuItem value="Premium">Premium</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          <Grid size={{ xs: 12, sm: 12, md: 12, xl: 4 }}>
            <Typography
              sx={{
                fontSize: 14,
                fontWeight: 600,
                fontFamily: "Open Sans",
                color: "#374151",
                mb: 1,
              }}
            >
              Agent*
            </Typography>
            <FormControl fullWidth>
              <Select
                value="Backup Restored"
                MenuProps={menuProps}
                sx={{
                  height: 44,
                  fontSize: 14,
                  fontFamily: "Open Sans",
                  "& .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#D1D5DB",
                  },
                  "&:hover .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#D1D5DB",
                  },
                }}
              >
                <MenuItem value="Backup Restored">Backup Restored</MenuItem>
                <MenuItem value="Issue Resolved">Issue Resolved</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>

        {/* Action Buttons */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "flex-end",
            gap: 2,
            p: 2,
            borderTop: "1px solid #E5E7EB",
          }}
        >
         
          <Button
            onClick={() => handleReopenUpdate(update.id)}
            variant="contained"
            sx={{
              backgroundColor: "#409BFF",
              color: "#FFFFFF",
              fontFamily: "Open Sans",
              fontWeight: 600,
              fontSize: 14,
              borderRadius: "16px",
              height: "44px",
              px: 4,
              textTransform: "none",
              boxShadow: "none",
              "&:hover": {
                backgroundColor: "#2563EB",
              },
            }}
          >
            Send Update
          </Button>
           <Button
            onClick={() => handleDiscardReopen(update.id)}
            variant="contained"
            sx={{
              backgroundColor: "#FF5E5E",
              color: "#FFFFFF",
              fontFamily: "Open Sans",
              fontWeight: 600,
              fontSize: 14,
              borderRadius: "16px",
              height: "44px",
              px: 4,
              textTransform: "none",
              boxShadow: "none",
              "&:hover": {
                backgroundColor: "#E54545",
              },
            }}
          >
            Discard
          </Button>
        </Box>
      </Box>
    )}

  {/* Re-Opened Status Display - Shows FIRST after submitting */}
{update.reopened && update.reopenData && index === 0 && (
  <Box
    sx={{
      border: "1px solid #E5E7EB",
      borderRadius: "8px",
      backgroundColor: "#FFFFFF",
      boxShadow: "0px 1px 2px 0px #0000000D",
      mb: 2,
    }}
  >
    {/* Header */}
    <Box 
      sx={{ 
        p: 2,
        display: "flex",
        justifyContent: "space-between",
        alignItems: "flex-start"
      }}
    >
      <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
        <Avatar src="https://randomuser.me/api/portraits/men/20.jpg" sx={{ width: 48, height: 48 }}>BW</Avatar>
        <Box>
          <Typography
            sx={{
              fontWeight: 400,
              fontFamily: "Open Sans",
              fontSize: 16,
              color: "#111827",
            }}
          >
            Bruce Wayne
          </Typography>
          <Typography
            sx={{
              fontWeight: 600,
              fontSize: 14,
              fontFamily: "Open Sans",
              color: "#CC6900",
              mt: 0.5,
            }}
          >
            | Re-Open
          </Typography>
        </Box>
      </Box>
      
      {/* Timestamp in Right Corner */}
      <Typography
        sx={{
          fontSize: 16,
          color: "#929292",
          fontFamily: "Open Sans",
        }}
      >
        {update.reopenData.timestamp}
      </Typography>
    </Box>

    {/* Content */}
    <Box sx={{ p: 2 }}>
      <Box
        sx={{
          backgroundColor: "#DBECFF",
          borderRadius: "8px",
          p: 2,
          maxWidth: "300px",
          border: "1px solid #DBECFF"
        }}
      >
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1,
            mb: 1.5,
            border:"1px solid #FFFFFF",
            width:"150px",
            p:0.5,
            background:"#FFFFFF"
          }}
        >
          {/* Check Icon from Heroicons */}
          <CheckCircleIcon style={{height:"20px", width:"20px", color:"#409BFF"}}/>
          <Typography
            sx={{
              fontSize: 14,
              fontFamily: "Open Sans",
              color: "#4B4B4B",
              fontWeight: 400,
            }}
          >
            {update.reopenData.status}
          </Typography>
        </Box>
        <Typography
          sx={{
            fontSize: 16,
            fontFamily: "Open Sans",
            color: "#000",
          }}
        >
          <strong>To:</strong> {update.reopenData.email}
        </Typography>
      </Box>
    </Box>
  </Box>
)}


    {/* Main Closed Ticket Box */}
    <Box
      sx={{
        border: "1px solid #E5E7EB",
        borderRadius: "8px",
        backgroundColor: "#FFFFFF",
        boxShadow: "0px 1px 2px 0px #0000000D",
        mb: 2,
      }}
    >
   {/* Header Section */}
<Box
  sx={{
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 2,
    p: 2,
  }}
>
  <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
    <Avatar 
      src="https://randomuser.me/api/portraits/men/20.jpg" 
      sx={{ width: 48, height: 48 }}
    >
      BW
    </Avatar>
    <Box>
      <Typography
        sx={{
          fontWeight: 400,
          fontFamily: "Open Sans",
          fontSize: 16,
          color: "#111827",
        }}
      >
        Bruce Wayne
      </Typography>
      <Typography
        sx={{
          fontWeight: 600,
          fontFamily: "Open Sans",
          fontSize: 14,
          color: "#DC2626",
          mt: 0.5,
        }}
      >
        | Closed
      </Typography>
    </Box>
  </Box>

  {/* Timestamp in Right Corner - Use update.timestamp instead */}
  <Typography
    sx={{
      fontSize: 16,
      color: "#929292",
      fontFamily: "Open Sans",
    }}
  >
    {update.timestamp}
  </Typography>
</Box>


      {/* Content Area with Padding */}
      <Box sx={{ p: 2 }}>
        {/* Info Box - Light Blue with Rounded Corners */}
        <Box
          sx={{
            backgroundColor: "#DBECFF",
            borderRadius: "8px",
            p: 2,
            mb: 2,
            maxWidth: "300px",
          }}
        >
          <Typography
            sx={{
              fontSize: 16,
              fontFamily: "Open Sans",
              color: "#000",
              mb: 0.8,
            }}
          >
            <strong>Time Taken :</strong> {update.timeTaken}(travel)
          </Typography>
          <Typography
            sx={{
              fontSize: 16,
              fontFamily: "Open Sans",
              color: "#000",
              mb: 2,
            }}
          >
            <strong>Billed Hours:</strong> {update.timeTaken}
          </Typography>
          <Typography
            sx={{
              fontSize: 16,
              fontFamily: "Open Sans",
              color: "#000",
            }}
          >
            <strong>To:</strong> {update.email}
          </Typography>
        </Box>

        {/* Description Box - Lighter Blue with Rounded Corners */}
        <Box
          sx={{
            backgroundColor: "#DBECFF",
            borderRadius: "8px",
            p: 2,
          }}
        >
          <Typography
            sx={{
              fontSize: 16,
              fontFamily: "Open Sans",
              color: "#242424",
              lineHeight: 1.6,
              whiteSpace: "pre-wrap",
            }}
          >
            {update.note}
          </Typography>
        </Box>
      </Box>
    </Box>
  </React.Fragment>
))}




    {/* Resolve Ticket Form */}
    {showResolveForm && (
      <Box
        sx={{
          border: "1px solid #E5E7EB",
          borderRadius: 1,
          backgroundColor: "#FFFFFF",
          boxShadow: "0px 1px 2px 0px #0000000D",
          mb: 2,
        }}
      >
        {/* Header Section */}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 2,
            p: 2,
          }}
        >
          <Avatar src="https://randomuser.me/api/portraits/men/20.jpg"  sx={{ width: 48, height: 48 }}>BW</Avatar>
          <Box>
            <Typography
              sx={{
                fontWeight: 400,
                fontFamily: "Open Sans",
                fontSize: 16,
                color: "#111827",
              }}
            >
              Bruce Wayne
            </Typography>
            <Typography
              sx={{
                fontWeight: 600,
                fontFamily: "Open Sans",
                fontSize: 14,
                color: "#10B981",
                mt: 0.5,
              }}
            >
              | Resolve Ticket
            </Typography>
          </Box>
        </Box>

        {/* To Email Section */}
        <Box sx={{ p: 2 }}>
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 1,
            }}
          >
            <Typography
              sx={{
                fontSize: 16,
                fontWeight: 600,
                fontFamily: "Open Sans",
                color: "#000000",
                minWidth: "30px",
              }}
            >
              To:
            </Typography>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 0.5,
                backgroundColor: "#E0E0E0",
                px: 1.5,
                py: 0.5,
                borderRadius: "4px",
              }}
            >
              <Typography
                sx={{
                  fontSize: 14,
                  fontFamily: "Open Sans",
                  color: "#000000",
                }}
              >
                {resolveEmail}
              </Typography>
              <IconButton
                size="small"
                onClick={handleRemoveEmail}
                sx={{ p: 0, ml: 0.5 }}
              >
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                >
                  <path
                    d="M18 6L6 18M6 6l12 12"
                    stroke="#000000"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </IconButton>
            </Box>
          </Box>
        </Box>

        {/* Text Editor with Toolbar */}
        <Box sx={{ p: 2 }}>
          <Box
            sx={{
              border: "1px solid #D1D5DB",
              borderRadius: "4px",
              overflow: "hidden",
            }}
          >
            {/* Toolbar */}
            <Box
              sx={{
                borderBottom: "1px solid #D1D5DB",
                backgroundColor: "#F2F8FF",
                p: 1,
                display: "flex",
                gap: 0.5,
              }}
            >
              <IconButton
                size="small"
                onClick={handleBold}
                sx={{
                  p: 0.5,
                  minWidth: 28,
                  height: 28,
                  backgroundColor: isBold ? "#E5E7EB" : "transparent",
                  borderRadius: "4px",
                  "&:hover": { backgroundColor: "#E5E7EB" },
                }}
              >
                <BoldIcon style={{ width: 16, height: 16, color: "#000000" }} />
              </IconButton>

              <IconButton
                size="small"
                onClick={handleItalic}
                sx={{
                  p: 0.5,
                  minWidth: 28,
                  height: 28,
                  backgroundColor: isItalic ? "#E5E7EB" : "transparent",
                  borderRadius: "4px",
                  "&:hover": { backgroundColor: "#E5E7EB" },
                }}
              >
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="#000000"
                  strokeWidth="2"
                >
                  <path d="M19 4h-9M14 20H5M15 4L9 20" />
                </svg>
              </IconButton>

              <IconButton
                size="small"
                onClick={handleUnderline}
                sx={{
                  p: 0.5,
                  minWidth: 28,
                  height: 28,
                  backgroundColor: isUnderline ? "#E5E7EB" : "transparent",
                  borderRadius: "4px",
                  "&:hover": { backgroundColor: "#E5E7EB" },
                }}
              >
                <UnderlineIcon style={{ width: 16, height: 16, color: "#000000" }} />
              </IconButton>

              <IconButton
                size="small"
                onClick={handleAlignLeft}
                sx={{
                  p: 0.5,
                  minWidth: 28,
                  height: 28,
                  backgroundColor: textAlign === "left" ? "#E5E7EB" : "transparent",
                  borderRadius: "4px",
                  "&:hover": { backgroundColor: "#E5E7EB" },
                }}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"
                    stroke="#000000"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </IconButton>

              <IconButton
                size="small"
                onClick={handleAlignRight}
                sx={{
                  p: 0.5,
                  minWidth: 28,
                  height: 28,
                  backgroundColor: textAlign === "center" ? "#E5E7EB" : "transparent",
                  borderRadius: "4px",
                  "&:hover": { backgroundColor: "#E5E7EB" },
                }}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M3 6h18M3 12h18M3 18h18"
                    stroke="#000000"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </IconButton>
            </Box>

            {/* Text Input */}
            <TextField
              fullWidth
              multiline
              rows={4}
              value={resolveNote}
              onChange={(e) => setResolveNote(e.target.value)}
              placeholder="Type your update/note here..."
              sx={{
                "& .MuiOutlinedInput-root": {
                  fontSize: 14,
                  fontFamily: "Open Sans",
                  fontWeight: isBold ? 700 : 400,
                  fontStyle: isItalic ? "italic" : "normal",
                  textDecoration: isUnderline ? "underline" : "none",
                  textAlign: textAlign,
                  "& fieldset": {
                    border: "none",
                  },
                  "&:hover fieldset": {
                    border: "none",
                  },
                  "&.Mui-focused fieldset": {
                    border: "none",
                  },
                },
              }}
            />
          </Box>
        </Box>

        {/* Form Fields */}
        <Grid container spacing={2} sx={{ px: 2, pb: 2 }}>
          <Grid size={{ xs: 12, sm: 12, md: 12, xl: 4 }}>
            <Typography
              sx={{
                fontSize: 14,
                fontWeight: 600,
                fontFamily: "Open Sans",
                color: "#374151",
                mb: 1,
              }}
            >
              Time Taken*
            </Typography>
            <TextField
              fullWidth
              value={timeTaken}
              onChange={(e) => setTimeTaken(e.target.value)}
              sx={{
                "& .MuiOutlinedInput-root": {
                  height: 44,
                  fontSize: 14,
                  fontFamily: "Open Sans",
                  "& fieldset": {
                    borderColor: "#D1D5DB",
                  },
                  "&:hover fieldset": {
                    borderColor: "#D1D5DB",
                  },
                },
              }}
            />
          </Grid>

          <Grid size={{ xs: 12, sm: 12, md: 12, xl: 4 }}>
            <Typography
              sx={{
                fontSize: 14,
                fontWeight: 600,
                fontFamily: "Open Sans",
                color: "#374151",
                mb: 1,
              }}
            >
              Charge Type*
            </Typography>
            <FormControl fullWidth>
              <Select
                value={chargeType}
                MenuProps={menuProps}
                onChange={(e) => setChargeType(e.target.value)}
                sx={{
                  height: 44,
                  fontSize: 14,
                  fontFamily: "Open Sans",
                  "& .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#D1D5DB",
                  },
                  "&:hover .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#D1D5DB",
                  },
                }}
              >
                <MenuItem value="No Charge">No Charge</MenuItem>
                <MenuItem value="Standard">Standard</MenuItem>
                <MenuItem value="Premium">Premium</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          <Grid size={{ xs: 12, sm: 12, md: 12, xl: 4 }}>
            <Typography
              sx={{
                fontSize: 14,
                fontWeight: 600,
                fontFamily: "Open Sans",
                color: "#374151",
                mb: 1,
              }}
            >
              Resolution Code
            </Typography>
            <FormControl fullWidth>
              <Select
              MenuProps={menuProps}
                value={resolutionCode}
                onChange={(e) => setResolutionCode(e.target.value)}
                sx={{
                  height: 44,
                  fontSize: 14,
                  fontFamily: "Open Sans",
                  "& .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#D1D5DB",
                  },
                  "&:hover .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#D1D5DB",
                  },
                }}
              >
                <MenuItem value="Backup Restored">Backup Restored</MenuItem>
                <MenuItem value="Issue Resolved">Issue Resolved</MenuItem>
                <MenuItem value="User Error">User Error</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>

        {/* Action Buttons */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "flex-end",
            gap: 2,
            p: 2,
            borderTop: "1px solid #E5E7EB",
          }}
        >
        
          <Button
            onClick={handleSendUpdate}
            variant="contained"
            sx={{
              backgroundColor: "#409BFF",
              color: "#FFFFFF",
              fontFamily: "Open Sans",
              fontWeight: 600,
              fontSize: 14,
              borderRadius: "16px",
              height: "44px",
              px: 4,
              textTransform: "none",
              boxShadow: "none",
              "&:hover": {
                backgroundColor: "#2563EB",
              },
            }}
          >
            Send Update
          </Button>
            <Button
            onClick={handleDiscard}
            variant="contained"
            sx={{
              backgroundColor: "#FF5E5E",
              color: "#FFFFFF",
              fontFamily: "Open Sans",
              fontWeight: 600,
              fontSize: 14,
              borderRadius: "16px",
              height: "44px",
              px: 4,
              textTransform: "none",
              boxShadow: "none",
              "&:hover": {
                backgroundColor: "#E54545",
              },
            }}
          >
            Discard
          </Button>
        </Box>
      </Box>
    )}

    {/* Original Progress Feed Box */}
    <Box
      sx={{
        border: "1px solid #E5E7EB",
        borderRadius: 1,
        p: 2,
        backgroundColor: "#FFFFFF",
        boxShadow: "0px 1px 2px 0px #0000000D",
      }}
    >
      <Box sx={{ display: "flex", gap: 2 }}>
        <Avatar src="https://randomuser.me/api/portraits/men/20.jpg" sx={{ width: 40, height: 40 }}>BW</Avatar>
        <Box sx={{ flex: 1 }}>
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 4,
              mb: 1,
            }}
          >
            <Typography
              sx={{
                fontWeight: 500,
                fontFamily: "Open Sans",
                fontSize: 16,
              }}
            >
              Bruce Wayne
            </Typography>
            <Typography
              sx={{
                fontSize: 14,
                color: "#6B7280",
                fontFamily: "Open Sans",
              }}
            >
              {ticketInfo.dateCreated}
            </Typography>
          </Box>
          <Box sx={{ display: "flex", gap: 1, pb: 1 }}>
            <Chip
              label="Opened"
              size="small"
              sx={{
                backgroundColor: "#DBEAFE",
                color: "#1E40AF",
                fontWeight: 500,
                fontFamily: "Open Sans",
              }}
            />
            <Chip
              label="New"
              size="small"
              sx={{
                backgroundColor: "#F3F4F6",
                color: "#1F2937",
                fontWeight: 500,
                fontFamily: "Open Sans",
              }}
            />
          </Box>
          <Typography
            sx={{
              fontSize: 16,
              color: "#374151",
              fontFamily: "Open Sans",
              fontWeight: "600",
            }}
          >
            Ticket created for {ticketInfo.summary.toLowerCase()} reported by Theresa Samuels.
          </Typography>
        </Box>
      </Box>
    </Box>
  </>
)}


              {tab === tabValue[1] && (
                <>
                  {/* Billing Tables Section */}
                  <Grid
                    sx={{
                      border: "1px solid #E5E7EB",
                      p: 3,
                      boxShadow: "0px 1px 2px 0px #0000000D",
                    }}
                    size={{ xs: 12, sm: 12, md: 12, lg: 12, xl: 12 }}
                  >
                    <Box>
                      <Typography
                        sx={{
                          fontSize: 14,
                          color: "#000",
                          fontFamily: "Open Sans",
                          mb: 3,
                        }}
                      >
                        The table below shows the time logged for each Charge
                        Type. When edited the time entries remain but the time
                        allocated towards billing is overridden.
                      </Typography>

                      {/* Bill Section Header with Divider */}
                      <Box
                        sx={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                          mb: 2,
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: 19,
                            fontWeight: 700,
                            color: "#409BFF",
                            fontFamily: "Open Sans",
                          }}
                        >
                          Bill
                        </Typography>
                        <Button
                          variant="contained"
                          startIcon={
                            <PlusIcon style={{ width: 16, height: 16 }} />
                          }
                          onClick={handleOpenBillingDialog}
                          sx={{
                            backgroundColor: "#409BFF",
                            color: "#fff",
                            textTransform: "none",
                            fontFamily: "Open Sans",
                            fontWeight: 400,
                            fontSize: 14,
                            px: 2,
                            py: 0.75,
                            borderRadius: "6px",
                            "&:hover": {
                              backgroundColor: "#2563EB",
                            },
                          }}
                        >
                          Add
                        </Button>
                      </Box>

                      {/* Charge Types Table */}
                      <Box sx={{ borderRadius: 1, overflow: "hidden", mb: 3 }}>
                        <table
                          style={{
                            width: "100%",
                            borderCollapse: "collapse",
                            fontFamily: "Open Sans",
                          }}
                        >
                          <thead style={{ backgroundColor: "#F0F0F0" }}>
                            <tr>
                              <th
                                style={{
                                  padding: "12px 16px",
                                  textAlign: "left",
                                  fontSize: 14,
                                  fontWeight: 600,
                                  color: "#00000099",
                                }}
                              >
                                Change Type ▼
                              </th>
                              <th
                                style={{
                                  padding: "12px 16px",
                                  textAlign: "left",
                                  fontSize: 14,
                                  fontWeight: 600,
                                  color: "#00000099",
                                }}
                              >
                                Actual Time ▼
                              </th>
                              <th
                                style={{
                                  padding: "12px 16px",
                                  textAlign: "left",
                                  fontSize: 14,
                                  fontWeight: 600,
                                  color: "#00000099",
                                }}
                              >
                                Contract/Billable Time ▼
                              </th>
                              <th
                                style={{
                                  padding: "12px 16px",
                                  textAlign: "left",
                                  fontSize: 14,
                                  fontWeight: 600,
                                  color: "#00000099",
                                }}
                              >
                                Overriding Actual Time ▼
                              </th>
                              <th
                                style={{ padding: "12px 16px", width: "80px" }}
                              ></th>
                            </tr>
                          </thead>
                          <tbody >
                            {chargeTypes.map((item, index) => (
                              <BillingTableRow
                                key={index}
                                item={item}
                                index={index}
                                isLast={index === chargeTypes.length - 1}
                                onEdit={() => {
                                  setSelectedBillItem(item);
                                  setOpenEditBillDialog(true);
                                }}
                                onDelete={() => {
                                  setSelectedBillItem(item);
                                  setOpenDeleteBillDialog(true);
                                }}
                              />
                            ))}
                          </tbody>
                        </table>
                      </Box>

                      <Divider sx={{ my: 3 }} />

                      {/* Expenses Section */}
                      <Box sx={{ mb: 3 }}>
                        <Box
                          sx={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            mb: 2,
                          }}
                        >
                          <Typography
                            sx={{
                              fontSize: 19,
                              fontWeight: 700,
                              color: "#409BFF",
                              fontFamily: "Open Sans",
                            }}
                          >
                            Expenses
                          </Typography>
                          <Button
                            variant="contained"
                            startIcon={
                              <PlusIcon style={{ width: 16, height: 16 }} />
                            }
                            onClick={handleOpenExpenseDialog}
                            sx={{
                              backgroundColor: "#409BFF",
                              color: "#fff",
                              textTransform: "none",
                              fontFamily: "Open Sans",
                              fontWeight: 400,
                              fontSize: 14,
                              px: 2,
                              py: 0.75,
                              borderRadius: "6px",
                              "&:hover": {
                                backgroundColor: "#2563EB",
                              },
                            }}
                          >
                            Add
                          </Button>
                        </Box>

                        {/* Expenses Table */}
                        <Box sx={{ borderRadius: 1, overflow: "hidden" }}>
                          <table
                            style={{
                              width: "100%",
                              borderCollapse: "collapse",
                              fontFamily: "Open Sans",
                            }}
                          >
                            <thead style={{ backgroundColor: "#F0F0F0" }}>
                              <tr>
                                <th
                                  style={{
                                    padding: "12px 16px",
                                    textAlign: "left",
                                    fontSize: 14,
                                    fontWeight: 600,
                                    color: "#00000099",
                                  }}
                                >
                                  Agents ▼
                                </th>
                                <th
                                  style={{
                                    padding: "12px 16px",
                                    textAlign: "left",
                                    fontSize: 14,
                                    fontWeight: 600,
                                    color: "#00000099",
                                  }}
                                >
                                  Description ▼
                                </th>
                                <th
                                  style={{
                                    padding: "12px 16px",
                                    textAlign: "left",
                                    fontSize: 14,
                                    fontWeight: 600,
                                    color: "#00000099",
                                  }}
                                >
                                  Cost ▼
                                </th>
                                <th
                                  style={{
                                    padding: "12px 16px",
                                    textAlign: "left",
                                    fontSize: 14,
                                    fontWeight: 600,
                                    color: "#00000099",
                                  }}
                                >
                                  Expenses type ▼
                                </th>
                                <th
                                  style={{
                                    padding: "12px 16px",
                                    textAlign: "left",
                                    fontSize: 14,
                                    fontWeight: 600,
                                    color: "#00000099",
                                  }}
                                >
                                  Date Added ▼
                                </th>
                                <th
                                  style={{
                                    padding: "12px 16px",
                                    textAlign: "left",
                                    fontSize: 14,
                                    fontWeight: 600,
                                    color: "#00000099",
                                  }}
                                >
                                  Reviewed ▼
                                </th>
                                <th
                                  style={{
                                    padding: "12px 16px",
                                    width: "80px",
                                  }}
                                ></th>
                              </tr>
                            </thead>
                            <tbody>
                              {expenses.map((expense, index) => (
                                <ExpenseTableRow
                                  key={index}
                                  expense={expense}
                                  index={index}
                                  isLast={index === expenses.length - 1}
                                  onEdit={() => {
                                    setSelectedExpenseItem(expense);
                                    setOpenEditExpenseDialog(true);
                                  }}
                                  onDelete={() => {
                                    setSelectedExpenseItem(expense);
                                    setOpenDeleteExpenseDialog(true);
                                  }}
                                />
                              ))}
                            </tbody>
                          </table>
                        </Box>
                      </Box>
                    </Box>
                  </Grid>

                  {/* Invoice Details Section */}
                  <Grid
                    size={{ xs: 12, sm: 12, md: 12, lg: 12, xl: 12 }}
                    sx={{ mt: 3 }}
                  >
                    <Box
                      sx={{
                        border: "1px solid #E5E7EB",
                        borderRadius: 1,
                        p: 3,
                        backgroundColor: "#FFFFFF",
                        boxShadow: "0px 1px 2px 0px #0000000D",
                      }}
                    >
                      {/* Amount of hours invoiced */}
                      <Box
                        sx={{
                          display: "flex",
                          alignItems: "center",
                          mb: 3,
                          gap: 2,
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#000",
                            fontFamily: "Open Sans",
                            fontWeight: 400,
                          }}
                        >
                          Amount of hours invoiced so far
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#000",
                            fontFamily: "Open Sans",
                            fontWeight: 600,
                          }}
                        >
                          00:00
                        </Typography>
                      </Box>

                      {/* Invoice this Ticket separately Checkbox */}
                      <Box sx={{ mb: 3 }}>
                        <Box
                          sx={{
                            display: "flex",
                            alignItems: "flex-start",
                            gap: 1.5,
                          }}
                        >
                          <input
                            type="checkbox"
                            id="invoice-separately"
                            style={{
                              width: 16,
                              height: 16,
                              marginTop: 2,
                              cursor: "pointer",
                              accentColor: "#409BFF",
                            }}
                          />
                          <Box>
                            <label
                              htmlFor="invoice-separately"
                              style={{
                                fontSize: 14,
                                color: "#000",
                                fontFamily: "Open Sans",
                                fontWeight: 400,
                                cursor: "pointer",
                                display: "block",
                                marginBottom: 4,
                              }}
                            >
                              Invoice this Ticket separately
                            </label>
                            <Typography
                              sx={{
                                fontSize: 12,
                                color: "#9E9E9E",
                                fontFamily: "Open Sans",
                              }}
                            >
                              This Ticket will be put onto its own invoice
                            </Typography>
                          </Box>
                        </Box>
                      </Box>

                      {/* Invoice to this Client */}
                      <Box sx={{ mb: 3 }}>
                        <Box
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            gap: 1,
                          }}
                        >
                          <Typography
                            sx={{
                              fontSize: 14,
                              color: "#000",
                              fontFamily: "Open Sans",
                              fontWeight: 400,
                              mb: 1,
                            }}
                          >
                            Invoice to this Client
                          </Typography>
                          <select
                            style={{
                              flex: 0.2,
                              padding: "10px 12px",
                              border: "1px solid #D1D5DB",
                              borderRadius: "6px",
                              fontSize: 14,
                              fontFamily: "Open Sans",
                              color: "#9CA3AF",
                              backgroundColor: "#FFFFFF",
                              cursor: "pointer",
                              appearance: "none",
                              backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%239CA3AF'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E")`,
                              backgroundRepeat: "no-repeat",
                              backgroundPosition: "right 12px center",
                              backgroundSize: "20px",
                              paddingRight: "40px",
                              marginLeft: "90px",
                            }}
                            defaultValue=""
                          >
                            <option value="" disabled>
                              Not set
                            </option>
                            <option value="client1">Client 1</option>
                            <option value="client2">Client 2</option>
                          </select>
                          <IconButton
                            size="small"
                            sx={{
                              border: "1px solid #D1D5DB",
                              borderRadius: "6px",
                              p: 1.5,
                              "&:hover": {
                                backgroundColor: "#F9FAFB",
                              },
                            }}
                          >
                            <svg
                              width="16"
                              height="16"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="#6B7280"
                              strokeWidth="2"
                            >
                              <circle cx="11" cy="11" r="8" />
                              <path d="m21 21-4.35-4.35" />
                            </svg>
                          </IconButton>
                        </Box>
                      </Box>

                      {/* Purchase Order Number */}
                      <Box>
                        <Box
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            gap: 1,
                          }}
                        >
                          <Typography
                            sx={{
                              fontSize: 14,
                              color: "#000",
                              fontFamily: "Open Sans",
                              fontWeight: 400,
                              mb: 1,
                            }}
                          >
                            Purchase Order Number
                          </Typography>
                          <select
                            style={{
                              flex: 0.2,
                              padding: "10px 12px",
                              border: "1px solid #D1D5DB",
                              borderRadius: "6px",
                              fontSize: 14,
                              fontFamily: "Open Sans",
                              color: "#9CA3AF",
                              backgroundColor: "#FFFFFF",
                              cursor: "pointer",
                              appearance: "none",
                              backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%239CA3AF'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E")`,
                              backgroundRepeat: "no-repeat",
                              backgroundPosition: "right 12px center",
                              backgroundSize: "20px",
                              paddingRight: "40px",
                              marginLeft: "60px",
                            }}
                            defaultValue=""
                          >
                            <option value="" disabled>
                              Not set
                            </option>
                            <option value="po1">PO-001</option>
                            <option value="po2">PO-002</option>
                          </select>
                          <IconButton
                            size="small"
                            sx={{
                              border: "1px solid #D1D5DB",
                              borderRadius: "6px",
                              p: 1.5,
                              "&:hover": {
                                backgroundColor: "#F9FAFB",
                              },
                            }}
                          >
                            <svg
                              width="16"
                              height="16"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="#6B7280"
                              strokeWidth="2"
                            >
                              <circle cx="11" cy="11" r="8" />
                              <path d="m21 21-4.35-4.35" />
                            </svg>
                          </IconButton>
                        </Box>
                        <Typography
                          sx={{
                            fontSize: 12,
                            color: "#9CA3AF",
                            fontFamily: "Open Sans",
                            maxWidth: "230px",
                          }}
                        >
                          This is a free text field that is not linked to the
                          Purchase Orders feature
                        </Typography>
                      </Box>
                    </Box>
                  </Grid>
                </>
              )}
            </Grid>

            {/* Right Section - Sticky Sidebar */}
            <Grid size={{ xs: 12, sm: 12, md: 12, lg: 12, xl: 3 }}>
              <Box sx={{ position: "sticky", top: 16 }}>
                <Paper
                  sx={{ p: 2.5, border: "1px solid #E4E4E7" }}
                  elevation={0}
                >
                  {/* Timer Section */}
                 {/* Timer Section - UPDATED */}
<Box sx={{ textAlign: "center", mb: 2.5 }}>
  <Typography
    sx={{
      fontSize: 14,
      color: "#6B7280",
      mb: 1,
      fontFamily: "Open Sans",
    }}
  >
    Timer
  </Typography>
  <Typography
    sx={{
      fontSize: 24,
      fontWeight: 600,
      mb: 1.5,
      fontFamily: "Open Sans",
      color: "#111827",
    }}
  >
    {formatTime(timerSeconds)}  
  </Typography>
  <button
    onClick={handleToggleTimer} 
    style={{
      backgroundColor: isTimerRunning ? "#EF4444" : "#10B981",
      color: "#fff",
      border: "none",
      padding: "8px 40px",
      borderRadius: "6px",
      fontWeight: 500,
      cursor: "pointer",
      fontFamily: "Open Sans",
      fontSize: "14px",
    }}
  >
    {isTimerRunning ? "Stop" : "Start"}  {/* CHANGED THIS LINE */}
  </button>
</Box>


                  <Divider sx={{ my: 2.5 }} />

                  {/* Ticket Information Section */}
                  <Box sx={{ mb: 2.5 }}>
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        mb: 2,
                      }}
                    >
                      <Typography
                        sx={{
                          fontWeight: 600,
                          fontSize: 18,
                          fontFamily: "Open Sans",
                          color: "#111827",
                        }}
                      >
                        Ticket Information
                      </Typography>
                      <PencilSquareIcon
                        onClick={handleOpenEditDialog}
                        style={{
                          width: 16,
                          height: 16,
                          color: "#9CA3AF",
                          cursor: "pointer",
                        }}
                      />
                    </Box>

                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        gap: 1.5,
                      }}
                    >
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#6B7280",
                            fontFamily: "Open Sans",
                          }}
                        >
                          Date Created
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: 14,
                            fontWeight: 400,
                            fontFamily: "Open Sans",
                            textAlign: "right",
                            color: "#111827",
                          }}
                        >
                          {ticketInfo.dateCreated}
                        </Typography>
                      </Box>
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#6B7280",
                            fontFamily: "Open Sans",
                          }}
                        >
                          Ticket Type
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: 14,
                            fontWeight: 400,
                            fontFamily: "Open Sans",
                            textAlign: "right",
                            color: "#111827",
                          }}
                        >
                          {ticketInfo.ticketType}
                        </Typography>
                      </Box>
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#6B7280",
                            fontFamily: "Open Sans",
                          }}
                        >
                          Workflow
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: 14,
                            fontWeight: 400,
                            fontFamily: "Open Sans",
                            textAlign: "right",
                            color: "#111827",
                          }}
                        >
                          {ticketInfo.workflow}
                        </Typography>
                      </Box>
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#6B7280",
                            fontFamily: "Open Sans",
                          }}
                        >
                          Status
                        </Typography>
                        <Chip
                          label={ticketInfo.status}
                          size="small"
                          sx={{
                            backgroundColor: statusColor.bg,
                            color: statusColor.text,
                            fontWeight: 600,
                            fontFamily: "Open Sans",
                            fontSize: 12,
                            height: 22,
                          }}
                        />
                      </Box>
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#6B7280",
                            fontFamily: "Open Sans",
                          }}
                        >
                          Team
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: 14,
                            fontWeight: 400,
                            fontFamily: "Open Sans",
                            textAlign: "right",
                            color: "#111827",
                          }}
                        >
                          {ticketInfo.team}
                        </Typography>
                      </Box>
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#6B7280",
                            fontFamily: "Open Sans",
                          }}
                        >
                          Assigned Agent
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: 14,
                            fontWeight: 400,
                            fontFamily: "Open Sans",
                            textAlign: "right",
                            color: "#111827",
                          }}
                        >
                          {ticketInfo.assignedAgent}
                        </Typography>
                      </Box>
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#6B7280",
                            fontFamily: "Open Sans",
                          }}
                        >
                          Category
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: 14,
                            fontWeight: 400,
                            fontFamily: "Open Sans",
                            textAlign: "right",
                            color: "#111827",
                          }}
                        >
                          Hardware &gt; {ticketInfo.category}
                        </Typography>
                      </Box>
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#6B7280",
                            fontFamily: "Open Sans",
                          }}
                        >
                          Source
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: 14,
                            fontWeight: 400,
                            fontFamily: "Open Sans",
                            textAlign: "right",
                            color: "#111827",
                          }}
                        >
                          {ticketInfo.source}
                        </Typography>
                      </Box>
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#6B7280",
                            fontFamily: "Open Sans",
                          }}
                        >
                          Time Recorded
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: 14,
                            fontWeight: 400,
                            fontFamily: "Open Sans",
                            textAlign: "right",
                            color: "#111827",
                          }}
                        >
                          {ticketInfo.timeRecorded}
                        </Typography>
                      </Box>
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#6B7280",
                            fontFamily: "Open Sans",
                          }}
                        >
                          Estimated Time
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: 14,
                            fontWeight: 400,
                            fontFamily: "Open Sans",
                            textAlign: "right",
                            color: "#111827",
                          }}
                        >
                          {ticketInfo.estimatedTime}
                        </Typography>
                      </Box>
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#6B7280",
                            fontFamily: "Open Sans",
                          }}
                        >
                          Urgency
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: 14,
                            fontWeight: 400,
                            fontFamily: "Open Sans",
                            textAlign: "right",
                            color: "#111827",
                          }}
                        >
                          {ticketInfo.urgency}
                        </Typography>
                      </Box>
                    </Box>
                  </Box>

                  <Divider sx={{ my: 2.5 }} />

                  {/* End-User Details Section */}
                  <Box sx={{ mb: 2.5 }}>
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        mb: 2,
                      }}
                    >
                      <Typography
                        sx={{
                          fontWeight: 600,
                          fontSize: 18,
                          fontFamily: "Open Sans",
                          color: "#111827",
                        }}
                      >
                        End-User Details
                      </Typography>
                      <PencilSquareIcon
                      onClick={handleOpenEditEndUserDialog}
                        style={{
                          width: 16,
                          height: 16,
                          color: "#9CA3AF",
                          cursor: "pointer",
                        }}
                      />
                    </Box>

                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        gap: 2,
                        mb: 2,
                      }}
                    >
                      <Avatar
                        sx={{
                          width: 48,
                          height: 48,
                          backgroundColor: "#DBEAFE",
                          color: "#2563EB",
                          fontWeight: 600,
                          fontFamily: "Open Sans",
                        }}
                      >
                        TS
                      </Avatar>
                      <Box>
                        <Typography
                          sx={{
                            fontWeight: 600,
                            fontSize: 16,
                            fontFamily: "Open Sans",
                            color: "#111827",
                          }}
                        >
                          Theresa Samuels
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#6B7280",
                            fontFamily: "Open Sans",
                          }}
                        >
                          St Johns High School
                        </Typography>
                      </Box>
                    </Box>

                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        gap: 1.5,
                        mb: 2,
                      }}
                    >
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#6B7280",
                            fontFamily: "Open Sans",
                          }}
                        >
                          Site
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: 14,
                            fontWeight: 400,
                            fontFamily: "Open Sans",
                            textAlign: "right",
                            color: "#111827",
                          }}
                        >
                          {endUserData.site}
                        </Typography>
                      </Box>
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#6B7280",
                            fontFamily: "Open Sans",
                          }}
                        >
                          Email
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: 14,
                            fontWeight: 400,
                            fontFamily: "Open Sans",
                            textAlign: "right",
                            color: "#111827",
                          }}
                        >
                          {endUserData.email}
                        </Typography>
                      </Box>
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#6B7280",
                            fontFamily: "Open Sans",
                          }}
                        >
                          Account Manager
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: 14,
                            fontWeight: 400,
                            fontFamily: "Open Sans",
                            textAlign: "right",
                            color: "#111827",
                          }}
                        >
                          {ticketInfo.accountManager}
                        </Typography>
                      </Box>
                    </Box>

                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        gap: 1.5,
                      }}
                    >
                      <button
                        style={{
                          backgroundColor: "#409BFF",
                          color: "#fff",
                          border: "none",
                          padding: "10px 16px",
                          borderRadius: "6px",
                          fontWeight: 500,
                          cursor: "pointer",
                          width: "100%",
                          fontFamily: "Open Sans",
                          fontSize: 14,
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          gap: "8px",
                        }}
                      >
                        <img
                          src={TeamsImg}
                          alt="Teams"
                          style={{ width: 18, height: 18 }}
                        />
                        Call on Microsoft Teams
                      </button>
                      <button
                        style={{
                          backgroundColor: "#fff",
                          color: "#374151",
                          border: "1px solid #D1D5DB",
                          padding: "10px 16px",
                          borderRadius: "6px",
                          fontWeight: 500,
                          cursor: "pointer",
                          width: "100%",
                          fontFamily: "Open Sans",
                          fontSize: 14,
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          gap: "8px",
                        }}
                      >
                        <img
                          src={TeamsDarkImg}
                          alt="Teams"
                          style={{ width: 18, height: 18 }}
                        />
                        Message Directly on Teams
                      </button>
                    </Box>
                  </Box>

                  <Divider sx={{ my: 2.5 }} />

                  {/* Other Open Tickets Section */}
                  <Box sx={{ mb: 2.5 }}>
                    <Typography
                      sx={{
                        fontWeight: 600,
                        fontSize: 18,
                        fontFamily: "Open Sans",
                        mb: 2,
                        color: "#111827",
                      }}
                    >
                      Other Open Tickets
                    </Typography>

                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        gap: 1.5,
                      }}
                    >
                      {otherTickets.map((ticket) => (
                        <Box
                          key={ticket.id}
                          sx={{
                            p: 2,
                            border: "1px solid #E5E7EB",
                            borderRadius: 1,
                            cursor: "pointer",
                            transition: "all 0.2s ease",
                            "&:hover": {
                              backgroundColor: "#F9FAFB",
                              borderColor: "#D1D5DB",
                            },
                          }}
                        >
                          <Box
                            sx={{
                              display: "flex",
                              justifyContent: "space-between",
                              alignItems: "center",
                              mb: 0.5,
                            }}
                          >
                            <Typography
                              sx={{
                                fontSize: 15,
                                fontWeight: 600,
                                fontFamily: "Open Sans",
                                color: "#111827",
                              }}
                            >
                              {ticket.id}
                            </Typography>
                            <Chip
                              label={ticket.status}
                              size="small"
                              sx={{
                                backgroundColor: ticket.statusColor,
                                color: ticket.textColor,
                                fontWeight: 600,
                                fontFamily: "Open Sans",
                                fontSize: 11,
                                height: 22,
                              }}
                            />
                          </Box>
                          <Typography
                            sx={{
                              fontSize: 14,
                              color: "#374151",
                              fontFamily: "Open Sans",
                              mb: 0.5,
                            }}
                          >
                            {ticket.title}
                          </Typography>
                          <Typography
                            sx={{
                              fontSize: 12,
                              color: "#6B7280",
                              fontFamily: "Open Sans",
                            }}
                          >
                            {ticket.date}
                          </Typography>
                        </Box>
                      ))}
                    </Box>
                  </Box>

                  <Divider sx={{ my: 2.5 }} />

                  {/* Related Assets Section */}
                  <Box>
                    <Typography
                      sx={{
                        fontWeight: 600,
                        fontSize: 18,
                        fontFamily: "Open Sans",
                        mb: 2,
                        color: "#111827",
                      }}
                    >
                      Related Assets
                    </Typography>

                    {relatedAssets.length === 0 ? (
                      <Box
                        sx={{
                          display: "flex",
                          flexDirection: "column",
                          alignItems: "center",
                          justifyContent: "center",
                          py: 3,
                          px: 2,
                        }}
                      >
                        <ExclamationTriangleIcon
                          style={{
                            width: 48,
                            height: 48,
                            color: "#9CA3AF",
                            marginBottom: 12,
                          }}
                        />
                        <Typography
                          sx={{
                            fontSize: 14,
                            color: "#6B7280",
                            textAlign: "center",
                            mb: 2,
                            fontFamily: "Open Sans",
                          }}
                        >
                          We're having trouble getting data at the moment...
                        </Typography>
                        <Button
                          onClick={handleOpenAssetsDialog}
                          variant="contained"
                          sx={{
                            backgroundColor: "#409BFF",
                            color: "#fff",
                            textTransform: "none",
                            fontFamily: "Open Sans",
                            fontWeight: 600,
                            fontSize: 14,
                            px: 3,
                            py: 1,
                            borderRadius: "6px",
                            "&:hover": {
                              backgroundColor: "#2563EB",
                            },
                          }}
                        >
                          <PlusIcon
                            style={{ width: 18, height: 18, marginRight: 8 }}
                          />
                          Add Asset
                        </Button>
                      </Box>
                    ) : (
                      <>
                        {relatedAssets.map((asset) => (
                          <Box
                            key={asset.id}
                            sx={{
                              display: "flex",
                              alignItems: "center",
                              gap: 2,
                              p: 2,
                              border: "1px solid #E5E7EB",
                              borderRadius: 1,
                              mb: 1.5,
                              backgroundColor: "#FFFFFF",
                            }}
                          >
                            <Box>
                              <img
                                src={LapBackgroundImg}
                                alt="Laptop"
                                style={{ width: 60, height: 60 }}
                              />
                            </Box>
                            <Box sx={{ flex: 1 }}>
                              <Typography
                                sx={{
                                  fontSize: 15,
                                  fontWeight: 600,
                                  fontFamily: "Open Sans",
                                  color: "#111827",
                                }}
                              >
                                {asset.name}
                              </Typography>
                              <Typography
                                sx={{
                                  fontSize: 13,
                                  fontFamily: "Open Sans",
                                  color: "#6B7280",
                                }}
                              >
                                {asset.description}...
                              </Typography>
                            </Box>
                          </Box>
                        ))}
                        <Button
                          onClick={handleOpenAssetsDialog}
                          variant="contained"
                          fullWidth
                          sx={{
                            backgroundColor: "#409BFF",
                            color: "#fff",
                            textTransform: "none",
                            fontFamily: "Open Sans",
                            fontWeight: 600,
                            fontSize: 14,
                            py: 1,
                            mt: 2,
                            borderRadius: "6px",
                            "&:hover": {
                              backgroundColor: "#2563EB",
                            },
                          }}
                        >
                          <PlusIcon
                            style={{ width: 18, height: 18, marginRight: 8 }}
                          />
                          Add Asset
                        </Button>
                      </>
                    )}
                  </Box>
                </Paper>
              </Box>
            </Grid>
          </Grid>
        </Grid>
      </Grid>

      {/* All Dialogs */}
      <EditTicketInfoDialog
      disableScrollLock
        open={openEditDialog}
        onClose={handleCloseEditDialog}
        ticketData={ticketInfo}
        onSave={handleSaveTicketInfo}
      />
      <AddBillingDialog
      disableScrollLock
        open={openBillingDialog}
        onClose={handleCloseBillingDialog}
        onSave={handleSaveBilling}
      />
      <AddExpenseDialog
      disableScrollLock
        open={openExpenseDialog}
        onClose={handleCloseExpenseDialog}
        onSave={handleSaveExpense}
      />
      <AddAssetsDialog
      disableScrollLock
        open={openAssetsDialog}
        onClose={handleCloseAssetsDialog}
        onSave={handleSaveAssets}
      />

      <EditBillDialog
      disableScrollLock
        open={openEditBillDialog}
        onClose={() => setOpenEditBillDialog(false)}
        onSave={(data) => {
          const updatedChargeTypes = chargeTypes.map((item) =>
            item === selectedBillItem
              ? { ...item, billableTime: data.timeTaken }
              : item
          );
          setChargeTypes(updatedChargeTypes);
          setOpenEditBillDialog(false);
        }}
        initialData={selectedBillItem}
      />

      <DeleteContentDialog
      disableScrollLock
        open={openDeleteBillDialog}
        onClose={() => setOpenDeleteBillDialog(false)}
        onConfirm={() => {
          const updatedChargeTypes = chargeTypes.filter(
            (item) => item !== selectedBillItem
          );
          setChargeTypes(updatedChargeTypes);
          setOpenDeleteBillDialog(false);
        }}
        title="Delete Billing Entry"
        message="Are you sure you want to delete this billing entry? This action cannot be undone."
      />

      <EditExpenseDialog
      disableScrollLock
        open={openEditExpenseDialog}
        onClose={() => setOpenEditExpenseDialog(false)}
        onSave={(data) => {
          const updatedExpenses = expenses.map((item) =>
            item === selectedExpenseItem
              ? {
                  ...item,
                  description: data.description,
                  cost: data.cost,
                  expenseType: data.expenseType,
                  dateAdded: data.dateAdded,
                }
              : item
          );
          setExpenses(updatedExpenses);
          setOpenEditExpenseDialog(false);
        }}
        initialData={selectedExpenseItem}
      />

      <DeleteContentDialog
      disableScrollLock
        open={openDeleteExpenseDialog}
        onClose={() => setOpenDeleteExpenseDialog(false)}
        onConfirm={() => {
          const updatedExpenses = expenses.filter(
            (item) => item !== selectedExpenseItem
          );
          setExpenses(updatedExpenses);
          setOpenDeleteExpenseDialog(false);
        }}
        title="Delete Expense"
        message="Are you sure you want to delete this expense? This action cannot be undone."
      />

      <EditEndUserDialog
  disableScrollLock
  open={openEditEndUserDialog}
  onClose={handleCloseEditEndUserDialog}
  endUserData={endUserData}
  onSave={handleSaveEndUserDetails}
/>

    </>
  );
};

export default TicketDetails;
