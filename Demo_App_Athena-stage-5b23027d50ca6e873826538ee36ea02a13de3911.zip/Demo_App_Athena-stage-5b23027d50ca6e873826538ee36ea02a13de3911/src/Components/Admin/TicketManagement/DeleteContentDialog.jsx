import {
  Dialog,
  Button,
  Typography,
  Box,
} from "@mui/material";
import {TrashIcon} from '@heroicons/react/24/solid';

const DeleteContentDialog = ({ open, onClose, onConfirm, title, message }) => {
  return (
    <Dialog
    disableScrollLock
      open={open}
      onClose={onClose}
      maxWidth="xs"
      PaperProps={{
        sx: {
          borderRadius: "12px",
          width: "400px",
        },
      }}
    >
      <Box sx={{ textAlign: "center", py: 3, px: 4 }}>
        {/* Icon */}
        <Box
          sx={{
            height: 70,
            width: 70,
            mx: "auto",
            borderRadius: "50%",
            backgroundColor: "#FEE2E1",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            mb: 2,
          }}
        >
         <TrashIcon style={{height:"40px", color:"#FF5E5E"}}/>
        </Box>

        {/* Title */}
        <Typography
          sx={{
            color: "#000000",
            fontFamily: "Open Sans",
            fontWeight: 600,
            fontSize: 24,
            mb: 2,
          }}
        >
          {title || "Delete Item"}
        </Typography>

        {/* Message */}
        <Typography
          sx={{
            color: "#6E6E6E",
            fontFamily: "Open Sans",
            fontWeight: 400,
            fontSize: 16,
            mb: 3,
          }}
        >
          {message || "Are you sure you want to delete this item?"}
        </Typography>

        {/* Buttons */}
        <Box
          sx={{
            display: "flex",
            gap: 2,
            justifyContent: "center",
            width: "100%",
          }}
        >
          <Button
            onClick={onClose}
            variant="outlined"
            fullWidth
            sx={{
              color: "#409BFF",
              fontFamily: "Open Sans",
              fontWeight: 600,
              fontSize: 14,
              borderRadius: "8px",
              borderColor: "#409BFF",
              height: "44px",
              textTransform: "none",
            }}
          >
            Cancel
          </Button>
          <Button
            onClick={onConfirm}
            variant="contained"
            fullWidth
            sx={{
              backgroundColor: "#FF5E5E",
              color: "#FFFFFF",
              fontFamily: "Open Sans",
              fontWeight: 600,
              fontSize: 14,
              borderRadius: "8px",
              height: "44px",
              textTransform: "none",
              boxShadow: "none",
              "&:hover": {
                backgroundColor: "#E54545",
              },
            }}
          >
            Delete
          </Button>
        </Box>
      </Box>
    </Dialog>
  );
};

export default DeleteContentDialog;
