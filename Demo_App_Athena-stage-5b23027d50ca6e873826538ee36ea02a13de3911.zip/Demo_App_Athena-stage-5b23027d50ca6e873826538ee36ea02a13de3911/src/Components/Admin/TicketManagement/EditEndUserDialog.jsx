import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Box,
  Typography,
  TextField,
  MenuItem,
  IconButton,
  Button,
  Divider,
  Avatar,
} from "@mui/material";
import { XMarkIcon } from "@heroicons/react/24/solid";
import { useFormik } from "formik";
import * as Yup from "yup";

// Validation Schema with Yup
const validationSchema = Yup.object({
  email: Yup.string()
    .email("Invalid email format")
    .required("Email is required"),
  site: Yup.string().required("Site is required"),
  accountManager: Yup.string().required("Account Manager is required"),
});

const EditEndUserDialog = ({ open, onClose, endUserData, onSave }) => {
  // Formik setup
  const formik = useFormik({
    initialValues: {
      name: endUserData?.name || "Theresa Samuels",
      company: endUserData?.company || "St Johns High School",
      site: endUserData?.site || "Leeds",
      email: endUserData?.email || "Theresa.Samuels@contoso.com",
      accountManager: endUserData?.accountManager || "James Brown",
    },
    validationSchema: validationSchema,
    enableReinitialize: true, // This allows form to update when endUserData changes
    onSubmit: (values) => {
      onSave(values);
      onClose();
    },
  });

  const handleCancel = () => {
    formik.resetForm();
    onClose();
  };

  // MenuProps to hide scrollbar
  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        "&::-webkit-scrollbar": {
          display: "none",
        },
        "-ms-overflow-style": "none",
        "scrollbar-width": "none",
      },
    },
  };

  return (
    <Dialog
      open={open}
      onClose={handleCancel}
      disableScrollLock
      maxWidth="sm"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 2,
        },
      }}
    >
      <form onSubmit={formik.handleSubmit}>
        {/* Dialog Header */}
        <DialogTitle sx={{ p: 0 }}>
          <Box
            sx={{
              px: 3,
              pt: 3,
              pb: 2,
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Typography
              sx={{
                fontSize: 22,
                fontWeight: 600,
                fontFamily: "Open Sans",
                color: "#111827",
              }}
            >
              Edit End-User Details
            </Typography>
            <IconButton onClick={handleCancel} size="small">
              <XMarkIcon style={{ width: 24, height: 24, color: "#000000" }} />
            </IconButton>
          </Box>
        </DialogTitle>

        <Divider sx={{ m: 0 }} />

        {/* Dialog Content */}
        <DialogContent sx={{ p: 3 }}>
          {/* User Avatar and Name Section */}
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 2,
              mb: 3,
              pb: 3,
              borderBottom: "1px solid #E5E7EB",
            }}
          >
            <Avatar
              sx={{
                width: 56,
                height: 56,
                backgroundColor: "#DBEAFE",
                color: "#2563EB",
                fontWeight: 600,
                fontFamily: "Open Sans",
                fontSize: 20,
              }}
            >
              {formik.values.name
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </Avatar>
            <Box>
              <Typography
                sx={{
                  fontWeight: 600,
                  fontSize: 18,
                  fontFamily: "Open Sans",
                  color: "#111827",
                }}
              >
                {formik.values.name}
              </Typography>
              <Typography
                sx={{
                  fontSize: 14,
                  color: "#6B7280",
                  fontFamily: "Open Sans",
                }}
              >
                {formik.values.company}
              </Typography>
            </Box>
          </Box>

          {/* Form Fields */}
          <Box sx={{ display: "flex", flexDirection: "column", gap: 2.5 }}>
            {/* Site Dropdown */}
            <Box>
              <Typography
                sx={{
                  fontSize: 14,
                  color: "#4B5563",
                  fontFamily: "Open Sans",
                  mb: 1,
                  fontWeight: 600,
                }}
              >
                Site
              </Typography>
              <TextField
                select
                fullWidth
                name="site"
                value={formik.values.site}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                error={formik.touched.site && Boolean(formik.errors.site)}
                helperText={formik.touched.site && formik.errors.site}
                size="small"
                SelectProps={{
                  MenuProps: menuProps,
                }}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    fontFamily: "Open Sans",
                    fontSize: 14,
                    borderRadius: "8px",
                    "& fieldset": {
                      borderColor: "#D1D5DB",
                    },
                    "&:hover fieldset": {
                      borderColor: "#9CA3AF",
                    },
                    "&.Mui-focused fieldset": {
                      borderColor: "#409BFF",
                    },
                  },
                  "& .MuiFormHelperText-root": {
                    fontFamily: "Open Sans",
                    fontSize: 12,
                  },
                }}
              >
                <MenuItem value="Leeds">Leeds</MenuItem>
                <MenuItem value="London">London</MenuItem>
                <MenuItem value="Manchester">Manchester</MenuItem>
                <MenuItem value="Birmingham">Birmingham</MenuItem>
                <MenuItem value="Edinburgh">Edinburgh</MenuItem>
              </TextField>
            </Box>

            {/* Email TextField (No Dropdown - Editable with Validation) */}
            <Box>
              <Typography
                sx={{
                  fontSize: 14,
                  color: "#4B5563",
                  fontFamily: "Open Sans",
                  mb: 1,
                  fontWeight: 600,
                }}
              >
                Email
              </Typography>
              <TextField
                fullWidth
                name="email"
                type="email"
                value={formik.values.email}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                error={formik.touched.email && Boolean(formik.errors.email)}
                helperText={formik.touched.email && formik.errors.email}
                placeholder="Enter email address"
                size="small"
                sx={{
                  "& .MuiOutlinedInput-root": {
                    fontFamily: "Open Sans",
                    fontSize: 14,
                    borderRadius: "8px",
                    "& fieldset": {
                      borderColor: "#D1D5DB",
                    },
                    "&:hover fieldset": {
                      borderColor: "#9CA3AF",
                    },
                    "&.Mui-focused fieldset": {
                      borderColor: "#409BFF",
                    },
                  },
                  "& .MuiOutlinedInput-input": {
                    color: "#111827",
                    "&::placeholder": {
                      color: "#9CA3AF",
                      opacity: 1,
                    },
                  },
                  "& .MuiFormHelperText-root": {
                    fontFamily: "Open Sans",
                    fontSize: 12,
                  },
                }}
              />
            </Box>

            {/* Account Manager Dropdown */}
            <Box>
              <Typography
                sx={{
                  fontSize: 14,
                  color: "#4B5563",
                  fontFamily: "Open Sans",
                  mb: 1,
                  fontWeight: 600,
                }}
              >
                Account Manager
              </Typography>
              <TextField
                select
                fullWidth
                name="accountManager"
                value={formik.values.accountManager}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                error={
                  formik.touched.accountManager &&
                  Boolean(formik.errors.accountManager)
                }
                helperText={
                  formik.touched.accountManager && formik.errors.accountManager
                }
                size="small"
                SelectProps={{
                  MenuProps: menuProps,
                }}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    fontFamily: "Open Sans",
                    fontSize: 14,
                    borderRadius: "8px",
                    "& fieldset": {
                      borderColor: "#D1D5DB",
                    },
                    "&:hover fieldset": {
                      borderColor: "#9CA3AF",
                    },
                    "&.Mui-focused fieldset": {
                      borderColor: "#409BFF",
                    },
                  },
                  "& .MuiFormHelperText-root": {
                    fontFamily: "Open Sans",
                    fontSize: 12,
                  },
                }}
              >
                <MenuItem value="James Brown">James Brown</MenuItem>
                <MenuItem value="Sarah Johnson">Sarah Johnson</MenuItem>
                <MenuItem value="Michael Chen">Michael Chen</MenuItem>
                <MenuItem value="Emily Davis">Emily Davis</MenuItem>
                <MenuItem value="David Rodriguez">David Rodriguez</MenuItem>
              </TextField>
            </Box>
          </Box>
        </DialogContent>

        <Divider sx={{ m: 0 }} />

        {/* Dialog Actions */}
        <DialogActions sx={{ p: 3, gap: 2, justifyContent: "flex-end" }}>
          <Button
            type="submit"
            disabled={!formik.isValid || !formik.dirty}
            sx={{
              backgroundColor:
                formik.isValid && formik.dirty ? "#409BFF" : "#E5E7EB",
              color: formik.isValid && formik.dirty ? "#fff" : "#9CA3AF",
              textTransform: "none",
              fontFamily: "Open Sans",
              fontWeight: 600,
              fontSize: 14,
              px: 4,
              py: 1,
              borderRadius: "16px",
              "&:hover": {
                backgroundColor:
                  formik.isValid && formik.dirty ? "#2563EB" : "#E5E7EB",
              },
            }}
          >
            Save
          </Button>
          <Button
            onClick={handleCancel}
            sx={{
              backgroundColor: "#FF4141",
              color: "#fff",
              textTransform: "none",
              fontFamily: "Open Sans",
              fontWeight: 600,
              fontSize: 14,
              px: 4,
              py: 1,
              borderRadius: "16px",
              "&:hover": {
                backgroundColor: "#DC2626",
              },
            }}
          >
            Cancel
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
};

export default EditEndUserDialog;
