import React from "react";
import { Dialog, DialogTitle, DialogContent, DialogActions, Box, Typography, TextField, MenuItem, IconButton, Button, Divider } from "@mui/material";
import { XMarkIcon } from "@heroicons/react/24/solid";

const EditTicketInfoDialog = ({ open, onClose, ticketData, onSave }) => {
  const [formData, setFormData] = React.useState(ticketData);

  React.useEffect(() => {
    setFormData(ticketData);
  }, [ticketData]);

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSave = () => {
    onSave(formData);
    onClose();
  };

  const handleCancel = () => {
    setFormData(ticketData);
    onClose();
  };

  return (
    <Dialog
      open={open}
      disableScrollLock
      onClose={handleCancel}
      maxWidth="md"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 2,
          minHeight: "500px",
        },
      }}
    >
      {/* Dialog Header */}
      <DialogTitle sx={{ p: 0 }}>
        <Box sx={{ px: 3, pt: 3, pb: 2, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <Typography sx={{ fontSize: 22, fontWeight: 600, fontFamily: "Open Sans", color: "#111827" }}>
            Edit Ticket Information
          </Typography>
          <IconButton onClick={handleCancel} size="small">
            <XMarkIcon style={{ width: 24, height: 24, color: "#000000" }} />
          </IconButton>
        </Box>
        <Divider sx={{ mb: 3 }} />
      </DialogTitle>

      {/* Dialog Content */}
      <DialogContent sx={{ p: 3, pt: 3 }}>
        <Box sx={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 2 }}>
          {/* Row 1 */}
          <Box>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Date Created
            </Typography>
            <TextField
              fullWidth
              value={formData.dateCreated}
              onChange={(e) => handleChange("dateCreated", e.target.value)}
              size="small"
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "8px",
                },
              }}
            />
          </Box>

          <Box>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Ticket Type
            </Typography>
            <TextField
              select
              fullWidth
              value={formData.ticketType}
              onChange={(e) => handleChange("ticketType", e.target.value)}
              size="small"
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "8px",
                },
              }}
            >
              <MenuItem value="Incident">Incident</MenuItem>
              <MenuItem value="Service Request">Service Request</MenuItem>
              <MenuItem value="Problem">Problem</MenuItem>
            </TextField>
          </Box>

          <Box>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Workflow
            </Typography>
            <TextField
              select
              fullWidth
              value={formData.workflow}
              onChange={(e) => handleChange("workflow", e.target.value)}
              size="small"
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "8px",
                },
              }}
            >
              <MenuItem value="Incident Management">Incident Management</MenuItem>
              <MenuItem value="Service Request Management">Service Request Management</MenuItem>
            </TextField>
          </Box>

          {/* Row 2 */}
          <Box>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Status
            </Typography>
            <TextField
              select
              fullWidth
              value={formData.status}
              onChange={(e) => handleChange("status", e.target.value)}
              size="small"
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "8px",
                },
              }}
            >
              <MenuItem value="In Progress">In Progress</MenuItem>
              <MenuItem value="On Hold">On Hold</MenuItem>
              <MenuItem value="Completed">Completed</MenuItem>
              <MenuItem value="Cancelled">Cancelled</MenuItem>
            </TextField>
          </Box>

          <Box>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Team
            </Typography>
            <TextField
              select
              fullWidth
              value={formData.team}
              onChange={(e) => handleChange("team", e.target.value)}
              size="small"
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "8px",
                },
              }}
            >
              <MenuItem value="1st Line Support">1st Line Support</MenuItem>
              <MenuItem value="2nd Line Support">2nd Line Support</MenuItem>
              <MenuItem value="Infrastructure">Infrastructure</MenuItem>
            </TextField>
          </Box>

          <Box>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Assigned Agent
            </Typography>
            <TextField
              select
              fullWidth
              value={formData.assignedAgent}
              onChange={(e) => handleChange("assignedAgent", e.target.value)}
              size="small"
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "8px",
                },
              }}
            >
              <MenuItem value="Vinay T">Vinay T</MenuItem>
              <MenuItem value="John Doe">John Doe</MenuItem>
              <MenuItem value="Jane Smith">Jane Smith</MenuItem>
            </TextField>
          </Box>

          {/* Row 3 */}
          <Box>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Category
            </Typography>
            <TextField
              select
              fullWidth
              value={formData.category}
              onChange={(e) => handleChange("category", e.target.value)}
              size="small"
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "8px",
                },
              }}
            >
              <MenuItem value="Laptop">Laptop</MenuItem>
              <MenuItem value="Desktop">Desktop</MenuItem>
              <MenuItem value="Mobile">Mobile</MenuItem>
            </TextField>
          </Box>

          <Box>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Source
            </Typography>
            <TextField
              fullWidth
              value={formData.source}
              onChange={(e) => handleChange("source", e.target.value)}
              size="small"
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "8px",
                },
              }}
            />
          </Box>

          <Box>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Time Recorded
            </Typography>
            <TextField
              fullWidth
              value={formData.timeRecorded}
              onChange={(e) => handleChange("timeRecorded", e.target.value)}
              size="small"
              InputProps={{
                sx: {
                  backgroundColor: "#E9EAEB",
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "8px",
                },
              }}
            />
          </Box>

          {/* Row 4 */}
          <Box>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Billable Time Recorded...
            </Typography>
            <TextField
              fullWidth
              value={formData.billableTime}
              onChange={(e) => handleChange("billableTime", e.target.value)}
              size="small"
              InputProps={{
                sx: {
                  backgroundColor: "#E9EAEB",
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "8px",
                },
              }}
            />
          </Box>

          <Box>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Estimated Time
            </Typography>
            <TextField
              select
              fullWidth
              value={formData.estimatedTime}
              onChange={(e) => handleChange("estimatedTime", e.target.value)}
              size="small"
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "8px",
                },
              }}
            >
              <MenuItem value="00:00">00:00</MenuItem>
              <MenuItem value="01:00">01:00</MenuItem>
              <MenuItem value="02:00">02:00</MenuItem>
            </TextField>
          </Box>

          <Box>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Urgency
            </Typography>
            <TextField
              select
              fullWidth
              value={formData.urgency}
              onChange={(e) => handleChange("urgency", e.target.value)}
              size="small"
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "8px",
                },
              }}
            >
              <MenuItem value="Not Set">Not Set</MenuItem>
              <MenuItem value="Low">Low</MenuItem>
              <MenuItem value="Medium">Medium</MenuItem>
              <MenuItem value="High">High</MenuItem>
            </TextField>
          </Box>
        </Box>
      </DialogContent>

      <Divider sx={{ m: 0 }} />

      {/* Dialog Actions */}
      <DialogActions sx={{ p: 3, gap: 2 }}>
        <Button
          onClick={handleSave}
          sx={{
            backgroundColor: "#409BFF",
            color: "#fff",
            textTransform: "none",
            fontFamily: "Open Sans",
            fontWeight: 600,
            fontSize: 14,
            px: 4,
            py: 1,
            borderRadius: "16px",
            "&:hover": {
              backgroundColor: "#2563EB",
            },
          }}
        >
          Save
        </Button>
        <Button
          onClick={handleCancel}
          sx={{
            backgroundColor: "#FF4141",
            color: "#fff",
            textTransform: "none",
            fontFamily: "Open Sans",
            fontWeight: 600,
            fontSize: 14,
            px: 4,
            py: 1,
            borderRadius: "16px",
            "&:hover": {
              backgroundColor: "#DC2626",
            },
          }}
        >
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default EditTicketInfoDialog;

