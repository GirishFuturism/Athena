import React from "react";
import { Dialog, DialogTitle, DialogContent, DialogActions, Box, Typography, TextField, MenuItem, IconButton, Button, Divider } from "@mui/material";
import { XMarkIcon } from "@heroicons/react/24/solid";

const AddBillingDialog = ({ open, onClose, onSave }) => {
  const [formData, setFormData] = React.useState({
    chargeType: "",
    timeTaken: "",
  });
  const [timeError, setTimeError] = React.useState("");

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  // Handle time input with validation and auto-formatting
  const handleTimeChange = (e) => {
    let value = e.target.value;
    
    // Remove all non-numeric characters
    value = value.replace(/\D/g, '');
    
    // Limit to 4 digits (HHMM)
    if (value.length > 4) {
      value = value.slice(0, 4);
    }
    
    // Auto-format as HH:MM
    let formatted = '';
    if (value.length > 0) {
      if (value.length <= 2) {
        formatted = value;
      } else {
        formatted = value.slice(0, 2) + ':' + value.slice(2);
      }
    }
    
    // Validate the format
    if (formatted.length === 5) {
      const [hours, minutes] = formatted.split(':');
      const hoursNum = parseInt(hours, 10);
      const minutesNum = parseInt(minutes, 10);
      
      if (hoursNum > 23 || minutesNum > 59) {
        setTimeError("Invalid time format (00:00 - 23:59)");
      } else {
        setTimeError("");
      }
    } else if (formatted.length > 0) {
      setTimeError("");
    }
    
    handleChange("timeTaken", formatted);
  };

  const handleSave = () => {
    // Validate time format before saving
    const timeRegex = /^([0-1]?[0-9]|2[0-3]):([0-5][0-9])$/;
    
    if (formData.chargeType && formData.timeTaken && timeRegex.test(formData.timeTaken)) {
      onSave(formData);
      setFormData({ chargeType: "", timeTaken: "" });
      setTimeError("");
      onClose();
    } else if (formData.timeTaken && !timeRegex.test(formData.timeTaken)) {
      setTimeError("Please enter valid time (HH:MM)");
    }
  };

  const handleCancel = () => {
    setFormData({ chargeType: "", timeTaken: "" });
    setTimeError("");
    onClose();
  };

  // Check if form is valid
  const isFormValid = formData.chargeType && 
                     formData.timeTaken && 
                     /^([0-1]?[0-9]|2[0-3]):([0-5][0-9])$/.test(formData.timeTaken) &&
                     !timeError;

  return (
    <Dialog
      open={open}
      onClose={handleCancel}
      disableScrollLock
      maxWidth="sm"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 2,
        },
      }}
    >
      {/* Dialog Header */}
      <DialogTitle sx={{ p: 0 }}>
        <Box sx={{ px: 3, pt: 3, pb: 2, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <Typography sx={{ fontSize: 22, fontWeight: 600, fontFamily: "Open Sans", color: "#111827" }}>
            Add Billing
          </Typography>
          <IconButton onClick={handleCancel} size="small">
            <XMarkIcon style={{ width: 24, height: 24, color: "#000000" }} />
          </IconButton>
        </Box>
      </DialogTitle>

      <Divider sx={{ m: 0 }} />

      {/* Dialog Content */}
      <DialogContent sx={{ p: 3 }}>
        <Box sx={{ display: "flex", flexDirection: "column", gap: 2.5 }}>
          {/* Charge Type */}
          <Box>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Charge Type <span style={{ color: "#EF4444" }}>*</span>
            </Typography>
            <TextField
              select
              fullWidth
              value={formData.chargeType}
              onChange={(e) => handleChange("chargeType", e.target.value)}
              placeholder="Charge type"
              size="small"
              SelectProps={{
                displayEmpty: true,
              }}
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "6px",
                },
              }}
            >
              <MenuItem value="" disabled>
                Charge type
              </MenuItem>
              <MenuItem value="Travel">Travel</MenuItem>
              <MenuItem value="Remote Support">Remote Support</MenuItem>
              <MenuItem value="On-Site Support">On-Site Support</MenuItem>
              <MenuItem value="Consultation">Consultation</MenuItem>
            </TextField>
          </Box>

          {/* Time Taken */}
          <Box>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Time Taken <span style={{ color: "#EF4444" }}>*</span>
            </Typography>
            <TextField
              fullWidth
              value={formData.timeTaken}
              onChange={handleTimeChange}
              placeholder="HH:MM"
              size="small"
              error={!!timeError}
              helperText={timeError || "Format: HH:MM (00:00 - 23:59)"}
              inputProps={{
                maxLength: 5,
              }}
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "6px",
                },
              }}
              FormHelperTextProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 12,
                  color: timeError ? "#EF4444" : "#6B7280",
                }
              }}
            />
          </Box>
        </Box>
      </DialogContent>

      <Divider sx={{ m: 0 }} />

      {/* Dialog Actions */}
      <DialogActions sx={{ p: 3, gap: 2, justifyContent: "flex-start" }}>
        <Button
          onClick={handleSave}
          disabled={!isFormValid}
          sx={{
            backgroundColor: isFormValid ? "#409BFF" : "#E5E7EB",
            color: isFormValid ? "#fff" : "#9CA3AF",
            textTransform: "none",
            fontFamily: "Open Sans",
            fontWeight: 600,
            fontSize: 16,
            px: 4,
            py: 1,
            borderRadius: "16px",
            "&:hover": {
              backgroundColor: isFormValid ? "#2563EB" : "#E5E7EB",
            },
          }}
        >
          Save
        </Button>
        <Button
          onClick={handleCancel}
          sx={{
            backgroundColor: "#FF4141",
            color: "#fff",
            textTransform: "none",
            fontFamily: "Open Sans",
            fontWeight: 600,
            fontSize: 16,
            px: 4,
            py: 1,
            borderRadius: "16px",
            "&:hover": {
              backgroundColor: "#DC2626",
            },
          }}
        >
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AddBillingDialog;
