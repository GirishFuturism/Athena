import React, { useState } from "react";
import {
  Dialog,
  Button,
  Typography,
  Box,
  IconButton,
  TextField,
  Select,
  MenuItem,
  FormControl,
  Checkbox,
  FormControlLabel,
  InputAdornment,
} from "@mui/material";
import { XMarkIcon } from "@heroicons/react/24/solid";

// Add this helper function at the top of your component (outside the component function)
const formatNumberWithCommas = (value) => {
  if (!value) return "";
  
  // Remove all non-numeric characters except decimal point
  const numericValue = value.replace(/[^\d.]/g, "");
  
  // Split into integer and decimal parts
  const parts = numericValue.split(".");
  
  // Add commas to integer part
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  
  // Join parts back together (limit to 2 decimal places)
  return parts.length > 1 ? `${parts[0]}.${parts[1].slice(0, 2)}` : parts[0];
};

const removeCommas = (value) => {
  return value.replace(/,/g, "");
};

const EditExpenseDialog = ({ open, onClose, onSave, initialData }) => {
  const [description, setDescription] = useState(initialData?.description || "");
  const [cost, setCost] = useState(initialData?.cost || "");
  const [expenseType, setExpenseType] = useState(initialData?.expenseType || "Other");
  const [dateAdded, setDateAdded] = useState(initialData?.dateAdded || "");
  const [dateReimbursed, setDateReimbursed] = useState(initialData?.dateReimbursed || "");
  const [dateInvoice, setDateInvoice] = useState(initialData?.dateInvoice || "");
  const [isBillable, setIsBillable] = useState(initialData?.isBillable || false);

  // Handle cost input with automatic comma formatting
  const handleCostChange = (e) => {
    const value = e.target.value;
    
    // Allow empty string
    if (value === "") {
      setCost("");
      return;
    }
    
    // Remove commas for validation
    const valueWithoutCommas = removeCommas(value);
    
    // Regular expression to allow only numbers and one decimal point
    const regex = /^\d*\.?\d{0,2}$/;
    
    if (regex.test(valueWithoutCommas)) {
      // Format with commas and update state
      const formattedValue = formatNumberWithCommas(valueWithoutCommas);
      setCost(formattedValue);
    }
  };

  const handleSave = () => {
    // Remove commas before saving
    const numericCost = removeCommas(cost);
    
    onSave({
      description,
      cost: numericCost ? `$${parseFloat(numericCost).toFixed(2)}` : "",
      expenseType,
      dateAdded,
      dateReimbursed,
      dateInvoice,
      isBillable,
    });
    onClose();
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      disableScrollLock
      maxWidth="md"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: "12px",
          maxWidth: "700px",
        },
      }}
    >
      <Box sx={{ p: 3 }}>
        {/* Header */}
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 3 }}>
          <Typography
            sx={{
              fontSize: 22,
              fontWeight: 600,
              fontFamily: "Open Sans",
              color: "#111827",
            }}
          >
            Edit Expenses
          </Typography>
          <IconButton onClick={onClose} sx={{ p: 0 }}>
            <XMarkIcon style={{ width: 24, height: 24, color: "#000000" }} />
          </IconButton>
        </Box>

        {/* Description */}
        <Box sx={{ mb: 3 }}>
          <Typography
            sx={{
              fontSize: 14,
              fontWeight: 600,
              fontFamily: "Open Sans",
              color: "#374151",
              mb: 1,
            }}
          >
            Description
          </Typography>
          <TextField
            fullWidth
            multiline
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Enter description"
            sx={{
              "& .MuiOutlinedInput-root": {
                fontSize: 14,
                fontFamily: "Open Sans",
                "& fieldset": {
                  borderColor: "#D1D5DB",
                },
                "&:hover fieldset": {
                  borderColor: "#D1D5DB",
                },
              },
            }}
          />
        </Box>

        {/* Row 1: Cost, Expense Type, Date Added */}
        <Box sx={{ display: "flex", gap: 2, mb: 3 }}>
          <Box sx={{ flex: 1 }}>
            <Typography
              sx={{
                fontSize: 14,
                fontWeight: 600,
                fontFamily: "Open Sans",
                color: "#374151",
                mb: 1,
              }}
            >
              Cost
            </Typography>
            <TextField
              fullWidth
              value={cost}
              onChange={handleCostChange}
              placeholder="0.00"
              type="text"
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Typography
                      sx={{
                        fontSize: 14,
                        fontWeight: 600,
                        fontFamily: "Open Sans",
                        color: "#6B7280",
                      }}
                    >
                      $
                    </Typography>
                  </InputAdornment>
                ),
              }}
              sx={{
                "& .MuiOutlinedInput-root": {
                  fontSize: 14,
                  fontFamily: "Open Sans",
                  height: 44,
                  "& fieldset": {
                    borderColor: "#D1D5DB",
                  },
                  "&:hover fieldset": {
                    borderColor: "#D1D5DB",
                  },
                  "&.Mui-focused fieldset": {
                    borderColor: "#409BFF",
                  },
                },
                "& .MuiOutlinedInput-input": {
                  color: "#111827",
                },
              }}
            />
          </Box>

          <Box sx={{ flex: 1 }}>
            <Typography
              sx={{
                fontSize: 14,
                fontWeight: 600,
                fontFamily: "Open Sans",
                color: "#374151",
                mb: 1,
              }}
            >
              Expenses Type
            </Typography>
            <FormControl fullWidth>
              <Select
                value={expenseType}
                onChange={(e) => setExpenseType(e.target.value)}
                sx={{
                  fontSize: 14,
                  fontFamily: "Open Sans",
                  height: 44,
                  "& .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#D1D5DB",
                  },
                  "&:hover .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#D1D5DB",
                  },
                  "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#409BFF",
                  },
                }}
              >
                <MenuItem value="Other">Other</MenuItem>
                <MenuItem value="Travel">Travel</MenuItem>
                <MenuItem value="Equipment">Equipment</MenuItem>
                <MenuItem value="Software">Software</MenuItem>
              </Select>
            </FormControl>
          </Box>

          <Box sx={{ flex: 1 }}>
            <Typography
              sx={{
                fontSize: 14,
                fontWeight: 600,
                fontFamily: "Open Sans",
                color: "#374151",
                mb: 1,
              }}
            >
              Date added
            </Typography>
            <TextField
              fullWidth
              value={dateAdded}
              onChange={(e) => setDateAdded(e.target.value)}
              placeholder="10/8/2025 12:00"
              sx={{
                "& .MuiOutlinedInput-root": {
                  fontSize: 14,
                  fontFamily: "Open Sans",
                  height: 44,
                  "& fieldset": {
                    borderColor: "#D1D5DB",
                  },
                  "&:hover fieldset": {
                    borderColor: "#D1D5DB",
                  },
                },
              }}
            />
          </Box>
        </Box>

        {/* Row 2: Date Reimbursed, Date Invoice, Is Billable */}
        <Box sx={{ display: "flex", gap: 2, mb: 3, alignItems: "flex-end" }}>
          <Box sx={{ flex: 1 }}>
            <Typography
              sx={{
                fontSize: 14,
                fontWeight: 600,
                fontFamily: "Open Sans",
                color: "#374151",
                mb: 1,
              }}
            >
              Date Reimbursed
            </Typography>
            <TextField
              fullWidth
              value={dateReimbursed}
              onChange={(e) => setDateReimbursed(e.target.value)}
              placeholder="10/8/2025 12:00"
              sx={{
                "& .MuiOutlinedInput-root": {
                  fontSize: 14,
                  fontFamily: "Open Sans",
                  height: 44,
                  "& fieldset": {
                    borderColor: "#D1D5DB",
                  },
                  "&:hover fieldset": {
                    borderColor: "#D1D5DB",
                  },
                },
              }}
            />
          </Box>

          <Box sx={{ flex: 1 }}>
            <Typography
              sx={{
                fontSize: 14,
                fontWeight: 600,
                fontFamily: "Open Sans",
                color: "#374151",
                mb: 1,
              }}
            >
              Date Invoice
            </Typography>
            <TextField
              fullWidth
              value={dateInvoice}
              onChange={(e) => setDateInvoice(e.target.value)}
              placeholder="10/8/2025 12:00"
              sx={{
                "& .MuiOutlinedInput-root": {
                  fontSize: 14,
                  fontFamily: "Open Sans",
                  height: 44,
                  "& fieldset": {
                    borderColor: "#D1D5DB",
                  },
                  "&:hover fieldset": {
                    borderColor: "#D1D5DB",
                  },
                },
              }}
            />
          </Box>

          <Box sx={{ flex: 1, display: "flex", alignItems: "center", height: 44 }}>
            <FormControlLabel
              control={
                <Checkbox
                  checked={isBillable}
                  onChange={(e) => setIsBillable(e.target.checked)}
                  sx={{
                    color: "#D1D5DB",
                    "&.Mui-checked": {
                      color: "#409BFF",
                    },
                  }}
                />
              }
              label={
                <Typography
                  sx={{
                    fontSize: 14,
                    fontWeight: 600,
                    fontFamily: "Open Sans",
                    color: "#374151",
                  }}
                >
                  Is Billable
                </Typography>
              }
            />
          </Box>
        </Box>

        {/* Buttons */}
        <Box sx={{ display: "flex", gap: 2, justifyContent: "flex-end", pt: 2 }}>
          <Button
            onClick={onClose}
            variant="contained"
            sx={{
              backgroundColor: "#FF5E5E",
              color: "#FFFFFF",
              fontFamily: "Open Sans",
              fontWeight: 600,
              fontSize: 14,
              borderRadius: "8px",
              height: "44px",
              px: 4,
              textTransform: "none",
              boxShadow: "none",
              "&:hover": {
                backgroundColor: "#E54545",
              },
            }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            variant="contained"
            sx={{
              backgroundColor: "#409BFF",
              color: "#FFFFFF",
              fontFamily: "Open Sans",
              fontWeight: 600,
              fontSize: 14,
              borderRadius: "8px",
              height: "44px",
              px: 4,
              textTransform: "none",
              boxShadow: "none",
              "&:hover": {
                backgroundColor: "#2563EB",
              },
            }}
          >
            Save
          </Button>
        </Box>
      </Box>
    </Dialog>
  );
};

export default EditExpenseDialog;
