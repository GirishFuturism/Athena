import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Box,
  Typography,
  TextField,
  MenuItem,
  IconButton,
  Button,
  Divider,
  Checkbox,
  FormControlLabel,
} from "@mui/material";
import { XMarkIcon } from "@heroicons/react/24/solid";
import LapBackgroundImg from "../../../assets/lap_background.png";

const AddAssetsDialog = ({ open, onClose, onSave }) => {
  const [selectedAssets, setSelectedAssets] = React.useState([]);
  const [filters, setFilters] = React.useState({
    user: "",
    activeInactive: "all",
    accountNumber: "",
  });

  // Mock asset data
  const assets = [
    {
      id: 1,
      name: "KL-LAP-1 (Laptop)",
      description: "Lenovo ThinkStation P500",
      serialNumber: "4CE0460D0F",
    },
    {
      id: 2,
      name: "KL-LAP-1 (Laptop)",
      description: "Lenovo ThinkStation P500",
      serialNumber: "4CE0460D0F",
    },
  ];

  const handleAssetToggle = (asset) => {
    setSelectedAssets((prev) => {
      const exists = prev.find((a) => a.id === asset.id);
      if (exists) {
        return prev.filter((a) => a.id !== asset.id);
      } else {
        return [...prev, asset];
      }
    });
  };

  const handleConfirm = () => {
    onSave(selectedAssets);
    setSelectedAssets([]);
    onClose();
  };

  const handleCancel = () => {
    setSelectedAssets([]);
    onClose();
  };

  return (
    <Dialog
    disableScrollLock
      open={open}
      onClose={handleCancel}
      maxWidth="md"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 2,
        //   minHeight: "400px",
        },
      }}
    >
      {/* Dialog Header */}
      <DialogTitle sx={{ p: 0 ,borderBottom:"1px solid #D6D6D6",mb:2}}>
        <Box sx={{ px: 3, pt: 3, pb: 2, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <Typography sx={{ fontSize: 22, fontWeight: 600, fontFamily: "Open Sans", color: "#111827" }}>
            Add Assets
          </Typography>
          <IconButton onClick={handleCancel} size="small">
            <XMarkIcon style={{ width: 24, height: 24, color: "#000000" }} />
          </IconButton>
        </Box>
      </DialogTitle>

      {/* Dialog Content */}
      <DialogContent sx={{ p: 3, pt: 2 }}>
        {/* Search and Sort Row */}
        <Box sx={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 2, mb: 3 }}>
          <Box>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Search Assets
            </Typography>
            <TextField
              select
              fullWidth
              placeholder="Search the User Assets"
              size="small"
              SelectProps={{
                displayEmpty: true,
              }}
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "6px",
                },
              }}
            >
              <MenuItem value="" disabled>
                Search the User Assets
              </MenuItem>
              <MenuItem value="asset1">Asset 1</MenuItem>
              <MenuItem value="asset2">Asset 2</MenuItem>
            </TextField>
          </Box>

          <Box>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Sort By
            </Typography>
            <TextField
              select
              fullWidth
              defaultValue="assetNumber"
              size="small"
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "6px",
                },
              }}
            >
              <MenuItem value="assetNumber">Asset Number(A to Z)</MenuItem>
              <MenuItem value="assetNumberDesc">Asset Number(Z to A)</MenuItem>
              <MenuItem value="date">Date Added</MenuItem>
            </TextField>
          </Box>
        </Box>

        {/* Main Content Area */}
        <Box sx={{ display: "grid", gridTemplateColumns: "200px 1fr", gap: 2, minHeight: "400px" }}>
          {/* Left Filters Panel */}
          <Box
            sx={{
              backgroundColor: "#F3F3F3",
              p: 2.5,
              borderRadius: 1,
              height: "fit-content",
            }}
          >
            <Typography sx={{ fontSize: 18, fontWeight: 600, fontFamily: "Open Sans", mb: 2, color: "#111827" }}>
              Filters
            </Typography>

            {/* User Filter */}
            <Box sx={{ mb: 2 }}>
              <Typography sx={{ fontSize: 14, fontWeight: 400, fontFamily: "Open Sans", mb: 1, color: "#000000" }}>
                User
              </Typography>
            </Box>

            {/* Active/Inactive Filter */}
            <Box sx={{ mb: 2 }}>
              <Typography sx={{ fontSize: 14, fontWeight: 600, fontFamily: "Open Sans", mb: 1, color: "#000000" }}>
                Active/Inactive
              </Typography>
              <Box sx={{ display: "flex", flexDirection: "column", gap: 0 }}>
                <FormControlLabel
                  control={
                    <Checkbox
                      size="small"
                      sx={{
                        color: "#D1D5DB",
                        "&.Mui-checked": {
                          color: "#409BFF",
                        },
                      }}
                    />
                  }
                  label={
                    <Typography sx={{ fontSize: 13, fontFamily: "Open Sans", color: "#4B5563" }}>
                      Active
                    </Typography>
                  }
                />
                <FormControlLabel
                  control={
                    <Checkbox
                      size="small"
                      sx={{
                        color: "#D1D5DB",
                        "&.Mui-checked": {
                          color: "#409BFF",
                        },
                      }}
                    />
                  }
                  label={
                    <Typography sx={{ fontSize: 13, fontFamily: "Open Sans", color: "#4B5563" }}>
                      Inactive
                    </Typography>
                  }
                />
              </Box>
            </Box>

            {/* Add Filter Dropdown */}
            <Box>
              <Typography sx={{ fontSize: 14, fontWeight: 600, fontFamily: "Open Sans", mb: 1, color: "#4B5563" }}>
                Add Filter
              </Typography>
              <TextField
                select
                fullWidth
                defaultValue="accountNumber"
                size="small"
                InputProps={{
                  sx: {
                    fontFamily: "Open Sans",
                    fontSize: 13,
                    borderRadius: "8px",
                  },
                }}
              >
                <MenuItem value="accountNumber">Account N...</MenuItem>
                <MenuItem value="location">Location</MenuItem>
                <MenuItem value="type">Type</MenuItem>
              </TextField>
            </Box>
          </Box>

          {/* Right Assets List Panel */}
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              gap: 2,
            }}
          >
            {assets.map((asset) => (
              <Box
                key={asset.id}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  gap: 2,
                  p: 2,
                  borderRadius: 1,
                  cursor: "pointer",
                  backgroundColor: "#F4F4F4",
                  transition: "all 0.2s ease",
                
                }}
                onClick={() => handleAssetToggle(asset)}
              >
                {/* Checkbox */}
                <Checkbox
                  checked={selectedAssets.some((a) => a.id === asset.id)}
                  onChange={() => handleAssetToggle(asset)}
                  sx={{
                    color: "#D1D5DB",
                    "&.Mui-checked": {
                      color: "#409BFF",
                    },
                  }}
                  onClick={(e) => e.stopPropagation()}
                />

                {/* Laptop Image with Red Background */}
                <Box
                  sx={{
                    // width: 56,
                    // height: 56,
                    // borderRadius: "50%",
                    // // backgroundColor: "#DC2626",
                    // display: "flex",
                    // alignItems: "center",
                    // justifyContent: "center",
                    // flexShrink: 0,
                  }}
                >
                  <img src={LapBackgroundImg} alt="Laptop" style={{ width: 60, height: 60, objectFit: "contain" }} />
                </Box>

                {/* Asset Details */}
                <Box sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, fontFamily: "Open Sans", color: "#000000", mb: 0.5 }}>
                    {asset.name}
                  </Typography>
                  <Typography sx={{ fontSize: 14, fontFamily: "Open Sans", color: "#000000" }}>
                    {asset.description}
                  </Typography>
                  <Typography sx={{ fontSize: 14, fontFamily: "Open Sans", color: "#000000" }}>
                    {asset.serialNumber}
                  </Typography>
                </Box>
              </Box>
            ))}
          </Box>
        </Box>
      </DialogContent>

      <Divider sx={{ m: 0 }} />

      {/* Dialog Actions */}
      <DialogActions sx={{ p: 3, gap: 2, justifyContent: "flex-end" }}>
        <Button
          onClick={handleConfirm}
          disabled={selectedAssets.length === 0}
          sx={{
            backgroundColor: selectedAssets.length > 0 ? "#409BFF" : "#E5E7EB",
            color: selectedAssets.length > 0 ? "#fff" : "#9CA3AF",
            textTransform: "none",
            fontFamily: "Open Sans",
            fontWeight: 600,
            fontSize: 16,
            px: 4,
            py: 1,
            borderRadius: "16px",
            "&:hover": {
              backgroundColor: selectedAssets.length > 0 ? "#2563EB" : "#E5E7EB",
            },
          }}
        >
          Confirm selection
        </Button>
        <Button
          onClick={handleCancel}
          sx={{
            backgroundColor: "#FF4141",
            color: "#fff",
            textTransform: "none",
            fontFamily: "Open Sans",
            fontWeight: 600,
            fontSize: 16,
            px: 4,
            py: 1,
            borderRadius: "16px",
            "&:hover": {
              backgroundColor: "#DC2626",
            },
          }}
        >
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AddAssetsDialog;
