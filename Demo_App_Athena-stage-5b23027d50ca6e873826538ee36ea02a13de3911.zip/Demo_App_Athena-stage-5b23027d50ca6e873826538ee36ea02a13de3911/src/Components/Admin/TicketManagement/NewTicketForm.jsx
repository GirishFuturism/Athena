import React, { useState } from "react";
import { Grid, Box, Typography, TextField, MenuItem, IconButton, Button, Autocomplete, Dialog, DialogContent, Select, FormControl, FormHelperText } from "@mui/material";
import TitleBreadcrumb from "../../Shared/TitleBreadcrumb";
import { useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import * as Yup from "yup";
import {
  HomeIcon,
  BugAntIcon,
  LightBulbIcon,
  QuestionMarkCircleIcon,
  MagnifyingGlassIcon,
  XMarkIcon,
  CloudArrowUpIcon,
  PaperClipIcon,
  CheckCircleIcon,
} from "@heroicons/react/24/solid";
import ReactQuill from "react-quill-new";
import 'react-quill-new/dist/quill.snow.css';

const hardwareOptions = [
  "Desktop Computer", "Laptop", "Monitor", "Keyboard", "Mouse", "Printer",
  "Scanner", "External Hard Drive", "Graphics Card", "RAM Module", "Motherboard",
  "Power Supply Unit (PSU)", "Network Router", "Webcam", "Docking Station", "USB Hub"
];

const templates = [
  {
    icon: <BugAntIcon style={{ width: 20, height: 20, color: "#EF4444" }} />,
    title: "Bug Report",
    description: "Report system issues",
    value: "bug",
  },
  {
    icon: <LightBulbIcon style={{ width: 20, height: 20, color: "#EAB308" }} />,
    title: "Feature Request",
    description: "Suggest improvements",
    value: "feature"
  },
  {
    icon: <QuestionMarkCircleIcon style={{ width: 20, height: 20, color: "#3B82F6" }} />,
    title: "General Support",
    description: "Get help with questions",
    value: "support"
  }
];

const validationSchema = Yup.object({
  fullName: Yup.string().required("Full Name is required"),
  site: Yup.string().required("Site is required"),
  username: Yup.string().required("Username is required"),
  email: Yup.string().email("Invalid email").required("Email is required"),
  phone: Yup.string()
    .matches(/^\+1 \(\d{3}\) \d{3}-\d{4}$/, "Phone must be in format +1 (555) 123-4567")
    .required("Phone is required"),
  postCode: Yup.string().required("Post/Zip Code is required"),
  ticketType: Yup.string().required("Ticket Type is required"),
  category: Yup.string().required("Category is required"),
  summary: Yup.string().required("Summary is required"),
  details: Yup.string().required("Details are required"),
});

const NewTicketForm = () => {
  const navigate = useNavigate();
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [attachments, setAttachments] = useState([]);
  const [isDragging, setIsDragging] = useState(false);
  const [assets, setAssets] = useState([]);
  const [successDialogOpen, setSuccessDialogOpen] = useState(false);

  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

  const formik = useFormik({
    initialValues: {
      fullName: "",
      site: "",
      username: "",
      email: "",
      phone: "",
      address1: "",
      address2: "",
      postCode: "",
      ticketType: "",
      category: "",
      summary: "",
      details: "",
      agreement: "",
      impact: "",
      urgency: "",
      otherTemplate: "",
    },
    validationSchema,
    onSubmit: (values) => {
      console.log("Form submitted:", values);
      console.log("Assets:", assets);
      console.log("Attachments:", attachments);
      setSuccessDialogOpen(true);
      setTimeout(() => { navigate('/ticket-management'); }, 2000);
    },
  });

  const handleFileUpload = (event) => {
    const files = Array.from(event.target.files);
    setAttachments([...attachments, ...files]);
  };

  const removeAttachment = (index) => {
    setAttachments(attachments.filter((_, i) => i !== index));
  };

  const handleDragEnter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files);
    const allowedTypes = ['.jpg', '.jpeg', '.png', '.pdf', '.doc', '.docx'];
    const validFiles = files.filter(file => {
      const extension = '.' + file.name.split('.').pop().toLowerCase();
      return allowedTypes.includes(extension);
    });
    if (validFiles.length > 0) {
      setAttachments([...attachments, ...validFiles]);
    }
  };

  // Quill editor configuration
  const quillModules = {
    toolbar: [
      ['bold', 'italic', 'underline'],
      [{ 'align': [] }],
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      ['link'],
      ['clean']
    ]
  };

  const quillFormats = [
    'bold', 'italic', 'underline', 'align', 'list', 'bullet', 'link'
  ];

  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <Grid container spacing={{ xs: 1, md: 2 }} columns={{ xs: 12, sm: 12, md: 12, xl: 12 }} sx={{ width: "100%", maxWidth: "100vw", m: 0, p: { xs: 0, sm: 1 }, justifyContent: "center", flexGrow: 1 }}>
          <Grid item size={{ xs: 12, sm: 12, md: 12, xl: 12 }} sx={{ border: "1px solid #E4E4E7", backgroundColor: "#fff", px: { xs: 1, sm: 4, md: 6, xl: 3 }, py: { xs: 0, sm: 3 }, boxShadow: { xs: "none", sm: "0 2px 14px rgba(116,185,255,.08)" } }}>
            
            {/* Breadcrumb */}
            <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
              <HomeIcon style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8 }} />
              <TitleBreadcrumb breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin" },
                { type: "link", label: "Tickets", to: "/ticket-management" },
                { type: "text", label: "New" }
              ]} />
            </Box>

            {/* Title */}
            <Typography sx={{ fontSize: 24, fontWeight: 700, mb: 0.5, color: "#111827", fontFamily: 'Open Sans' }}>
              Create New Ticket
            </Typography>

            {/* Subtitle */}
            <Typography sx={{ fontSize: 15, fontWeight: 400, mb: 4, color: "#4B5563", fontFamily: 'Open Sans' }}>
              Fill out the form below to submit a new support ticket
            </Typography>

            {/* Template Selection Grid */}
            <Box sx={{ border: "1px solid #E4E4E7", borderRadius: "8px", p: 3, mb: 4 }}>
              <Typography sx={{ fontSize: 18, fontWeight: 600, mb: 2.5, color: "#000", fontFamily: 'Open Sans' }}>
                Template Selection
              </Typography>
              <Grid container spacing={2.5}>
                {templates.map((template) => (
                  <Grid item xs={12} sm={6} md={3} key={template.value} sx={{ flex: 1 }}>
                    <Box onClick={() => setSelectedTemplate(template.value)} sx={{
                      border: "1px solid #E4E4E7",
                      borderRadius: "8px",
                      p: 2,
                      cursor: "pointer",
                      transition: "all 0.2s",
                      backgroundColor: selectedTemplate === template.value ? "#EFF6FF" : "#fff",
                      height: "100%",
                    }}>
                      <Box sx={{ display: "flex", alignItems: "center", mb: 0 }}>
                        <Box sx={{ width: 40, height: 32, borderRadius: "6px", display: "flex", alignItems: "center", justifyContent: "center" }}>
                          {template.icon}
                        </Box>
                        <Typography sx={{ fontSize: 16, fontWeight: 600, color: "#000", fontFamily: 'Open Sans' }}>
                          {template.title}
                        </Typography>
                      </Box>
                      <Typography sx={{ fontSize: 14, fontWeight: 400, color: "#6B7280", fontFamily: 'Open Sans', ml: 4.9 }}>
                        {template.description}
                      </Typography>
                    </Box>
                  </Grid>
                ))}

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Box sx={{ borderRadius: "8px", p: 1, height: "100%", display: "flex", flexDirection: "column", justifyContent: "center" }}>
                    <Typography sx={{ fontSize: 15, fontWeight: 500, mb: 1.5, color: "#374151", fontFamily: 'Open Sans' }}>
                      Other Choose a Template
                    </Typography>
                    <FormControl fullWidth size="small">
                      <Select
                        name="otherTemplate"
                        value={formik.values.otherTemplate}
                        onChange={formik.handleChange}
                        displayEmpty
                        MenuProps={menuProps}
                        sx={{
                          fontSize: 14,
                          fontFamily: 'Open Sans',
                          backgroundColor: "#fff",
                          height: 42,
                          "& .MuiOutlinedInput-notchedOutline": { borderColor: "#E4E4E7" },
                          "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#E4E4E7" },
                          "& .MuiSelect-select": { color: formik.values.otherTemplate ? "#000" : "#A1A1AA" }
                        }}
                      >
                        <MenuItem value="">Choose a Template</MenuItem>
                        <MenuItem value="custom1">Custom Template 1</MenuItem>
                        <MenuItem value="custom2">Custom Template 2</MenuItem>
                      </Select>
                    </FormControl>
                  </Box>
                </Grid>
              </Grid>
            </Box>

            {/* End User Details */}
            <Box sx={{ border: "1px solid #E4E4E7", borderRadius: "8px", p: 3, mb: 3 }}>
              <Typography sx={{ fontSize: 18, fontWeight: 600, mb: 2, color: "#000", fontFamily: 'Open Sans' }}>
                End User Details
              </Typography>

              {/* First Row */}
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Full Name <span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <Box sx={{ position: "relative" }}>
                    <TextField
                      fullWidth
                      size="small"
                      name="fullName"
                      placeholder="Enter full name"
                      value={formik.values.fullName}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      error={formik.touched.fullName && Boolean(formik.errors.fullName)}
                      sx={{
                        "& .MuiOutlinedInput-root": {
                          fontSize: 13,
                          fontFamily: 'Open Sans',
                          backgroundColor: "#fff",
                          height: 36,
                          paddingRight: "70px",
                          "& fieldset": { borderColor: formik.touched.fullName && formik.errors.fullName ? "#EF4444" : "#D1D5DB" },
                          "&:hover fieldset": { borderColor: "#D1D5DB" },
                          "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                        }
                      }}
                    />
                    <Box sx={{ position: "absolute", right: 8, top: 8, display: "flex", gap: 0.5, alignItems: "center" }}>
                      {formik.values.fullName && (
                        <IconButton size="small" onClick={() => formik.setFieldValue("fullName", "")} sx={{ p: 0.3 }}>
                          <XMarkIcon style={{ width: 14, height: 14, color: "#71717A" }} />
                        </IconButton>
                      )}
                      <Box sx={{ width: 1, height: 16, backgroundColor: "#E4E4E7", mx: 0.3 }} />
                      <IconButton size="small" sx={{ p: 0.3 }}>
                        <svg width="14" height="14" viewBox="0 0 20 20" fill="none">
                          <path d="M10 6V6.01M10 8V12M10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10C2 14.4183 5.58172 18 10 18Z" 
                            stroke="#71717A" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      </IconButton>
                      <IconButton size="small" sx={{ p: 0.3 }}>
                        <MagnifyingGlassIcon style={{ width: 14, height: 14, color: "#71717A" }} />
                      </IconButton>
                    </Box>
                    {formik.touched.fullName && formik.errors.fullName && (
                      <FormHelperText error sx={{ mx: 1.75, mt: 0.5 }}>
                        {formik.errors.fullName}
                      </FormHelperText>
                    )}
                  </Box>
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Site <span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <Box sx={{ position: "relative" }}>
                    <FormControl fullWidth size="small" error={formik.touched.site && Boolean(formik.errors.site)}>
                      <Select
                        name="site"
                        value={formik.values.site}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        displayEmpty
                        MenuProps={menuProps}
                        sx={{
                          fontSize: 13,
                          fontFamily: 'Open Sans',
                          backgroundColor: "#fff",
                          height: 36,
                          paddingRight: "32px",
                          "& .MuiOutlinedInput-notchedOutline": { borderColor: formik.touched.site && formik.errors.site ? "#EF4444" : "#D1D5DB" },
                          "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                          "& .MuiSelect-select": { color: formik.values.site ? "#000" : "#A1A1AA" }
                        }}
                      >
                        <MenuItem value="">Search by Name</MenuItem>
                        <MenuItem value="site1">Site 1</MenuItem>
                        <MenuItem value="site2">Site 2</MenuItem>
                        <MenuItem value="site3">Site 3</MenuItem>
                      </Select>
                      {formik.touched.site && formik.errors.site && (
                        <FormHelperText>{formik.errors.site}</FormHelperText>
                      )}
                    </FormControl>
                    <IconButton size="small" sx={{ position: "absolute", right: 32, top: 8, p: 0.3, pointerEvents: "none" }}>
                      <MagnifyingGlassIcon style={{ width: 14, height: 14, color: "#71717A" }} />
                    </IconButton>
                  </Box>
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Username<span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <Box sx={{ position: "relative" }}>
                    <FormControl fullWidth size="small" error={formik.touched.username && Boolean(formik.errors.username)}>
                      <Select
                        name="username"
                        value={formik.values.username}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        displayEmpty
                        MenuProps={menuProps}
                        sx={{
                          fontSize: 13,
                          fontFamily: 'Open Sans',
                          backgroundColor: "#fff",
                          height: 36,
                          paddingRight: "32px",
                          "& .MuiOutlinedInput-notchedOutline": { borderColor: formik.touched.username && formik.errors.username ? "#EF4444" : "#D1D5DB" },
                          "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                          "& .MuiSelect-select": { color: formik.values.username ? "#000" : "#A1A1AA" }
                        }}
                      >
                        <MenuItem value="">Search by Name</MenuItem>
                        <MenuItem value="user1">User 1</MenuItem>
                        <MenuItem value="user2">User 2</MenuItem>
                        <MenuItem value="user3">User 3</MenuItem>
                      </Select>
                      {formik.touched.username && formik.errors.username && (
                        <FormHelperText>{formik.errors.username}</FormHelperText>
                      )}
                    </FormControl>
                    <IconButton size="small" sx={{ position: "absolute", right: 32, top: 8, p: 0.3, pointerEvents: "none" }}>
                      <MagnifyingGlassIcon style={{ width: 14, height: 14, color: "#71717A" }} />
                    </IconButton>
                  </Box>
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Email<span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="email"
                    placeholder="john@company.com" 
                    value={formik.values.email}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    error={formik.touched.email && Boolean(formik.errors.email)}
                    helperText={formik.touched.email && formik.errors.email}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: formik.touched.email && formik.errors.email ? "#EF4444" : "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>
              </Grid>

              {/* Second Row */}
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Phone<span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="phone"
                    placeholder="+1 (555) 123-4567" 
                    value={formik.values.phone}
                    onChange={(e) => {
                      let value = e.target.value.replace(/\D/g, '');
                      if (value.length > 10) value = value.slice(0, 10);
                      let formatted = '';
                      if (value.length > 0) {
                        formatted = '+1 ';
                        if (value.length <= 3) {
                          formatted += `(${value}`;
                        } else if (value.length <= 6) {
                          formatted += `(${value.slice(0, 3)}) ${value.slice(3)}`;
                        } else {
                          formatted += `(${value.slice(0, 3)}) ${value.slice(3, 6)}-${value.slice(6)}`;
                        }
                      }
                      formik.setFieldValue("phone", formatted);
                    }}
                    onBlur={formik.handleBlur}
                    error={formik.touched.phone && Boolean(formik.errors.phone)}
                    helperText={formik.touched.phone && formik.errors.phone}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: formik.touched.phone && formik.errors.phone ? "#EF4444" : "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Contact Address
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="address1"
                    placeholder="Address line 1" 
                    value={formik.values.address1}
                    onChange={formik.handleChange}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Contact Address
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="address2"
                    placeholder="Address line 2" 
                    value={formik.values.address2}
                    onChange={formik.handleChange}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Post/Zip Code<span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="postCode"
                    placeholder="Post/Zip Code" 
                    value={formik.values.postCode}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    error={formik.touched.postCode && Boolean(formik.errors.postCode)}
                    helperText={formik.touched.postCode && formik.errors.postCode}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: formik.touched.postCode && formik.errors.postCode ? "#EF4444" : "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>
              </Grid>
            </Box>

            {/* Ticket Details Section */}
            <Box sx={{ border: "1px solid #E4E4E7", borderRadius: "8px", p: 3, mb: 3 }}>
              <Typography sx={{ fontSize: 18, fontWeight: 600, mb: 2.5, color: "#111827", fontFamily: 'Open Sans' }}>
                Ticket Details
              </Typography>

              {/* Row 1: Ticket Type, Category, Summary */}
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item xs={12} sm={6} md={4} flex={1}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Ticket Type<span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <FormControl fullWidth size="small" error={formik.touched.ticketType && Boolean(formik.errors.ticketType)}>
                    <Select
                      name="ticketType"
                      value={formik.values.ticketType}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& .MuiOutlinedInput-notchedOutline": { borderColor: formik.touched.ticketType && formik.errors.ticketType ? "#EF4444" : "#D1D5DB" },
                        "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { color: formik.values.ticketType ? "#000" : "#A1A1AA" }
                      }}
                    >
                      <MenuItem value="">Select Type</MenuItem>
                      <MenuItem value="incident">Incident</MenuItem>
                      <MenuItem value="request">Request</MenuItem>
                      <MenuItem value="problem">Problem</MenuItem>
                    </Select>
                    {formik.touched.ticketType && formik.errors.ticketType && (
                      <FormHelperText>{formik.errors.ticketType}</FormHelperText>
                    )}
                  </FormControl>
                </Grid>

                <Grid item xs={12} sm={6} md={4} flex={1}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Category<span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <FormControl fullWidth size="small" error={formik.touched.category && Boolean(formik.errors.category)}>
                    <Select
                      name="category"
                      value={formik.values.category}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& .MuiOutlinedInput-notchedOutline": { borderColor: formik.touched.category && formik.errors.category ? "#EF4444" : "#D1D5DB" },
                        "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { color: formik.values.category ? "#000" : "#A1A1AA" }
                      }}
                    >
                      <MenuItem value="">Select Category</MenuItem>
                      <MenuItem value="hardware">Hardware</MenuItem>
                      <MenuItem value="software">Software</MenuItem>
                      <MenuItem value="network">Network</MenuItem>
                    </Select>
                    {formik.touched.category && formik.errors.category && (
                      <FormHelperText>{formik.errors.category}</FormHelperText>
                    )}
                  </FormControl>
                </Grid>

                <Grid item xs={12} sm={12} md={4} flex={1}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans'}}>
                    Summary<span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="summary"
                    value={formik.values.summary} 
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    error={formik.touched.summary && Boolean(formik.errors.summary)}
                    helperText={formik.touched.summary && formik.errors.summary}
                    placeholder="Brief description of the issue" 
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: formik.touched.summary && formik.errors.summary ? "#EF4444" : "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>
              </Grid>

              {/* RICH TEXT EDITOR - REPLACED */}
              <Box sx={{ mb: 3 }}>
                <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                  Details<span style={{ color: '#EF4444' }}>*</span>
                </Typography>
                
                <Box sx={{
                  border: formik.touched.details && formik.errors.details ? "1px solid #EF4444" : "1px solid #D1D5DB",
                  borderRadius: "4px",
                  '& .quill': {
                    fontFamily: 'Open Sans',
                  },
                  '& .ql-container': {
                    minHeight: '150px',
                    fontSize: '13px',
                    fontFamily: 'Open Sans',
                    borderBottomLeftRadius: '4px',
                    borderBottomRightRadius: '4px',
                  },
                  '& .ql-editor': {
                    minHeight: '150px',
                  },
                  '& .ql-toolbar': {
                    borderTopLeftRadius: '4px',
                    borderTopRightRadius: '4px',
                    backgroundColor: '#F2F8FF',
                    borderColor: formik.touched.details && formik.errors.details ? "#EF4444" : "#D1D5DB",
                  },
                  '& .ql-stroke': {
                    stroke: '#000',
                  },
                  '& .ql-fill': {
                    fill: '#000',
                  },
                  '& .ql-picker-label': {
                    color: '#000',
                  }
                }}>
                  <ReactQuill
                    theme="snow"
                    value={formik.values.details}
                    onChange={(value) => formik.setFieldValue("details", value)}
                    onBlur={() => formik.setFieldTouched("details", true)}
                    modules={quillModules}
                    formats={quillFormats}
                    placeholder="Provide detailed description of the issue, steps to reproduce, expected vs actual behavior..."
                  />
                </Box>
                {formik.touched.details && formik.errors.details && (
                  <Typography sx={{ fontSize: 12, color: "#EF4444", mt: 0.5, ml: 1.5 }}>
                    {formik.errors.details}
                  </Typography>
                )}
              </Box>

              {/* Row 2: Agreement, Impact, Priority */}
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item xs={12} sm={4} flex={1}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Agreement
                  </Typography>
                  <FormControl fullWidth size="small">
                    <Select
                      name="agreement"
                      value={formik.values.agreement}
                      onChange={formik.handleChange}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { color: formik.values.agreement ? "#000" : "#A1A1AA" }
                      }}
                    >
                      <MenuItem value="">Select Agreement</MenuItem>
                      <MenuItem value="sla1">SLA Level 1</MenuItem>
                      <MenuItem value="sla2">SLA Level 2</MenuItem>
                      <MenuItem value="sla3">SLA Level 3</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>

                <Grid item xs={12} sm={4} flex={1}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Impact
                  </Typography>
                  <FormControl fullWidth size="small">
                    <Select
                      name="impact"
                      value={formik.values.impact}
                      onChange={formik.handleChange}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { color: formik.values.impact ? "#000" : "#A1A1AA" }
                      }}
                    >
                      <MenuItem value="">Select Impact</MenuItem>
                      <MenuItem value="high">Company Wide</MenuItem>
                      <MenuItem value="medium">Multiple User Affiliate</MenuItem>
                      <MenuItem value="low">Individual User</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>

                <Grid item xs={12} sm={4} flex={1}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Priority
                  </Typography>
                  <FormControl fullWidth size="small">
                    <Select
                      name="urgency"
                      value={formik.values.urgency}
                      onChange={formik.handleChange}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { color: formik.values.urgency ? "#000" : "#A1A1AA" }
                      }}
                    >
                      <MenuItem value="">Select Urgency</MenuItem>
                      <MenuItem value="urgent">Urgent</MenuItem>
                      <MenuItem value="high">High</MenuItem>
                      <MenuItem value="normal">Normal</MenuItem>
                      <MenuItem value="low">Low</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
              </Grid>

              {/* Assets Field */}
              <Box sx={{ mb: 3 }}>
                <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                  Assets
                </Typography>
                <Autocomplete
                  multiple
                  freeSolo
                  options={hardwareOptions}
                  value={assets}
                  onChange={(event, newValue) => setAssets(newValue)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      placeholder="Search or select hardware assets"
                      sx={{
                        "& .MuiOutlinedInput-root": {
                          fontSize: 13,
                          fontFamily: 'Open Sans',
                          backgroundColor: "#fff",
                          minHeight: 42,  
                          height: "auto",  
                          padding: "4px 8px",  
                          "& fieldset": { borderColor: "#D1D5DB" },
                          "&:hover fieldset": { borderColor: "#D1D5DB" },
                          "& input": {
                            height: "20px",  
                            padding: "0 !important",  
                          },
                          "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                        }
                      }}
                    />
                  )}
                  sx={{
                    "& .MuiAutocomplete-tag": {
                      backgroundColor: "#EFF6FF",
                      color: "#1E40AF",
                      fontSize: 12,
                      fontFamily: 'Open Sans',
                      height: 24,
                      margin: "2px",
                    },
                    "& .MuiAutocomplete-inputRoot": {
                      paddingTop: "2px !important",
                      paddingBottom: "2px !important",
                    }
                  }}
                />
              </Box>

              {/* Attachments Section */}
              <Box>
                <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                  Attachments
                </Typography>
                
                <input
                  type="file"
                  id="file-upload"
                  multiple
                  accept=".jpg,.jpeg,.png,.pdf,.doc,.docx"
                  style={{ display: "none" }}
                  onChange={handleFileUpload}
                />
                
                <Box
                  onDragEnter={handleDragEnter}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  onClick={() => document.getElementById('file-upload').click()}
                  sx={{
                    border: isDragging ? "2px dashed #3B82F6" : "2px dashed #E4E4E7",
                    borderRadius: "8px",
                    p: 4,
                    textAlign: "center",
                    backgroundColor: isDragging ? "#F8FAFC" : "transparent",
                    cursor: "pointer",
                    transition: "all 0.2s",
                    "&:hover": {
                      borderColor: "#3B82F6",
                      backgroundColor: "#F8FAFC"
                    }
                  }}
                >
                  <CloudArrowUpIcon style={{ width: 48, height: 48, color: isDragging ? "#3B82F6" : "#9CA3AF", margin: "0 auto", display: "block" }} />
                  <Typography sx={{ fontSize: 16, fontWeight: 600, color: "#4B5563", mt: 2, fontFamily: 'Open Sans' }}>
                    Drop files here or click to browse
                  </Typography>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, color: "#6B7280", mt: 0.5, fontFamily: 'Open Sans' }}>
                    Supports: JPG, PNG, PDF, DOC, DOCX (Max 10MB each)
                  </Typography>
                  <Button
                    variant="contained"
                    onClick={(e) => {
                      e.stopPropagation();
                      document.getElementById('file-upload').click();
                    }}
                    startIcon={<PaperClipIcon style={{ width: 16, height: 16 }} />}
                    sx={{
                      mt: 2,
                      backgroundColor: "#409BFF",
                      textTransform: "none",
                      fontSize: 16,
                      fontWeight: 600,
                      borderRadius: "8px",
                      fontFamily: 'Open Sans',
                      px: 3,
                      py: 1,
                      "&:hover": { backgroundColor: "#3380e8" }
                    }}
                  >
                    Choose Files
                  </Button>
                </Box>

                {attachments.length > 0 && (
                  <Box sx={{ mt: 2 }}>
                    <Typography sx={{ fontSize: 14, fontWeight: 500, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                      Attached Files ({attachments.length})
                    </Typography>
                    {attachments.map((file, index) => (
                      <Box
                        key={index}
                        sx={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                          p: 1.5,
                          borderRadius: "6px",
                          mb: 1,
                          backgroundColor: "#F9FAFB",
                          border: "1px solid #E5E7EB"
                        }}
                      >
                        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                          <PaperClipIcon style={{ width: 16, height: 16, color: "#6B7280" }} />
                          <Typography sx={{ fontSize: 14, fontFamily: 'Open Sans', color: "#374151" }}>
                            {file.name}
                          </Typography>
                          <Typography sx={{ fontSize: 12, fontFamily: 'Open Sans', color: "#9CA3AF" }}>
                            ({(file.size / 1024).toFixed(1)} KB)
                          </Typography>
                        </Box>
                        <IconButton
                          size="small"
                          onClick={() => removeAttachment(index)}
                          sx={{ 
                            p: 0.5,
                            "&:hover": {
                              backgroundColor: "#FEE2E2",
                              "& svg": { color: "#DC2626" }
                            }
                          }}
                        >
                          <XMarkIcon style={{ width: 16, height: 16, color: "#6B7280" }} />
                        </IconButton>
                      </Box>
                    ))}
                  </Box>
                )}
              </Box>
            </Box>

            {/* Footer Section */}
            <Box sx={{ 
              position: "sticky",
              bottom: 0,
              left: 0,
              right: 0,
              bgcolor:"#fff",
              borderTop: "1px solid #E4E4E7",
              pt: 3,
              pb: 2,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              flexWrap: "wrap",
              gap: 2
            }}>
              <Typography sx={{ fontSize: 16, fontWeight: 700, color: "#4B5563", fontFamily: 'Open Sans' }}>
                Save as Draft
              </Typography>

              <Box sx={{ display: "flex", gap: 2 }}>
                <Button
                  variant="outlined"
                  onClick={() => navigate('/ticket-management')}
                  sx={{
                    px: 3,
                    py: 1,
                    fontSize: 15,
                    fontWeight: 500,
                    fontFamily: 'Open Sans',
                    textTransform: "none",
                    color: "#374151",
                    borderColor: "#D1D5DB",
                    borderRadius: "6px",
                    "&:hover": {
                      borderColor: "#9CA3AF",
                      backgroundColor: "#F9FAFB"
                    }
                  }}
                >
                  Cancel
                </Button>
                
                <Button
                  type="submit"
                  variant="contained"
                  startIcon={
                    <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M3.105 2.289a.75.75 0 00-.826.95l1.414 4.925A1.5 1.5 0 005.135 9.25h6.115a.75.75 0 010 1.5H5.135a1.5 1.5 0 00-1.442 1.086l-1.414 4.926a.75.75 0 00.826.95 28.896 28.896 0 0015.293-7.154.75.75 0 000-1.115A28.897 28.897 0 003.105 2.289z" />
                    </svg>
                  }
                  sx={{
                    px: 3,
                    py: 1,
                    fontSize: 15,
                    fontWeight: 600,
                    fontFamily: 'Open Sans',
                    textTransform: "none",
                    backgroundColor: "#409BFF",
                    borderRadius: "6px",
                    boxShadow: "none",
                  }}
                >
                  Submit Ticket
                </Button>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </form>

      {/* Success Dialog */}
      <Dialog open={successDialogOpen} disableScrollLock PaperProps={{ sx: { borderRadius: "12px", p: 2, minWidth: "400px" } }}>
        <DialogContent>
          <Box sx={{ textAlign: "center", py: 2 }}>
            <CheckCircleIcon style={{ width: 64, height: 64, color: "#409BFF", margin: "0 auto", display: "block" }} />
            <Typography sx={{ fontSize: 20, fontWeight: 700, color: "#111827", mt: 2, fontFamily: 'Open Sans' }}>
              Ticket Submitted Successfully!
            </Typography>
            <Typography sx={{ fontSize: 14, fontWeight: 400, color: "#6B7280", mt: 1, fontFamily: 'Open Sans' }}>
              Your ticket has been created. Redirecting...
            </Typography>
          </Box>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default NewTicketForm;
