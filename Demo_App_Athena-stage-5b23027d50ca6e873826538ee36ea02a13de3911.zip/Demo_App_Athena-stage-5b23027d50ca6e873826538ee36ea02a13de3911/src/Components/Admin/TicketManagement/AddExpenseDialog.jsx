import React from "react";
import { Dialog, DialogTitle, DialogContent, DialogActions, Box, Typography, TextField, MenuItem, IconButton, Button, Divider, Grid, Checkbox, FormControlLabel, InputAdornment } from "@mui/material";
import { XMarkIcon } from "@heroicons/react/24/solid";

// Helper functions for number formatting
const formatNumberWithCommas = (value) => {
  if (!value) return "";
  
  // Remove all non-numeric characters except decimal point
  const numericValue = value.replace(/[^\d.]/g, "");
  
  // Split into integer and decimal parts
  const parts = numericValue.split(".");
  
  // Add commas to integer part
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  
  // Join parts back together (limit to 2 decimal places)
  return parts.length > 1 ? `${parts[0]}.${parts[1].slice(0, 2)}` : parts[0];
};

const removeCommas = (value) => {
  return value.replace(/,/g, "");
};

const AddExpenseDialog = ({ open, onClose, onSave }) => {
  const [formData, setFormData] = React.useState({
    description: "",
    cost: "",
    type: "",
    dateAdded: "",
    dateReimbursed: "",
    dateInvoice: "",
    isBillable: false,
  });

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  // Handle cost input with automatic comma formatting
  const handleCostChange = (e) => {
    const value = e.target.value;
    
    // Allow empty string
    if (value === "") {
      handleChange("cost", "");
      return;
    }
    
    // Remove commas for validation
    const valueWithoutCommas = removeCommas(value);
    
    // Regular expression to allow only numbers and one decimal point
    const regex = /^\d*\.?\d{0,2}$/;
    
    if (regex.test(valueWithoutCommas)) {
      // Format with commas and update state
      const formattedValue = formatNumberWithCommas(valueWithoutCommas);
      handleChange("cost", formattedValue);
    }
  };

  const handleSave = () => {
    if (formData.description && formData.type) {
      // Remove commas before saving
      const numericCost = removeCommas(formData.cost);
      
      onSave({
        ...formData,
        cost: numericCost ? `$${parseFloat(numericCost).toFixed(2)}` : "",
      });
      
      setFormData({
        description: "",
        cost: "",
        type: "",
        dateAdded: "",
        dateReimbursed: "",
        dateInvoice: "",
        isBillable: false,
      });
      onClose();
    }
  };

  const handleCancel = () => {
    setFormData({
      description: "",
      cost: "",
      type: "",
      dateAdded: "",
      dateReimbursed: "",
      dateInvoice: "",
      isBillable: false,
    });
    onClose();
  };

  return (
    <Dialog
      open={open}
      disableScrollLock
      onClose={handleCancel}
      maxWidth="sm"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 2,
        },
      }}
    >
      {/* Dialog Header */}
      <DialogTitle sx={{ p: 0 }}>
        <Box sx={{ px: 3, pt: 3, pb: 2, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <Typography sx={{ fontSize: 22, fontWeight: 600, fontFamily: "Open Sans", color: "#111827" }}>
            Expenses
          </Typography>
          <IconButton onClick={handleCancel} size="small">
            <XMarkIcon style={{ width: 24, height: 24, color: "#000000" }} />
          </IconButton>
        </Box>
      </DialogTitle>

      <Divider sx={{ m: 0 }} />

      {/* Dialog Content */}
      <DialogContent sx={{ p: 3 }}>
        <Grid container spacing={2}>
          {/* Description - Full Width (12) */}
          <Grid size={{ xs: 12, sm: 12, md: 12, lg: 12, xl: 12 }}>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Description
            </Typography>
            <TextField
              fullWidth
              multiline
              rows={4}
              value={formData.description}
              onChange={(e) => handleChange("description", e.target.value)}
              placeholder="Type here"
              sx={{
                "& .MuiOutlinedInput-root": {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "6px",
                },
              }}
            />
          </Grid>

          {/* Row 1: Cost, Type, Date Added (4 each) */}
          <Grid size={{ xs: 12, sm: 4, md: 4, lg: 4, xl: 4 }}>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Cost
            </Typography>
            <TextField
              fullWidth
              value={formData.cost}
              onChange={handleCostChange}
              placeholder="0.00"
              size="small"
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Typography
                      sx={{
                        fontSize: 14,
                        fontWeight: 600,
                        fontFamily: "Open Sans",
                        color: "#6B7280",
                      }}
                    >
                      $
                    </Typography>
                  </InputAdornment>
                ),
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "6px",
                },
              }}
              sx={{
                "& .MuiOutlinedInput-root": {
                  "&.Mui-focused fieldset": {
                    borderColor: "#409BFF",
                  },
                },
                "& .MuiOutlinedInput-input": {
                  color: "#111827",
                },
              }}
            />
          </Grid>

          <Grid size={{ xs: 12, sm: 4, md: 4, lg: 4, xl: 4 }}>
            <Typography sx={{fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Type
            </Typography>
            <TextField
              select
              fullWidth
              value={formData.type}
              onChange={(e) => handleChange("type", e.target.value)}
              size="small"
              SelectProps={{
                displayEmpty: true,
              }}
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "6px",
                },
              }}
            >
              <MenuItem value="" disabled>
               Select Type
              </MenuItem>
              <MenuItem value="Travel">Travel</MenuItem>
              <MenuItem value="Equipment">Equipment</MenuItem>
              <MenuItem value="Software">Software</MenuItem>
              <MenuItem value="Other">Other</MenuItem>
            </TextField>
          </Grid>

          <Grid size={{ xs: 12, sm: 4, md: 4, lg: 4, xl: 4 }}>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Date added
            </Typography>
            <TextField
              fullWidth
              type="date"
              value={formData.dateAdded}
              onChange={(e) => handleChange("dateAdded", e.target.value)}
              placeholder="Date"
              size="small"
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "6px",
                },
              }}
              InputLabelProps={{
                shrink: true,
              }}
            />
          </Grid>

          {/* Row 2: Date Reimbursed, Date Invoice, Is Billable (4 each) */}
          <Grid size={{ xs: 12, sm: 4, md: 4, lg: 4, xl: 4 }}>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600  }}>
              Date Reimbursed
            </Typography>
            <TextField
              fullWidth
              type="date"
              value={formData.dateReimbursed}
              onChange={(e) => handleChange("dateReimbursed", e.target.value)}
              placeholder="Date"
              size="small"
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "6px",
                },
              }}
              InputLabelProps={{
                shrink: true,
              }}
            />
          </Grid>

          <Grid size={{ xs: 12, sm: 4, md: 4, lg: 4, xl: 4 }}>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600  }}>
              Date Invoice
            </Typography>
            <TextField
              fullWidth
              type="date"
              value={formData.dateInvoice}
              onChange={(e) => handleChange("dateInvoice", e.target.value)}
              placeholder="Date"
              size="small"
              InputProps={{
                sx: {
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  borderRadius: "6px",
                },
              }}
              InputLabelProps={{
                shrink: true,
              }}
            />
          </Grid>

          <Grid size={{ xs: 12, sm: 4, md: 4, lg: 4, xl: 4 }}>
            <Typography sx={{ fontSize: 14, color: "#4B5563", fontFamily: "Open Sans", mb: 1, fontWeight: 600 }}>
              Is Billable
            </Typography>
            <FormControlLabel
              control={
                <Checkbox
                  checked={formData.isBillable}
                  onChange={(e) => handleChange("isBillable", e.target.checked)}
                  sx={{
                    color: "#D1D5DB",
                    ml:2.5,
                    "&.Mui-checked": {
                      color: "#409BFF",
                    },
                  }}
                />
              }
              label=""
              sx={{ mt: 0.5 }}
            />
          </Grid>
        </Grid>
      </DialogContent>

      <Divider sx={{ m: 0 }} />

      {/* Dialog Actions */}
      <DialogActions sx={{ p: 3, gap: 2, justifyContent: "flex-end" }}>
        <Button
          onClick={handleSave}
          disabled={!formData.description || !formData.type}
          sx={{
            backgroundColor: formData.description && formData.type ? "#409BFF" : "#E5E7EB",
            color: formData.description && formData.type ? "#fff" : "#9CA3AF",
            textTransform: "none",
            fontFamily: "Open Sans",
            fontWeight: 600,
            fontSize: 16,
            px: 4,
            py: 1,
            borderRadius: "16px",
            "&:hover": {
              backgroundColor: formData.description && formData.type ? "#2563EB" : "#E5E7EB",
            },
          }}
        >
          Save
        </Button>
        <Button
          onClick={handleCancel}
          sx={{
            backgroundColor: "#FF4141",
            color: "#fff",
            textTransform: "none",
            fontFamily: "Open Sans",
            fontWeight: 600,
            fontSize: 16,
            px: 4,
            py: 1,
            borderRadius: "16px",
            "&:hover": {
              backgroundColor: "#DC2626",
            },
          }}
        >
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AddExpenseDialog;
