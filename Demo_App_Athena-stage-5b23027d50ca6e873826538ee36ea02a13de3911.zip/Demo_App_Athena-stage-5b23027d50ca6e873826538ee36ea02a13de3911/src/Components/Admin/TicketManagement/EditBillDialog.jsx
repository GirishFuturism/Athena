import React, { useState } from "react";
import {
  Dialog,
  Button,
  Typography,
  Box,
  IconButton,
  Select,
  MenuItem,
  FormControl,
} from "@mui/material";
import { XMarkIcon } from "@heroicons/react/24/solid";

const EditBillDialog = ({ open, onClose, onSave, initialData }) => {
  const [timeTaken, setTimeTaken] = useState(initialData?.billableTime || "04:00");

  const handleSave = () => {
    onSave({ timeTaken });
    onClose();
  };

  return (
    <Dialog
      open={open}
      disableScrollLock
      onClose={onClose}
      maxWidth="sm"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: "12px",
          maxWidth: "500px",
        },
      }}
    >
      <Box sx={{ p: 3 }}>
        {/* Header */}
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 3 }}>
          <Typography
            sx={{
              fontSize: 22,
              fontWeight: 600,
              fontFamily: "Open Sans",
              color: "#111827",
            }}
          >
            Edit Billing
          </Typography>
          <IconButton onClick={onClose} sx={{ p: 0 }}>
            <XMarkIcon style={{ width: 24, height: 24, color: "#000000" }} />
          </IconButton>
        </Box>

        {/* Time Taken Field */}
        <Box sx={{ mb: 4,}}>
          <Typography
            sx={{
              fontSize: 14,
              fontWeight: 600,
              fontFamily: "Open Sans",
              color: "#374151",
              mb: 1,
            }}
          >
            Time Taken
          </Typography>
          <FormControl fullWidth>
            <Select
              value={timeTaken}
              onChange={(e) => setTimeTaken(e.target.value)}
              sx={{
                fontSize: 14,
                fontFamily: "Open Sans",
                height: 44,
                "& .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#D1D5DB",
                },
                "&:hover .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#D1D5DB",
                },
              }}
            >
              <MenuItem value="00:30">00:30</MenuItem>
              <MenuItem value="01:00">01:00</MenuItem>
              <MenuItem value="01:30">01:30</MenuItem>
              <MenuItem value="02:00">02:00</MenuItem>
              <MenuItem value="02:30">02:30</MenuItem>
              <MenuItem value="03:00">03:00</MenuItem>
              <MenuItem value="03:30">03:30</MenuItem>
              <MenuItem value="04:00">04:00</MenuItem>
              <MenuItem value="04:30">04:30</MenuItem>
              <MenuItem value="05:00">05:00</MenuItem>
            </Select>
          </FormControl>
        </Box>

        {/* Buttons */}
        <Box sx={{ display: "flex", gap: 2, justifyContent: "flex-end", pt: 2 }}>
         
          <Button
            onClick={handleSave}
            variant="contained"
            sx={{
              backgroundColor: "#409BFF",
              color: "#FFFFFF",
              fontFamily: "Open Sans",
              fontWeight: 600,
              fontSize: 14,
              borderRadius: "8px",
              height: "44px",
              px: 4,
              textTransform: "none",
              boxShadow: "none",
              "&:hover": {
                backgroundColor: "#2563EB",
              },
            }}
          >
            Save
          </Button>
           <Button
            onClick={onClose}
            variant="contained"
            sx={{
              backgroundColor: "#FF5E5E",
              color: "#FFFFFF",
              fontFamily: "Open Sans",
              fontWeight: 600,
              fontSize: 14,
              borderRadius: "8px",
              height: "44px",
              px: 4,
              textTransform: "none",
              boxShadow: "none",
              "&:hover": {
                backgroundColor: "#E54545",
              },
            }}
          >
            Cancel
          </Button>
        </Box>
      </Box>
    </Dialog>
  );
};

export default EditBillDialog;
