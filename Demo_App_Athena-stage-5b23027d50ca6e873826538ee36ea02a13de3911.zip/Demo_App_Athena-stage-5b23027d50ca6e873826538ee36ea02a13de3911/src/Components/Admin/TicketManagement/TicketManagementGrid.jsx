import React, { useState } from "react";
import { Grid, Box, Typography, Chip, Avatar, LinearProgress, Button, IconButton, Select, MenuItem, FormControl, OutlinedInput, TextField } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import TitleBreadcrumb from "../../Shared/TitleBreadcrumb";
import { rows } from "../../../Data/TicketManagementData";
import { useNavigate } from "react-router-dom";
import {
  HomeIcon,
  TicketIcon,
  ClockIcon,
  ChevronDoubleUpIcon,
  ExclamationCircleIcon,
  CheckCircleIcon,
  XCircleIcon,
  ChevronUpIcon,
  ChevronDownIcon,
  ArrowPathIcon,
  ArrowTopRightOnSquareIcon,
  EllipsisHorizontalIcon,
  CalendarIcon,
  AdjustmentsHorizontalIcon,
} from "@heroicons/react/24/solid";
import { UserCircleIcon } from "@heroicons/react/24/solid";
import approvedImg from "../../../assets/approved.png"
import holdImg from "../../../assets/hold.png"
import quoteImg from "../../../assets/quote.png"
import rejectedImg from "../../../assets/rejected.png"


const TicketManagementGrid = () => {
  const [typeFilter, setTypeFilter] = useState("all");
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [appliedDateRange, setAppliedDateRange] = useState(null);
  const [loading, setLoading] = useState(false);
  const [gridKey, setGridKey] = useState(0);
  
  const navigate = useNavigate();

  const handleRowClick = (params) => {
    navigate('/ticket-details', { state: { ticketData: params.row } });
  };

  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

  const kpiCards = [
    { label: "1st Line Support", value: 12, icon: <TicketIcon style={{ width: 24, height: 24 }} />, color: "#3B82F6" },
    { label: "2nd Line Support", value: 4, icon: <TicketIcon style={{ width: 24, height: 24 }} />, color: "#3B82F6" },
    { label: "3rd Line Support", value: 2, icon: <TicketIcon style={{ width: 24, height: 24 }} />, color: "#3B82F6" },
    { label: "Breaching SLA", value: 15, icon: <TicketIcon style={{ width: 24, height: 24 }} />, color: "#3B82F6" },
    { label: "Active Requests", value: 15, icon: <TicketIcon style={{ width: 24, height: 24 }} />, color: "#3B82F6" },
    { label: "Unassigned Ticket", value: 15, icon: <TicketIcon style={{ width: 24, height: 24 }} />, color: "#3B82F6" },
  ];

  const parseDateString = (dateStr) => {
    const [datePart] = dateStr.split(' ');
    const [month, day, year] = datePart.split('/');
    return new Date(year, month - 1, day);
  };

  const getFilteredRows = () => {
    let filtered = [...rows];

    if (typeFilter !== "all") {
      filtered = filtered.filter(row => {
        const rowType = (row.type || '').toLowerCase();
        const filterType = typeFilter.toLowerCase();
        return rowType === filterType;
      });
    }

    if (appliedDateRange && appliedDateRange.length === 2) {
      const [start, end] = appliedDateRange;
      
      filtered = filtered.filter(row => {
        const rowDate = parseDateString(row.dateCreated);
        const startFilter = new Date(start);
        const endFilter = new Date(end);
        
        startFilter.setHours(0, 0, 0, 0);
        endFilter.setHours(23, 59, 59, 999);
        
        return rowDate >= startFilter && rowDate <= endFilter;
      });
    }

    return filtered;
  };

  const handleReset = () => {
    setTypeFilter("all");
    setStartDate(null);
    setEndDate(null);
    setAppliedDateRange(null);
  };

  // ✅ NEW: Refresh function that resets everything
  const handleRefresh = async () => {
    setLoading(true);
    
    try {
      setTimeout(() => {
        // Reset all filters
        setTypeFilter("all");
        setStartDate(null);
        setEndDate(null);
        setAppliedDateRange(null);
        
        // Force DataGrid to reset by changing key
        setGridKey(prev => prev + 1);
        
        setLoading(false);
      }, 300);
    } catch (error) {
      console.error("Error refreshing data:", error);
      setLoading(false);
    }
  };

  const handleApply = () => {
    if (startDate && endDate) {
      setAppliedDateRange([startDate, endDate]);
    }
  };

  const handleStartDateChange = (newStartDate) => {
    setStartDate(newStartDate);
    if (endDate && newStartDate && endDate < newStartDate) {
      setEndDate(null);
    }
  };

  const filteredRows = getFilteredRows();

  const columns = [
    {
      field: "id",
      headerName: "ID",
      width: 90,
      sortable: true,
      renderCell: (params) => (
        <Typography sx={{ fontSize: "14px", fontWeight: 500, color: "#4B4B4B", fontFamily: "Open Sans", pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: "customer",
      headerName: "Customer/Site/User",
      flex: 1,
      minWidth: 180,
      renderCell: (params) => (
        <Typography sx={{ fontSize: "14px", fontWeight: 500, color: "#4B4B4B", fontFamily: "Open Sans", pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: "status",
      headerName: "Status",
      width: 150,
      sortable: false,
      renderCell: (params) => {
        const statusConfig = {
          "In Progress": { icon: <CheckCircleIcon style={{ width: 16, height: 16, color: "#409BFF" }} />, color: "#409BFF" },
          "New": { icon: <CheckCircleIcon style={{ width: 16, height: 16, color: "#10B981" }} />, color: "#10B981" },
          "Quote Send": { img: quoteImg, color: "#8B5CF6" },
          "Rejected": { img: rejectedImg, color: "#EF4444" },
          "On Hold": { img: holdImg, color: "#FACC15" },
          "Approved": { img: approvedImg, color: "#10B981" },
          "Quote Raised": { icon: <CheckCircleIcon style={{ width: 16, height: 16, color: "#8B5CF6" }} />, color: "#8B5CF6" },
          "Closed": { icon: <XCircleIcon style={{ width: 16, height: 16, color: "#000000" }} />, color: "#000000" },
        };
        const config = statusConfig[params.value] || statusConfig["New"];
        return (
          <Box sx={{ display: "flex", alignItems: "center", gap: 0.8, pt: 1.5 }}>
            {config.img ? <img src={config.img} alt={params.value} style={{ width: 16, height: 16 }} /> : config.icon}
            <Typography sx={{ fontSize: "14px", fontWeight: 500, color: "#4B4B4B", fontFamily: "Open Sans" }}>
              {params.value}
            </Typography>
          </Box>
        );
      },
    },
    {
      field: "sla",
      headerName: "SLA Time Left",
      width: 140,
      sortable: false,
      renderCell: (params) => {
        const slaPercent = params.row.slaPercent || 50;
        const slaColor = params.row.slaColor || "#FF6B6B";
        return (
          <Box sx={{ width: "100%", position: "relative", pt: 1.5 }}>
            <LinearProgress
              variant="determinate"
              value={slaPercent}
              sx={{
                height: 22,
                borderRadius: "6px",
                backgroundColor: "#F3F4F6",
                "& .MuiLinearProgress-bar": { backgroundColor: slaColor, borderRadius: "6px" },
              }}
            />
            <Typography sx={{
              position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)",
              fontSize: "12px", fontWeight: 700, color: "#232323", fontFamily: "Open Sans", pt: 1.5,
            }}>
              {params.value}
            </Typography>
          </Box>
        );
      },
    },
    {
      field: "priority",
      headerName: "Priority",
      width: 120,
      sortable: true,
      renderCell: (params) => {
        const priorityStyles = {
          Critical: { color: "#7E0606", icon: <ChevronDoubleUpIcon style={{ width: 16, height: 16 }} /> },
          High: { color: "#F59E0B", icon: <ChevronDoubleUpIcon style={{ width: 16, height: 16 }} /> },
          Medium: { color: "#10B981", icon: <ChevronDoubleUpIcon style={{ width: 16, height: 16 }} /> },
          Low: { color: "#07BD81", icon: <ChevronDownIcon style={{ width: 16, height: 16 }} /> },
          "Very High": { color: "#EF4444", icon: <ChevronUpIcon style={{ width: 16, height: 16 }} /> },
          Trivial: { color: "#9CA3AF", icon: <ChevronDoubleUpIcon style={{ width: 16, height: 16 }} /> },
          Urgent: { color: "#B91C1C", icon: <ChevronDoubleUpIcon style={{ width: 16, height: 16 }} /> },
          Severe: { color: "#DC2626", icon: <ChevronDoubleUpIcon style={{ width: 16, height: 16 }} /> },
        };
        const style = priorityStyles[params.value] || priorityStyles["Medium"];
        return (
          <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
            <span style={{ color: style.color }}>{style.icon}</span>
            <Typography sx={{ fontSize: "14px", fontWeight: 500, color: "#4B4B4B", fontFamily: "Open Sans" }}>
              {params.value}
            </Typography>
          </Box>
        );
      },
    },
    {
      field: "agent",
      headerName: "Agents",
      flex: 1,
      minWidth: 160,
      renderCell: (params) => (
        <Box sx={{ display: "flex", alignItems: "center", gap: 1, pt: 1.5 }}>
          <UserCircleIcon style={{ width: 24, height: 24 }} />
          <Typography sx={{ fontSize: "13px", fontWeight: 400, color: "#232323", fontFamily: "Open Sans" }}>
            {params.value}
          </Typography>
        </Box>
      ),
    },
    {
      field: "summary",
      headerName: "Summary",
      flex: 1.5,
      minWidth: 250,
      renderCell: (params) => (
        <Typography sx={{ fontSize: "14px", fontWeight: 500, color: "#4B4B4B", fontFamily: "Open Sans", pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: "dateCreated",
      headerName: "Date Created",
      width: 140,
      renderCell: (params) => (
        <Typography sx={{ fontSize: "14px", fontWeight: 500, color: "#4B4B4B", fontFamily: "Open Sans", pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: "type",
      headerName: "Type",
      width: 100,
      renderCell: (params) => (
        <Typography sx={{ fontSize: "14px", fontWeight: 500, color: "#4B4B4B", fontFamily: "Open Sans", pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: "timeTaken",
      headerName: "Time Taken",
      width: 110,
      renderCell: (params) => (
        <Typography sx={{ fontSize: "14px", fontWeight: 500, color: "#4B4B4B", fontFamily: "Open Sans", pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: "accountManager",
      headerName: "Account Manager",
      flex: 1,
      minWidth: 160,
      renderCell: (params) => (
        <Typography sx={{ fontSize: "14px", fontWeight: 500, color: "#4B4B4B", fontFamily: "Open Sans", pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
  ];

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Grid container spacing={{ xs: 1, md: 2 }} columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{ width: "100%", maxWidth: "100vw", m: 0, p: { xs: 0, sm: 1 }, justifyContent: "center", flexGrow: 1 }}>
        <Grid item size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{ border: "1px solid #E4E4E7", backgroundColor: "#fff", px: { xs: 1, sm: 4, md: 6, xl: 3 }, 
               py: { xs: 0, sm: 3 }, boxShadow: { xs: "none", sm: "0 2px 14px rgba(116,185,255,.08)" } }}>
          
          <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
            <HomeIcon style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8, cursor:"pointer" }} onClick={() => navigate("/admin")}/>
            <TitleBreadcrumb breadcrumbsData={[
              { type: "link", label: "Service Desk", to: "/admin" }, 
              { type: "text", label: "Tickets" }
            ]} />
          </Box>

          <Grid container spacing={2} columns={12} sx={{ mb: 3 }}>
  {kpiCards.map((card, index) => (
    <Grid item size={{ xs: 6, sm: 4, md: 2, xl: 2 }} key={index}>
      <Box sx={{
        display: "flex", 
        flexDirection: "column", 
        alignItems: "center", 
        justifyContent: "center",
        py: 2, 
        px: 1.5, 
        borderRadius: "12px", 
        background: "#fff", 
        border: "1px solid #E5E7EB",
        boxSizing: "border-box", 
        minHeight: "90px",
        cursor: "pointer", // ✅ Add cursor pointer
        transition: 'box-shadow 0.3s cubic-bezier(0.4, 0, 0.2, 1), transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.3s cubic-bezier(0.4, 0, 0.2, 1)', // ✅ Smooth transition
        '&:hover': { // ✅ Hover effect
          boxShadow: '0 8px 24px rgba(67, 144, 248, 0.2)',
          transform: 'translateY(-4px)',
          borderColor: '#4390F8',
        }
      }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 0.5 }}>
          <Box sx={{ color: card.color }}>{card.icon}</Box>
          <Typography sx={{ 
            mb: 0.5, 
            fontSize: "15px", 
            fontWeight: "500", 
            color: "#4B5563", 
            fontFamily: "Open Sans" 
          }}>
            {card.label}
          </Typography>
        </Box>
        <Typography sx={{ 
          fontWeight: 700, 
          fontSize: "30px", 
          color: "#111827", 
          fontFamily: "Open Sans" 
        }}>
          {card.value}
        </Typography>
      </Box>
    </Grid>
  ))}
</Grid>


          <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 2, flexWrap: "wrap", gap: 2 }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 2, flexWrap: "wrap" }}>
              <Typography sx={{ fontFamily: "Open Sans", fontWeight: "400", fontSize: "14px", color: "#4B4B4B" }}>
                Type
              </Typography>
              
              <FormControl size="small" sx={{ minWidth: 200 }}>
                <Select 
                  value={typeFilter} 
                  MenuProps={menuProps} 
                  onChange={(e) => setTypeFilter(e.target.value)}
                  input={<OutlinedInput />}
                  sx={{ height: 36, fontSize: "14px", fontWeight: 400, color: "#232323", borderRadius: "4px", fontFamily: "Open Sans" }}
                >
                  <MenuItem value="all">All Tickets</MenuItem>
                  <MenuItem value="incident">Incident</MenuItem>
                  <MenuItem value="request">Request</MenuItem>
                </Select>
              </FormControl>

              <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B4B4B", fontFamily: "Open Sans" }}>
                  Date
                </Typography>
                
                <DatePicker
                  value={startDate}
                  onChange={handleStartDateChange}
                  format="MM/dd/yyyy"
                  slotProps={{
                    textField: {
                      size: "small",
                      placeholder: "Start Date",
                      sx: {
                        width: 170,
                        "& .MuiOutlinedInput-root": {
                          fontSize: 13,
                          fontFamily: 'Open Sans',
                          height: 36,
                        }
                      }
                    },
                  }}
                />

                <Typography sx={{ color: "#6B7280", fontFamily: 'Open Sans' }}>–</Typography>

                <DatePicker
                  value={endDate}
                  onChange={setEndDate}
                  format="MM/dd/yyyy"
                  disabled={!startDate}
                  minDate={startDate}
                  openTo="day"
                  views={['year', 'month', 'day']}
                  slotProps={{
                    textField: {
                      size: "small",
                      placeholder: "End Date",
                      sx: {
                        width: 170,
                        "& .MuiOutlinedInput-root": {
                          fontSize: 13,
                          fontFamily: 'Open Sans',
                          height: 36,
                          backgroundColor: startDate ? "#fff" : "#F3F4F6",
                          cursor: startDate ? "pointer" : "not-allowed",
                        }
                      }
                    },
                  }}
                  defaultCalendarMonth={startDate || undefined}
                  referenceDate={startDate}
                />
              </Box>

              <Box sx={{ display: "flex", alignItems: "center", gap: 2, ml: 2 }}>
                <Button variant="outlined" onClick={handleReset}
                  sx={{
                    height: 38, px: 4, border: "1px solid #E1E1E1", backgroundColor: "#fff", borderRadius: 2,
                    fontWeight: 600, fontSize: "14px", color: "#4B4B4B", fontFamily: "Open Sans", textTransform: "none",
                  }}>
                  Reset
                </Button>
                
                <Button 
                  variant="contained" 
                  onClick={handleApply}
                  disabled={!startDate || !endDate}
                  sx={{
                    height: 38, px: 4, backgroundColor: "#409BFF", borderRadius: 2,
                    fontWeight: 600, fontSize: "14px", color: "#fff", fontFamily: "Open Sans", textTransform: "none",
                    "&:hover": { backgroundColor: "#3380e8", boxShadow: "none" },
                    "&:disabled": { backgroundColor: "#D1D5DB", color: "#9CA3AF" }
                  }}
                >
                  Apply
                </Button>
              </Box>
            </Box>

            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              {/* ✅ UPDATED: Refresh button with functionality */}
              <IconButton 
                onClick={handleRefresh}
                disabled={loading}
                sx={{ 
                  width: 30, 
                  height: 30, 
                  borderRadius: "8px", 
                  background: loading ? "#93c5fd" : "#409BFF", 
                  "&:hover": { background: "#3380e8" },
                  transition: "transform 0.3s ease",
                  animation: loading ? "spin 1s linear infinite" : "none",
                  "@keyframes spin": {
                    "0%": { transform: "rotate(0deg)" },
                    "100%": { transform: "rotate(360deg)" },
                  },
                }}
              >
                <ArrowPathIcon style={{ width: 18, height: 18, color: "#fff" }} />
              </IconButton>
              <IconButton sx={{ width: 30, height: 30, borderRadius: "8px", background: "#409BFF", "&:hover": { background: "#3380e8" } }}>
                <EllipsisHorizontalIcon style={{ width: 18, height: 18, color: "#fff" }} />
              </IconButton>
            </Box>
          </Box>

          <Box sx={{ width: "100%", overflowX: "auto", "-ms-overflow-style": "none", "scrollbar-width": "none", "&::-webkit-scrollbar": { display: "none" } }}>
            <DataGrid 
              key={gridKey}
              rows={filteredRows} 
              columns={columns} 
              checkboxSelection 
              onRowClick={handleRowClick}
              disableRowSelectionOnClick
              loading={loading}
              initialState={{ pagination: { paginationModel: { page: 0, pageSize: 10 } } }}
              // pageSizeOptions={[5, 10, 15]}
              sx={{
                border: "none", fontFamily: "Open Sans",
                "& .MuiDataGrid-columnHeader": { backgroundColor: "#FAFAFA" },
                "& .MuiDataGrid-columnHeaderTitle": { fontSize: "14px", fontWeight: 700, color: "#4B4B4B", fontFamily: "Open Sans" },
                "& .MuiDataGrid-cell": { fontSize: "14px", fontWeight: 900, color: "#4B4B4B", fontFamily: "Open Sans" },
                "& .MuiDataGrid-row": {
                  cursor: "pointer",
                  "&:hover": { background: "#D3E0F6C7" },
                  "&.Mui-selected": { background: "#E3F2FD !important", "&:hover": { background: "#E3F2FD !important" } },
                },
                "& .MuiCheckbox-root": { color: "#D1D5DB", "&.Mui-checked": { color: "#4390F8" } },
                "& .MuiDataGrid-columnSeparator": { display: "none" },
                "& .MuiDataGrid-cell:focus": { outline: "none" },
                "& .MuiDataGrid-cell:focus-within": { outline: "none" },
                "& .MuiDataGrid-columnHeader:focus": { outline: "none" },
                "& .MuiDataGrid-columnHeader:focus-within": { outline: "none" },
              }}
            />
          </Box>
        </Grid>
      </Grid>
    </LocalizationProvider>
  );
};

export default TicketManagementGrid;
