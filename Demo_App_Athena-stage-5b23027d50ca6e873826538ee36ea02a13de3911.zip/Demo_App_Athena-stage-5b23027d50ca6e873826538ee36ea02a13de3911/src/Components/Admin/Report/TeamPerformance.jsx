import * as React from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { Select, MenuItem, FormControl, OutlinedInput } from "@mui/material";
import { BarChart } from "@mui/x-charts/BarChart";

const TEAM_NAMES = ["1st Line Support", "2nd Line Support", "Infrastructure", "Projects", "3rd Line Support"];

// Data by reporting period
const chartData = {
  "Last 3 Months": {
    responseRate: [67, 32, 100, 0, 100],
    satisfactionScore: [82, 98, 98, 98, 98],
  },
  "Last 6 Months": {
    responseRate: [75, 45, 100, 0, 95],
    satisfactionScore: [85, 92, 95, 96, 97],
  },
  "Last Year": {
    responseRate: [80, 55, 100, 0, 90],
    satisfactionScore: [88, 90, 93, 94, 96],
  },
};

export default function TeamPerformance() {
  const [reportingPeriod, setReportingPeriod] = React.useState("Last 3 Months");
  const data = chartData[reportingPeriod];

  // MenuProps to hide scrollbar and disable scroll lock
  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

  // Calculate averages for display
  const avgResponseRate = Math.round(data.responseRate.reduce((a, b) => a + b, 0) / data.responseRate.length);
  const avgSatisfactionScore = Math.round(data.satisfactionScore.reduce((a, b) => a + b, 0) / data.satisfactionScore.length);

  return (
    <Box
      sx={{
        background: "#fff",
        boxShadow: "0 6px 20px #EEF3FE70",
        width: "100%",
        minHeight: 400,
        display: "flex",
        flexDirection: "column",
        border: "1px solid #E5E7EB",
      }}
    >
      {/* Header */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          pt: 2.5,
          px: 2.5,
          pb: 1.5,
          borderBottom: "1px solid #F3F4F6",
        }}
      >
        <Typography
          sx={{
            fontSize: "18px",
            fontWeight: 700,
            fontFamily: "Open Sans",
            color: "#111827",
          }}
        >
          Team Performance
        </Typography>

        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <FormControl
            size="small"
            sx={{
              background: "#fff",
              borderRadius: "8px",
              minWidth: 180,
              ".MuiOutlinedInput-notchedOutline": { borderColor: "#E4E4E7" },
              "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#4390F8" },
            }}
          >
            <Select
              value={reportingPeriod}
              onChange={(e) => setReportingPeriod(e.target.value)}
              input={<OutlinedInput />}
              MenuProps={menuProps}
              sx={{
                height: 36,
                fontSize: 14,
                fontWeight: 500,
                color: "#374151",
                fontFamily: "Open Sans",
              }}
            >
              <MenuItem value="Last 3 Months" sx={{ fontSize: 14, fontFamily: "Open Sans" }}>
                Last 3 Months
              </MenuItem>
              <MenuItem value="Last 6 Months" sx={{ fontSize: 14, fontFamily: "Open Sans" }}>
                Last 6 Months
              </MenuItem>
              <MenuItem value="Last Year" sx={{ fontSize: 14, fontFamily: "Open Sans" }}>
                Last Year
              </MenuItem>
            </Select>
          </FormControl>

         
        </Box>
      </Box>

      {/* Legend Badges with Percentages */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 2.5,
          px: 2.5,
          py: 2,
        }}
      >
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1,
            border: "1px solid #3762D0",
            borderRadius: "8px",
            px: 2,
            py: 0.8,
            backgroundColor: "#F0F4FF",
            transition: "all 0.2s",
            '&:hover': {
              backgroundColor: "#E0E7FF",
              transform: "translateY(-2px)",
              boxShadow: "0 4px 8px rgba(55, 98, 208, 0.15)",
            }
          }}
        >
          <Box
            sx={{
              width: 14,
              height: 14,
              backgroundColor: "#3762D0",
              borderRadius: "4px",
            }}
          />
          <Typography
            sx={{
              fontFamily: "Open Sans",
              fontSize: 13,
              fontWeight: 600,
              color: "#3762D0",
            }}
          >
            Response Rate
          </Typography>
          <Box
            sx={{
              ml: 0.5,
              px: 1,
              py: 0.3,
              backgroundColor: "#3762D0",
              borderRadius: "4px",
            }}
          >
            <Typography
              sx={{
                fontFamily: "Open Sans",
                fontSize: 12,
                fontWeight: 700,
                color: "#fff",
              }}
            >
              {avgResponseRate}%
            </Typography>
          </Box>
        </Box>

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1,
            border: "1px solid #F59E0B",
            borderRadius: "8px",
            px: 2,
            py: 0.8,
            backgroundColor: "#FEF3C7",
            transition: "all 0.2s",
            '&:hover': {
              backgroundColor: "#FDE68A",
              transform: "translateY(-2px)",
              boxShadow: "0 4px 8px rgba(245, 158, 11, 0.15)",
            }
          }}
        >
          <Box
            sx={{
              width: 14,
              height: 14,
              backgroundColor: "#F59E0B",
              borderRadius: "4px",
            }}
          />
          <Typography
            sx={{
              fontFamily: "Open Sans",
              fontSize: 13,
              fontWeight: 600,
              color: "#F59E0B",
            }}
          >
            Satisfaction Score
          </Typography>
          <Box
            sx={{
              ml: 0.5,
              px: 1,
              py: 0.3,
              backgroundColor: "#F59E0B",
              borderRadius: "4px",
            }}
          >
            <Typography
              sx={{
                fontFamily: "Open Sans",
                fontSize: 12,
                fontWeight: 700,
                color: "#fff",
              }}
            >
              {avgSatisfactionScore}%
            </Typography>
          </Box>
        </Box>
      </Box>

      {/* Bar Chart */}
      <Box
        sx={{
          flex: 1,
          pt: 1,
          pr: 2,
        //   pb: 2,
          pl: 1,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <BarChart
          height={300}
          margin={{ left: 30, right: 20, top: 5, bottom: 40 }}
          xAxis={[
            {
              scaleType: "band",
              data: TEAM_NAMES,
              categoryGapRatio: 0.4,
              barGapRatio: 0.2,
            //   label: "Teams",
              labelStyle: {
                fontFamily: "'Open Sans', sans-serif",
                fontWeight: 600,
                fontSize: 13,
                fill: "#374151",
              },
              tickLabelStyle: {
                fontFamily: "'Open Sans', sans-serif",
                fontWeight: 500,
                fontSize: 11,
                fill: "#6B7280",
                angle: -20,
                textAnchor: "end",
              },
            },
          ]}
          yAxis={[
            {
              min: 0,
              max: 110,
              label: "Percentage (%)",
              labelStyle: {
                fontFamily: "'Open Sans', sans-serif",
                fontWeight: 600,
                fontSize: 13,
                fill: "#374151",
              },
              tickLabelStyle: {
                fontFamily: "'Open Sans', sans-serif",
                fontWeight: 500,
                fontSize: 11,
                fill: "#6B7280",
              },
            },
          ]}
          series={[
            {
              data: data.responseRate,
              color: "#3762D0",
              label: "Response Rate %",
            },
            {
              data: data.satisfactionScore,
              color: "#F59E0B",
              label: "Satisfaction Score %",
            },
          ]}
          slotProps={{
            legend: { hidden: true },
          }}
          grid={{ horizontal: true, vertical: false }}
          sx={{
            ".MuiBarElement-root": {
              rx: 5,
              transition: "all 0.2s",
              '&:hover': {
                opacity: 0.85,
                cursor: "pointer",
              }
            },
            ".MuiChartsGrid-line": {
              stroke: "#E5E7EB",
              strokeWidth: 1,
              strokeDasharray: "4 4",
            },
            ".MuiChartsLegend-root": {
              display: "none !important",
            },
            ".MuiChartsAxis-label": {
              fontFamily: "'Open Sans', sans-serif !important",
              fontSize: "13px !important",
              fontWeight: "600 !important",
              fill: "#374151 !important",
            },
            ".MuiChartsAxis-tickLabel": {
              fontFamily: "'Open Sans', sans-serif !important",
              fontSize: "11px !important",
              fontWeight: "500 !important",
              fill: "#6B7280 !important",
            },
            ".MuiChartsAxis-line": {
              stroke: "#D1D5DB",
              strokeWidth: 1.5,
            },
            ".MuiChartsAxis-tick": {
              stroke: "#D1D5DB",
            }
          }}
        />
      </Box>
    </Box>
  );
}
