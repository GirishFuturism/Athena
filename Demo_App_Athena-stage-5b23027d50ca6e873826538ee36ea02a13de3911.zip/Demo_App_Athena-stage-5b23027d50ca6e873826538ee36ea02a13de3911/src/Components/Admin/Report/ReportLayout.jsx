import React, { useState } from 'react';
import TitleBreadcrumb from "../../Shared/TitleBreadcrumb";
import TeamPerformance from './TeamPerformance'; 
import {
  exportToExcel,
  exportToCSV,
  exportToPDF,
  REPORT_DATA,
  reportCategories
} from '../../../Data/ReportData';
import {
  Grid, Box, Typography, Button, IconButton, Card, CardContent,
  Select, MenuItem, FormControl, Chip, Avatar, LinearProgress, Menu
} from "@mui/material";
import {
  HomeIcon, ArrowTrendingUpIcon, ArrowTrendingDownIcon, EllipsisVerticalIcon,
  ArrowDownTrayIcon, CalendarIcon, ChartPieIcon, DocumentTextIcon
} from '@heroicons/react/24/solid';
import { useNavigate } from 'react-router-dom';

const ReportLayout = () => {
  const navigate = useNavigate();
  const [dateRange, setDateRange] = useState('last30days');
  const [anchorEl, setAnchorEl] = useState(null);

  const { overviewStats, ticketsByPriority, ticketsByStatus, topPerformers, recentReports } = REPORT_DATA[dateRange];

  // Menuprops for dropdowns
  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

  const handleOpenMenu = (event) => setAnchorEl(event.currentTarget);
  const handleCloseMenu = () => setAnchorEl(null);

  const handleExportReport = (format) => {
    const data = overviewStats.map(({ title, value, change, subtitle }) => ({
      Metric: title, Value: value, Change: change, Note: subtitle
    }));
    if (format === 'excel') {
      exportToExcel(data, "OverviewReport.xlsx");
    } else if (format === 'csv') {
      exportToCSV(data, "OverviewReport.csv");
    } else if (format === 'pdf') {
      exportToPDF(data, ["Metric", "Value", "Change", "Note"], "OverviewReport.pdf", "Overview Statistics");
    }
    handleCloseMenu();
  };

  return (
    <>
      <Grid
        container
        spacing={2}
        columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{
          width: "100%",
          maxWidth: "100vw",
          m: 0,
          p: { xs: 0, sm: 1 },
          flexGrow: 1,
        }}
      >
        <Grid
          item
          size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{
            border: "1px solid #E4E4E7",
            backgroundColor: "#fff",
            px: { xs: 1, sm: 4, md: 6, xl: 3 },
            py: { xs: 0, sm: 3 },
          }}
        >
          {/* Breadcrumb */}
          <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
            <HomeIcon style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8, cursor: "pointer" }} onClick={() => navigate("/admin")} />
            <TitleBreadcrumb
              breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin" },
                { type: "text", label: "Reports", to: "" }
              ]}
            />
          </Box>

          {/* Header with Title and Actions */}
          <Box
            sx={{
              mt: 2,
              pt: 1,
              pb: 1,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: 2
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <Typography
                sx={{
                  fontFamily: "Open Sans",
                  fontSize: "24px",
                  fontWeight: "700",
                  color: "#111827"
                }}
              >
                Reports & Analytics
              </Typography>
              <Chip
                icon={<ChartPieIcon style={{ width: 16, height: 16 }} />}
                label="Live Data"
                size="small"
                sx={{
                  backgroundColor: '#DCFCE7',
                  color: '#166534',
                  fontWeight: 600,
                  animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                  '@keyframes pulse': {
                    '0%, 100%': { opacity: 1 },
                    '50%': { opacity: 0.7 }
                  }
                }}
              />
            </Box>
            <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
              <FormControl size="small" sx={{ minWidth: 150 }}>
                <Select
                  MenuProps={menuProps}
                  value={dateRange}
                  onChange={(e) => setDateRange(e.target.value)}
                  startAdornment={
                    <CalendarIcon style={{ width: 18, height: 18, marginRight: 8, color: '#6B7280' }} />
                  }
                  sx={{
                    fontSize: '14px',
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#E4E4E7'
                    }
                  }}
                >
                  <MenuItem value="today">Today</MenuItem>
                  <MenuItem value="last7days">Last 7 Days</MenuItem>
                  <MenuItem value="last30days">Last 30 Days</MenuItem>
                </Select>
              </FormControl>
              <Button
                variant="contained"
                startIcon={<DocumentTextIcon style={{ width: 18, height: 18 }} />}
                onClick={handleOpenMenu}
                disableRipple
                sx={{
                  textTransform: 'none',
                  backgroundColor: '#4390F8',
                  color: '#fff',
                  fontFamily: 'Open Sans',
                  fontWeight: 600,
                  '&:hover': {
                    backgroundColor: '#3B82F6'
                  }
                }}
              >
                Generate Report
              </Button>
            </Box>
          </Box>

          {/* Export Menu */}
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleCloseMenu}
            disableScrollLock
            PaperProps={{
              sx: {
                mt: 1,
                boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                border: '1px solid #E4E4E7'
              }
            }}
          >
            <MenuItem onClick={() => handleExportReport('pdf')} sx={{ fontSize: '14px', fontFamily: 'Open Sans' }}>
              <ArrowDownTrayIcon style={{ width: 18, height: 18, marginRight: 8 }} />
              Export as PDF
            </MenuItem>
            <MenuItem onClick={() => handleExportReport('excel')} sx={{ fontSize: '14px', fontFamily: 'Open Sans' }}>
              <ArrowDownTrayIcon style={{ width: 18, height: 18, marginRight: 8 }} />
              Export as Excel
            </MenuItem>
            <MenuItem onClick={() => handleExportReport('csv')} sx={{ fontSize: '14px', fontFamily: 'Open Sans' }}>
              <ArrowDownTrayIcon style={{ width: 18, height: 18, marginRight: 8 }} />
              Export as CSV
            </MenuItem>
          </Menu>

          {/* Overview Stats Cards */}
          <Grid container spacing={1} sx={{ mt: 2 }}>
            {overviewStats.map((stat, index) => (
              <Grid item size={{ xs: 12, sm: 12, md: 3, xl: 3 }} key={index}>
                <Card
                  sx={{
                    border: '1px solid #E4E4E7',
                    boxShadow: 'none',
                    cursor: "pointer", 
                    transition: 'box-shadow 0.3s cubic-bezier(0.4, 0, 0.2, 1), transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                    '&:hover': {
                      boxShadow: '0 8px 24px rgba(67, 144, 248, 0.2)',
                      transform: 'translateY(-4px)',
                      borderColor: '#4390F8',
                    }
                  }}
                >
                  <CardContent>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                      <Box>
                        <Typography sx={{ fontSize: '14px', color: '#000', fontWeight: 500, mb: 1 }}>
                          {stat.title}
                        </Typography>
                        <Typography sx={{ fontSize: '28px', fontWeight: 700, color: '#111827', }}>
                          {stat.value}
                        </Typography>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, pt: 0.5 }}>
                          <Chip
                            icon={stat.trend === 'up' ?
                              <ArrowTrendingUpIcon style={{ width: 14, height: 14 }} /> :
                              <ArrowTrendingDownIcon style={{ width: 14, height: 14 }} />
                            }
                            label={stat.change}
                            size="small"
                            sx={{
                              height: 24,
                              fontSize: '14px',
                              fontWeight: 600,
                              backgroundColor: stat.trend === 'up' ? '#DCFCE7' : '#FEE2E2',
                              color: stat.trend === 'up' ? '#166534' : '#991B1B'
                            }}
                          />
                          <Typography sx={{ fontSize: '14px', color: '#6B7280' }}>
                            {stat.subtitle}
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        sx={{
                          width: 48,
                          height: 48,
                          borderRadius: '12px',
                          backgroundColor: stat.color + '20',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}
                      >
                        <stat.icon style={{ width: 24, height: 24, color: stat.color }} />
                      </Box>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>

          {/* Report Categories */}
          <Box sx={{ mt: 4 }}>
            <Typography sx={{ fontSize: '18px', fontWeight: 700, color: '#111827', mb: 3 }}>
              Report Categories
            </Typography>
            <Grid container spacing={1}>
              {reportCategories.map((category, index) => (
                <Grid item size={{ xs: 12, sm: 12, md: 4, xl: 4 }} key={index}>
                  <Card
                    sx={{
                      border: '1px solid #E4E4E7',
                      boxShadow: 'none',
                      cursor: 'pointer',
                      '&:hover': {
                        boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                        transform: 'translateY(-2px)',
                        transition: 'all 0.2s',
                        borderColor: category.color
                      }
                    }}
                  >
                    <CardContent>
                      <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 2 }}>
                        <Box
                          sx={{
                            width: 48,
                            height: 48,
                            borderRadius: '12px',
                            backgroundColor: category.bgColor,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            flexShrink: 0
                          }}
                        >
                          <category.icon style={{ width: 24, height: 24, color: category.color }} />
                        </Box>
                        <Box sx={{ flexGrow: 1 }}>
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                            <Typography sx={{ fontSize: '16px', fontWeight: 700, color: '#111827' }}>
                              {category.title}
                            </Typography>
                            <Chip
                              label={category.count}
                              size="small"
                              sx={{
                                height: 20,
                                fontSize: '13px',
                                fontWeight: 600,
                                backgroundColor: category.bgColor,
                                color: category.color
                              }}
                            />
                          </Box>
                          <Typography sx={{ fontSize: '14px', color: '#6B7280', lineHeight: 1.5 }}>
                            {category.description}
                          </Typography>
                        </Box>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              ))}
            </Grid>
          </Box>

          {/* Analytics Section */}
          <Grid container spacing={1} sx={{ mt: 2 }}>
            {/* Tickets by Priority */}
            <Grid item size={{ xs: 12, sm: 12, md: 12, xl: 6 }} xl={6}>
              <Card sx={{ border: '1px solid #E4E4E7', boxShadow: 'none' }}>
                <CardContent>
                  <Typography sx={{ fontSize: '16px', fontWeight: 700, color: '#111827', mb: 3 }}>
                    Tickets by Priority
                  </Typography>
                  {ticketsByPriority.map((item, index) => (
                    <Box key={index} sx={{ mb: 2.5 }}>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box
                            sx={{
                              width: 12,
                              height: 12,
                              borderRadius: '3px',
                              backgroundColor: item.color
                            }}
                          />
                          <Typography sx={{ fontSize: '14px', fontWeight: 600, color: '#374151' }}>
                            {item.priority}
                          </Typography>
                        </Box>
                        <Typography sx={{ fontSize: '14px', fontWeight: 700, color: '#111827' }}>
                          {item.count} ({item.percentage}%)
                        </Typography>
                      </Box>
                      <LinearProgress
                        variant="determinate"
                        value={item.percentage}
                        sx={{
                          height: 8,
                          borderRadius: 4,
                          backgroundColor: '#F3F4F6',
                          '& .MuiLinearProgress-bar': {
                            backgroundColor: item.color,
                            borderRadius: 4
                          }
                        }}
                      />
                    </Box>
                  ))}
                </CardContent>
              </Card>
            </Grid>

            {/* Tickets by Status */}
            <Grid item size={{ xs: 12, sm: 12, md: 12, xl: 6 }}>
              <Card sx={{ border: '1px solid #E4E4E7', boxShadow: 'none' }}>
                <CardContent>
                  <Typography sx={{ fontSize: '16px', fontWeight: 700, color: '#111827', mb: 3 }}>
                    Tickets by Status
                  </Typography>
                  {ticketsByStatus.map((item, index) => (
                    <Box key={index} sx={{ mb: 2.5 }}>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Box
                            sx={{
                              width: 12,
                              height: 12,
                              borderRadius: '3px',
                              backgroundColor: item.color
                            }}
                          />
                          <Typography sx={{ fontSize: '14px', fontWeight: 600, color: '#374151' }}>
                            {item.status}
                          </Typography>
                        </Box>
                        <Typography sx={{ fontSize: '14px', fontWeight: 700, color: '#111827' }}>
                          {item.count} ({item.percentage}%)
                        </Typography>
                      </Box>
                      <LinearProgress
                        variant="determinate"
                        value={item.percentage}
                        sx={{
                          height: 8,
                          borderRadius: 4,
                          backgroundColor: '#F3F4F6',
                          '& .MuiLinearProgress-bar': {
                            backgroundColor: item.color,
                            borderRadius: 4
                          }
                        }}
                      />
                    </Box>
                  ))}
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          {/* ✅ REPLACED: Top Performers and Team Performance */}
          <Grid container spacing={1} sx={{ mt: 2 }}>
            {/* Top Performers */}
            <Grid item size={{ xs: 12, sm: 12, md: 12, xl: 6 }}>
              <Card sx={{ border: '1px solid #E4E4E7', boxShadow: 'none' }}>
                <CardContent>
                  <Typography sx={{ fontSize: '16px', fontWeight: 700, color: '#111827', mb: 3 }}>
                    Top Performers
                  </Typography>
                  {topPerformers.map((performer, index) => (
                    <Box key={index} sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2, pb: 2, borderBottom: index < topPerformers.length - 1 ? '1px solid #E4E4E7' : 'none' }}>
                      <Box sx={{ position: 'relative' }}>
                        <Avatar
                          src={performer.avatar}
                          alt={performer.name}
                          sx={{ width: 48, height: 48 }}
                        />
                        <Box
                          sx={{
                            position: 'absolute',
                            top: -4,
                            right: -4,
                            width: 20,
                            height: 20,
                            borderRadius: '50%',
                            backgroundColor: index === 0 ? '#FBBF24' : index === 1 ? '#D1D5DB' : '#CD7F32',
                            border: '2px solid #fff',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '10px',
                            fontWeight: 700,
                            color: '#fff'
                          }}
                        >
                          {index + 1}
                        </Box>
                      </Box>
                      <Box sx={{ flexGrow: 1 }}>
                        <Typography sx={{ fontSize: '14px', fontWeight: 700, color: '#111827' }}>
                          {performer.name}
                        </Typography>
                        <Typography sx={{ fontSize: '14px', color: '#6B7280' }}>
                          {performer.role}
                        </Typography>
                      </Box>
                      <Box sx={{ textAlign: 'right' }}>
                        <Typography sx={{ fontSize: '16px', fontWeight: 700, color: '#10B981' }}>
                          {performer.resolved}
                        </Typography>
                        <Typography sx={{ fontSize: '12px', color: '#6B7280' }}>
                          ⭐ {performer.rating}
                        </Typography>
                      </Box>
                    </Box>
                  ))}
                </CardContent>
              </Card>
            </Grid>

            {/* ✅ NEW: Team Performance Component */}
            <Grid item size={{ xs: 12, sm: 12, md: 12, xl: 6 }}>
              <TeamPerformance />
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};

export default ReportLayout;