import React, { useState } from 'react';
import TitleBreadcrumb from "../../Shared/TitleBreadcrumb";
import { Grid, Box, Typography, Button, IconButton, Card, CardContent, Avatar } from "@mui/material";
import { 
  HomeIcon, 
} from '@heroicons/react/24/solid';
import { useNavigate } from 'react-router-dom';

const SuperAdminAthenaLayout = () => {
  const navigate = useNavigate();


  return (
    <>
      <Grid
        container
        spacing={{ xs: 1, md: 2 }}
        columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{
          width: "100%",
          maxWidth: "100vw",
          m: 0,
          p: { xs: 0, sm: 1 },
          justifyContent: "center",
          flexGrow: 1,
        }}
      >
        <Grid
          item
          size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{
            border: "1px solid #E4E4E7",
            backgroundColor: "#fff",
            px: { xs: 1, sm: 4, md: 6, xl: 3 },
            py: { xs: 0, sm: 3 },
          }}
        >
          {/* Breadcrumb */}
          <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
            <HomeIcon style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8, cursor: "pointer" }} onClick={() => navigate("/admin")}/>
            <TitleBreadcrumb 
              breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin" }, 
                { type: "text", label: "CRM", to: "" }
              ]} 
            />
          </Box>

          {/* Header with Title */}
          <Box 
            sx={{ 
              mt: 2, 
              pt: 1, 
              pb: 1,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: 2
            }}
          >
            <Typography 
              sx={{ 
                fontFamily: "Open Sans", 
                fontSize: "24px", 
                fontWeight: "700", 
                color: "#111827" 
              }}
            >
            Super Admin (Athena)
            </Typography>
          </Box>
          </Grid>
          </Grid>
          </>
  )
}

export default SuperAdminAthenaLayout;