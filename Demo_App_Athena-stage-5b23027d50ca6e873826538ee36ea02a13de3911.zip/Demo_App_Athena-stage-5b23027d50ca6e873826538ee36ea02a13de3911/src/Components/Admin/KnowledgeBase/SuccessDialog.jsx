import React from "react";
import { Dialog, DialogContent, Box, Typography } from "@mui/material";
import { CheckCircleIcon } from "@heroicons/react/24/solid";

const SuccessDialog = ({ open, onClose, title, message }) => {
  return (
    <Dialog
      open={open}
      onClose={onClose}
      disableScrollLock
      PaperProps={{
        sx: {
          borderRadius: "12px",
          p: 2,
          minWidth: "400px",
        },
      }}
    >
      <DialogContent>
        <Box sx={{ textAlign: "center", py: 2 }}>
          <CheckCircleIcon
            style={{
              width: 64,
              height: 64,
              color: "#409bff",
              margin: "0 auto",
              display: "block",
            }}
          />
          <Typography
            sx={{
              fontSize: 20,
              fontWeight: 700,
              color: "#111827",
              mt: 2,
              fontFamily: "Open Sans",
            }}
          >
            {title || "Success!"}
          </Typography>
          <Typography
            sx={{
              fontSize: 14,
              fontWeight: 400,
              color: "#6B7280",
              mt: 1,
              fontFamily: "Open Sans",
            }}
          >
            {message || "Operation completed successfully."}
          </Typography>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default SuccessDialog;
