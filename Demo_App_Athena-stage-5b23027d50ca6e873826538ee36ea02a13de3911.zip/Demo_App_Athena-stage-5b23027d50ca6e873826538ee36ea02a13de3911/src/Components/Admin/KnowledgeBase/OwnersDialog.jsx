import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  Box,
  Typography,
  Button,
  TextField,
  MenuItem,
  Autocomplete,
  IconButton,
} from "@mui/material";
import { XMarkIcon } from "@heroicons/react/24/outline";

const ownerTypes = ["Agent", "Team", "Supplier"];

const agentOptions = [
  "John Smith",
  "Sarah Johnson",
  "Michael Brown",
  "Emily Davis",
  "David Wilson",
];

const teamOptions = [
  "Operations",
  "2nd Line Support",
  "1st Line Support",
  "3rd Line Support",
  "Projects",
  "Sales",
];

const supplierOptions = [
  "Tech Solutions Ltd",
  "Hardware Experts Inc",
  "Software Innovations",
  "IT Services Pro",
];

const OwnersDialog = ({ open, onClose, onSave }) => {
  const [ownerType, setOwnerType] = useState("Agent");
  const [selectedOwners, setSelectedOwners] = useState([]);

  const handleSave = () => {
    if (selectedOwners.length > 0) {
      const ownersWithType = selectedOwners.map((owner) => ({
        type: ownerType,
        name: owner,
      }));
      onSave(ownersWithType);
      setSelectedOwners([]);
      setOwnerType("Agent");
      onClose();
    }
  };

  const handleCancel = () => {
    setSelectedOwners([]);
    setOwnerType("Agent");
    onClose();
  };

  const getOwnerOptions = () => {
    switch (ownerType) {
      case "Agent":
        return agentOptions;
      case "Team":
        return teamOptions;
      case "Supplier":
        return supplierOptions;
      default:
        return [];
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleCancel}
      maxWidth="sm"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: "12px",
          p: 2,
        },
      }}
    >
      <DialogContent sx={{ p: 3 }}>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            mb: 3,
          }}
        >
          <Typography
            sx={{
              fontSize: 20,
              fontWeight: 700,
              color: "#111827",
              fontFamily: "Open Sans",
            }}
          >
            Owners
          </Typography>
          <IconButton
            onClick={handleCancel}
            sx={{
              color: "#6B7280",
              "&:hover": {
                backgroundColor: "#F3F4F6",
              },
            }}
          >
            <XMarkIcon style={{ width: 20, height: 20 }} />
          </IconButton>
        </Box>

        <Box sx={{ mb: 3 }}>
          <Typography
            sx={{
              fontSize: 14,
              fontWeight: 600,
              mb: 1,
              color: "#374151",
              fontFamily: "Open Sans",
            }}
          >
            Type<span style={{ color: "#EF4444" }}>*</span>
          </Typography>
          <TextField
            select
            fullWidth
            value={ownerType}
            onChange={(e) => {
              setOwnerType(e.target.value);
              setSelectedOwners([]);
            }}
            InputProps={{
              sx: {
                fontFamily: "Open Sans",
                fontSize: 14,
                height: "40px",
              },
            }}
          >
            {ownerTypes.map((type) => (
              <MenuItem key={type} value={type}>
                {type}
              </MenuItem>
            ))}
          </TextField>
        </Box>

        <Box sx={{ mb: 3 }}>
          <Typography
            sx={{
              fontSize: 14,
              fontWeight: 600,
              mb: 1,
              color: "#374151",
              fontFamily: "Open Sans",
            }}
          >
            Owners<span style={{ color: "#EF4444" }}>*</span>
          </Typography>
          <Autocomplete
            multiple
            options={getOwnerOptions()}
            value={selectedOwners}
            onChange={(event, newValue) => setSelectedOwners(newValue)}
            renderInput={(params) => (
              <TextField
                {...params}
                placeholder="Select..."
                InputProps={{
                  ...params.InputProps,
                  sx: {
                    fontFamily: "Open Sans",
                    fontSize: 14,
                    minHeight: "40px",
                  },
                }}
              />
            )}
            ListboxProps={{
              sx: {
                maxHeight: 200,
                fontFamily: "Open Sans",
                fontSize: 14,
              },
            }}
          />
        </Box>

        <Box sx={{ display: "flex", justifyContent: "center", gap: 2, mt: 4 }}>
          <Button
            onClick={handleSave}
            disabled={selectedOwners.length === 0}
            sx={{
              backgroundColor: "#409BFF",
              color: "#FFFFFF",
              fontFamily: "Open Sans",
              fontSize: "14px",
              fontWeight: 600,
              textTransform: "none",
              px: 4,
              py: 1.5,
              borderRadius: "6px",
              "&:hover": {
                backgroundColor: "#2563EB",
              },
              "&:disabled": {
                backgroundColor: "#D1D5DB",
                color: "#9CA3AF",
              },
            }}
          >
            Save
          </Button>
          <Button
            onClick={handleCancel}
            sx={{
              backgroundColor: "#fff",
              color: "#374151",
              border: "1px solid #D1D5DB",
              fontFamily: "Open Sans",
              fontSize: "14px",
              fontWeight: 600,
              textTransform: "none",
              px: 4,
              py: 1.5,
              borderRadius: "6px",
              "&:hover": {
                backgroundColor: "#F9FAFB",
              },
            }}
          >
            Cancel
          </Button>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default OwnersDialog;
