import React, { useState } from "react";
import {
  Grid,
  Box,
  Typography,
  TextField,
  MenuItem,
  Button,
  Autocomplete,
  Chip,
  Checkbox,
  FormControlLabel,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Paper,
} from "@mui/material";
import TitleBreadcrumb from "../../Shared/TitleBreadcrumb";
import { useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import * as Yup from "yup";
import {
  HomeIcon,
  XMarkIcon,
  CloudArrowUpIcon,
  PlusIcon,
  TrashIcon,
} from "@heroicons/react/24/solid";
import { PaperClipIcon, PencilIcon } from "@heroicons/react/24/outline";
import ReactQuill from "react-quill-new";
import "react-quill-new/dist/quill.snow.css";
import AllowedCustomersDialog from "./AllowedCustomersDialog";
import TopLevelDialog from "./TopLevelDialog";
import AssetsDialog from "./AssetsDialog";
import OwnersDialog from "./OwnersDialog";
import SuccessDialog from "./SuccessDialog";

const articleTypes = ["Knowledge Base Article", "News Article"];

const relatedArticlesOptions = [
  "5. Billing - Click me!",
  "Remove Print Job From Queue",
  "Outlook Issues with Logging in",
  "1. Welcome to HaloPSA - Click me!",
  "3. CRM - Click me!",
  "Emails not Sending",
  "Could not load SSL library",
  "4. Projects - Click me!",
  "Correct common formula errors one at a time in Excel",
  "4. Projects",
  "2. Service Desk - Click me!",
];

const teamOptions = [
  "Operations",
  "2nd Line Support",
  "1st Line Support",
  "3rd Line Support",
  "Any Team",
  "Leads",
  "Projects",
];

const faqLists = ["Excel Issues", "Email Issues", "Print Issues", "Hardware Issues"];

const validationSchema = Yup.object({
  title: Yup.string().required("Title is required"),
  articleType: Yup.string().required("Article Type is required"),
  description: Yup.string().required("Description is required"),
});

const NewArticle = () => {
  const navigate = useNavigate();
  const [attachments, setAttachments] = useState([]);
  const [isDragging, setIsDragging] = useState(false);
  const [tags, setTags] = useState("");
  const [selectedRelatedArticles, setSelectedRelatedArticles] = useState([]);
  const [selectedTeams, setSelectedTeams] = useState([]);
  const [selectedFaqLists, setSelectedFaqLists] = useState([]);
  const [isActive, setIsActive] = useState(false);
  const [selectedClients, setSelectedClients] = useState([]);
  const [topLevelEntries, setTopLevelEntries] = useState([]);
  const [assets, setAssets] = useState([]);
  const [owners, setOwners] = useState([]);

  // Dialog states
  const [clientDialogOpen, setClientDialogOpen] = useState(false);
  const [topLevelDialogOpen, setTopLevelDialogOpen] = useState(false);
  const [assetsDialogOpen, setAssetsDialogOpen] = useState(false);
  const [ownersDialogOpen, setOwnersDialogOpen] = useState(false);
  const [successDialogOpen, setSuccessDialogOpen] = useState(false);

const formik = useFormik({
  initialValues: {
    title: "",
    articleType: "",
    description: "",
  },
  validationSchema,
  onSubmit: (values) => {
    console.log("Form submitted:", {
      ...values,
      attachments,
      tags,
      relatedArticles: selectedRelatedArticles,
      teams: selectedTeams,
      faqLists: selectedFaqLists,
      isActive,
      allowedClients: selectedClients,
      topLevel: topLevelEntries,
      assets,
      owners,
    });
    
    // Show success dialog
    setSuccessDialogOpen(true);
    
    // Redirect after 2 seconds
    setTimeout(() => {
      navigate("/knowledge-base");
    }, 2000);
  },
});


  const handleFileUpload = (event) => {
    const files = Array.from(event.target.files);
    if (files.length > 0) {
      setAttachments([...attachments, ...files]);
    }
  };

  const removeAttachment = (index) => {
    setAttachments(attachments.filter((_, i) => i !== index));
  };

  const handleDragEnter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX;
    const y = e.clientY;

    if (x < rect.left || x >= rect.right || y < rect.top || y >= rect.bottom) {
      setIsDragging(false);
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      setAttachments([...attachments, ...files]);
    }
  };

  const handleSaveClients = (clients) => {
    setSelectedClients([...selectedClients, ...clients]);
  };

  const removeClient = (index) => {
    setSelectedClients(selectedClients.filter((_, i) => i !== index));
  };

  const handleSaveTopLevels = (topLevels) => {
    const newEntries = topLevels.map((name) => ({ name }));
    setTopLevelEntries([...topLevelEntries, ...newEntries]);
  };

  const removeTopLevel = (index) => {
    setTopLevelEntries(topLevelEntries.filter((_, i) => i !== index));
  };

  const handleSaveAssets = (selectedAssets) => {
    const newAssets = selectedAssets.map((asset) => ({ name: asset }));
    setAssets([...assets, ...newAssets]);
  };

  const removeAsset = (index) => {
    setAssets(assets.filter((_, i) => i !== index));
  };

  const handleSaveOwners = (selectedOwners) => {
    setOwners([...owners, ...selectedOwners]);
  };

  const removeOwner = (index) => {
    setOwners(owners.filter((_, i) => i !== index));
  };

  const quillModules = {
    toolbar: [
      ["bold", "italic", "underline", "strike"],
      [{ align: [] }],
      [{ list: "ordered" }, { list: "bullet" }],
      [{ indent: "-1" }, { indent: "+1" }],
      ["link", "image"],
      ["clean"],
    ],
  };

  const quillFormats = [
    "bold",
    "italic",
    "underline",
    "strike",
    "align",
    "list",
    "bullet",
    "indent",
    "link",
    "image",
  ];

  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <Grid
          container
          spacing={{ xs: 1, md: 2 }}
          columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{
            width: "100%",
            maxWidth: "100vw",
            m: 0,
            p: { xs: 0, sm: 1 },
            justifyContent: "center",
            flexGrow: 1,
          }}
        >
          <Grid
            item
            size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
            sx={{
              border: "1px solid #E4E4E7",
              backgroundColor: "#fff",
              px: { xs: 1, sm: 4, md: 6, xl: 3 },
              py: { xs: 0, sm: 3 },
              boxShadow: {
                xs: "none",
                sm: "0 2px 14px rgba(116,185,255,.08)",
              },
            }}
          >
            {/* Breadcrumb */}
            <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
              <HomeIcon
                style={{
                  width: 18,
                  height: 18,
                  color: "#4390F8",
                  marginRight: 8,
                  cursor: "pointer",
                }}
                onClick={() => navigate("/admin")}
              />
              <TitleBreadcrumb
                breadcrumbsData={[
                  { type: "link", label: "Service Desk", to: "/admin" },
                  { type: "link", label: "Knowledge Base", to: "/knowledge-base" },
                  { type: "text", label: "New Article" },
                ]}
              />
            </Box>

            {/* Title */}
            <Typography
              sx={{
                fontSize: 24,
                fontWeight: 700,
                mb: 0.5,
                color: "#111827",
                fontFamily: "Open Sans",
              }}
            >
              Create New Article
            </Typography>

            {/* Subtitle */}
            <Typography
              sx={{
                fontSize: 15,
                fontWeight: 400,
                mb: 4,
                color: "#4B5563",
                fontFamily: "Open Sans",
              }}
            >
              Fill out the form below to create a new knowledge base article
            </Typography>

            {/* Title Field */}
            <Box sx={{ mb: 3 }}>
              <Typography
                sx={{
                  fontSize: 16,
                  fontWeight: 600,
                  mb: 1,
                  color: "#374151",
                  fontFamily: "Open Sans",
                }}
              >
                Title<span style={{ color: "#EF4444" }}>*</span>
              </Typography>
              <TextField
                fullWidth
                name="title"
                placeholder="Give the article a title"
                value={formik.values.title}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                error={formik.touched.title && Boolean(formik.errors.title)}
                helperText={formik.touched.title && formik.errors.title}
                InputProps={{
                  sx: {
                    fontFamily: "Open Sans",
                    fontSize: 14,
                    height: "40px",
                  },
                }}
              />
            </Box>

          {/* Article Type Field */}
<Box sx={{ mb: 3 }}>
  <Typography
    sx={{
      fontSize: 16,
      fontWeight: 600,
      mb: 1,
      color: "#374151",
      fontFamily: "Open Sans",
    }}
  >
    Article Type<span style={{ color: "#EF4444" }}>*</span>
  </Typography>
  <TextField
    select
    fullWidth
    name="articleType"
    value={formik.values.articleType}
    onChange={formik.handleChange}
    onBlur={formik.handleBlur}
    error={
      formik.touched.articleType && Boolean(formik.errors.articleType)
    }
    helperText={formik.touched.articleType && formik.errors.articleType}
    InputProps={{
      sx: {
        fontFamily: "Open Sans",
        fontSize: 14,
        height: "40px",
      },
    }}
    SelectProps={{
      displayEmpty: true,
      renderValue: (selected) => {
        if (!selected || selected === "") {
          return (
            <span style={{ color: "#9CA3AF" }}>Select Article Type</span>
          );
        }
        return selected;
      },
    }}
  >
    <MenuItem value="" disabled>
      <span style={{ color: "#9CA3AF" }}>Select Article Type</span>
    </MenuItem>
    {articleTypes.map((type) => (
      <MenuItem key={type} value={type}>
        {type}
      </MenuItem>
    ))}
  </TextField>
</Box>


            {/* Description Field with ReactQuill */}
            <Box sx={{ mb: 3 }}>
              <Typography
                sx={{
                  fontSize: 16,
                  fontWeight: 600,
                  mb: 1,
                  color: "#374151",
                  fontFamily: "Open Sans",
                }}
              >
                Description<span style={{ color: "#EF4444" }}>*</span>
              </Typography>

              <Box
                sx={{
                  border:
                    formik.touched.description && formik.errors.description
                      ? "1px solid #EF4444"
                      : "1px solid #D1D5DB",
                  borderRadius: "4px",
                  "& .quill": {
                    fontFamily: "Open Sans",
                  },
                  "& .ql-container": {
                    minHeight: "150px",
                    fontSize: "13px",
                    fontFamily: "Open Sans",
                    borderBottomLeftRadius: "4px",
                    borderBottomRightRadius: "4px",
                  },
                  "& .ql-editor": {
                    minHeight: "150px",
                  },
                  "& .ql-toolbar": {
                    borderTopLeftRadius: "4px",
                    borderTopRightRadius: "4px",
                    backgroundColor: "#F2F8FF",
                    borderColor:
                      formik.touched.description && formik.errors.description
                        ? "#EF4444"
                        : "#D1D5DB",
                  },
                  "& .ql-stroke": {
                    stroke: "#000",
                  },
                  "& .ql-fill": {
                    fill: "#000",
                  },
                  "& .ql-picker-label": {
                    color: "#000",
                  },
                }}
              >
                <ReactQuill
                  theme="snow"
                  value={formik.values.description}
                  onChange={(value) => formik.setFieldValue("description", value)}
                  onBlur={() => formik.setFieldTouched("description", true)}
                  modules={quillModules}
                  formats={quillFormats}
                  placeholder="Enter the description of the problem&#10;Note: if left blank this field will not show for Agents/Users"
                />
              </Box>
              {formik.touched.description && formik.errors.description && (
                <Typography
                  sx={{
                    fontSize: 12,
                    color: "#EF4444",
                    mt: 0.5,
                    fontFamily: "Open Sans",
                  }}
                >
                  {formik.errors.description}
                </Typography>
              )}
            </Box>

            {/* Attachments */}
            <Box sx={{ mb: 3 }}>
              <Typography
                sx={{
                  fontSize: 16,
                  fontWeight: 600,
                  mb: 1,
                  color: "#374151",
                  fontFamily: "Open Sans",
                }}
              >
                Attachments
              </Typography>
              <Box
                onDragEnter={handleDragEnter}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                sx={{
                  border: isDragging
                    ? "2px dashed #409BFF"
                    : "2px dashed #D1D5DB",
                  borderRadius: "8px",
                  p: 4,
                  textAlign: "center",
                  backgroundColor: isDragging ? "#F0F9FF" : "#FAFAFA",
                  cursor: "pointer",
                  transition: "all 0.2s",
                }}
                onClick={() => document.getElementById("file-upload").click()}
              >
                <CloudArrowUpIcon
                  style={{ width: 48, height: 48, color: "#9CA3AF", margin: "0 auto" }}
                />
                <Typography
                  sx={{
                    fontSize: 14,
                    color: "#6B7280",
                    mt: 2,
                    fontFamily: "Open Sans",
                  }}
                >
                  Click here or drag and drop files to upload
                </Typography>
                <input
                  id="file-upload"
                  type="file"
                  multiple
                  onChange={handleFileUpload}
                  style={{ display: "none" }}
                />
              </Box>

              {attachments.length > 0 && (
                <Box sx={{ mt: 2 }}>
                  {attachments.map((file, index) => (
                    <Box
                      key={index}
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        p: 2,
                        border: "1px solid #E5E7EB",
                        borderRadius: "6px",
                        mb: 1,
                        backgroundColor: "#fff",
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                        <PaperClipIcon style={{ width: 18, height: 18, color: "#6B7280" }} />
                        <Typography
                          sx={{
                            fontSize: 14,
                            fontFamily: "Open Sans",
                            color: "#374151",
                          }}
                        >
                          {file.name}
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: 12,
                            fontFamily: "Open Sans",
                            color: "#9CA3AF",
                            ml: 1,
                          }}
                        >
                          ({(file.size / 1024).toFixed(2)} KB)
                        </Typography>
                      </Box>
                      <IconButton
                        size="small"
                        onClick={() => removeAttachment(index)}
                        sx={{ color: "#EF4444" }}
                      >
                        <XMarkIcon style={{ width: 18, height: 18 }} />
                      </IconButton>
                    </Box>
                  ))}
                </Box>
              )}
            </Box>

            {/* Tags - Simple TextField */}
            <Box sx={{ mb: 3 }}>
              <Typography
                sx={{
                  fontSize: 16,
                  fontWeight: 600,
                  mb: 1,
                  color: "#374151",
                  fontFamily: "Open Sans",
                }}
              >
                Tags
              </Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Type and press 'Enter' to add a Tag"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                InputProps={{
                  sx: {
                    fontFamily: "Open Sans",
                    fontSize: 14,
                    height: "40px",
                  },
                }}
              />
            </Box>

            {/* Related Articles - WITH DROPDOWN */}
            <Box sx={{ mb: 3 }}>
              <Typography
                sx={{
                  fontSize: 16,
                  fontWeight: 600,
                  mb: 1,
                  color: "#374151",
                  fontFamily: "Open Sans",
                }}
              >
                Related Articles
              </Typography>
              <Autocomplete
                multiple
                options={relatedArticlesOptions}
                value={selectedRelatedArticles}
                onChange={(event, newValue) => setSelectedRelatedArticles(newValue)}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    placeholder="Select related articles"
                    InputProps={{
                      ...params.InputProps,
                      sx: { fontFamily: "Open Sans", fontSize: 14, minHeight: "40px" },
                    }}
                  />
                )}
                renderTags={(value, getTagProps) =>
                  value.map((option, index) => (
                    <Chip
                      label={option}
                      {...getTagProps({ index })}
                      sx={{
                        fontFamily: "Open Sans",
                        fontSize: 13,
                        // backgroundColor: "#1F2937",
                        // color: "#fff",
                      }}
                    />
                  ))
                }
              />
            </Box>

            {/* Teams that can access this Article */}
            <Box sx={{ mb: 3 }}>
              <Typography
                sx={{
                  fontSize: 16,
                  fontWeight: 600,
                  mb: 1,
                  color: "#374151",
                  fontFamily: "Open Sans",
                }}
              >
                Teams that can access this Article<span style={{ color: "#EF4444" }}>*</span>
              </Typography>
              <Autocomplete
                multiple
                options={teamOptions}
                value={selectedTeams}
                onChange={(event, newValue) => setSelectedTeams(newValue)}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    placeholder="Select teams"
                    InputProps={{
                      ...params.InputProps,
                      sx: { fontFamily: "Open Sans", fontSize: 14, minHeight: "40px" },
                    }}
                  />
                )}
                renderTags={(value, getTagProps) =>
                  value.map((option, index) => (
                    <Chip
                      label={option}
                      {...getTagProps({ index })}
                      sx={{
                        fontFamily: "Open Sans",
                        fontSize: 13,
                      
                      }}
                    />
                  ))
                }
              />
            </Box>

            {/* FAQ Lists that this Article appears on */}
            <Box sx={{ mb: 3 }}>
              <Typography
                sx={{
                  fontSize: 16,
                  fontWeight: 600,
                  mb: 1,
                  color: "#374151",
                  fontFamily: "Open Sans",
                }}
              >
                FAQ Lists that this Article appears on
              </Typography>
              <Typography
                sx={{
                  fontSize: 13,
                  fontWeight: 400,
                  mb: 1,
                  color: "#6B7280",
                  fontFamily: "Open Sans",
                }}
              >
                The order of articles per FAQ List can be configured in
                Configuration&gt;Knowledge Base&gt;FAQ Lists
              </Typography>
              <Autocomplete
                multiple
                options={faqLists}
                value={selectedFaqLists}
                onChange={(event, newValue) => setSelectedFaqLists(newValue)}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    placeholder="Select FAQ lists"
                    InputProps={{
                      ...params.InputProps,
                      sx: { fontFamily: "Open Sans", fontSize: 14, minHeight: "40px" },
                    }}
                  />
                )}
                renderTags={(value, getTagProps) =>
                  value.map((option, index) => (
                    <Chip
                      label={option}
                      {...getTagProps({ index })}
                      sx={{
                        fontFamily: "Open Sans",
                        fontSize: 13,
                      }}
                    />
                  ))
                }
              />
            </Box>

            {/* Active Checkbox */}
            <Box sx={{ mb: 3 }}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                    sx={{
                      "&.Mui-checked": {
                        color: "#409BFF",
                      },
                    }}
                  />
                }
                label={
                  <Typography
                    sx={{
                      fontSize: 14,
                      fontFamily: "Open Sans",
                      color: "#374151",
                    }}
                  >
                    Active (Shows in lists and search results)
                  </Typography>
                }
              />
            </Box>

    {/* Allowed Customers - UPDATED */}
<Box sx={{ mb: 3 }}>
  <Box
    sx={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      mb: 2,
    }}
  >
    <Box>
      <Typography
        sx={{
          fontSize: 16,
          fontWeight: 600,
          color: "#374151",
          fontFamily: "Open Sans",
        }}
      >
        Allowed Customers
      </Typography>
      <Typography
        sx={{
          fontSize: 13,
          fontWeight: 400,
          color: "#6B7280",
          fontFamily: "Open Sans",
          mt: 0.5,
        }}
      >
        In addition to the Clients granted access to the FAQ List, this
        will also allow the chosen Clients access to this KB Article and
        FAQ List (but not other articles in the FAQ List)
      </Typography>
    </Box>
    <Button
      onClick={() => setClientDialogOpen(true)}
      startIcon={<PlusIcon style={{ width: 16, height: 16 }} />}
      sx={{
        backgroundColor: "#409BFF",
        color: "#FFFFFF",
        fontFamily: "Open Sans",
        fontSize: "14px",
        fontWeight: 600,
        textTransform: "none",
        px: 3,
        py: 1,
        borderRadius: "6px",
        whiteSpace: "nowrap",
        ml: 2,
        "&:hover": {
          backgroundColor: "#2563EB",
        },
      }}
    >
      Add
    </Button>
  </Box>

  <TableContainer sx={{ border: "1px solid #E5E7EB" }}>
    <Table>
      <TableHead>
        <TableRow sx={{ backgroundColor: "#F9FAFB" }}>
          <TableCell
            sx={{
              fontFamily: "Open Sans",
              fontSize: 14,
              fontWeight: 600,
              color: "#374151",
              borderBottom: "1px solid #E5E7EB",
              height: "48px",
            }}
          >
            Client Name
          </TableCell>
          <TableCell
            width={100}
            sx={{
              borderBottom: "1px solid #E5E7EB",
              height: "48px",
            }}
          ></TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {selectedClients.length === 0 ? (
          <TableRow>
            <TableCell
              colSpan={2}
              sx={{
                textAlign: "center",
                py: 0,
                border: "none",
                height: "53px",
              }}
            >
              <Typography
                sx={{
                  fontSize: 14,
                  color: "#9CA3AF",
                  fontFamily: "Open Sans",
                }}
              >
                No rows found
              </Typography>
            </TableCell>
          </TableRow>
        ) : (
          selectedClients.map((client, index) => (
            <TableRow
              key={index}
              sx={{
                "&:hover": {
                  backgroundColor: "#F9FAFB",
                  "& .action-buttons": {
                    opacity: 1,
                  },
                },
              }}
            >
              <TableCell
                sx={{
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  color: "#374151",
                  borderBottom:
                    index === selectedClients.length - 1
                      ? "none"
                      : "1px solid #E5E7EB",
                  height: "53px",
                  py: 1.5,
                }}
              >
                {client}
              </TableCell>
              <TableCell
                sx={{
                  borderBottom:
                    index === selectedClients.length - 1
                      ? "none"
                      : "1px solid #E5E7EB",
                  height: "53px",
                  py: 1.5,
                }}
              >
                <Box
                  className="action-buttons"
                  sx={{
                    display: "flex",
                    gap: 1,
                    opacity: 0,
                    transition: "opacity 0.2s",
                  }}
                >
                 
                  <IconButton
                    size="small"
                    onClick={() => removeClient(index)}
                    sx={{
                      color: "#EF4444",
                      "&:hover": {
                        backgroundColor: "#FEF2F2",
                      },
                    }}
                  >
                    <TrashIcon style={{ width: 16, height: 16 }} />
                  </IconButton>
                </Box>
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  </TableContainer>
</Box>

{/* Top Level - UPDATED */}
<Box sx={{ mb: 3 }}>
  <Box
    sx={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      mb: 2,
    }}
  >
    <Box>
      <Typography
        sx={{
          fontSize: 16,
          fontWeight: 600,
          color: "#374151",
          fontFamily: "Open Sans",
        }}
      >
        Top Level
      </Typography>
      <Typography
        sx={{
          fontSize: 13,
          fontWeight: 400,
          color: "#6B7280",
          fontFamily: "Open Sans",
          mt: 0.5,
        }}
      >
        In addition to the Clients granted access to the FAQ List, this
        will also allow the chosen Top Level access to this KB Article and
        FAQ List (but not other articles in the FAQ List)
      </Typography>
    </Box>
    <Button
      onClick={() => setTopLevelDialogOpen(true)}
      startIcon={<PlusIcon style={{ width: 16, height: 16 }} />}
      sx={{
        backgroundColor: "#409BFF",
        color: "#FFFFFF",
        fontFamily: "Open Sans",
        fontSize: "14px",
        fontWeight: 600,
        textTransform: "none",
        px: 3,
        py: 1,
        borderRadius: "6px",
        whiteSpace: "nowrap",
        ml: 2,
        "&:hover": {
          backgroundColor: "#2563EB",
        },
      }}
    >
      Add
    </Button>
  </Box>

  <TableContainer sx={{ border: "1px solid #E5E7EB" }}>
    <Table>
      <TableHead>
        <TableRow sx={{ backgroundColor: "#F9FAFB" }}>
          <TableCell
            sx={{
              fontFamily: "Open Sans",
              fontSize: 14,
              fontWeight: 600,
              color: "#374151",
              borderBottom: "1px solid #E5E7EB",
              height: "48px",
            }}
          >
            Top Level Name
          </TableCell>
          <TableCell
            width={100}
            sx={{
              borderBottom: "1px solid #E5E7EB",
              height: "48px",
            }}
          ></TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {topLevelEntries.length === 0 ? (
          <TableRow>
            <TableCell
              colSpan={2}
              sx={{
                textAlign: "center",
                py: 0,
                border: "none",
                height: "53px",
              }}
            >
              <Typography
                sx={{
                  fontSize: 14,
                  color: "#9CA3AF",
                  fontFamily: "Open Sans",
                }}
              >
                No rows found
              </Typography>
            </TableCell>
          </TableRow>
        ) : (
          topLevelEntries.map((entry, index) => (
            <TableRow
              key={index}
              sx={{
                "&:hover": {
                  backgroundColor: "#F9FAFB",
                  "& .action-buttons": {
                    opacity: 1,
                  },
                },
              }}
            >
              <TableCell
                sx={{
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  color: "#374151",
                  borderBottom:
                    index === topLevelEntries.length - 1
                      ? "none"
                      : "1px solid #E5E7EB",
                  height: "53px",
                  py: 1.5,
                }}
              >
                {entry.name}
              </TableCell>
              <TableCell
                sx={{
                  borderBottom:
                    index === topLevelEntries.length - 1
                      ? "none"
                      : "1px solid #E5E7EB",
                  height: "53px",
                  py: 1.5,
                }}
              >
                <Box
                  className="action-buttons"
                  sx={{
                    display: "flex",
                    gap: 1,
                    opacity: 0,
                    transition: "opacity 0.2s",
                  }}
                >
                  <IconButton
                    size="small"
                    sx={{
                      color: "#409BFF",
                      "&:hover": {
                        backgroundColor: "#EEF2FF",
                      },
                    }}
                  >
                    {/* <PencilIcon style={{ width: 16, height: 16 }} /> */}
                  </IconButton>
                  <IconButton
                    size="small"
                    onClick={() => removeTopLevel(index)}
                    sx={{
                      color: "#EF4444",
                      "&:hover": {
                        backgroundColor: "#FEF2F2",
                      },
                    }}
                  >
                    <TrashIcon style={{ width: 16, height: 16 }} />
                  </IconButton>
                </Box>
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  </TableContainer>
</Box>

{/* Assets - UPDATED */}
<Box sx={{ mb: 3 }}>
  <Box
    sx={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      mb: 2,
    }}
  >
    <Typography
      sx={{
        fontSize: 16,
        fontWeight: 600,
        color: "#374151",
        fontFamily: "Open Sans",
      }}
    >
      Assets
    </Typography>
    <Button
      onClick={() => setAssetsDialogOpen(true)}
      startIcon={<PlusIcon style={{ width: 16, height: 16 }} />}
      sx={{
        backgroundColor: "#409BFF",
        color: "#FFFFFF",
        fontFamily: "Open Sans",
        fontSize: "14px",
        fontWeight: 600,
        textTransform: "none",
        px: 3,
        py: 1,
        borderRadius: "6px",
        "&:hover": {
          backgroundColor: "#2563EB",
        },
      }}
    >
      Add
    </Button>
  </Box>

  <TableContainer sx={{ border: "1px solid #E5E7EB" }}>
    <Table>
      <TableHead>
        <TableRow sx={{ backgroundColor: "#F9FAFB" }}>
          <TableCell
            sx={{
              fontFamily: "Open Sans",
              fontSize: 14,
              fontWeight: 600,
              color: "#374151",
              borderBottom: "1px solid #E5E7EB",
              height: "48px",
            }}
          >
            Asset Type
          </TableCell>
          <TableCell
            sx={{
              fontFamily: "Open Sans",
              fontSize: 14,
              fontWeight: 600,
              color: "#374151",
              borderBottom: "1px solid #E5E7EB",
              height: "48px",
            }}
          >
            Asset Tag
          </TableCell>
          <TableCell
            width={100}
            sx={{
              borderBottom: "1px solid #E5E7EB",
              height: "48px",
            }}
          ></TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {assets.length === 0 ? (
          <TableRow>
            <TableCell
              colSpan={3}
              sx={{
                textAlign: "center",
                py: 0,
                border: "none",
                height: "53px",
              }}
            >
              <Typography
                sx={{
                  fontSize: 14,
                  color: "#9CA3AF",
                  fontFamily: "Open Sans",
                }}
              >
                No rows found
              </Typography>
            </TableCell>
          </TableRow>
        ) : (
          assets.map((asset, index) => (
            <TableRow
              key={index}
              sx={{
                "&:hover": {
                  backgroundColor: "#F9FAFB",
                  "& .action-buttons": {
                    opacity: 1,
                  },
                },
              }}
            >
              <TableCell
                sx={{
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  color: "#374151",
                  borderBottom:
                    index === assets.length - 1
                      ? "none"
                      : "1px solid #E5E7EB",
                  height: "53px",
                  py: 1.5,
                }}
              >
                {asset.name.split(" - ")[0]}
              </TableCell>
              <TableCell
                sx={{
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  color: "#374151",
                  borderBottom:
                    index === assets.length - 1
                      ? "none"
                      : "1px solid #E5E7EB",
                  height: "53px",
                  py: 1.5,
                }}
              >
                {asset.name.split(" - ")[1] || ""}
              </TableCell>
              <TableCell
                sx={{
                  borderBottom:
                    index === assets.length - 1
                      ? "none"
                      : "1px solid #E5E7EB",
                  height: "53px",
                  py: 1.5,
                }}
              >
                <Box
                  className="action-buttons"
                  sx={{
                    display: "flex",
                    gap: 1,
                    opacity: 0,
                    transition: "opacity 0.2s",
                  }}
                >
                  <IconButton
                    size="small"
                    sx={{
                      color: "#409BFF",
                      "&:hover": {
                        backgroundColor: "#EEF2FF",
                      },
                    }}
                  >
                    {/* <PencilIcon style={{ width: 16, height: 16 }} /> */}
                  </IconButton>
                  <IconButton
                    size="small"
                    onClick={() => removeAsset(index)}
                    sx={{
                      color: "#EF4444",
                      "&:hover": {
                        backgroundColor: "#FEF2F2",
                      },
                    }}
                  >
                    <TrashIcon style={{ width: 16, height: 16 }} />
                  </IconButton>
                </Box>
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  </TableContainer>
</Box>

{/* Owners - UPDATED */}
<Box sx={{ mb: 3 }}>
  <Box
    sx={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      mb: 2,
    }}
  >
    <Typography
      sx={{
        fontSize: 16,
        fontWeight: 600,
        color: "#374151",
        fontFamily: "Open Sans",
      }}
    >
      Owners
    </Typography>
    <Button
      onClick={() => setOwnersDialogOpen(true)}
      startIcon={<PlusIcon style={{ width: 16, height: 16 }} />}
      sx={{
        backgroundColor: "#409BFF",
        color: "#FFFFFF",
        fontFamily: "Open Sans",
        fontSize: "14px",
        fontWeight: 600,
        textTransform: "none",
        px: 3,
        py: 1,
        borderRadius: "6px",
        "&:hover": {
          backgroundColor: "#2563EB",
        },
      }}
    >
      Add
    </Button>
  </Box>

  <TableContainer sx={{ border: "1px solid #E5E7EB" }}>
    <Table>
      <TableHead>
        <TableRow sx={{ backgroundColor: "#F9FAFB" }}>
          <TableCell
            sx={{
              fontFamily: "Open Sans",
              fontSize: 14,
              fontWeight: 600,
              color: "#374151",
              borderBottom: "1px solid #E5E7EB",
              height: "48px",
            }}
          >
            Name
          </TableCell>
          <TableCell
            width={100}
            sx={{
              borderBottom: "1px solid #E5E7EB",
              height: "48px",
            }}
          ></TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {owners.length === 0 ? (
          <TableRow>
            <TableCell
              colSpan={2}
              sx={{
                textAlign: "center",
                py: 0,
                border: "none",
                height: "53px",
              }}
            >
              <Typography
                sx={{
                  fontSize: 14,
                  color: "#9CA3AF",
                  fontFamily: "Open Sans",
                }}
              >
                No rows found
              </Typography>
            </TableCell>
          </TableRow>
        ) : (
          owners.map((owner, index) => (
            <TableRow
              key={index}
              sx={{
                "&:hover": {
                  backgroundColor: "#F9FAFB",
                  "& .action-buttons": {
                    opacity: 1,
                  },
                },
              }}
            >
              <TableCell
                sx={{
                  fontFamily: "Open Sans",
                  fontSize: 14,
                  color: "#374151",
                  borderBottom:
                    index === owners.length - 1
                      ? "none"
                      : "1px solid #E5E7EB",
                  height: "53px",
                  py: 1.5,
                }}
              >
                {owner.type} - {owner.name}
              </TableCell>
              <TableCell
                sx={{
                  borderBottom:
                    index === owners.length - 1
                      ? "none"
                      : "1px solid #E5E7EB",
                  height: "53px",
                  py: 1.5,
                }}
              >
                <Box
                  className="action-buttons"
                  sx={{
                    display: "flex",
                    gap: 1,
                    opacity: 0,
                    transition: "opacity 0.2s",
                  }}
                >
                  <IconButton
                    size="small"
                    sx={{
                      color: "#409BFF",
                      "&:hover": {
                        backgroundColor: "#EEF2FF",
                      },
                    }}
                  >
                    {/* <PencilIcon style={{ width: 16, height: 16 }} /> */}
                  </IconButton>
                  <IconButton
                    size="small"
                    onClick={() => removeOwner(index)}
                    sx={{
                      color: "#EF4444",
                      "&:hover": {
                        backgroundColor: "#FEF2F2",
                      },
                    }}
                  >
                    <TrashIcon style={{ width: 16, height: 16 }} />
                  </IconButton>
                </Box>
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  </TableContainer>
</Box>


            {/* Action Buttons */}
            <Box
              sx={{
                position: "sticky",
    bottom: 0,
    left: 0,
    right: 0,
    display: "flex",
    justifyContent: "flex-end",
    gap: 2,
    mt: 4,
    py: 2,
    backgroundColor: "#fff",
    borderTop: "1px solid #E5E7EB",
    zIndex: 10,
    // boxShadow: "0 -2px 10px rgba(0, 0, 0, 0.05)",
              }}
            >
              <Button
                type="submit"
                sx={{
                  backgroundColor: "#409BFF",
                  color: "#FFFFFF",
                  fontFamily: "Open Sans",
                  fontSize: "14px",
                  fontWeight: 600,
                  textTransform: "none",
                  px: 4,
                  py: 1.5,
                  borderRadius: "6px",
                  "&:hover": {
                    backgroundColor: "#2563EB",
                  },
                }}
              >
                Save
              </Button>
              <Button
                onClick={() => navigate("/knowledge-base")}
                sx={{
                  backgroundColor: "#fff",
                  color: "#374151",
                  border: "1px solid #D1D5DB",
                  fontFamily: "Open Sans",
                  fontSize: "14px",
                  fontWeight: 600,
                  textTransform: "none",
                  px: 4,
                  py: 1.5,
                  borderRadius: "6px",
                  "&:hover": {
                    backgroundColor: "#F9FAFB",
                  },
                }}
              >
                Cancel
              </Button>
            </Box>
          </Grid>
        </Grid>
      </form>

          {/* Dialogs */}
      <AllowedCustomersDialog
        open={clientDialogOpen}
        onClose={() => setClientDialogOpen(false)}
        onSave={handleSaveClients}
      />

      <TopLevelDialog
        open={topLevelDialogOpen}
        onClose={() => setTopLevelDialogOpen(false)}
        onSave={handleSaveTopLevels}
      />

      <AssetsDialog
        open={assetsDialogOpen}
        onClose={() => setAssetsDialogOpen(false)}
        onSave={handleSaveAssets}
      />

      <OwnersDialog
        open={ownersDialogOpen}
        onClose={() => setOwnersDialogOpen(false)}
        onSave={handleSaveOwners}
      />

      <SuccessDialog
        open={successDialogOpen}
        onClose={() => setSuccessDialogOpen(false)}
        title="Article Created Successfully!"
        message="Your knowledge base article has been created. Redirecting..."
      />
=

    </>
  );
};

export default NewArticle;