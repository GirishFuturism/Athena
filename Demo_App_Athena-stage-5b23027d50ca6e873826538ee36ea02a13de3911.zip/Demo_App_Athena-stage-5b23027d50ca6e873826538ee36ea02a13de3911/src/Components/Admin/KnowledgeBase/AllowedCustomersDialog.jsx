import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  Box,
  Typography,
  Button,
  Autocomplete,
  TextField,
  IconButton,
} from "@mui/material";
import { XMarkIcon } from "@heroicons/react/24/outline";

const clientOptions = [
  "Acorn Construction",
  "Freston Cakes and Bakes",
  "FT",
  "Mario and Luigi's Pizza Place",
  "Ron's Iron works",
  "St Johns High School",
  "Terry's Chocolates",
  "Tony's Tyre Emporium",
];

const AllowedCustomersDialog = ({ open, onClose, onSave }) => {
  const [selectedClients, setSelectedClients] = useState([]);

  const handleSave = () => {
    if (selectedClients.length > 0) {
      onSave(selectedClients);
      setSelectedClients([]);
      onClose();
    }
  };

  const handleCancel = () => {
    setSelectedClients([]);
    onClose();
  };

  return (
    <Dialog
      open={open}
      onClose={handleCancel}
      maxWidth="sm"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: "12px",
          p: 2,
        },
      }}
    >
      <DialogContent sx={{ p: 3 }}>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            mb: 3,
          }}
        >
          <Typography
            sx={{
              fontSize: 20,
              fontWeight: 700,
              color: "#111827",
              fontFamily: "Open Sans",
            }}
          >
            Client Restrictions
          </Typography>
          <IconButton
            onClick={handleCancel}
            sx={{
              color: "#6B7280",
              "&:hover": {
                backgroundColor: "#F3F4F6",
              },
            }}
          >
            <XMarkIcon style={{ width: 20, height: 20 }} />
          </IconButton>
        </Box>

        <Box sx={{ mb: 3 }}>
          <Typography
            sx={{
              fontSize: 14,
              fontWeight: 600,
              mb: 1,
              color: "#374151",
              fontFamily: "Open Sans",
            }}
          >
            Clients<span style={{ color: "#EF4444" }}>*</span>
          </Typography>
          <Autocomplete
            multiple
            options={clientOptions}
            value={selectedClients}
            onChange={(event, newValue) => setSelectedClients(newValue)}
            renderInput={(params) => (
              <TextField
                {...params}
                placeholder="Select one or more Clients"
                InputProps={{
                  ...params.InputProps,
                  sx: {
                    fontFamily: "Open Sans",
                    fontSize: 14,
                    minHeight: "40px",
                  },
                }}
              />
            )}
            ListboxProps={{
              sx: {
                maxHeight: 200,
                fontFamily: "Open Sans",
                fontSize: 14,
              },
            }}
          />
        </Box>

        <Box sx={{ display: "flex", justifyContent: "center", gap: 2, mt: 4 }}>
          <Button
            onClick={handleSave}
            disabled={selectedClients.length === 0}
            sx={{
              backgroundColor: "#409BFF",
              color: "#FFFFFF",
              fontFamily: "Open Sans",
              fontSize: "14px",
              fontWeight: 600,
              textTransform: "none",
              px: 4,
              py: 1.5,
              borderRadius: "6px",
              "&:hover": {
                backgroundColor: "#2563EB",
              },
              "&:disabled": {
                backgroundColor: "#D1D5DB",
                color: "#9CA3AF",
              },
            }}
          >
            Save
          </Button>
          <Button
            onClick={handleCancel}
            sx={{
              backgroundColor: "#fff",
              color: "#374151",
              border: "1px solid #D1D5DB",
              fontFamily: "Open Sans",
              fontSize: "14px",
              fontWeight: 600,
              textTransform: "none",
              px: 4,
              py: 1.5,
              borderRadius: "6px",
              "&:hover": {
                backgroundColor: "#F9FAFB",
              },
            }}
          >
            Cancel
          </Button>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default AllowedCustomersDialog;
