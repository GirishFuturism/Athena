import React, { useState } from 'react';
import TitleBreadcrumb from "../../Shared/TitleBreadcrumb";
import {
  Grid,
  Box,
  Typography,
  Button,
  TextField,
  InputAdornment,
  Drawer,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  List,
  ListItem,
  ListItemText,
  IconButton,
  Card,
  CardContent,
  Chip,
  Divider,
} from "@mui/material";
import {
  MagnifyingGlassIcon,
  ChevronDownIcon,
  HandThumbUpIcon,
  HandThumbDownIcon,
  PlusIcon,
  XMarkIcon,
  ArrowPathIcon,
} from '@heroicons/react/24/outline';
import {HomeIcon} from '@heroicons/react/24/solid'
import { useNavigate } from 'react-router-dom';

const knowledgeBaseData = [
  {
    id: 1,
    category: "Accounts Integrations",
    articles: [
      {
        id: 101,
        title: "Could not load SSL library",
        tags: ["Xero", "OpenSSL", "Accounts Integration"],
        votes: { up: 0, down: 0 },
        description: "When attempting to use a 3rd party integration that uses Open SSL (such as Xero) you will encounter an error reading 'Could not load SSL library'.",
        solution: "To resolve this issue, you need to install the latest OpenSSL library on your system. Download it from the official OpenSSL website and ensure it's properly configured in your system PATH. After installation, restart your application and the integration should work correctly."
      }
    ]
  },
  {
    id: 2,
    category: "Email Issues",
    articles: [
      {
        id: 201,
        title: "Emails not Sending",
        tags: ["email", "office365", "microsoft365"],
        votes: { up: 0, down: 0 },
        description: "If you see messages piling up in your Outlook outbox or people you're sending messages to aren't receiving them, try the following methods to fix the issue.",
        solution: "1. Check your internet connection\n2. Verify SMTP settings\n3. Check if emails are stuck in Outbox\n4. Disable antivirus temporarily\n5. Recreate your email profile\n6. Check mailbox storage limits"
      }
    ]
  },
  {
    id: 3,
    category: "Excel Issues",
    articles: [
      {
        id: 301,
        title: "Correct common formula errors one at a time in Excel",
        tags: ["Excel", "msoffice", "ms office"],
        votes: { up: 0, down: 0 },
        description: "If the worksheet has previously been checked for errors, any errors that were ignored will not appear until ignored errors have been reset.",
        solution: "1. Select the worksheet that you want to check for errors\n2. Click on Formula tab > Error Checking\n3. Review each error and choose appropriate action\n4. Use 'Evaluate Formula' to step through complex formulas\n5. Check for circular references\n6. Verify cell references are correct"
      }
    ]
  },
  {
    id: 4,
    category: "Print Articles",
    articles: [
      {
        id: 401,
        title: "Remove Print Job From Queue",
        tags: ["printer", "print", "Hardware>Printer"],
        votes: { up: 0, down: 0 },
        description: "When you can't remove a print job from the printing queue window by right-clicking the stuck job and clicking Cancel, you can try restarting your PC.",
        solution: "1. Open Services (services.msc)\n2. Find 'Print Spooler' service\n3. Stop the service\n4. Navigate to C:\\Windows\\System32\\spool\\PRINTERS\n5. Delete all files in this folder\n6. Restart Print Spooler service\n7. Try printing again"
      }
    ]
  }
];

const KnowledgeBaseLayout = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedArticle, setSelectedArticle] = useState(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [expandedCategory, setExpandedCategory] = useState(false);
  const [selectedCategoryId, setSelectedCategoryId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [votes, setVotes] = useState({});
  const [voted, setVoted] = useState({});

  const handleRefresh = () => {
    setLoading(true);
    setTimeout(() => {
      setSearchQuery("");
      setSelectedCategoryId(null);
      setExpandedCategory(false);
      setVotes({});
      setVoted({});
      setLoading(false);
    }, 500);
  };

  const handleAccordionChange = (panel) => (event, isExpanded) => {
    setExpandedCategory(isExpanded ? panel : false);
  };

  const handleAccordionArticleClick = (categoryId) => {
    setSelectedCategoryId(categoryId);
    setSearchQuery("");
  };

  const handleArticleCardClick = (article) => {
    setSelectedArticle(article);
    setDrawerOpen(true);
  };

  const handleCloseDrawer = () => {
    setDrawerOpen(false);
    setSelectedArticle(null);
  };

  // Voting logic
  const handleVote = (id, type) => {
    if (voted[id]) return;
    setVotes(prevVotes => ({
      ...prevVotes,
      [id]: {
        up: type === 'yes'
          ? (prevVotes[id]?.up || 0) + 1
          : (prevVotes[id]?.up || 0),
        down: type === 'no'
          ? (prevVotes[id]?.down || 0) + 1
          : (prevVotes[id]?.down || 0)
      }
    }));
    setVoted(prev => ({ ...prev, [id]: type }));
  };

  const handleDrawerVote = (type) => {
    if (!selectedArticle) return;
    handleVote(selectedArticle.id, type);
  };

  const getVoteForId = (id, type, originalUp, originalDown) => {
    return type === 'yes'
      ? (votes[id]?.up ?? originalUp)
      : (votes[id]?.down ?? originalDown);
  };

  // Filtering
  const getFilteredDataBySearch = () => {
    return knowledgeBaseData.map(category => ({
      ...category,
      articles: category.articles.filter(article =>
        article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    })).filter(category => category.articles.length > 0);
  };

  const getDisplayedArticles = () => {
    if (searchQuery) return getFilteredDataBySearch();
    if (selectedCategoryId) return knowledgeBaseData.filter(cat => cat.id === selectedCategoryId);
    return knowledgeBaseData;
  };

  const displayedArticles = getDisplayedArticles();

  return (
    <>
      <Grid
        container
        spacing={{ xs: 1, md: 2 }}
        columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{
          width: "100%",
          maxWidth: "100vw",
          m: 0,
          p: { xs: 0, sm: 1 },
          justifyContent: "center",
          flexGrow: 1,
        }}
      >
        <Grid
          item
          size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{
            border: "1px solid #E4E4E7",
            backgroundColor: "#fff",
            px: { xs: 1, sm: 4, md: 6, xl: 3 },
            py: { xs: 0, sm: 3 },
          }}
        >
          {/* Breadcrumb */}
          <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
            <HomeIcon
              style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8, cursor: "pointer" }}
              onClick={() => navigate("/admin")}
            />
            <TitleBreadcrumb
              breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin" },
                { type: "text", label: "Knowledge Base", to: "" }
              ]}
            />
          </Box>
          {/* Header with Title and Action Buttons */}
          <Box
            sx={{
              mt: 2,
              pt: 1,
              pb: 1,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: 2,
            }}
          >
            <Typography
              sx={{
                fontFamily: "Open Sans",
                fontSize: "24px",
                fontWeight: "700",
                color: "#111827"
              }}
            >
              Knowledge Base
            </Typography>
            <Box sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 2,
              flexWrap: 'wrap'
            }}>
              <TextField
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setSelectedCategoryId(null);
                }}
                size="small"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <MagnifyingGlassIcon style={{ width: 18, height: 18, color: "#9CA3AF" }} />
                    </InputAdornment>
                  ),
                  sx: {
                    fontFamily: "Open Sans",
                    fontSize: 14,
                    borderRadius: "8px",
                  }
                }}
                sx={{
                  minWidth: 220,
                  width: { xs: "100%", sm: 240, md: 260 },
                  mr: 0 // no margin if using gap in parent
                }}
              />
              <Button
                startIcon={<PlusIcon style={{ width: 18, height: 18 }} />}
                onClick={() => navigate('/new-article')}
                sx={{
                  backgroundColor: '#409BFF',
                  color: '#FFFFFF',
                  fontFamily: 'Open Sans',
                  fontSize: '14px',
                  fontWeight: 600,
                  textTransform: 'none',
                  px: 5,
                  py: 1,
                  borderRadius: '6px',
                  boxShadow: 'none',
                  whiteSpace: "nowrap",
                  '&:hover': {
                    backgroundColor: '#2563EB',
                    boxShadow: 'none'
                  }
                }}
              >
                New Article
              </Button>
              <IconButton
                onClick={handleRefresh}
                disabled={loading}
                sx={{
                  backgroundColor: loading ? '#93c5fd' : '#409BFF',
                  color: '#FFFFFF',
                  width: 38,
                  height: 38,
                  borderRadius: '6px',
                  transition: "transform 0.3s ease",
                  animation: loading ? "spin 1s linear infinite" : "none",
                  "@keyframes spin": {
                    "0%": { transform: "rotate(0deg)" },
                    "100%": { transform: "rotate(360deg)" },
                  },
                  '&:hover': {
                    backgroundColor: '#2563EB'
                  }
                }}
              >
                <ArrowPathIcon style={{ width: 18, height: 18 }} />
              </IconButton>
            </Box>
          </Box>
          {/* Main Content Grid */}
          <Grid container spacing={1} sx={{ mt: 2 }}>
            {/* Article cards/content: left */}
            <Grid item size={{ xs: 12, sm: 12, md: 8.5, xl: 9 }}>
              <Box sx={{ border: '1px solid #E5E7EB', p: 2, borderRadius: "8px" }}>
                <Grid container spacing={2}>
                  {displayedArticles.reduce((acc, category) => [
                    ...acc,
                    ...category.articles.map((article) => (
                      <Grid item xs={12} key={article.id}>
                        <Card
                          onClick={() => handleArticleCardClick(article)}
                          sx={{
                            border: "1px solid #E5E7EB",
                            borderRadius: "12px",
                            boxShadow: "none",
                            cursor: "pointer",
                            transition: "all 0.2s",
                            "&:hover": {
                              boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
                              transform: "translateY(-2px)",
                            },
                          }}
                        >
                          <CardContent sx={{ p: 3 }}>
                            <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", mb: 2 }}>
                              <Typography
                                sx={{
                                  fontFamily: "Open Sans",
                                  fontSize: 17,
                                  fontWeight: 700,
                                  color: "#111827",
                                  flex: 1,
                                }}
                              >
                                {article.title}
                              </Typography>
                              <Box sx={{ display: "flex", gap: 2, ml: 2 }}>
                                <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                                  <HandThumbUpIcon style={{ width: 18, height: 18, color: "#10B981" }} />
                                  <Typography sx={{ fontFamily: "Open Sans", fontSize: 13, fontWeight: 600, color: "#10B981" }}>
                                    {getVoteForId(article.id, 'yes', article.votes.up, article.votes.down)}
                                  </Typography>
                                </Box>
                                <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                                  <HandThumbDownIcon style={{ width: 18, height: 18, color: "#EF4444" }} />
                                  <Typography sx={{ fontFamily: "Open Sans", fontSize: 13, fontWeight: 600, color: "#EF4444" }}>
                                    {getVoteForId(article.id, 'no', article.votes.up, article.votes.down)}
                                  </Typography>
                                </Box>
                              </Box>
                            </Box>
                            <Box sx={{ display: "flex", gap: 1, flexWrap: "wrap", mb: 2 }}>
                              {article.tags.map((tag, index) => (
                                <Chip
                                  key={index}
                                  label={tag}
                                  size="small"
                                  sx={{
                                    bgcolor: "#EEF2FF",
                                    color: "#4F46E5",
                                    fontFamily: "Open Sans",
                                    fontSize: 13,
                                    fontWeight: 600,
                                    height: 24,
                                  }}
                                />
                              ))}
                            </Box>
                            <Typography
                              sx={{
                                fontFamily: "Open Sans",
                                fontSize: 14,
                                color: "#6B7280",
                                lineHeight: 1.6,
                              }}
                            >
                              {article.description}
                            </Typography>
                            <Box sx={{ mt: 3, display: "flex", gap: 2 }}>
                              <Button
                                variant="outlined"
                                disabled={!!voted[article.id]}
                                onClick={e => { e.stopPropagation(); handleVote(article.id, 'yes'); }}
                                startIcon={<HandThumbUpIcon style={{ width: 16, height: 16, color: "#10B981" }} />}
                                sx={{
                                  borderColor: "#10B981",
                                  color: "#10B981",
                                  textTransform: "none",
                                  fontFamily: "Open Sans",
                                  fontWeight: 600,
                                  fontSize: 14,
                                  px: 2.5,
                                  py: 0.5,
                                  borderRadius: "8px",
                                  "&:hover": {
                                    borderColor: "#059669",
                                    bgcolor: "#ECFDF5",
                                  },
                                }}
                              >
                                Yes ({getVoteForId(article.id, 'yes', article.votes.up, article.votes.down)})
                              </Button>
                              <Button
                                variant="outlined"
                                disabled={!!voted[article.id]}
                                onClick={e => { e.stopPropagation(); handleVote(article.id, 'no'); }}
                                startIcon={<HandThumbDownIcon style={{ width: 16, height: 16, color: "#EF4444" }} />}
                                sx={{
                                  borderColor: "#EF4444",
                                  color: "#EF4444",
                                  textTransform: "none",
                                  fontFamily: "Open Sans",
                                  fontWeight: 600,
                                  fontSize: 14,
                                  px: 2.5,
                                  py: 0.5,
                                  borderRadius: "8px",
                                  "&:hover": {
                                    borderColor: "#DC2626",
                                    bgcolor: "#FEF2F2",
                                  },
                                }}
                              >
                                No ({getVoteForId(article.id, 'no', article.votes.up, article.votes.down)})
                              </Button>
                            </Box>
                          </CardContent>
                        </Card>
                      </Grid>
                    ))
                  ], [])}
                  {displayedArticles.length === 0 && (
                    <Grid item xs={12}>
                      <Box sx={{ textAlign: "center", py: 8 }}>
                        <Typography sx={{ fontFamily: "Open Sans", fontSize: 16, color: "#9CA3AF" }}>
                          No articles found matching your search.
                        </Typography>
                      </Box>
                    </Grid>
                  )}
                </Grid>
              </Box>
            </Grid>
            {/* Accordion sidebar: right */}
            <Grid item size={{ xs: 12, sm: 12, md: 3.5, xl: 3 }}>
              <Box
                sx={{
                  border: "1px solid #E5E7EB",
                  borderRadius: "12px",
                  p: 2,
                  bgcolor: "#fff",
                  position: "sticky", top: 80
                }}
              >
                <Box>
                  {knowledgeBaseData.map((category) => (
                    <Accordion
                      key={category.id}
                      expanded={expandedCategory === category.id}
                      onChange={handleAccordionChange(category.id)}
                      sx={{
                        boxShadow: "none",
                        border: "none",
                        "&:before": { display: "none" },
                        mb: 1,
                      }}
                    >
                      <AccordionSummary
                        expandIcon={<ChevronDownIcon style={{ width: 18, height: 18 }} />}
                        sx={{
                          bgcolor: expandedCategory === category.id ? "#EEF2FF" : "transparent",
                          borderRadius: "8px",
                          minHeight: 48,
                          "&:hover": {
                            bgcolor: "#F9FAFB",
                          },
                          "& .MuiAccordionSummary-content": {
                            my: 1,
                          },
                        }}
                      >
                        <Typography
                          sx={{
                            fontFamily: "Open Sans",
                            fontSize: 15,
                            fontWeight: 600,
                            color: "#111827",
                          }}
                        >
                          {category.category}
                        </Typography>
                      </AccordionSummary>
                      <AccordionDetails sx={{ pt: 0, pb: 1 }}>
                        <List sx={{ p: 0 }}>
                          {category.articles.map((article) => (
                            <ListItem
                              key={article.id}
                              onClick={() => handleAccordionArticleClick(category.id)}
                              sx={{
                                borderRadius: "6px",
                                mb: 0.5,
                                cursor: "pointer",
                                bgcolor: selectedCategoryId === category.id ? "#EEF2FF" : "transparent",
                                "&:hover": {
                                  bgcolor: "#F3F4F6",
                                },
                              }}
                            >
                              <ListItemText
                                primary={article.title}
                                primaryTypographyProps={{
                                  sx: {
                                    fontFamily: "Open Sans",
                                    fontSize: 15,
                                    fontWeight: 500,
                                    color: "#374151",
                                  }
                                }}
                              />
                            </ListItem>
                          ))}
                        </List>
                      </AccordionDetails>
                    </Accordion>
                  ))}
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      {/* Article Detail Drawer */}
      <Drawer
        anchor="right"
        open={drawerOpen}
        onClose={handleCloseDrawer}
        PaperProps={{
          sx: {
            width: { xs: "100%", sm: 600 },
            p: 0,
          }
        }}
      >
        {selectedArticle && (
          <Box sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
            <Box
              sx={{
                p: 3,
                borderBottom: "1px solid #E5E7EB",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                mt:2
              }}
            >
            </Box>
            <Box sx={{ flex: 1, overflowY: "auto", p: 3 }}>
              <Box sx={{display:"flex", justifyContent:"space-between"}}>
              <Typography
                sx={{
                  fontFamily: "Open Sans",
                  fontSize: 24,
                  fontWeight: 700,
                  color: "#111827",
                  mb: 4,
                }}
              >
                {selectedArticle.title}
              </Typography>

              <Box
                onClick={handleCloseDrawer}
                sx={{
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: 32,
                  height: 32,
                  borderRadius: "6px",
                  "&:hover": {
                    bgcolor: "#F3F4F6",
                  },
                }}
              >
                <XMarkIcon style={{ width: 25, height: 25, color: "#000" }} />
              </Box>
              </Box>
              <Box sx={{ display: "flex", gap: 1, flexWrap: "wrap", mb: 3 }}>
                {selectedArticle.tags.map((tag, index) => (
                  <Chip
                    key={index}
                    label={tag}
                    size="small"
                    sx={{
                      bgcolor: "#EEF2FF",
                      color: "#4F46E5",
                      fontFamily: "Open Sans",
                      fontSize: 13,
                      fontWeight: 600,
                      height: 32,
                    }}
                  />
                ))}
              </Box>
              <Divider sx={{ mb: 3 }} />
              <Box sx={{ mb: 3 }}>
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontSize: 16,
                    fontWeight: 700,
                    color: "#111827",
                    mb: 2,
                  }}
                >
                  Description
                </Typography>
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontSize: 14,
                    color: "#4B5563",
                    lineHeight: 1.8,
                  }}
                >
                  {selectedArticle.description}
                </Typography>
              </Box>
              <Divider sx={{ mb: 3 }} />
              <Box sx={{ mb: 3 }}>
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontSize: 16,
                    fontWeight: 700,
                    color: "#111827",
                    mb: 2,
                  }}
                >
                  Solution
                </Typography>
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontSize: 14,
                    color: "#4B5563",
                    lineHeight: 1.8,
                    whiteSpace: "pre-line",
                  }}
                >
                  {selectedArticle.solution}
                </Typography>
              </Box>
              <Divider sx={{ mb: 3 }} />
              <Box>
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontSize: 16,
                    fontWeight: 700,
                    color: "#111827",
                    mb: 2,
                  }}
                >
                  Was this article helpful?
                </Typography>
                <Box sx={{ display: "flex", gap: 2 }}>
                  <Button
                    variant="outlined"
                    disabled={!!voted[selectedArticle.id]}
                    onClick={() => handleVote(selectedArticle.id, 'yes')}
                    startIcon={<HandThumbUpIcon style={{ width: 18, height: 18, color: "#10B981" }} />}
                    sx={{
                      borderColor: "#10B981",
                      color: "#10B981",
                      textTransform: "none",
                      fontFamily: "Open Sans",
                      fontWeight: 600,
                      fontSize: 14,
                      px: 3,
                      py: 1,
                      borderRadius: "8px",
                      "&:hover": {
                        borderColor: "#059669",
                        bgcolor: "#ECFDF5",
                      },
                    }}
                  >
                    Yes ({getVoteForId(selectedArticle.id, 'yes', selectedArticle.votes.up, selectedArticle.votes.down)})
                  </Button>
                  <Button
                    variant="outlined"
                    disabled={!!voted[selectedArticle.id]}
                    onClick={() => handleVote(selectedArticle.id, 'no')}
                    startIcon={<HandThumbDownIcon style={{ width: 18, height: 18, color: "#EF4444" }} />}
                    sx={{
                      borderColor: "#EF4444",
                      color: "#EF4444",
                      textTransform: "none",
                      fontFamily: "Open Sans",
                      fontWeight: 600,
                      fontSize: 14,
                      px: 3,
                      py: 1,
                      borderRadius: "8px",
                      "&:hover": {
                        borderColor: "#DC2626",
                        bgcolor: "#FEF2F2",
                      },
                    }}
                  >
                    No ({getVoteForId(selectedArticle.id, 'no', selectedArticle.votes.up, selectedArticle.votes.down)})
                  </Button>
                </Box>
              </Box>
            </Box>
          </Box>
        )}
      </Drawer>
    </>
  );
};

export default KnowledgeBaseLayout;
