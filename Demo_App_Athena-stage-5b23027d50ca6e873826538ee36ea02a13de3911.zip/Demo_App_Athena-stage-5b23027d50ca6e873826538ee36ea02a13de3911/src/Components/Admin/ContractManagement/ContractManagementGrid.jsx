import React, { useState, forwardRef, useImperativeHandle } from "react";
import { Box, Typography, Chip } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { contractRows } from "../../../Data/ContractData";
import { useNavigate } from "react-router-dom";

const ContractManagementGrid = forwardRef((props, ref) => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [gridKey, setGridKey] = useState(0);

  // Expose refresh method to parent via ref
  useImperativeHandle(ref, () => ({
    refresh: () => {
      setLoading(true);
      setTimeout(() => {
        setGridKey(prev => prev + 1);
        setLoading(false);
      }, 300);
    }
  }));

  const handleRowClick = (params) => {
    console.log("Contract clicked:", params.row);
    // Navigate to new contract form with row data
    navigate('/new-contract-form', { state: { contractData: params.row } });
  };

  const columns = [
    {
      field: "ref",
      headerName: "Ref",
      width: 120,
      sortable: true,
      renderCell: (params) => (
        <Typography 
          sx={{ 
            fontSize: "14px", 
            fontWeight: 500, 
            color: "#4B4B4B", 
            fontFamily: "Open Sans", 
            pt: 1.5 
          }}
        >
          {params.value}
        </Typography>
      ),
    },
    {
      field: "client",
      headerName: "Client",
      flex: 1,
      minWidth: 180,
      renderCell: (params) => (
        <Typography 
          sx={{ 
            fontSize: "14px", 
            fontWeight: 500, 
            color: "#4B4B4B", 
            fontFamily: "Open Sans", 
            pt: 1.5 
          }}
        >
          {params.value}
        </Typography>
      ),
    },
    {
      field: "site",
      headerName: "Site",
      flex: 1,
      minWidth: 200,
      renderCell: (params) => (
        <Typography 
          sx={{ 
            fontSize: "14px", 
            fontWeight: 500, 
            color: "#4B4B4B", 
            fontFamily: "Open Sans", 
            pt: 1.5 
          }}
        >
          {params.value}
        </Typography>
      ),
    },
    {
      field: "startDate",
      headerName: "Start Date",
      width: 120,
      renderCell: (params) => (
        <Typography 
          sx={{ 
            fontSize: "14px", 
            fontWeight: 500, 
            color: "#4B4B4B", 
            fontFamily: "Open Sans", 
            pt: 1.5 
          }}
        >
          {params.value}
        </Typography>
      ),
    },
    {
      field: "endDate",
      headerName: "End Date",
      width: 120,
      renderCell: (params) => (
        <Typography 
          sx={{ 
            fontSize: "14px", 
            fontWeight: 500, 
            color: "#4B4B4B", 
            fontFamily: "Open Sans", 
            pt: 1.5 
          }}
        >
          {params.value}
        </Typography>
      ),
    },
    {
      field: "status",
      headerName: "Status",
      width: 120,
      renderCell: (params) => {
        const statusConfig = {
          "Active": { color: "#10B981", bgColor: "#D1FAE5" },
          "In Effect": { color: "#409BFF", bgColor: "#DBEAFE" },
          "Expired": { color: "#6B7280", bgColor: "#F3F4F6" },
          "Terminated": { color: "#EF4444", bgColor: "#FEE2E2" },
        };
        
        const config = statusConfig[params.value] || statusConfig["Active"];
        
        return (
          <Chip
            label={params.value}
            sx={{
              fontSize: "12px",
              fontWeight: 600,
              color: config.color,
              backgroundColor: config.bgColor,
              fontFamily: "Open Sans",
              height: "24px",
              "& .MuiChip-label": { px: 1.5 }
            }}
          />
        );
      },
    },
    {
      field: "billingPeriod",
      headerName: "Billing Period",
      width: 130,
      renderCell: (params) => (
        <Typography 
          sx={{ 
            fontSize: "14px", 
            fontWeight: 500, 
            color: "#4B4B4B", 
            fontFamily: "Open Sans", 
            pt: 1.5 
          }}
        >
          {params.value}
        </Typography>
      ),
    },
    {
      field: "contractType",
      headerName: "Contract Type",
      flex: 1,
      minWidth: 180,
      renderCell: (params) => (
        <Typography 
          sx={{ 
            fontSize: "14px", 
            fontWeight: 500, 
            color: "#4B4B4B", 
            fontFamily: "Open Sans", 
            pt: 1.5 
          }}
        >
          {params.value}
        </Typography>
      ),
    },
  ];

  return (
    <Box sx={{ mt: 3 }}>
      {/* DataGrid */}
      <Box 
        sx={{ 
          width: "100%", 
          overflowX: "auto", 
          "-ms-overflow-style": "none", 
          "scrollbar-width": "none", 
          "&::-webkit-scrollbar": { display: "none" } 
        }}
      >
        <DataGrid
          key={gridKey}
          rows={contractRows}
          columns={columns}
          onRowClick={handleRowClick}
          disableRowSelectionOnClick
          loading={loading}
          initialState={{ 
            pagination: { 
              paginationModel: { page: 0, pageSize: 10 } 
            } 
          }}
          sx={{
            border: "none",
            fontFamily: "Open Sans",
            "& .MuiDataGrid-columnHeader": { 
              backgroundColor: "#FAFAFA" 
            },
            "& .MuiDataGrid-columnHeaderTitle": { 
              fontSize: "14px", 
              fontWeight: 700, 
              color: "#4B4B4B", 
              fontFamily: "Open Sans" 
            },
            "& .MuiDataGrid-cell": { 
              fontSize: "14px", 
              fontWeight: 400, 
              color: "#4B4B4B", 
              fontFamily: "Open Sans" 
            },
            "& .MuiDataGrid-row": {
              cursor: "pointer",
              "&:hover": { background: "#D3E0F6C7" },
              "&.Mui-selected": { 
                background: "#E3F2FD !important", 
                "&:hover": { background: "#E3F2FD !important" } 
              },
            },
            "& .MuiDataGrid-columnSeparator": { display: "none" },
            "& .MuiDataGrid-cell:focus": { outline: "none" },
            "& .MuiDataGrid-cell:focus-within": { outline: "none" },
            "& .MuiDataGrid-columnHeader:focus": { outline: "none" },
            "& .MuiDataGrid-columnHeader:focus-within": { outline: "none" },
          }}
        />
      </Box>
    </Box>
  );
});

ContractManagementGrid.displayName = 'ContractManagementGrid';

export default ContractManagementGrid;
