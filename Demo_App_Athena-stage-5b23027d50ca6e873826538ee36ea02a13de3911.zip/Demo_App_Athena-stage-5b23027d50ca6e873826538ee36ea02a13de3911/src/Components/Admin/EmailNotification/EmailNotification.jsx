import React, { useState, useMemo } from 'react';
import TitleBreadcrumb from "../../Shared/TitleBreadcrumb";
import DeleteNotifyDialog from "./DeleteNotifyDialog";
import {
  Grid, Box, Typography, Button, IconButton, Card, Avatar,
  List, ListItem, ListItemAvatar, ListItemText, ListItemButton,
  Chip, TextField, InputAdornment, Drawer, Divider, Badge, Stack,
  Checkbox, Menu, MenuItem, Snackbar, Alert, Tooltip, Select, FormControl,
  Pagination, ToggleButtonGroup, ToggleButton
} from "@mui/material";
import {
  HomeIcon, MagnifyingGlassIcon, EnvelopeIcon, EnvelopeOpenIcon,
  TrashIcon, ArchiveBoxIcon, XMarkIcon, EllipsisVerticalIcon,
  CheckIcon, FunnelIcon, ArrowPathIcon, StarIcon as StarIconSolid,
  ClockIcon, BellAlertIcon, BookmarkIcon
} from '@heroicons/react/24/solid';
import { StarIcon as StarIconOutline } from '@heroicons/react/24/outline';
import { useNavigate } from 'react-router-dom';

const EmailNotification = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [selectedNotification, setSelectedNotification] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [selectedIds, setSelectedIds] = useState([]);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [notificationToDelete, setNotificationToDelete] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [anchorEl, setAnchorEl] = useState(null);
  const [filterMenuAnchor, setFilterMenuAnchor] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  
  // New state for enhanced features
  const [sortBy, setSortBy] = useState('date');
  const [sortOrder, setSortOrder] = useState('desc');
  const [typeFilter, setTypeFilter] = useState('all'); 
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [viewMode, setViewMode] = useState('comfortable');
  const [starredIds, setStarredIds] = useState([]);
  const [archivedIds, setArchivedIds] = useState([]);
  const [showArchived, setShowArchived] = useState(false);

const [notifications, setNotifications] = useState([
  {
    id: 1,
    sender: 'John Williams',
    senderEmail: 'john.williams@company.com',
    subject: 'Ticket #002187 - Trackpad stops working randomly',
    message: 'The issue has been investigated and a solution has been proposed. Please review the ticket for more details.',
    timestamp: '2 hours ago',
    date: '09/18/2025',
    fullDate: new Date('2025-09-18T14:30:00'),
    type: 'Ticket Update',
    isRead: false,
    priority: 'Critical',
    avatar: 'JW',
    avatarUrl: 'https://i.pravatar.cc/150?img=12'
  },
  {
    id: 2,
    sender: 'Sarah Johnson',
    senderEmail: 'sarah.johnson@company.com',
    subject: 'Invoice #INV-001 - Payment Received',
    message: 'Payment of $2,500.00 has been successfully received from Acme Corp. Invoice has been marked as paid.',
    timestamp: '5 hours ago',
    date: '09/18/2025',
    fullDate: new Date('2025-09-18T11:30:00'),
    type: 'Billing',
    isRead: false,
    priority: 'High',
    avatar: 'SJ',
    avatarUrl: 'https://i.pravatar.cc/150?img=47'
  },
  {
    id: 3,
    sender: 'Michael Chen',
    senderEmail: 'michael.chen@company.com',
    subject: 'Asset #000262 - Laptop Assignment',
    message: 'A new laptop has been assigned to your account. Please visit the IT department to collect it.',
    timestamp: 'Yesterday',
    date: '09/17/2025',
    fullDate: new Date('2025-09-17T10:00:00'),
    type: 'Asset Management',
    isRead: true,
    priority: 'Medium',
    avatar: 'MC',
    avatarUrl: 'https://i.pravatar.cc/150?img=33' 
  },
  {
    id: 4,
    sender: 'Emily Rodriguez',
    senderEmail: 'emily.rodriguez@company.com',
    subject: 'Quote #QUO-234 - Approved',
    message: 'Your quote for Desktop Services has been approved. You can now proceed with creating an invoice.',
    timestamp: '2 days ago',
    date: '09/16/2025',
    fullDate: new Date('2025-09-16T09:00:00'),
    type: 'CRM',
    isRead: true,
    priority: 'Low',
    avatar: 'ER',
    avatarUrl: 'https://i.pravatar.cc/150?img=45' 
  },
  {
    id: 5,
    sender: 'David Anderson',
    senderEmail: 'david.anderson@company.com',
    subject: 'Ticket #002256 - Software update failures',
    message: 'A new ticket has been assigned to you. Priority: High. Please respond within 24 hours.',
    timestamp: '3 days ago',
    date: '09/15/2025',
    fullDate: new Date('2025-09-15T16:00:00'),
    type: 'Ticket Update',
    isRead: true,
    priority: 'High',
    avatar: 'DA',
    avatarUrl: 'https://i.pravatar.cc/150?img=68' 
  },
  {
    id: 6,
    sender: 'Lisa Thompson',
    senderEmail: 'lisa.thompson@company.com',
    subject: 'System Maintenance Scheduled',
    message: 'System maintenance will be performed this weekend. Please save your work.',
    timestamp: '1 week ago',
    date: '09/11/2025',
    fullDate: new Date('2025-09-11T08:00:00'),
    type: 'System',
    isRead: true,
    priority: 'Medium',
    avatar: 'LT',
    avatarUrl: 'https://i.pravatar.cc/150?img=20' 
  },
  {
    id: 7,
    sender: 'Robert Martinez',
    senderEmail: 'robert.martinez@company.com',
    subject: 'New Purchase Order - PO#5678',
    message: 'A new purchase order has been created and requires your approval before proceeding with the vendor.',
    timestamp: '1 week ago',
    date: '09/11/2025',
    fullDate: new Date('2025-09-11T15:30:00'),
    type: 'Billing',
    isRead: false,
    priority: 'High',
    avatar: 'RM',
    avatarUrl: 'https://i.pravatar.cc/150?img=15' 
  },
  {
    id: 8,
    sender: 'Jennifer Lee',
    senderEmail: 'jennifer.lee@company.com',
    subject: 'Security Alert - Login from new device',
    message: 'We detected a login to your account from a new device. If this was not you, please reset your password immediately.',
    timestamp: '2 weeks ago',
    date: '09/04/2025',
    fullDate: new Date('2025-09-04T10:15:00'),
    type: 'System',
    isRead: true,
    priority: 'Critical',
    avatar: 'JL',
    avatarUrl: 'https://i.pravatar.cc/150?img=32'
  }
]);

  // Advanced filtering and sorting
  const filteredAndSortedNotifications = useMemo(() => {
    let filtered = notifications.filter(notif => {
      if (showArchived && !archivedIds.includes(notif.id)) return false;
      if (!showArchived && archivedIds.includes(notif.id)) return false;

      const matchesSearch = notif.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
        notif.sender.toLowerCase().includes(searchQuery.toLowerCase()) ||
        notif.message.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesReadFilter = filterType === 'all' ? true :
        filterType === 'unread' ? !notif.isRead :
        filterType === 'read' ? notif.isRead :
        filterType === 'starred' ? starredIds.includes(notif.id) : true;

      const matchesType = typeFilter === 'all' ? true : notif.type === typeFilter;
      const matchesPriority = priorityFilter === 'all' ? true : notif.priority === priorityFilter;

      return matchesSearch && matchesReadFilter && matchesType && matchesPriority;
    });

    filtered.sort((a, b) => {
      let comparison = 0;
      
      if (sortBy === 'date') {
        comparison = a.fullDate - b.fullDate;
      } else if (sortBy === 'priority') {
        const priorityOrder = { 'Critical': 4, 'High': 3, 'Medium': 2, 'Low': 1 };
        comparison = (priorityOrder[a.priority] || 0) - (priorityOrder[b.priority] || 0);
      } else if (sortBy === 'sender') {
        comparison = a.sender.localeCompare(b.sender);
      }

      return sortOrder === 'asc' ? comparison : -comparison;
    });

    return filtered;
  }, [notifications, searchQuery, filterType, typeFilter, priorityFilter, sortBy, sortOrder, starredIds, archivedIds, showArchived]);

  const paginatedNotifications = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredAndSortedNotifications.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredAndSortedNotifications, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(filteredAndSortedNotifications.length / itemsPerPage);
  const unreadCount = notifications.filter(n => !n.isRead && !archivedIds.includes(n.id)).length;
  const isAllSelected = paginatedNotifications.length > 0 && selectedIds.length === paginatedNotifications.length;
  const isSomeSelected = selectedIds.length > 0 && selectedIds.length < paginatedNotifications.length;

  const handleNotificationClick = (notification) => {
    setSelectedNotification(notification);
    setNotifications(notifications.map(n =>
      n.id === notification.id ? { ...n, isRead: true } : n
    ));
  };

  const handleSelectAll = () => {
    if (isAllSelected) {
      setSelectedIds([]);
    } else {
      setSelectedIds(paginatedNotifications.map(n => n.id));
    }
  };

  const handleSelectOne = (id) => {
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleMarkAsRead = (id) => {
    setNotifications(notifications.map(n =>
      n.id === id ? { ...n, isRead: true } : n
    ));
  };

  const handleMarkAsUnread = (id) => {
    setNotifications(notifications.map(n =>
      n.id === id ? { ...n, isRead: false } : n
    ));
  };

  const handleBulkMarkAsRead = () => {
    setNotifications(notifications.map(n =>
      selectedIds.includes(n.id) ? { ...n, isRead: true } : n
    ));
    setSelectedIds([]);
    showSnackbar(`${selectedIds.length} notification(s) marked as read`, 'success');
    handleCloseMenu();
  };

  const handleBulkMarkAsUnread = () => {
    setNotifications(notifications.map(n =>
      selectedIds.includes(n.id) ? { ...n, isRead: false } : n
    ));
    setSelectedIds([]);
    showSnackbar(`${selectedIds.length} notification(s) marked as unread`, 'success');
    handleCloseMenu();
  };

  const handleMarkAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, isRead: true })));
    showSnackbar('All notifications marked as read', 'success');
    handleCloseMenu();
  };

  const handleToggleStar = (e, id) => {
    e.stopPropagation();
    setStarredIds(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
    showSnackbar(
      starredIds.includes(id) ? 'Removed from starred' : 'Added to starred',
      'success'
    );
  };

  const handleArchive = (id) => {
    setArchivedIds(prev => [...prev, id]);
    setSelectedIds(prev => prev.filter(i => i !== id));
    if (selectedNotification?.id === id) {
      setSelectedNotification(null);
    }
    showSnackbar('Notification archived', 'success');
  };

  const handleBulkArchive = () => {
    setArchivedIds(prev => [...prev, ...selectedIds]);
    setSelectedIds([]);
    showSnackbar(`${selectedIds.length} notification(s) archived`, 'success');
    handleCloseMenu();
  };

  const handleUnarchive = (id) => {
    setArchivedIds(prev => prev.filter(i => i !== id));
    showSnackbar('Notification unarchived', 'success');
  };

  const handleRefresh = () => {
    setLoading(true);
    showSnackbar('Notifications refreshed', 'info');
    setTimeout(() => setLoading(false), 1000);
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setFilterType('all');
    setTypeFilter('all');
    setPriorityFilter('all');
    setSortBy('date');
    setSortOrder('desc');
    setCurrentPage(1);
    showSnackbar('Filters reset', 'info');
  };

  const handleDeleteFromList = (e, notification) => {
    e.stopPropagation();
    setNotificationToDelete(notification);
    setDeleteTarget('single');
    setDeleteDialogOpen(true);
  };

  const handleDeleteFromDrawer = () => {
    setNotificationToDelete(selectedNotification);
    setDeleteTarget('single');
    setDeleteDialogOpen(true);
  };

  const handleBulkDeleteClick = () => {
    setDeleteTarget('multiple');
    setDeleteDialogOpen(true);
    handleCloseMenu();
  };

  const handleConfirmDelete = () => {
    if (deleteTarget === 'single' && notificationToDelete) {
      setNotifications(notifications.filter(n => n.id !== notificationToDelete.id));
      if (selectedNotification?.id === notificationToDelete.id) {
        setSelectedNotification(null);
      }
      showSnackbar('Notification deleted successfully', 'success');
    } else if (deleteTarget === 'multiple') {
      const count = selectedIds.length;
      setNotifications(notifications.filter(n => !selectedIds.includes(n.id)));
      if (selectedNotification && selectedIds.includes(selectedNotification.id)) {
        setSelectedNotification(null);
      }
      setSelectedIds([]);
      showSnackbar(`${count} notification(s) deleted successfully`, 'success');
    }
    setDeleteDialogOpen(false);
    setDeleteTarget(null);
    setNotificationToDelete(null);
  };

  const handleCloseDeleteDialog = () => {
    setDeleteDialogOpen(false);
    setDeleteTarget(null);
    setNotificationToDelete(null);
  };

  const handleCloseDrawer = () => setSelectedNotification(null);
  const handleOpenMenu = (event) => setAnchorEl(event.currentTarget);
  const handleCloseMenu = () => setAnchorEl(null);
  const handleOpenFilterMenu = (event) => setFilterMenuAnchor(event.currentTarget);
  const handleCloseFilterMenu = () => setFilterMenuAnchor(null);

  const showSnackbar = (message, severity = 'success') => {
    setSnackbar({ open: true, message, severity });
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'Critical': return '#EF4444';
      case 'High': return '#F59E0B';
      case 'Medium': return '#3B82F6';
      case 'Low': return '#10B981';
      default: return '#6B7280';
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'Ticket Update': return '#3B82F6';
      case 'Billing': return '#10B981';
      case 'Asset Management': return '#F59E0B';
      case 'CRM': return '#8B5CF6';
      case 'System': return '#6B7280';
      default: return '#6B7280';
    }
  };

  const uniqueTypes = [...new Set(notifications.map(n => n.type))];
  const uniquePriorities = ['Critical', 'High', 'Medium', 'Low'];

  return (
    <>
      <Grid
        container
        spacing={{ xs: 1, md: 2 }}
        columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{
          width: "100%",
          maxWidth: "100vw",
          m: 0,
          p: { xs: 0, sm: 1 },
          flexGrow: 1,
        }}
      >
        <Grid
          item
          size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{
            border: "1px solid #E4E4E7",
            backgroundColor: "#fff",
            px: { xs: 1, sm: 4, md: 6, xl: 3 },
            py: { xs: 0, sm: 3 },
          }}
        >
          {/* Breadcrumb */}
          <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
            <HomeIcon style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8, cursor: "pointer" }} onClick={() => navigate("/admin")} />
            <TitleBreadcrumb
              breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin" },
                { type: "text", label: "Email Notification", to: "" }
              ]}
            />
          </Box>

          {/* Header with Title and Actions */}
          <Box
            sx={{
              mt: 2,
              pt: 1,
              pb: 1,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: 2
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <Typography
                sx={{
                  fontFamily: "Open Sans",
                  fontSize: "24px",
                  fontWeight: "700",
                  color: "#111827"
                }}
              >
                Email Notification
              </Typography>
              <Badge
                badgeContent={unreadCount}
                sx={{
                  '& .MuiBadge-badge': {
                    backgroundColor: '#EF4444',
                    color: '#fff',
                    fontWeight: 600
                  }
                }}
              >
                <EnvelopeIcon style={{ width: 24, height: 24, color: "#4390F8" }} />
              </Badge>
              {starredIds.length > 0 && (
                <Chip
                  icon={<StarIconSolid style={{ width: 16, height: 16 }} />}
                  label={`${starredIds.length} starred`}
                  size="small"
                  sx={{
                    backgroundColor: '#FEF3C7',
                    color: '#92400E',
                    fontWeight: 600
                  }}
                />
              )}
            </Box>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Tooltip title="Refresh">
                <IconButton
                  onClick={handleRefresh}
                  size="small"
                  sx={{
                    backgroundColor: loading ? '#93c5fd' : '#409BFF',
                    color: '#FFFFFF',
                    width: 38,
                    height: 38,
                    borderRadius: '6px',
                    transition: "transform 0.3s ease",
                    animation: loading ? "spin 1s linear infinite" : "none",
                    "@keyframes spin": {
                      "0%": { transform: "rotate(0deg)" },
                      "100%": { transform: "rotate(360deg)" },
                    },
                    '&:hover': {
                      backgroundColor: '#2563EB'
                    }
                  }}
                >
                  <ArrowPathIcon style={{ width: 20, height: 20 }} />
                </IconButton>
              </Tooltip>
              <Tooltip title="Advanced Filters">
                <IconButton
                  onClick={handleOpenFilterMenu}
                  size="small"
                  sx={{
                    backgroundColor: '#409BFF',
                    color: '#FFFFFF',
                    width: 38,
                    height: 38,
                    borderRadius: '6px',
                    '&:hover': {
                      backgroundColor: '#2563EB'
                    }
                  }}
                >
                  <FunnelIcon style={{ width: 20, height: 20 }} />
                </IconButton>
              </Tooltip>
              <IconButton
                onClick={handleOpenMenu}
                sx={{
                  backgroundColor: '#409BFF',
                  color: '#FFFFFF',
                  width: 38,
                  height: 38,
                  borderRadius: '6px',
                  '&:hover': {
                    backgroundColor: '#2563EB'
                  }
                }}
              >
                <EllipsisVerticalIcon style={{ width: 24, height: 24 }} />
              </IconButton>
            </Box>
          </Box>

          {/* Advanced Filter Menu */}
          <Menu
            anchorEl={filterMenuAnchor}
            open={Boolean(filterMenuAnchor)}
            onClose={handleCloseFilterMenu}
            disableScrollLock
            PaperProps={{
              sx: {
                mt: 1,
                p: 2,
                minWidth: 300,
                boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                border: '1px solid #E4E4E7'
              }
            }}
          >
            <Typography sx={{ fontSize: '14px', fontWeight: 700, mb: 2, color: '#111827' }}>
              Advanced Filters
            </Typography>
            
            <Box sx={{ mb: 2 }}>
              <Typography sx={{ fontSize: '12px', fontWeight: 600, mb: 1, color: '#6B7280' }}>
                Type
              </Typography>
              <FormControl fullWidth size="small">
                <Select
                  MenuProps={menuProps}
                  value={typeFilter}
                  onChange={(e) => setTypeFilter(e.target.value)}
                  sx={{ fontSize: '14px' }}
                >
                  <MenuItem value="all">All Types</MenuItem>
                  {uniqueTypes.map(type => (
                    <MenuItem key={type} value={type}>{type}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Box>

            <Box sx={{ mb: 2 }}>
              <Typography sx={{ fontSize: '12px', fontWeight: 600, mb: 1, color: '#6B7280' }}>
                Priority
              </Typography>
              <FormControl fullWidth size="small">
                <Select
                  MenuProps={menuProps}
                  value={priorityFilter}
                  onChange={(e) => setPriorityFilter(e.target.value)}
                  sx={{ fontSize: '14px' }}
                >
                  <MenuItem value="all">All Priorities</MenuItem>
                  {uniquePriorities.map(priority => (
                    <MenuItem key={priority} value={priority}>{priority}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Box>

            <Box sx={{ mb: 2 }}>
              <Typography sx={{ fontSize: '12px', fontWeight: 600, mb: 1, color: '#6B7280' }}>
                Sort By
              </Typography>
              <FormControl fullWidth size="small">
                <Select
                  value={sortBy}
                  MenuProps={menuProps}
                  onChange={(e) => setSortBy(e.target.value)}
                  sx={{ fontSize: '14px' }}
                >
                  <MenuItem value="date">Date</MenuItem>
                  <MenuItem value="priority">Priority</MenuItem>
                  <MenuItem value="sender">Sender</MenuItem>
                </Select>
              </FormControl>
            </Box>

            <Box sx={{ mb: 2 }}>
              <Typography sx={{ fontSize: '12px', fontWeight: 600, mb: 1, color: '#6B7280' }}>
                Order
              </Typography>
              <ToggleButtonGroup
                value={sortOrder}
                exclusive
                onChange={(e, value) => value && setSortOrder(value)}
                fullWidth
                size="small"
              >
                <ToggleButton value="asc" sx={{ textTransform: 'none', fontSize: '13px' }}>
                  Ascending
                </ToggleButton>
                <ToggleButton value="desc" sx={{ textTransform: 'none', fontSize: '13px' }}>
                  Descending
                </ToggleButton>
              </ToggleButtonGroup>
            </Box>

            <Button
              onClick={handleResetFilters}
              fullWidth
              variant="outlined"
              size="small"
              sx={{
                textTransform: 'none',
                borderColor: '#E4E4E7',
                color: '#6B7280'
              }}
            >
              Reset Filters
            </Button>
          </Menu>

          {/* Bulk Actions Menu */}
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleCloseMenu}
            disableScrollLock
            PaperProps={{
              sx: {
                mt: 1,
                boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                border: '1px solid #E4E4E7'
              }
            }}
          >
            <MenuItem onClick={handleMarkAllAsRead} sx={{ fontSize: '14px', fontFamily: 'Open Sans' }}>
              <CheckIcon style={{ width: 18, height: 18, marginRight: 8 }} />
              Mark All as Read
            </MenuItem>
            <MenuItem onClick={() => setShowArchived(!showArchived)} sx={{ fontSize: '14px', fontFamily: 'Open Sans' }}>
              <ArchiveBoxIcon style={{ width: 18, height: 18, marginRight: 8 }} />
              {showArchived ? 'Hide Archived' : 'Show Archived'}
            </MenuItem>
            {selectedIds.length > 0 && (
              <>
                <Divider sx={{ my: 1 }} />
                <MenuItem onClick={handleBulkMarkAsRead} sx={{ fontSize: '14px', fontFamily: 'Open Sans' }}>
                  <EnvelopeOpenIcon style={{ width: 18, height: 18, marginRight: 8 }} />
                  Mark Selected as Read ({selectedIds.length})
                </MenuItem>
                <MenuItem onClick={handleBulkMarkAsUnread} sx={{ fontSize: '14px', fontFamily: 'Open Sans' }}>
                  <EnvelopeIcon style={{ width: 18, height: 18, marginRight: 8 }} />
                  Mark Selected as Unread ({selectedIds.length})
                </MenuItem>
                <MenuItem onClick={handleBulkArchive} sx={{ fontSize: '14px', fontFamily: 'Open Sans' }}>
                  <ArchiveBoxIcon style={{ width: 18, height: 18, marginRight: 8 }} />
                  Archive Selected ({selectedIds.length})
                </MenuItem>
                <MenuItem onClick={handleBulkDeleteClick} sx={{ fontSize: '14px', fontFamily: 'Open Sans', color: '#EF4444' }}>
                  <TrashIcon style={{ width: 18, height: 18, marginRight: 8 }} />
                  Delete Selected ({selectedIds.length})
                </MenuItem>
              </>
            )}
          </Menu>

          {/* Search and Filter Bar */}
          <Box sx={{ mt: 3, mb: 2, display: 'flex', justifyContent: "space-between", alignItems: 'center', gap: 2, flexWrap: 'wrap' }}>
            <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
              {selectedIds.length > 0 && (
                <>
                  {/* <Badge 
                    badgeContent={selectedIds.length} 
                    sx={{
                      '& .MuiBadge-badge': {
                        backgroundColor: '#0369A1',
                        color: '#fff',
                        fontWeight: 600
                      }
                    }}
                  >
                    <Chip
                      label={`${selectedIds.length} selected`}
                      onDelete={() => setSelectedIds([])}
                      sx={{
                        backgroundColor: '#E0F2FE',
                        color: '#0369A1',
                        fontWeight: 600
                      }}
                    />
                  </Badge> */}
                  <Tooltip title="Delete Selected">
                    <Button
                      variant="contained"
                      startIcon={<TrashIcon style={{ width: 18, height: 18 }} />}
                      onClick={handleBulkDeleteClick}
                      sx={{
                        backgroundColor: '#EF4444',
                        color: '#fff',
                        textTransform: 'none',
                        fontWeight: 600,
                        fontSize: '14px',
                        '&:hover': {
                          backgroundColor: '#DC2626'
                        }
                      }}
                    >
                      Delete ({selectedIds.length})
                    </Button>
                  </Tooltip>
                </>
              )}
              {showArchived && (
                <Chip
                  label="Showing Archived"
                  onDelete={() => setShowArchived(false)}
                  sx={{
                    backgroundColor: '#FEF3C7',
                    color: '#92400E',
                    fontWeight: 600
                  }}
                />
              )}
            </Box>
            <Box sx={{ display: 'flex', gap: 2, alignItems: 'center', flexWrap: 'wrap' }}>
              <TextField
                placeholder="Search notifications..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                size="small"
                sx={{
                  minWidth: 250,
                  '& .MuiOutlinedInput-root': {
                    borderRadius: "8px",
                    backgroundColor: '#fff'
                  }
                }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <MagnifyingGlassIcon style={{ width: 20, height: 20, color: "#6B7280" }} />
                    </InputAdornment>
                  ),
                }}
              />
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                <Button
                  variant={filterType === 'all' ? 'contained' : 'outlined'}
                  onClick={() => setFilterType('all')}
                  disableRipple
                  sx={{
                    textTransform: 'none',
                    backgroundColor: filterType === 'all' ? '#4390F8' : 'transparent',
                    borderColor: '#E4E4E7',
                    color: filterType === 'all' ? '#fff' : '#6B7280',
                    '&:hover': {
                      backgroundColor: filterType === 'all' ? '#3B82F6' : '#F9FAFB',
                    }
                  }}
                >
                  All ({notifications.filter(n => !archivedIds.includes(n.id)).length})
                </Button>
                <Button
                  variant={filterType === 'unread' ? 'contained' : 'outlined'}
                  onClick={() => setFilterType('unread')}
                  disableRipple
                  sx={{
                    textTransform: 'none',
                    backgroundColor: filterType === 'unread' ? '#4390F8' : 'transparent',
                    borderColor: '#E4E4E7',
                    color: filterType === 'unread' ? '#fff' : '#6B7280',
                    '&:hover': {
                      backgroundColor: filterType === 'unread' ? '#3B82F6' : '#F9FAFB',
                    }
                  }}
                >
                  Unread ({unreadCount})
                </Button>
                <Button
                  variant={filterType === 'read' ? 'contained' : 'outlined'}
                  onClick={() => setFilterType('read')}
                  disableRipple
                  sx={{
                    textTransform: 'none',
                    backgroundColor: filterType === 'read' ? '#4390F8' : 'transparent',
                    borderColor: '#E4E4E7',
                    color: filterType === 'read' ? '#fff' : '#6B7280',
                    '&:hover': {
                      backgroundColor: filterType === 'read' ? '#3B82F6' : '#F9FAFB',
                    }
                  }}
                >
                  Read ({notifications.filter(n => n.isRead && !archivedIds.includes(n.id)).length})
                </Button>
                <Button
                  variant={filterType === 'starred' ? 'contained' : 'outlined'}
                  onClick={() => setFilterType('starred')}
                  startIcon={<StarIconSolid style={{ width: 16, height: 16 }} />}
                  disableRipple
                  sx={{
                    textTransform: 'none',
                    backgroundColor: filterType === 'starred' ? '#FBBF24' : 'transparent',
                    borderColor: '#E4E4E7',
                    color: filterType === 'starred' ? '#fff' : '#6B7280',
                    '&:hover': {
                      backgroundColor: filterType === 'starred' ? '#F59E0B' : '#F9FAFB',
                    }
                  }}
                >
                  Starred ({starredIds.length})
                </Button>
              </Box>
            </Box>
          </Box>

          {/* View Mode and Items Per Page */}
          <Box sx={{ mb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography sx={{ fontSize: '13px', color: '#6B7280' }}>
              Showing {paginatedNotifications.length} of {filteredAndSortedNotifications.length} notifications
            </Typography>
            <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
              <FormControl size="small">
                <Select
                  MenuProps={menuProps}
                  value={itemsPerPage}
                  onChange={(e) => {
                    setItemsPerPage(e.target.value);
                    setCurrentPage(1);
                  }}
                  sx={{ fontSize: '13px', minWidth: 80 }}
                >
                  <MenuItem value={5}>5</MenuItem>
                  <MenuItem value={10}>10</MenuItem>
                
                </Select>
              </FormControl>
              <ToggleButtonGroup
                value={viewMode}
                exclusive
                onChange={(e, value) => value && setViewMode(value)}
                size="small"
              >
                <ToggleButton value="comfortable" sx={{ px: 2 }}>
                  <Typography sx={{ fontSize: '12px' }}>Comfortable</Typography>
                </ToggleButton>
                <ToggleButton value="compact" sx={{ px: 2 }}>
                  <Typography sx={{ fontSize: '12px' }}>Compact</Typography>
                </ToggleButton>
              </ToggleButtonGroup>
            </Box>
          </Box>

          {/* Notifications List */}
          <Card
            sx={{
              mt: 2,
              border: '1px solid #E4E4E7',
              boxShadow: 'none',
              backgroundColor: '#fff'
            }}
          >
            {paginatedNotifications.length === 0 ? (
              <Box sx={{ p: 4, textAlign: 'center' }}>
                <EnvelopeIcon style={{ width: 48, height: 48, color: "#D1D5DB", margin: '0 auto' }} />
                <Typography sx={{ mt: 2, color: '#6B7280' }}>
                  No notifications found
                </Typography>
              </Box>
            ) : (
              <List sx={{ p: 0 }}>
                {/* Select All Row */}
                <ListItem
                  sx={{
                    py: 1.5,
                    px: 3,
                    borderBottom: '1px solid #E4E4E7',
                    backgroundColor: '#F9FAFB'
                  }}
                >
                  <Checkbox
                    checked={isAllSelected}
                    indeterminate={isSomeSelected}
                    onChange={handleSelectAll}
                    sx={{
                      color: '#4390F8',
                      '&.Mui-checked': {
                        color: '#4390F8',
                      },
                    }}
                  />
                  <Typography sx={{ fontSize: '14px', fontWeight: 600, color: '#6B7280', ml: 1 }}>
                    Select All
                  </Typography>
                </ListItem>

                {paginatedNotifications.map((notification, index) => (
                  <React.Fragment key={notification.id}>
                    <ListItemButton
                      onClick={() => handleNotificationClick(notification)}
                      sx={{
                        py: viewMode === 'comfortable' ? 2 : 1.5,
                        px: 3,
                        backgroundColor: notification.isRead ? '#fff' : '#ecf1f1ff',
                        '&:hover': {
                          backgroundColor: '#EEF2FF'
                        },
                        borderLeft: !notification.isRead ? '4px solid #818a83ff' : '4px solid transparent'
                      }}
                    >
                      <Checkbox
                        checked={selectedIds.includes(notification.id)}
                        onChange={() => handleSelectOne(notification.id)}
                        onClick={(e) => e.stopPropagation()}
                        sx={{
                          color: '#4390F8',
                          '&.Mui-checked': {
                            color: '#4390F8',
                          },
                          mr: 1
                        }}
                      />
                      <IconButton
                        size="small"
                        onClick={(e) => handleToggleStar(e, notification.id)}
                        sx={{ mr: 1, color: starredIds.includes(notification.id) ? '#FBBF24' : '#D1D5DB' }}
                      >
                        {starredIds.includes(notification.id) ? (
                          <StarIconSolid style={{ width: 20, height: 20 }} />
                        ) : (
                          <StarIconOutline style={{ width: 20, height: 20 }} />
                        )}
                      </IconButton>
                      <ListItemAvatar>
                        <Avatar
                          src={notification.avatarUrl}
                          alt={notification.sender}
                          sx={{
                            bgcolor: '#4390F8',
                            width: viewMode === 'comfortable' ? 48 : 40,
                            height: viewMode === 'comfortable' ? 48 : 40,
                            fontWeight: 600,
                            fontSize: viewMode === 'comfortable' ? '16px' : '14px'
                          }}
                        >
                          {notification.avatar}
                        </Avatar>
                      </ListItemAvatar>
                      <ListItemText
                        primary={
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                            <Typography
                              sx={{
                                fontWeight: notification.isRead ? 500 : 700,
                                color: '#111827',
                                fontSize: viewMode === 'comfortable' ? '15px' : '14px',
                                fontFamily: 'Open Sans'
                              }}
                            >
                              {notification.sender}
                            </Typography>
                            <Chip
                              label={notification.type}
                              size="small"
                              sx={{
                                height: 20,
                                fontSize: '12px',
                                fontWeight: 600,
                                backgroundColor: getTypeColor(notification.type) + '20',
                                color: getTypeColor(notification.type),
                                border: 'none'
                              }}
                            />
                            <Chip
                              label={notification.priority}
                              size="small"
                              sx={{
                                height: 20,
                                fontSize: '12px',
                                fontWeight: 600,
                                backgroundColor: getPriorityColor(notification.priority) + '20',
                                color: getPriorityColor(notification.priority),
                                border: 'none'
                              }}
                            />
                          </Box>
                        }
                        secondary={
                          <Box>
                            <Typography
                              sx={{
                                fontWeight: notification.isRead ? 400 : 600,
                                color: '#374151',
                                fontSize: viewMode === 'comfortable' ? '14px' : '13px',
                                mb: 0.5,
                                fontFamily: 'Open Sans'
                              }}
                            >
                              {notification.subject}
                            </Typography>
                            {viewMode === 'comfortable' && (
                              <Typography
                                sx={{
                                  color: '#6B7280',
                                  fontSize: '13px',
                                  overflow: 'hidden',
                                  textOverflow: 'ellipsis',
                                  display: '-webkit-box',
                                  WebkitLineClamp: 1,
                                  WebkitBoxOrient: 'vertical'
                                }}
                              >
                                {notification.message}
                              </Typography>
                            )}
                          </Box>
                        }
                      />
                      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 1, ml: 2 }}>
                        <Typography sx={{ fontSize: '12px', color: '#6B7280', whiteSpace: 'nowrap' }}>
                          {notification.timestamp}
                        </Typography>
                        <Box sx={{ display: 'flex', gap: 0.5 }}>
                          {!notification.isRead ? (
                            <Tooltip title="Mark as read">
                              <IconButton
                                size="small"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleMarkAsRead(notification.id);
                                }}
                                sx={{
                                  color: '#4390F8',
                                  '&:hover': { backgroundColor: '#E0F2FE' }
                                }}
                              >
                                <EnvelopeOpenIcon style={{ width: 18, height: 18 }} />
                              </IconButton>
                            </Tooltip>
                          ) : (
                            <Tooltip title="Mark as unread">
                              <IconButton
                                size="small"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleMarkAsUnread(notification.id);
                                }}
                                sx={{
                                  color: '#6B7280',
                                  '&:hover': { backgroundColor: '#F3F4F6' }
                                }}
                              >
                                <EnvelopeIcon style={{ width: 18, height: 18 }} />
                              </IconButton>
                            </Tooltip>
                          )}
                          {showArchived ? (
                            <Tooltip title="Unarchive">
                              <IconButton
                                size="small"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleUnarchive(notification.id);
                                }}
                                sx={{
                                  color: '#10B981',
                                  '&:hover': { backgroundColor: '#D1FAE5' }
                                }}
                              >
                                <ArchiveBoxIcon style={{ width: 18, height: 18 }} />
                              </IconButton>
                            </Tooltip>
                          ) : (
                            <Tooltip title="Archive">
                              <IconButton
                                size="small"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleArchive(notification.id);
                                }}
                                sx={{
                                  color: '#6B7280',
                                  '&:hover': { backgroundColor: '#F3F4F6' }
                                }}
                              >
                                <ArchiveBoxIcon style={{ width: 18, height: 18 }} />
                              </IconButton>
                            </Tooltip>
                          )}
                          <Tooltip title="Delete">
                            <IconButton
                              size="small"
                              onClick={(e) => handleDeleteFromList(e, notification)}
                              sx={{
                                color: '#EF4444',
                                '&:hover': { backgroundColor: '#FEE2E2' }
                              }}
                            >
                              <TrashIcon style={{ width: 18, height: 18 }} />
                            </IconButton>
                          </Tooltip>
                        </Box>
                      </Box>
                    </ListItemButton>
                    {index < paginatedNotifications.length - 1 && <Divider />}
                  </React.Fragment>
                ))}
              </List>
            )}
          </Card>

          {/* Pagination */}
          {totalPages > 1 && (
            <Box sx={{ mt: 3, display: 'flex', justifyContent: 'center' }}>
              <Pagination
                count={totalPages}
                page={currentPage}
                onChange={(e, page) => setCurrentPage(page)}
                color="primary"
                showFirstButton
                showLastButton
              />
            </Box>
          )}
        </Grid>
      </Grid>

      {/* Notification Detail Drawer */}
      <Drawer
        anchor="right"
        open={selectedNotification !== null}
        onClose={handleCloseDrawer}
        sx={{
          '& .MuiDrawer-paper': {
            width: { xs: '100%', sm: 500 },
            boxShadow: '-4px 0 20px rgba(0, 0, 0, 0.1)'
          }
        }}
      >
        {selectedNotification && (
          <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <Box
              sx={{
                p: 3,
                borderBottom: '1px solid #E4E4E7',
                backgroundColor: '#F9FAFB'
              }}
            >
            </Box>

            <Box sx={{ flexGrow: 1, overflow: 'auto', p: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3, mt: 2 }}>
                <Avatar
                  src={selectedNotification.avatarUrl}
                  alt={selectedNotification.sender}
                  sx={{
                    bgcolor: '#4390F8',
                    width: 56,
                    height: 56,
                    fontWeight: 600,
                    fontSize: '18px'
                  }}
                >
                  {selectedNotification.avatar}
                </Avatar>
                <Box sx={{ flexGrow: 1 }}>
                  <Typography sx={{ fontWeight: 700, fontSize: '16px', color: '#111827' }}>
                    {selectedNotification.sender}
                  </Typography>
                  <Typography sx={{ fontSize: '14px', color: '#6B7280' }}>
                    {selectedNotification.senderEmail}
                  </Typography>
                </Box>
                <IconButton
                  onClick={(e) => handleToggleStar(e, selectedNotification.id)}
                  sx={{ color: starredIds.includes(selectedNotification.id) ? '#FBBF24' : '#D1D5DB' }}
                >
                  {starredIds.includes(selectedNotification.id) ? (
                    <StarIconSolid style={{ width: 24, height: 24 }} />
                  ) : (
                    <StarIconOutline style={{ width: 24, height: 24 }} />
                  )}
                </IconButton>
                <IconButton onClick={handleCloseDrawer} size="small">
                  <XMarkIcon style={{ width: 24, height: 24, color: '#000' }} />
                </IconButton>
              </Box>
              <Box sx={{ mb: 3 }}>
                <Stack direction="row" spacing={1} sx={{ mb: 2, flexWrap: 'wrap' }}>
                  <Chip
                    label={selectedNotification.type}
                    sx={{
                      height: 24,
                      fontSize: '13px',
                      fontWeight: 600,
                      backgroundColor: getTypeColor(selectedNotification.type) + '20',
                      color: getTypeColor(selectedNotification.type),
                    }}
                  />
                  <Chip
                    label={selectedNotification.priority}
                    sx={{
                      height: 24,
                      fontSize: '13px',
                      fontWeight: 600,
                      backgroundColor: getPriorityColor(selectedNotification.priority) + '20',
                      color: getPriorityColor(selectedNotification.priority),
                    }}
                  />
                  {!selectedNotification.isRead && (
                    <Chip
                      label="Unread"
                      sx={{
                        height: 24,
                        fontSize: '12px',
                        fontWeight: 600,
                        backgroundColor: '#DBEAFE',
                        color: '#1E40AF',
                      }}
                    />
                  )}
                </Stack>
                <Typography sx={{ fontSize: '14px', color: '#6B7280', mb: 0.5 }}>
                  <strong>Date:</strong> {selectedNotification.date}
                </Typography>
                <Typography sx={{ fontSize: '14px', color: '#6B7280' }}>
                  <strong>Time:</strong> {selectedNotification.timestamp}
                </Typography>
              </Box>
              <Divider sx={{ my: 3 }} />
              <Box sx={{ mb: 3 }}>
                <Typography sx={{ fontSize: '14px', color: '#6B7280', mb: 1, fontWeight: 600 }}>
                  Subject
                </Typography>
                <Typography sx={{ fontSize: '16px', color: '#111827', fontWeight: 600 }}>
                  {selectedNotification.subject}
                </Typography>
              </Box>
              <Divider sx={{ my: 3 }} />
              <Box sx={{ mb: 3 }}>
                <Typography sx={{ fontSize: '14px', color: '#6B7280', mb: 1, fontWeight: 600 }}>
                  Message
                </Typography>
                <Typography
                  sx={{
                    fontSize: '14px',
                    color: '#374151',
                    lineHeight: 1.6,
                    backgroundColor: '#F9FAFB',
                    p: 2,
                    borderRadius: 1,
                    border: '1px solid #E4E4E7'
                  }}
                >
                  {selectedNotification.message}
                </Typography>
              </Box>
            </Box>
            <Box
              sx={{
                p: 3,
                borderTop: '1px solid #E4E4E7',
                backgroundColor: '#F9FAFB'
              }}
            >
              <Stack direction="row" spacing={2} sx={{ mb: 2 }}>
                <Button
                  variant="contained"
                  startIcon={<EnvelopeOpenIcon style={{ width: 18, height: 18 }} />}
                  onClick={() => {
                    handleMarkAsRead(selectedNotification.id);
                    handleCloseDrawer();
                  }}
                  fullWidth
                  disableRipple
                  sx={{
                    textTransform: 'none',
                    backgroundColor: '#4390F8',
                    '&:hover': {
                      backgroundColor: '#3B82F6'
                    }
                  }}
                >
                  Mark as Read
                </Button>
                <Button
                  variant="outlined"
                  startIcon={<ArchiveBoxIcon style={{ width: 18, height: 18 }} />}
                  onClick={() => {
                    handleArchive(selectedNotification.id);
                    handleCloseDrawer();
                  }}
                  fullWidth
                  disableRipple
                  sx={{
                    textTransform: 'none',
                    borderColor: '#E4E4E7',
                    color: '#6B7280',
                    '&:hover': {
                      borderColor: '#D1D5DB',
                      backgroundColor: '#F3F4F6'
                    }
                  }}
                >
                  Archive
                </Button>
                <IconButton
                  onClick={handleDeleteFromDrawer}
                  sx={{
                    color: '#EF4444',
                    border: '1px solid #FEE2E2',
                    '&:hover': {
                      backgroundColor: '#FEE2E2'
                    }
                  }}
                >
                  <TrashIcon style={{ width: 20, height: 20 }} />
                </IconButton>
              </Stack>
            </Box>
          </Box>
        )}
      </Drawer>

      {/* Delete Confirmation Dialog */}
      <DeleteNotifyDialog
        open={deleteDialogOpen}
        onClose={handleCloseDeleteDialog}
        onConfirm={handleConfirmDelete}
        notificationCount={deleteTarget === 'multiple' ? selectedIds.length : 1}
      />

      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert onClose={handleCloseSnackbar} severity={snackbar.severity} sx={{ width: '100%' }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </>
  );
};

export default EmailNotification;
