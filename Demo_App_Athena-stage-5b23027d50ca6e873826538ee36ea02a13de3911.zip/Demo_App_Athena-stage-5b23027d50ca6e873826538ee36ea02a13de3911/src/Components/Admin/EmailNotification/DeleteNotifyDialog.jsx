import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Box,
  Typography,
  Button,
  IconButton,
} from "@mui/material";
import { XMarkIcon } from "@heroicons/react/24/outline";

const DeleteNotifyDialog = ({ open, onClose, onConfirm, notificationCount = 1 }) => {
  const isMultiple = notificationCount > 1;

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="sm"
      fullWidth
      disableScrollLock
      PaperProps={{
        sx: {
          borderRadius: "12px",
        },
      }}
    >
      {/* Title row with close icon */}
      <DialogTitle
        sx={{
          px: 3,
          pt: 2.5,
          pb: 1.5,
          borderBottom: "1px solid #E5E7EB",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <Typography
          sx={{
            fontFamily: "Open Sans",
            fontSize: 22,
            fontWeight: 700,
            color: "#FF0202",
          }}
        >
          Delete {isMultiple ? 'Notifications' : 'Notification'}
        </Typography>

        <IconButton
          aria-label="Close"
          onClick={onClose}
          sx={{
            color: "#000000",
          }}
        >
          <XMarkIcon style={{ width: 22, height: 22 }} />
        </IconButton>
      </DialogTitle>

      {/* Content */}
      <DialogContent
        sx={{
          px: 3,
          py: 2,
          pb: 4,
          textAlign: "center",
        }}
      >
        <Typography
          sx={{
            fontFamily: "Open Sans",
            fontSize: 24,
            fontWeight: 700,
            color: "#FF0202",
            mb: 2,
            mt: 2
          }}
        >
          Are you sure?
        </Typography>

        <Typography
          sx={{
            fontFamily: "Open Sans",
            fontSize: 14,
            color: "#000000",
            mb: 0.8,
          }}
        >
          {isMultiple 
            ? `Deleting ${notificationCount} notifications is permanent and cannot be undone.`
            : 'Deleting this notification is permanent and cannot be undone.'
          }
        </Typography>
        <Typography
          sx={{
            fontFamily: "Open Sans",
            fontSize: 14,
            color: "#000000",
            mb: 0.8,
          }}
        >
          {isMultiple
            ? 'All selected notifications will be permanently removed from your inbox.'
            : 'This notification will be permanently removed from your inbox.'
          }
        </Typography>
        <Typography
          sx={{
            fontFamily: "Open Sans",
            fontSize: 14,
            color: "#000000",
            mt: 0.5,
          }}
        >
          Are you sure that you wish to delete {isMultiple ? 'these notifications' : 'this notification'}?
        </Typography>
      </DialogContent>

      {/* Actions */}
      <DialogActions
        sx={{
          px: 3,
          pt: 2,
          pb: 3,
          borderTop: "1px solid #E5E7EB",
          display: "flex",
          justifyContent: "end",
          gap: 2,
        }}
      >
        <Button
          onClick={onConfirm}
          sx={{
            minWidth: 110,
            borderRadius: "50px",
            textTransform: "none",
            fontFamily: "Open Sans",
            fontSize: 15,
            fontWeight: 600,
            bgcolor: "#409BFF",
            color: "#FFFFFF",
            px: 4,
            py: 0.8,
            "&:hover": {
              bgcolor: "#2563EB",
            },
          }}
        >
          Yes
        </Button>

        <Button
          onClick={onClose}
          sx={{
            minWidth: 110,
            borderRadius: "50px",
            textTransform: "none",
            fontFamily: "Open Sans",
            fontSize: 15,
            fontWeight: 600,
            bgcolor: "#FF4141",
            color: "#FFFFFF",
            px: 4,
            py: 0.8,
            "&:hover": {
              bgcolor: "#DC2626",
            },
          }}
        >
          No
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeleteNotifyDialog;
