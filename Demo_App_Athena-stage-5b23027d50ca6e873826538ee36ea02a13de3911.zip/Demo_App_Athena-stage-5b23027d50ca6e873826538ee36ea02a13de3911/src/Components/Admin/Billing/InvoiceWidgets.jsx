// InvoiceWidgets.jsx
import React from "react";
import { Grid, Box, Typography } from "@mui/material";
import {
  DocumentChartBarIcon,
  ExclamationCircleIcon,
  DocumentTextIcon,
  CurrencyDollarIcon
} from "@heroicons/react/24/solid";

const widgets = [
  {
    label: "Total Revenue",
    value: "$10,150",
    icon: <CurrencyDollarIcon style={{ width: 25, height: 25, color: "#16A34A" }} />,
    bgIcon: "#DCFCE7",
    extra: (
      <>
        <Typography
          sx={{
            fontSize: 14,
            color: "#16A34A",
            fontWeight: 500,
            lineHeight: "18px",
            display: "flex",
            alignItems: "center",
            mt: 1,
          }}
        >
          <span style={{ marginRight: 4, fontSize: 16 }}>↑</span>12% from last month
        </Typography>
      </>
    ),
  },
  {
    label: "Pending Invoices",
    value: "1",
    icon: (
      <DocumentTextIcon style={{ width: 25, height: 25, color: "#EA580C" }} />
    ),
    bgIcon: "#FFEDD5",
    extra: (
      <Typography
        sx={{
          fontSize: 14,
          color: "#EA580C",
          fontWeight: 500,
          lineHeight: "18px",
          display: "flex",
          alignItems: "center",
          mt: 1,
        }}
      >
        <span style={{ color: "#FF6F43", fontSize: 15, marginRight: 4 }}>●</span>
        $1,850 total
      </Typography>
    ),
  },
  {
    label: "Overdue Amount",
    value: "$3,200",
    icon: (
      <ExclamationCircleIcon
        style={{ width: 25, height: 25, color: "#DC2626" }}
      />
    ),
    bgIcon: "#FEE2E2",
    extra: (
      <Typography
        sx={{
          fontSize: 14,
          color: "#DC2626",
          fontWeight: 500,
          lineHeight: "18px",
          display: "flex",
          alignItems: "center",
          mt: 1,
        }}
      >
        <span style={{ color: "#DC2626", fontSize: 15, marginRight: 4 }}>▲</span>
        1 invoices
      </Typography>
    ),
  },
  {
    label: "Active Quotes",
    value: "2",
    icon: (
      <DocumentChartBarIcon style={{ width: 25, height: 25, color: "#2563EB" }} />
    ),
    bgIcon: "#DBEAFE",
    extra: null,
  },
];

const InvoiceWidgets = () => (
  <Grid container spacing={1} >
    {widgets.map((item, idx) => (
      <Grid item size={{ xs: 12, sm: 12, md: 3 }} key={item.label} >
        <Box
          sx={{
            height: "100%",
            border: "1.5px solid #E4E4E7",
            bgcolor: "#fff",
            borderRadius: "12px",
            display: "flex",
            alignItems: "center",
            px: 3,
            pt: 2,
            pb: 2,
            gap: 2,
        
            boxSizing: "border-box",
            // minWidth: 220,
            boxShadow: "0 0 0 rgba(0,0,0,0)",
            position: "relative",
            cursor: "pointer", 
        transition: 'box-shadow 0.3s cubic-bezier(0.4, 0, 0.2, 1), transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.3s cubic-bezier(0.4, 0, 0.2, 1)', // ✅ Smooth transition
        '&:hover': { 
          boxShadow: '0 8px 24px rgba(67, 144, 248, 0.2)',
          transform: 'translateY(-4px)',
          borderColor: '#4390F8',
        }
          }}
        >
          {/* Left Area: Content */}
          <Box sx={{ flex: 1 }}>
            <Typography
              sx={{
                fontSize: 15,
                color: "#4B5563",
                fontWeight: 700,
                mb: 0.5,
                fontFamily: "Open Sans",
              }}
            >
              {item.label}
            </Typography>
            <Typography
              sx={{
                fontSize: 26,
                fontWeight: 700,
                color: "#111827",
                letterSpacing: "-1px",
                lineHeight: 1.25,
                fontFamily: "Open Sans",
              }}
            >
              {item.value}
            </Typography>
            {item.extra}
          </Box>

          {/* Right: Icon in colored bg */}
          <Box
            sx={{
              minWidth: 48,
              minHeight: 48,
              borderRadius: "8px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              bgcolor: item.bgIcon,
              ml: 2,
            }}
          >
            {item.icon}
          </Box>
        </Box>
      </Grid>
    ))}
  </Grid>
);

export default InvoiceWidgets;
