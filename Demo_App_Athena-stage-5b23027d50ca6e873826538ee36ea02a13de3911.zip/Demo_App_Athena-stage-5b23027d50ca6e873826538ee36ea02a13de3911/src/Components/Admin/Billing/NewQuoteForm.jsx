import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import TitleBreadcrumb from "../../Shared/TitleBreadcrumb";
import { 
  Grid, 
  Box, 
  Typography, 
  Button, 
  TextField, 
  MenuItem,
  Select,
  FormControl,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from "@mui/material";
import { 
  HomeIcon, 
} from '@heroicons/react/24/solid';
import { 
  DocumentTextIcon,
  EyeIcon,
  PaperAirplaneIcon
} from '@heroicons/react/24/outline';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import QuoteViewDialog from "./QuoteViewDialog";

const NewQuoteForm = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [previewDialogOpen, setPreviewDialogOpen] = useState(false);
  const [previewData, setPreviewData] = useState(null);
  const [draftDialogOpen, setDraftDialogOpen] = useState(false);
  const [sendDialogOpen, setSendDialogOpen] = useState(false);

  // Check if we're in edit mode
  const editMode = location.state?.editMode || false;
  const editQuoteData = location.state?.quoteData || null;

  // Parse date string to YYYY-MM-DD format
  const parseDateString = (dateStr) => {
    if (!dateStr) return '';
    try {
      const date = new Date(dateStr);
      return date.toISOString().split('T')[0];
    } catch {
      return '';
    }
  };

  // Map client name to client ID
  const getClientIdByName = (name) => {
    const clientMap = {
      'Acme Corporation': 'client1',
      'TechStart Inc': 'client2',
      'Global Solutions': 'client3',
    };
    return clientMap[name] || '';
  };

  // Client database
  const clientDatabase = {
    client1: {
      name: 'Acme Corporation',
      address: '456 Client Street, Los Angeles, CA 90210',
      email: 'billing@acmecorp.com',
      phone: '+1 (555) 987-6543',
    },
    client2: {
      name: 'TechStart Inc',
      address: '789 Innovation Drive, San Francisco, CA 94105',
      email: 'sarah@techstart.com',
      phone: '+1 (555) 234-5678',
    },
    client3: {
      name: 'Global Solutions',
      address: '321 Enterprise Blvd, Boston, MA 02101',
      email: 'mike@global.com',
      phone: '+1 (555) 876-5432',
    },
  };

  // Item descriptions
const itemDescriptions = [
  'RAM',
  'Keyboard',
  'Motherboard',
  'Monitor',
  'Headphones',
  'Webcam',
];

const itemRates = {
  'RAM': 5000.00,
  'Keyboard': 1500.00,
  'Motherboard': 3500.00,
  'Monitor': 2500.00,
  'Headphones': 2000.00,
  'Webcam': 1200.00,
};
  // Map items from edit data
  const mapItemsFromEdit = () => {
    if (editMode && editQuoteData?.items) {
      return editQuoteData.items.map((item, index) => ({
        id: index + 1,
        description: item.description,
        qty: item.qty,
        rate: item.rate,
        amount: item.amount,
      }));
    }
    return [{ id: 1, description: '', qty: 0, rate: 0, amount: 0 }];
  };

 // Validation Schema
const validationSchema = Yup.object({
  quoteNumber: Yup.string().required('Quote number is required'),
  issueDate: Yup.date().required('Issue date is required'),
  expiryDate: Yup.date()
    .required('Expiry date is required')
    .min(Yup.ref('issueDate'), 'Expiry date must be after issue date'),
  selectedClient: Yup.string().required('Client is required'),
  clientName: Yup.string().required('Client name is required'),
  clientAddress: Yup.string().required('Client address is required'),
  clientEmail: Yup.string()
    .email('Invalid email format')
    .required('Client email is required'),
  items: Yup.array()
    .of(
      Yup.object().shape({
        description: Yup.string().required('Description is required'),
        qty: Yup.number()
          .min(1, 'Quantity must be at least 1')
          .required('Quantity is required'),
        rate: Yup.number()
          .min(0.01, 'Rate must be greater than 0')
          .required('Rate is required'),
      })
    )
    .min(1, 'At least one item is required'),

});


  // Formik setup
  const formik = useFormik({
    initialValues: {
      quoteNumber: editQuoteData?.quoteNumber || 'QT-2025-012',
      issueDate: editQuoteData ? parseDateString(editQuoteData.issueDate) : '',
      expiryDate: editQuoteData ? parseDateString(editQuoteData.dueDate) : '',
      paymentTerms: editQuoteData?.paymentTerms || 'Net 30',
      quoteStatus: editQuoteData?.quoteStatus || 'Draft',
      referenceId: editQuoteData?.reference || '',
      selectedClient: editQuoteData ? getClientIdByName(editQuoteData.buyerName) : '',
      clientName: editQuoteData?.buyerName || '',
      clientAddress: editQuoteData?.buyerAddress || '',
      clientEmail: editQuoteData?.buyerEmail || '',
      clientPhone: editQuoteData?.buyerPhone || '',
      items: mapItemsFromEdit(),
      notes: editQuoteData?.notes || '',
      terms: editQuoteData?.terms || '',
      discount: editQuoteData?.discount || 0,
    },
    validationSchema,
    validateOnChange: true,
    validateOnBlur: true,
    onSubmit: (values) => {
      console.log('Form submitted:', values);
    },
  });

  // Auto-populate client details when client is selected
  useEffect(() => {
    if (formik.values.selectedClient) {
      const selectedClientData = clientDatabase[formik.values.selectedClient];
      if (selectedClientData) {
        formik.setValues({
          ...formik.values,
          clientName: selectedClientData.name,
          clientAddress: selectedClientData.address,
          clientEmail: selectedClientData.email,
          clientPhone: selectedClientData.phone,
        });
      }
    }
  }, [formik.values.selectedClient]);

  // Calculate item amount when qty or rate changes
  useEffect(() => {
    const updatedItems = formik.values.items.map(item => ({
      ...item,
      amount: (item.qty || 0) * (item.rate || 0),
    }));
    
    if (JSON.stringify(updatedItems) !== JSON.stringify(formik.values.items)) {
      formik.setFieldValue('items', updatedItems);
    }
  }, [formik.values.items]);

  const handleAddItem = () => {
    formik.setFieldValue('items', [
      ...formik.values.items,
      { id: formik.values.items.length + 1, description: '', qty: 0, rate: 0, amount: 0 },
    ]);
  };

  const handleRemoveItem = (id) => {
    if (formik.values.items.length > 1) {
      formik.setFieldValue('items', formik.values.items.filter((item) => item.id !== id));
    }
  };

  const handleItemChange = (id, field, value) => {
    const updatedItems = formik.values.items.map((item) => {
      if (item.id === id) {
        const updatedItem = { ...item, [field]: value };
        
        if (field === 'description' && value && itemRates[value]) {
          updatedItem.rate = itemRates[value];
          updatedItem.amount = (updatedItem.qty || 0) * itemRates[value];
        }
        
        if (field === 'qty' || field === 'rate') {
          updatedItem.amount = (updatedItem.qty || 0) * (updatedItem.rate || 0);
        }
        
        return updatedItem;
      }
      return item;
    });
    
    formik.setFieldValue('items', updatedItems);
  };

  // Calculations
  const subtotal = formik.values.items.reduce((sum, item) => sum + item.amount, 0);
  const taxRate = 8.5;
  const taxAmount = (subtotal * (taxRate / 100));
  const discountAmount = formik.values.discount;
  const total = subtotal + taxAmount - discountAmount;

 
 // Preview Quote Handler with validation
const handlePreviewQuote = async () => {
  const errors = await formik.validateForm();
  formik.setTouched({
    quoteNumber: true,
    issueDate: true,
    expiryDate: true,
    selectedClient: true,
    clientName: true,
    clientAddress: true,
    clientEmail: true,
    items: formik.values.items.map(() => ({ description: true, qty: true, rate: true })),
  });

  if (Object.keys(errors).length === 0) {
    // Filter only items that have both description AND qty > 0
    const validItems = formik.values.items.filter(
      item => item.description && item.description !== '' && item.qty > 0
    );

    const previewQuoteData = {
      id: formik.values.quoteNumber,
      status: formik.values.quoteStatus,
      type: "Quote",
      amount: `$${total.toFixed(2)}`,
      quoteNumber: formik.values.quoteNumber,
      issueDate: formik.values.issueDate,
      dueDate: formik.values.expiryDate,
      buyerName: formik.values.clientName,
      buyerAddress: formik.values.clientAddress,
      buyerEmail: formik.values.clientEmail,
      buyerPhone: formik.values.clientPhone,
      paymentTerms: formik.values.paymentTerms,
      quoteStatus: formik.values.quoteStatus,
      reference: formik.values.referenceId,
      // Only show added items with description and qty > 0
      items: validItems.map(item => ({
        description: item.description,
        subDescription: "Product details",
        qty: item.qty,
        rate: item.rate,
        amount: item.amount
      })),
      // Pass actual calculated values
      subtotal: subtotal,
      taxRate: taxRate,
      taxAmount: taxAmount,
      discount: formik.values.discount,
      total: total,
      // Pass actual notes and terms from form
      notes: formik.values.notes,
      terms: formik.values.terms,
    };
    
    setPreviewData(previewQuoteData);
    setPreviewDialogOpen(true);
  } else {
    console.log('Validation errors:', errors);
  }
};


  const handleClosePreview = () => {
    setPreviewDialogOpen(false);
    setPreviewData(null);
  };

const handleSaveAsDraft = () => {
  setDraftDialogOpen(true);
};


  const handleCloseDraftDialog = () => {
    setDraftDialogOpen(false);
  };

  const handleConfirmSaveDraft = () => {
    console.log('Saving quote as draft...', formik.values);
    setDraftDialogOpen(false);
    navigate('/billing');
  };

  const handleSendQuote = async () => {
    const errors = await formik.validateForm();
    
    if (Object.keys(errors).length === 0) {
      setSendDialogOpen(true);
    } else {
      formik.setTouched({
        quoteNumber: true,
        issueDate: true,
        expiryDate: true,
        selectedClient: true,
        clientName: true,
        clientAddress: true,
        clientEmail: true,
        items: formik.values.items.map(() => ({ description: true, qty: true, rate: true })),
      });
      console.log('Validation errors:', errors);
    }
  };

  const handleCloseSendDialog = () => {
    setSendDialogOpen(false);
  };

  const handleConfirmSend = () => {
    console.log('Sending quote...', formik.values);
    setSendDialogOpen(false);
    navigate('/billing');
  };

  // UI Text
  const pageTitle = editMode ? "Edit Quote" : "New Quote";
  const headerTitle = editMode ? "Edit Quote" : "New Quote";
  const saveButtonText = editMode ? "Update & Send Quote" : "Save & Send Quote";

    const menuProps = {
  disableScrollLock: true,
  PaperProps: {
    sx: {
      maxHeight: 300,
      '&::-webkit-scrollbar': {
        display: 'none',
      },
      '-ms-overflow-style': 'none',
      'scrollbar-width': 'none',
    },
  },
};

// Check if the last item in the list is valid (has description and qty > 0)
const isLastItemValid = () => {
  if (formik.values.items.length === 0) return true;
  
  const lastItem = formik.values.items[formik.values.items.length - 1];
  return lastItem.description && lastItem.description !== '' && lastItem.qty > 0;
};


  return (
    <>
      <Grid container spacing={{ xs: 1, md: 2 }} columns={{ xs: 12, sm: 12, md: 12, xl: 12 }} sx={{ width: "100%", maxWidth: "100vw", m: 0, p: { xs: 0, sm: 1 }, justifyContent: "center", flexGrow: 1 }}>
        <Grid item size={{ xs: 12, sm: 12, md: 12, xl: 12 }} sx={{ border: "1px solid #E4E4E7", backgroundColor: "#fff", px: { xs: 1, sm: 4, md: 6, xl: 3 }, py: { xs: 0, sm: 3 }, boxShadow: { xs: "none", sm: "0 2px 14px rgba(116,185,255,.08)" } }}>
          
          {/* Breadcrumb */}
          <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
            <HomeIcon style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8,cursor:"pointer" }} onClick={() => navigate("/admin")}/>
            <TitleBreadcrumb breadcrumbsData={[{ type: "link", label: "Service Desk", to: "/admin" }, { type: "link", label: "Billing", to: "/billing" }, { type: "text", label: pageTitle, to: "" }]} />
          </Box>

          {/* Main Header */}
          <Box sx={{ mt: 2, pt: 1, pb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 2 }}>
            <Typography sx={{ fontFamily: "Open Sans", fontSize: "24px", fontWeight: "700", color: "#111827" }}>{pageTitle}</Typography>
          </Box>

          {/* Sub Header with Quote Number and Action Buttons */}
          <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 2, pb: 3, pt: 2, borderTop: "1px solid #E5E7EB", borderBottom: "1px solid #E5E7EB", mb: 3 }}>
            <Typography sx={{ fontFamily: "Open Sans", fontSize: "24px", fontWeight: "600", color: "#111827" }}>
              {headerTitle} <span style={{ color: "#111827", fontWeight: 400 }}>#{formik.values.quoteNumber}</span>
            </Typography>

            <Box sx={{ display: "flex", gap: 2, pt: 2 }}>
              <Button onClick={handleSaveAsDraft} startIcon={<DocumentTextIcon style={{ width: 18, height: 18 }} />} sx={{ textTransform: "none", fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#374151", bgcolor: "#FFFFFF", border: "1px solid #D1D5DB", px: 2.5, py: 0.75, borderRadius: "6px", boxShadow: "0 1px 2px rgba(0, 0, 0, 0.05)", "&:hover": { bgcolor: "#F9FAFB", borderColor: "#9CA3AF", boxShadow: "0 1px 3px rgba(0, 0, 0, 0.1)" } }}>
                Save as Draft
              </Button>
              <Button onClick={handlePreviewQuote} startIcon={<EyeIcon style={{ width: 18, height: 18 }} />} sx={{ textTransform: "none", fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", bgcolor: "#FFFFFF", color: "#374151", border: "1px solid #D1D5DB", px: 2.5, py: 0.75, borderRadius: "6px", boxShadow: "0 1px 2px rgba(0, 0, 0, 0.05)", "&:hover": { bgcolor: "#F9FAFB", borderColor: "#9CA3AF", boxShadow: "0 1px 3px rgba(0, 0, 0, 0.1)" } }}>
                Preview Quote
              </Button>
            </Box>
          </Box>

          {/* Main Content Area */}
          <Box sx={{ mt: 3, mb: 2, width: "100%", border: "1px solid #E5E7EB", p: 2 }}>
            <Grid container spacing={2}>
              <Grid container size={{ xs: 12, sm: 12, md: 12 }} sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                
                {/* Quote Information Section - First Row */}
                <Grid container spacing={2}>
                  <Grid size={{ xs: 12, sm: 12, md: 4, xl: 4 }}>
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 500, color: "#111827", mb: 1 }}>Quote Number</Typography>
                    <TextField 
                      fullWidth 
                      name="quoteNumber"
                      value={formik.values.quoteNumber} 
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      error={formik.touched.quoteNumber && Boolean(formik.errors.quoteNumber)}
                      helperText={formik.touched.quoteNumber && formik.errors.quoteNumber}
                      slotProps={{ input: { readOnly: true } }} 
                      sx={{ '& .MuiOutlinedInput-root': { fontFamily: "Open Sans", fontSize: "14px", borderRadius: "6px", bgcolor: "#fff", '& fieldset': { borderColor: "#E5E7EB" }, '&:hover fieldset': { borderColor: "#D1D5DB" }, '&.Mui-focused fieldset': { borderColor: "#E5E7EB" } }, '& .MuiOutlinedInput-input': { py: 1.25, color: "#000", fontWeight: 500, cursor: "not-allowed" } }} 
                    />
                  </Grid>

                  <Grid size={{ xs: 12, sm: 12, md: 4, xl: 4 }}>
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 500, color: "#111827", mb: 1 }}>Issue Date</Typography>
                    <TextField 
                      fullWidth 
                      type="date" 
                      name="issueDate"
                      value={formik.values.issueDate} 
                      onChange={(e) => { 
                        const newIssueDate = e.target.value; 
                        formik.setFieldValue('issueDate', newIssueDate);
                        if (formik.values.expiryDate && formik.values.expiryDate < newIssueDate) {
                          formik.setFieldValue('expiryDate', '');
                        }
                      }}
                      onBlur={formik.handleBlur}
                      error={formik.touched.issueDate && Boolean(formik.errors.issueDate)}
                      helperText={formik.touched.issueDate && formik.errors.issueDate}
                      placeholder="mm/dd/yyyy" 
                      sx={{ '& .MuiOutlinedInput-root': { fontFamily: "Open Sans", fontSize: "14px", borderRadius: "6px", '& fieldset': { borderColor: "#E5E7EB" }, '&:hover fieldset': { borderColor: "#D1D5DB" }, '&.Mui-focused fieldset': { borderColor: "#409BFF" } }, '& .MuiOutlinedInput-input': { py: 1.25, color: "#111827" } }} 
                    />
                  </Grid>

                  <Grid size={{ xs: 12, sm: 12, md: 4, xl: 4 }}>
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 500, color: "#111827", mb: 1 }}>Expiry Date</Typography>
                    <TextField 
                      fullWidth 
                      type="date" 
                      name="expiryDate"
                      value={formik.values.expiryDate} 
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      error={formik.touched.expiryDate && Boolean(formik.errors.expiryDate)}
                      helperText={formik.touched.expiryDate && formik.errors.expiryDate}
                      placeholder="mm/dd/yyyy" 
                      slotProps={{ input: { inputProps: { min: formik.values.issueDate || undefined } } }} 
                      disabled={!formik.values.issueDate} 
                      sx={{ '& .MuiOutlinedInput-root': { fontFamily: "Open Sans", fontSize: "14px", borderRadius: "6px", bgcolor: "#fff", '& fieldset': { borderColor: "#E5E7EB" }, '&:hover fieldset': { borderColor: "#D1D5DB" }, '&.Mui-focused fieldset': { borderColor: "#409BFF" }, '&.Mui-disabled': { bgcolor: "#F9FAFB" } }, '& .MuiOutlinedInput-input': { py: 1.25, color: "#111827" } }} 
                    />
                  </Grid>
                </Grid>

                {/* Company Information Section - Second Row */}
                <Grid container spacing={2} sx={{ mt: 1 }}>
                  <Grid size={{ xs: 12, sm: 12, md: 6, xl: 6 }}>
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 500, color: "#111827", mb: 2 }}>From</Typography>
                    <Box sx={{ bgcolor: "#F9FAFB", border: "1px solid #E5E7EB", borderRadius: "6px", p: 2.5 }}>
                      <Typography sx={{ fontFamily: "Open Sans", fontSize: "15px", fontWeight: 600, color: "#111827", mb: 0.5 }}>PSA Solutions</Typography>
                      <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 400, color: "#6B7280", lineHeight: 1.5 }}>123 Business Avenue</Typography>
                      <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 400, color: "#6B7280", lineHeight: 1.5 }}>New York, NY</Typography>
                      <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 400, color: "#6B7280", lineHeight: 1.5 }}>contact@techcorp.com</Typography>
                      <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 400, color: "#6B7280", lineHeight: 1.5 }}>+1 (555) 123-4567</Typography>
                    </Box>
                  </Grid>

                  <Grid size={{ xs: 12, sm: 12, md: 6, xl: 6 }}>
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 500, color: "#111827", mb: 2 }}>Bill To</Typography>
                    <FormControl 
                      fullWidth 
                      sx={{ mb: 2 }}
                      error={formik.touched.selectedClient && Boolean(formik.errors.selectedClient)}
                    >
                      <Select 
                      MenuProps={menuProps}
                        name="selectedClient"
                        value={formik.values.selectedClient} 
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        displayEmpty 
                        sx={{ fontFamily: "Open Sans", fontSize: "14px", borderRadius: "6px", '& .MuiOutlinedInput-notchedOutline': { borderColor: "#E5E7EB" }, '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: "#D1D5DB" }, '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: "#409BFF" }, '& .MuiSelect-select': { py: 1.25, color: formik.values.selectedClient ? "#111827" : "#9CA3AF", fontWeight: 500 } }}
                      >
                        <MenuItem value="" sx={{ fontFamily: "Open Sans", fontSize: "14px", color: "#9CA3AF" }}>Company Name</MenuItem>
                        <MenuItem value="client1" sx={{ fontFamily: "Open Sans", fontSize: "14px" }}>Acme Corporation</MenuItem>
                        <MenuItem value="client2" sx={{ fontFamily: "Open Sans", fontSize: "14px" }}>TechStart Inc</MenuItem>
                        <MenuItem value="client3" sx={{ fontFamily: "Open Sans", fontSize: "14px" }}>Global Solutions</MenuItem>
                      </Select>
                      {formik.touched.selectedClient && formik.errors.selectedClient && (
                        <Typography sx={{ color: '#d32f2f', fontSize: '0.75rem', mt: 0.5, ml: 2, fontFamily: 'Open Sans' }}>
                          {formik.errors.selectedClient}
                        </Typography>
                      )}
                    </FormControl>
                    <TextField 
                      fullWidth 
                     
                      placeholder="Address" 
                      name="clientAddress"
                      InputProps={{
    readOnly: true,
  }}
                      value={formik.values.clientAddress} 
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      error={formik.touched.clientAddress && Boolean(formik.errors.clientAddress)}
                      helperText={formik.touched.clientAddress && formik.errors.clientAddress}
                      sx={{ mb: 2, '& .MuiOutlinedInput-root': { fontFamily: "Open Sans", fontSize: "14px", borderRadius: "6px", '& fieldset': { borderColor: "#E5E7EB" }, '&:hover fieldset': { borderColor: "#D1D5DB" }, '&.Mui-focused fieldset': { borderColor: "#409BFF" } }, '& .MuiOutlinedInput-input': { py: 1.25, color: "#111827", '&::placeholder': { color: "#9CA3AF", opacity: 1 } } }} 
                    />
                    <TextField 
                      fullWidth 
                      placeholder="Email" 
                      type="email" 
                      name="clientEmail"
                       InputProps={{
    readOnly: true,
  }}
                      value={formik.values.clientEmail} 
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      error={formik.touched.clientEmail && Boolean(formik.errors.clientEmail)}
                      helperText={formik.touched.clientEmail && formik.errors.clientEmail}
                      sx={{ mb: 2, '& .MuiOutlinedInput-root': { fontFamily: "Open Sans", fontSize: "14px", borderRadius: "6px", '& fieldset': { borderColor: "#E5E7EB" }, '&:hover fieldset': { borderColor: "#D1D5DB" }, '&.Mui-focused fieldset': { borderColor: "#409BFF" } }, '& .MuiOutlinedInput-input': { py: 1.25, color: "#111827", '&::placeholder': { color: "#9CA3AF", opacity: 1 } } }} 
                    />
                    <TextField 
                      fullWidth 
                       InputProps={{
    readOnly: true,
  }}
                      placeholder="Phone" 
                      name="clientPhone"
                      value={formik.values.clientPhone} 
                      onChange={formik.handleChange}
                      sx={{ '& .MuiOutlinedInput-root': { fontFamily: "Open Sans", fontSize: "14px", borderRadius: "6px", '& fieldset': { borderColor: "#E5E7EB" }, '&:hover fieldset': { borderColor: "#D1D5DB" }, '&.Mui-focused fieldset': { borderColor: "#409BFF" } }, '& .MuiOutlinedInput-input': { py: 1.25, color: "#111827", '&::placeholder': { color: "#9CA3AF", opacity: 1 } } }} 
                    />
                  </Grid>
                </Grid>

                {/* Payment Terms, Quote Status, Reference ID - Third Row */}
                <Grid container spacing={2} sx={{ mt: 1 }}>
                  <Grid size={{ xs: 12, sm: 12, md: 4, xl: 4 }}>
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 500, color: "#111827", mb: 1 }}>Payment Terms</Typography>
                    <FormControl fullWidth>
                      <Select 
                      MenuProps={menuProps}
                        name="paymentTerms"
                        value={formik.values.paymentTerms} 
                        onChange={formik.handleChange}
                        sx={{ fontFamily: "Open Sans", fontSize: "14px", borderRadius: "6px", '& .MuiOutlinedInput-notchedOutline': { borderColor: "#E5E7EB" }, '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: "#D1D5DB" }, '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: "#409BFF" }, '& .MuiSelect-select': { py: 1.25, color: "#111827", fontWeight: 500 } }}
                      >
                        <MenuItem value="Net 30">Net 30</MenuItem>
                        <MenuItem value="Net 60">Net 60</MenuItem>
                        <MenuItem value="Due on Receipt">Due on Receipt</MenuItem>
                      </Select>
                    </FormControl>
                  </Grid>

                  <Grid size={{ xs: 12, sm: 12, md: 4, xl: 4 }}>
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 500, color: "#111827", mb: 1 }}>Quote Status</Typography>
                    <FormControl fullWidth>
                      <Select 
                      MenuProps={menuProps}
                        name="quoteStatus"
                        value={formik.values.quoteStatus} 
                        onChange={formik.handleChange}
                        sx={{ fontFamily: "Open Sans", fontSize: "14px", borderRadius: "6px", '& .MuiOutlinedInput-notchedOutline': { borderColor: "#E5E7EB" }, '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: "#D1D5DB" }, '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: "#409BFF" }, '& .MuiSelect-select': { py: 1.25, color: "#111827", fontWeight: 500 } }}
                      >
                        <MenuItem value="Draft">Draft</MenuItem>
                        <MenuItem value="Sent">Sent</MenuItem>
                        <MenuItem value="Accepted">Accepted</MenuItem>
                        <MenuItem value="Rejected">Rejected</MenuItem>
                      </Select>
                    </FormControl>
                  </Grid>

                  <Grid size={{ xs: 12, sm: 12, md: 4, xl: 4 }}>
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 500, color: "#111827", mb: 1 }}>Reference ID</Typography>
                    <TextField 
                      fullWidth 
                      placeholder="Optional" 
                      name="referenceId"
                      value={formik.values.referenceId} 
                      onChange={formik.handleChange}
                      sx={{ '& .MuiOutlinedInput-root': { fontFamily: "Open Sans", fontSize: "14px", borderRadius: "6px", '& fieldset': { borderColor: "#E5E7EB" }, '&:hover fieldset': { borderColor: "#D1D5DB" }, '&.Mui-focused fieldset': { borderColor: "#409BFF" } }, '& .MuiOutlinedInput-input': { py: 1.25, color: "#111827", '&::placeholder': { color: "#9CA3AF", opacity: 1 } } }} 
                    />
                  </Grid>
                </Grid>

                {/* Items List Section */}
                <Box sx={{ mt: 3 }}>
                  <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 3 }}>
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: "18px", fontWeight: 600, color: "#111827" }}>Items</Typography>
                   <Button 
  onClick={handleAddItem} 
  disabled={!isLastItemValid()}
  startIcon={<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 5v14M5 12h14" /></svg>} 
  sx={{ 
    textTransform: "none", 
    fontSize: "14px", 
    fontWeight: 600, 
    fontFamily: "Open Sans", 
    color: isLastItemValid() ? "#409BFF" : "#9CA3AF", 
    bgcolor: isLastItemValid() ? "#EFF6FF" : "#F3F4F6", 
    border: "1px solid",
    borderColor: isLastItemValid() ? "#BFDBFE" : "#D1D5DB",
    px: 2, 
    py: 0.75,
    cursor: isLastItemValid() ? "pointer" : "not-allowed",
    "&:hover": { 
      bgcolor: isLastItemValid() ? "#DBEAFE" : "#F3F4F6"
    } 
  }}
>
  Add Item
</Button>

                  </Box>

                  <Grid container spacing={2} sx={{ mb: 2 }}>
                    <Grid size={{ xs: 12, sm: 12, md: 5, xl: 5 }}><Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 600, color: "#6B7280" }}>Description</Typography></Grid>
                    <Grid size={{ xs: 12, sm: 12, md: 2, xl: 2 }}><Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 600, color: "#6B7280", textAlign: "center" }}>Qty</Typography></Grid>
                    <Grid size={{ xs: 12, sm: 12, md: 2, xl: 2 }}><Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 600, color: "#6B7280", textAlign: "center" }}>Rate</Typography></Grid>
                    <Grid size={{ xs: 12, sm: 12, md: 2, xl: 2 }}><Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 600, color: "#6B7280", textAlign: "right" }}>Amount</Typography></Grid>
                    <Grid size={{ xs: 12, sm: 12, md: 1, xl: 1 }}></Grid>
                  </Grid>

                  {formik.values.items.map((item, index) => (
                    <Grid container spacing={2} key={item.id} sx={{ mb: 2 }}>
                      <Grid size={{ xs: 12, sm: 12, md: 5, xl: 5 }}>
                        <FormControl 
                          fullWidth
                          error={formik.touched.items?.[index]?.description && Boolean(formik.errors.items?.[index]?.description)}
                        >
                          <Select 
                            MenuProps={menuProps}
                            value={item.description} 
                            onChange={(e) => handleItemChange(item.id, 'description', e.target.value)}
                            onBlur={formik.handleBlur}
                            name={`items[${index}].description`}
                            displayEmpty 
                            sx={{ fontFamily: "Open Sans", fontSize: "14px", borderRadius: "6px", '& .MuiOutlinedInput-notchedOutline': { borderColor: "#E5E7EB" }, '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: "#D1D5DB" }, '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: "#409BFF" }, '& .MuiSelect-select': { py: 1.25, color: item.description ? "#111827" : "#9CA3AF", fontWeight: 500 } }}
                          >
                            <MenuItem value="" disabled>Select Description</MenuItem>
                            {itemDescriptions.map((desc) => (<MenuItem key={desc} value={desc}>{desc}</MenuItem>))}
                          </Select>
                          {formik.touched.items?.[index]?.description && formik.errors.items?.[index]?.description && (
                            <Typography sx={{ color: '#d32f2f', fontSize: '0.75rem', mt: 0.5, ml: 2, fontFamily: 'Open Sans' }}>
                              {formik.errors.items[index].description}
                            </Typography>
                          )}
                        </FormControl>
                      </Grid>
                     <Grid size={{ xs: 12, sm: 12, md: 2, xl: 2 }}>
  <TextField 
    fullWidth 
    type="number" 
    value={item.qty === 0 ? '' : item.qty} 
    onChange={(e) => {
      const value = parseFloat(e.target.value) || 0;
      // Prevent negative values
      if (value < 0) return;
      handleItemChange(item.id, 'qty', value);
    }}
    onBlur={formik.handleBlur}
    name={`items[${index}].qty`}
    error={
      formik.touched.items?.[index]?.qty && 
      Boolean(formik.errors.items?.[index]?.qty)
    }
    helperText={
      formik.touched.items?.[index]?.qty && 
      formik.errors.items?.[index]?.qty
    }
    onFocus={(e) => e.target.select()} 
    placeholder="0" 
    inputProps={{ min: 0 }} // Also add this for HTML5 validation
    sx={{ 
      '& .MuiOutlinedInput-root': { 
        fontFamily: "Open Sans", 
        fontSize: "14px", 
        borderRadius: "6px", 
        '& fieldset': { borderColor: "#E5E7EB" }, 
        '&:hover fieldset': { borderColor: "#D1D5DB" }, 
        '&.Mui-focused fieldset': { borderColor: "#409BFF" } 
      }, 
      '& .MuiOutlinedInput-input': { 
        py: 1.25, 
        textAlign: "center", 
        color: "#111827", 
        fontWeight: 500, 
        '&::placeholder': { color: "#9CA3AF", opacity: 1 } 
      } 
    }} 
  />
</Grid>

                     <Grid size={{ xs: 12, sm: 12, md: 2, xl: 2 }}>
  <TextField 
    fullWidth 
    type="text" 
    value={item.rate === 0 ? '' : `$${parseFloat(item.rate).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`} 
    onChange={(e) => { 
      const value = e.target.value.replace(/[$,]/g, ''); 
      if (!/^\d*\.?\d*$/.test(value)) return; 
      const numValue = value === '' ? 0 : parseFloat(value) || 0;
      handleItemChange(item.id, 'rate', numValue); 
    }} 
    onFocus={(e) => { 
      const rawValue = e.target.value.replace(/[$,]/g, ''); 
      e.target.value = rawValue; 
      e.target.select(); 
    }} 
    onBlur={(e) => { 
      // Don't need to do anything here - onChange already handles it
      formik.handleBlur(e); 
    }} 
    name={`items[${index}].rate`}
    placeholder="$0.00" 
    inputProps={{ inputMode: 'decimal' }} 
    sx={{ 
      '& .MuiOutlinedInput-root': { 
        fontFamily: "Open Sans", 
        fontSize: "14px", 
        borderRadius: "6px", 
        '& fieldset': { borderColor: "#E5E7EB" }, 
        '&:hover fieldset': { borderColor: "#D1D5DB" }, 
        '&.Mui-focused fieldset': { borderColor: "#409BFF" } 
      }, 
      '& .MuiOutlinedInput-input': { 
        py: 1.25, 
        textAlign: "center", 
        color: "#111827", 
        fontWeight: 500, 
        '&::placeholder': { color: "#9CA3AF", opacity: 1 } 
      } 
    }} 
  />
</Grid>

                      <Grid size={{ xs: 12, sm: 12, md: 2, xl: 2 }}>
                        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "flex-end", height: "100%", py: 1.25 }}>
                          <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 600, color: "#111827" }}>${item.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</Typography>
                        </Box>
                      </Grid>
                      <Grid size={{ xs: 12, sm: 12, md: 1, xl: 1 }}>
                        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100%" }}>
                          <IconButton onClick={() => handleRemoveItem(item.id)} disabled={formik.values.items.length === 1} sx={{ color: formik.values.items.length === 1 ? "#D1D5DB" : "#EF4444", "&:hover": { bgcolor: formik.values.items.length === 1 ? "transparent" : "#FEE2E2" } }}>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" /></svg>
                          </IconButton>
                        </Box>
                      </Grid>
                    </Grid>
                  ))}

                  <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 4 }}>
                    <Box sx={{ width: "350px" }}>
                      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
                        <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 400, color: "#6B7280" }}>Subtotal:</Typography>
                        <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 600, color: "#111827" }}>${subtotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</Typography>
                      </Box>
                      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
                        <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 400, color: "#6B7280" }}>Tax ({taxRate}%):</Typography>
                        <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 600, color: "#111827" }}>${taxAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</Typography>
                      </Box>
                     <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3, gap: 2 }}>
  <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 400, color: "#6B7280" }}>
    Discount
  </Typography>
  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
   <TextField
  type="number"
  name="discount"
  value={formik.values.discount > 0 ? formik.values.discount : ''}
  onChange={(e) => {
    const value = parseFloat(e.target.value) || 0;
    // Prevent negative values
    if (value >= 0) {
      formik.setFieldValue('discount', value);
    }
  }}
  onFocus={(e) => e.target.select()}
  placeholder="0"
  inputProps={{
    min: 0, // HTML5 validation to prevent negative
    // step: "0.01"
  }}
  sx={{
    width: '70px',
    '& .MuiOutlinedInput-root': {
      fontFamily: "Open Sans",
      fontSize: "13px",
      borderRadius: "4px",
      '& fieldset': {
        borderColor: "#E5E7EB",
      },
      '&:hover fieldset': {
        borderColor: "#D1D5DB",
      },
      '&.Mui-focused fieldset': {
        borderColor: "#409BFF",
      },
    },
    '& .MuiOutlinedInput-input': {
      py: 0.75,
      px: 1,
      textAlign: 'center',
      color: "#111827",
      fontWeight: 500,
      '&::placeholder': {
        color: "#9CA3AF",
        opacity: 1,
      },
    },
  }}
/>

    <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 600, color: "#111827" }}>
      ${discountAmount.toFixed(2)}
    </Typography>
  </Box>
</Box>

                      <Box sx={{ borderTop: "2px solid #E5E7EB", mb: 3 }} />
                      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                        <Typography sx={{ fontFamily: "Open Sans", fontSize: "16px", fontWeight: 700, color: "#111827" }}>Total:</Typography>
                        <Typography sx={{ fontFamily: "Open Sans", fontSize: "20px", fontWeight: 700, color: "#111827" }}>${total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</Typography>
                      </Box>
                    </Box>
                  </Box>
                </Box>

                <Box sx={{ mt: 4 }}>
                  <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 500, color: "#111827", mb: 1 }}>Additional Notes</Typography>
                  <TextField 
                    fullWidth 
                    multiline 
                    rows={3} 
                    placeholder="Enter message or details for the client..." 
                    name="notes"
                    value={formik.values.notes} 
                    onChange={formik.handleChange}
                    sx={{ '& .MuiOutlinedInput-root': { fontFamily: "Open Sans", fontSize: "14px", borderRadius: "6px", '& fieldset': { borderColor: "#E5E7EB" }, '&:hover fieldset': { borderColor: "#D1D5DB" }, '&.Mui-focused fieldset': { borderColor: "#409BFF" } }, '& .MuiOutlinedInput-input': { color: "#111827", '&::placeholder': { color: "#9CA3AF", opacity: 1 } } }} 
                  />
                </Box>

                <Box sx={{ mt: 3 }}>
                  <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 500, color: "#111827", mb: 1 }}>Terms & Conditions</Typography>
                  <TextField 
                    fullWidth 
                    multiline 
                    rows={3} 
                    placeholder="Add payment terms, validity, or other details..." 
                    name="terms"
                    value={formik.values.terms} 
                    onChange={formik.handleChange}
                    sx={{ '& .MuiOutlinedInput-root': { fontFamily: "Open Sans", fontSize: "14px", borderRadius: "6px", '& fieldset': { borderColor: "#E5E7EB" }, '&:hover fieldset': { borderColor: "#D1D5DB" }, '&.Mui-focused fieldset': { borderColor: "#409BFF" } }, '& .MuiOutlinedInput-input': { color: "#111827", '&::placeholder': { color: "#9CA3AF", opacity: 1 } } }} 
                  />
                </Box>

                <Box sx={{ position: "sticky", bottom: 0, left: 0, right: 0, bgcolor: "#FFFFFF", borderTop: "1px solid #E5E7EB", mt: 4, py: 3, px: 4, zIndex: 10, display: "flex", justifyContent: "flex-end", alignItems: "center", gap: 2 }}>
                  <Button onClick={() => navigate('/billing')} sx={{ textTransform: "none", fontSize: "15px", fontWeight: 600, fontFamily: "Open Sans", color: "#FFFFFF", bgcolor: "#EF4444", px: 4, py: 1.25, borderRadius: "6px", boxShadow: "none", "&:hover": { bgcolor: "#DC2626", boxShadow: "none" } }}>Cancel</Button>
                  <Button onClick={handleSendQuote} startIcon={<PaperAirplaneIcon style={{ width: 18, height: 18 }} />} sx={{ textTransform: "none", fontSize: "15px", fontWeight: 600, fontFamily: "Open Sans", bgcolor: "#409BFF", color: "#FFFFFF", px: 4, py: 1.25, borderRadius: "6px", boxShadow: "none", "&:hover": { bgcolor: "#2563EB", boxShadow: "none" } }}>{saveButtonText}</Button>
                </Box>
              </Grid>
            </Grid>
          </Box>
        </Grid>
      </Grid>

      {/* Save as Draft Dialog */}
      <Dialog disableScrollLock open={draftDialogOpen} onClose={handleCloseDraftDialog} maxWidth="sm" fullWidth PaperProps={{ sx: { borderRadius: "12px", boxShadow: "0 8px 32px rgba(0, 0, 0, 0.12)" } }}>
        <DialogTitle sx={{ fontFamily: "Open Sans", fontSize: "20px", fontWeight: 700, color: "#111827", pb: 2 }}>Save Quote as Draft?</DialogTitle>
        <DialogContent><Typography sx={{ fontFamily: "Open Sans", fontSize: "15px", fontWeight: 400, color: "#6B7280", lineHeight: 1.6 }}>This quote will be saved as a draft and can be edited later. You can find it in the drafts section of your billing dashboard.</Typography></DialogContent>
        <DialogActions sx={{ px: 3, pb: 3, pt: 2 }}>
          <Button onClick={handleCloseDraftDialog} sx={{ textTransform: "none", fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#6B7280", px: 3, py: 1, "&:hover": { bgcolor: "#F3F4F6" } }}>Cancel</Button>
          <Button onClick={handleConfirmSaveDraft} startIcon={<DocumentTextIcon style={{ width: 18, height: 18 }} />} sx={{ textTransform: "none", fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", bgcolor: "#409BFF", color: "#FFFFFF", px: 3, py: 1, "&:hover": { bgcolor: "#2563EB" } }}>Save as Draft</Button>
        </DialogActions>
      </Dialog>

      {/* Send Quote Dialog */}
      <Dialog disableScrollLock open={sendDialogOpen} onClose={handleCloseSendDialog} maxWidth="sm" fullWidth PaperProps={{ sx: { borderRadius: "12px", boxShadow: "0 8px 32px rgba(0, 0, 0, 0.12)" } }}>
        <DialogTitle sx={{ fontFamily: "Open Sans", fontSize: "20px", fontWeight: 700, color: "#111827", pb: 2 }}>{editMode ? "Update & Send Quote?" : "Save & Send Quote?"}</DialogTitle>
        <DialogContent><Typography sx={{ fontFamily: "Open Sans", fontSize: "15px", fontWeight: 400, color: "#6B7280", lineHeight: 1.6 }}>{editMode ? "This quote will be updated and sent to the client via email. They will receive a notification with the updated quote details." : "This quote will be saved and sent to the client via email. They will receive a notification with the quote details and can accept or reject it."}</Typography></DialogContent>
        <DialogActions sx={{ px: 3, pb: 3, pt: 2 }}>
          <Button onClick={handleCloseSendDialog} sx={{ textTransform: "none", fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#6B7280", px: 3, py: 1, "&:hover": { bgcolor: "#F3F4F6" } }}>Cancel</Button>
          <Button onClick={handleConfirmSend} startIcon={<PaperAirplaneIcon style={{ width: 18, height: 18 }} />} sx={{ textTransform: "none", fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", bgcolor: "#409BFF", color: "#FFFFFF", px: 3, py: 1, "&:hover": { bgcolor: "#2563EB" } }}>{saveButtonText}</Button>
        </DialogActions>
      </Dialog>

      {/* Preview Quote Dialog */}
     {previewData && (
  <QuoteViewDialog open={previewDialogOpen} onClose={handleClosePreview} quoteData={previewData} />
)}

    </>
  );
};

export default NewQuoteForm;
