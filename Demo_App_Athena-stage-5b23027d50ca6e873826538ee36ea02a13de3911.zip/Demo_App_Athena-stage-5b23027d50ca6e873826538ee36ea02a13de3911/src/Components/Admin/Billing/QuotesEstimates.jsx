import React, { useState } from "react";
import { Box, Typography, Button, Chip } from "@mui/material";
import { PlusIcon } from "@heroicons/react/24/solid";
import QuoteViewDialog from "./QuoteViewDialog";
import { Navigate, useNavigate } from "react-router-dom";

// Example quotes data - minimal for list view
const quotes = [
  {
    id: "QUO-288",
    type: "Desktop",
    amount: "$4,882.00",
    status: "Active",
  },
  {
    id: "QUO-280",
    type: "Laptops",
    amount: "$8,797.00",
    status: "Accepted",
  },
  {
    id: "QUO-234",
    type: "Services",
    amount: "$3,038.00",
    status: "Pending",
  },
  {
    id: "QUO-223",
    type: "Tablets",
    amount: "$3,856.00",
    status: "Active",
  },
  {
    id: "QUO-213",
    type: "Accessories",
    amount: "$1,302.00",
    status: "Rejected",
  },
];

// Full quote details database (simulate API response)
const fullQuoteDetails = {
  "QUO-288": {
    id: "QUO-288",
    quoteNumber: "QUO-288",
    type: "Desktop",
    amount: "$4,500.00",
    status: "Active",
    issueDate: "2025-10-15",
    expiryDate: "2025-12-15",
    buyerName: "Acme Corporation",
    buyerAddress: "456 Client Street, Los Angeles, CA 90210",
    buyerEmail: "billing@acmecorp.com",
    buyerPhone: "+1 (555) 987-6543",
    paymentTerms: "Net 30",
    reference: "REF-001",
    items: [
      {
        description: "RAM",
        subDescription: "High-performance desktop with warranty",
        qty: 5,
        rate: 800.00,
        amount: 4000.00,
      },
      {
        description: "Keyboard",
        subDescription: "Professional installation service",
        qty: 1,
        rate: 500.00,
        amount: 500.00,
      },
    ],
    subtotal: 4500.00,
    taxRate: 8.5,
    taxAmount: 382.50,
    discount: 0,
    total: 4882.50,
    notes: "Thank you for your business! We appreciate your prompt payment.",
    terms: "Payment is due within 30 days. Late payments may incur a 1.5% monthly service charge.",
  },
  "QUO-280": {
    id: "QUO-280",
    quoteNumber: "QUO-280",
    type: "Laptops",
    amount: "$8,200.00",
    status: "Accepted",
    issueDate: "2025-10-20",
    expiryDate: "2025-12-20",
    buyerName: "TechStart Inc",
    buyerAddress: "789 Innovation Drive, San Francisco, CA 94105",
    buyerEmail: "sarah@techstart.com",
    buyerPhone: "+1 (555) 234-5678",
    paymentTerms: "Net 30",
    reference: "REF-002",
    items: [
      {
        description: "Motherboard",
        subDescription: "Business-class with extended warranty",
        qty: 10,
        rate: 800.00,
        amount: 8000.00,
      },
      {
        description: "Monitor",
        subDescription: "Microsoft Office suite licenses",
        qty: 10,
        rate: 20.00,
        amount: 200.00,
      },
    ],
    subtotal: 8200.00,
    taxRate: 8.5,
    taxAmount: 697.00,
    discount: 100.00,
    total: 8797.00,
    notes: "Thank you for accepting this quote! We will begin work shortly.",
    terms: "Payment is due within 30 days of delivery. Bulk discount applied.",
  },
  "QUO-234": {
    id: "QUO-234",
    quoteNumber: "QUO-234",
    type: "Services",
    amount: "$2,800.00",
    status: "Pending",
    issueDate: "2025-10-25",
    expiryDate: "2025-12-25",
    buyerName: "Global Solutions",
    buyerAddress: "321 Enterprise Blvd, Boston, MA 02101",
    buyerEmail: "mike@global.com",
    buyerPhone: "+1 (555) 876-5432",
    paymentTerms: "Net 60",
    reference: "REF-003",
    items: [
      {
        description: "RAM",
        subDescription: "IT consulting and system assessment",
        qty: 20,
        rate: 120.00,
        amount: 2400.00,
      },
      {
        description: "Webcam",
        subDescription: "3 months premium support",
        qty: 1,
        rate: 400.00,
        amount: 400.00,
      },
    ],
    subtotal: 2800.00,
    taxRate: 8.5,
    taxAmount: 238.00,
    discount: 0,
    total: 3038.00,
    notes: "This quote is awaiting your approval. Please review and let us know if you have any questions.",
    terms: "Quote is valid for 60 days from issue date. Please contact us if you need any modifications.",
  },
  "QUO-223": {
    id: "QUO-223",
    quoteNumber: "QUO-223",
    type: "Tablets",
    amount: "$3,600.00",
    status: "Active",
    issueDate: "2025-10-18",
    expiryDate: "2025-12-18",
    buyerName: "Modern Retail Co",
    buyerAddress: "555 Commerce St, Austin, TX 78701",
    buyerEmail: "orders@modernretail.com",
    buyerPhone: "+1 (555) 445-6677",
    paymentTerms: "Net 30",
    reference: "REF-004",
    items: [
      {
        description: "Monitor",
        subDescription: "iPad Air with protective case",
        qty: 12,
        rate: 300.00,
        amount: 3600.00,
      },
    ],
    subtotal: 3600.00,
    taxRate: 8.5,
    taxAmount: 306.00,
    discount: 50.00,
    total: 3856.00,
    notes: "Bulk order discount applied. Delivery within 2 weeks.",
    terms: "Payment is due within 30 days. Free shipping on orders over $3000.",
  },
  "QUO-213": {
    id: "QUO-213",
    quoteNumber: "QUO-213",
    type: "Accessories",
    amount: "$1,200.00",
    status: "Rejected",
    issueDate: "2025-10-10",
    expiryDate: "2025-11-10",
    buyerName: "Small Business LLC",
    buyerAddress: "999 Main Street, Seattle, WA 98101",
    buyerEmail: "admin@smallbiz.com",
    buyerPhone: "+1 (555) 123-9999",
    paymentTerms: "Net 30",
    reference: "REF-005",
    items: [
      {
        description: "Headphones",
        subDescription: "Wireless keyboard and mouse combo",
        qty: 20,
        rate: 45.00,
        amount: 900.00,
      },
      {
        description: "Webcam",
        subDescription: "HD webcam for video conferencing",
        qty: 10,
        rate: 30.00,
        amount: 300.00,
      },
    ],
    subtotal: 1200.00,
    taxRate: 8.5,
    taxAmount: 102.00,
    discount: 0,
    total: 1302.00,
    notes: "This quote has been rejected. Please contact us if you'd like to discuss alternative options.",
    terms: "This quote is no longer active. Contact us for a revised quote.",
  },
};

// Status chip color config
const statusMap = {
  Active: { bg: "#DBEAFE", color: "#1E40AF" },
  Accepted: { bg: "#DCFCE7", color: "#166534" },
  Pending: { bg: "#FFEDD5", color: "#9A3412" },
  Rejected: { bg: "#FEE2E2", color: "#991B1B" },
};

const QuotesEstimates = () => {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedQuote, setSelectedQuote] = useState(null);
  const navigate = useNavigate();

  const handleQuoteClick = (quote) => {
    // Fetch full quote details using the quote ID
    const fullDetails = fullQuoteDetails[quote.id];
    if (fullDetails) {
      setSelectedQuote(fullDetails);
      setDialogOpen(true);
    } else {
      console.error(`No full details found for quote ${quote.id}`);
    }
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setSelectedQuote(null);
  };

  return (
    <>
      <Box
        sx={{
          border: "1px solid #E5E7EB",
          borderRadius: "12px",
          height: 449,
          boxSizing: "border-box",
          background: "#fff",
          pb: 2,
          px: 0.5,
          pt: 1.8,
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
        }}
      >
        {/* Header */}
        <Typography
          sx={{
            fontFamily: "Open Sans",
            fontSize: 18,
            fontWeight: 700,
            color: "#1F2937",
            px: 3,
            pb: 1.5,
          }}
        >
          Quotes & Estimates
        </Typography>
        {/* Divider */}
        <Box sx={{ height: 1.5, bgcolor: "#F2F3F8", mb: 0.6 }} />

        {/* Card List */}
        <Box
          sx={{
            flex: 1,
            overflowY: "auto",
            px: 2.2,
            pt: 0.8,
            pb: 2,
            display: "flex",
            flexDirection: "column",
            gap: 2,
            minHeight: 0,
          }}
        >
          {quotes.map((q, idx) => (
            <Box
              key={q.id}
              onClick={() => handleQuoteClick(q)}
              sx={{
                border: "1.5px solid #E5E7EB",
                borderRadius: "8px",
                p: 2,
                bgcolor: "#fff",
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                mb: 0,
                boxSizing: "border-box",
                gap: 2,
                boxShadow: "none",
                cursor: "pointer",
                transition: "all 0.2s ease",
                "&:hover": {
                  bgcolor: "#F9FAFB",
                  borderColor: "#409BFF",
                  boxShadow: "0 2px 4px rgba(0,0,0,0.05)",
                },
              }}
            >
              {/* Left side (id, type, amount) */}
              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Typography
                  sx={{ fontSize: 14, fontWeight: 600, color: "#111827", fontFamily: "Open Sans" }}
                >
                  {"#" + q.id}
                </Typography>
                <Typography
                  sx={{ fontSize: 14, color: "#6B7280", fontWeight: 500, fontFamily: "Open Sans", mt: 0.3 }}
                >
                  {q.type}
                </Typography>
                <Typography
                  sx={{ fontSize: 14, color: "#4B95E7", fontWeight: 600, fontFamily: "Open Sans", mt: 0.6 }}
                >
                  {q.amount}
                </Typography>
              </Box>
              {/* Right side (Status) */}
              <Chip
                label={q.status}
                sx={{
                  bgcolor: statusMap[q.status].bg,
                  color: statusMap[q.status].color,
                  fontWeight: 600,
                  fontSize: 13,
                  borderRadius: "8px",
                  height: 28,
                  px: 0.9,
                  minWidth: 75,
                  fontFamily: "Open Sans",
                  boxShadow: "none",
                  textTransform: "capitalize",
                  float: "right",
                }}
              />
            </Box>
          ))}
        </Box>
        {/* Button */}
        <Box sx={{ px: 2 }}>
          <Button
            fullWidth
            onClick={() => navigate("/billing-quote")}
            startIcon={<PlusIcon style={{ width: 20, height: 20 }} />}
            sx={{
              background: "#EFF6FF",
              color: "#409BFF",
              fontWeight: 700,
              fontFamily: "Open Sans",
              fontSize: 16,
              textTransform: "none",
              mt: 0.1,
              borderRadius: "8px",
              height: 42,
              boxShadow: "none",
              "&:hover": {
                background: "#E1EAFF",
                boxShadow: "none",
              },
              alignItems: "center",
              display: "flex",
              justifyContent: "center",
            }}
          >
            Create New Quote
          </Button>
        </Box>
      </Box>

      {/* Quote View Dialog */}
      <QuoteViewDialog disableScrollLock open={dialogOpen} onClose={handleCloseDialog} quoteData={selectedQuote} />
    </>
  );
};

export default QuotesEstimates;
