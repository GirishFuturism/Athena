// RecentInvoicesGrid.jsx
import React, { useState } from "react";
import {
  Box,
  Typography,
  TextField,
  InputAdornment,
  Chip,
  IconButton,
  Tooltip,
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import {
  MagnifyingGlassIcon,
  ArrowDownTrayIcon,
  EyeIcon,
  PencilSquareIcon,
  TrashIcon,
} from "@heroicons/react/24/outline";
import { invoiceRows as initialInvoiceRows, statusConfig } from "../../../Data/BillingData";
import InvoiceViewDialog from "./InvoiceViewDialog";
import DeleteContentDialog from "../TicketManagement/DeleteContentDialog";
import { useNavigate } from 'react-router-dom';
import * as XLSX from 'xlsx';

const HEADER_BG = "#F9FAFB";
const HEADER_COLOR = "#4B4B4B";

const RecentInvoicesGrid = () => {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [invoiceToDelete, setInvoiceToDelete] = useState(null);
  
  // Local state to manage invoices with real-time updates
  const [invoices, setInvoices] = useState(initialInvoiceRows);

  const handleViewClick = (invoice, event) => {
    if (event) {
      event.stopPropagation();
    }
    setSelectedInvoice(invoice);
    setDialogOpen(true);
  };

  const handleRowClick = (params) => {
    setSelectedInvoice(params.row);
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setSelectedInvoice(null);
  };

  // Download single invoice as Excel
  const handleDownloadSingleInvoice = (invoice, event) => {
    event.stopPropagation();
    
    const invoiceData = [{
      'Invoice Number': invoice.id,
      'Date': invoice.date,
      'Customer Name': invoice.customer,
      'Email': invoice.email,
      'Amount': `$${invoice.amount.toFixed(2)}`,
      'Status': invoice.status,
      'Due Date': invoice.due,
    }];

    const worksheet = XLSX.utils.json_to_sheet(invoiceData);

    const columnWidths = [
      { wch: 15 },
      { wch: 12 },
      { wch: 20 },
      { wch: 25 },
      { wch: 12 },
      { wch: 12 },
      { wch: 12 },
    ];
    worksheet['!cols'] = columnWidths;

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Invoice');

    const filename = `${invoice.id}_${invoice.customer.replace(/\s+/g, '_')}.xlsx`;

    XLSX.writeFile(workbook, filename);
  };

  // Edit invoice handler
  const handleEdit = (invoice, event) => {
    event.stopPropagation();
    navigate('/billing-form', { 
      state: { 
        isEditMode: true, 
        invoiceData: invoice 
      } 
    });
  };

  const handleDelete = (invoice, event) => {
    event.stopPropagation();
    setInvoiceToDelete(invoice);
    setDeleteDialogOpen(true);
  };

  const handleCloseDeleteDialog = () => {
    setDeleteDialogOpen(false);
    setInvoiceToDelete(null);
  };

  // Real-time delete functionality
  const handleConfirmDelete = () => {
    if (invoiceToDelete) {
      setInvoices(prevInvoices => 
        prevInvoices.filter(invoice => invoice.id !== invoiceToDelete.id)
      );
      
      console.log("Deleted invoice:", invoiceToDelete.id);
    }
    
    handleCloseDeleteDialog();
  };

  // Enhanced search functionality
  const filteredRows = invoices.filter((row) => {
    const searchQuery = query.toLowerCase().trim();
    
    if (!searchQuery) return true;

    return (
      row.id.toLowerCase().includes(searchQuery) ||
      row.customer.toLowerCase().includes(searchQuery) ||
      row.email.toLowerCase().includes(searchQuery) ||
      row.status.toLowerCase().includes(searchQuery) ||
      row.date.toLowerCase().includes(searchQuery) ||
      row.due.toLowerCase().includes(searchQuery) ||
      row.amount.toString().includes(searchQuery)
    );
  });

  // Export all filtered invoices to Excel
  const handleExportToExcel = () => {
    const exportData = filteredRows.map((row) => ({
      'Invoice Number': row.id,
      'Date': row.date,
      'Customer Name': row.customer,
      'Email': row.email,
      'Amount': `$${row.amount.toFixed(2)}`,
      'Status': row.status,
      'Due Date': row.due,
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportData);

    const columnWidths = [
      { wch: 15 },
      { wch: 12 },
      { wch: 20 },
      { wch: 25 },
      { wch: 12 },
      { wch: 12 },
      { wch: 12 },
    ];
    worksheet['!cols'] = columnWidths;

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Invoices');

    const date = new Date();
    const filename = `Invoices_${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}.xlsx`;

    XLSX.writeFile(workbook, filename);
  };

  const columns = [
    {
      field: "id",
      headerName: "Invoice",
      minWidth: 100,
      flex: 0.15,
      headerAlign: "left",
      renderCell: (params) => (
        <Box sx={{ lineHeight: 1.4 }}>
          <Typography
            sx={{
              fontWeight: 600,
              fontSize: 14,
              color: "#232323",
              fontFamily: "Open Sans",
              lineHeight: 1.1,
            }}
          >
            {params.row.id}
          </Typography>
          <Typography
            sx={{
              fontWeight: 400,
              fontSize: 14,
              color: "#6B7280",
              fontFamily: "Open Sans",
              mt: 0.4,
              letterSpacing: 0.1,
              lineHeight: 1.15,
            }}
          >
            {params.row.date}
          </Typography>
        </Box>
      ),
    },
    {
      field: "customer",
      headerName: "Customer",
      minWidth: 170,
      flex: 0.21,
      renderCell: (params) => (
        <Box>
          <Typography
            sx={{
              fontWeight: 600,
              fontSize: 14,
              color: "#111827",
              fontFamily: "Open Sans",
              lineHeight: 1.1,
            }}
          >
            {params.row.customer}
          </Typography>
          <Typography
            sx={{
              fontWeight: 400,
              fontSize: 14,
              color: "#6B7280",
              fontFamily: "Open Sans",
              mt: 0.4,
              lineHeight: 1.13,
              letterSpacing: 0.05,
            }}
          >
            {params.row.email}
          </Typography>
        </Box>
      ),
    },
    {
      field: "amount",
      headerName: "Amount",
      minWidth: 120,
      flex: 0.10,
      renderCell: (params) => (
        <Typography
          sx={{
            fontWeight: 600,
            fontSize: 14,
            color: "#111827",
            fontFamily: "Open Sans",
          }}
        >
          {params.row.amount.toLocaleString("en-US", {
            style: "currency",
            currency: "USD",
            minimumFractionDigits: 2,
          })}
        </Typography>
      ),
    },
    {
      field: "status",
      headerName: "Status",
      minWidth: 140,
      flex: 0.13,
      renderCell: (params) => (
        <Chip
          label={statusConfig[params.value].label}
          sx={{
            bgcolor: statusConfig[params.value].bg,
            color: statusConfig[params.value].color,
            fontWeight: 600,
            fontSize: 13,
            borderRadius: "999px",
            px: 1,
            height: 26,
            fontFamily: "Open Sans",
            boxShadow: "none",
          }}
        />
      ),
    },
    {
      field: "due",
      headerName: "Due Date",
      minWidth: 120,
      flex: 0.11,
      renderCell: (params) => (
        <Typography
          sx={{
            fontWeight: 600,
            fontSize: 14,
            color: "#111827",
            fontFamily: "Open Sans",
          }}
        >
          {params.row.due}
        </Typography>
      ),
    },
    {
      field: "actions",
      headerName: "Actions",
      minWidth: 140,
      flex: 0.18,
      sortable: false,
      disableColumnMenu: true,
      align: "left",
      headerAlign: "left",
      renderCell: (params) => {
        const status = params.row.status;
        
        return (
          <Box sx={{ display: "flex", alignItems: "center", ml: 0 }}>
            {/* View Icon - Always visible */}
            <Tooltip title="View Invoice">
              <IconButton
                size="small"
                onClick={(e) => handleViewClick(params.row, e)}
                sx={{
                  color: "#409BFF",
                  width: 30,
                  height: 30,
                  // p: 0.5,
                  // mx: 0.3,
                }}
              >
                <EyeIcon style={{ width: 17, height: 17 }} />
              </IconButton>
            </Tooltip>

            {/* Download Icon - Always visible */}
            <Tooltip title="Download Invoice">
              <IconButton
                size="small"
                onClick={(e) => handleDownloadSingleInvoice(params.row, e)}
                sx={{ 
                  color: "#6B7280", 
                  width: 30, 
                  height: 30, 
                  // p: 0.5, 
                  // mx: 0.3,
                  "&:hover": {
                    color: "#409BFF",
                  }
                }}
              >
                <ArrowDownTrayIcon style={{ width: 17, height: 17 }} />
              </IconButton>
            </Tooltip>

            {/* Edit Icon - Only for Pending status */}
            {status === "Pending" && (
              <Tooltip title="Edit">
                <IconButton
                  size="small"
                  onClick={(e) => handleEdit(params.row, e)}
                  sx={{ 
                    color: "#6B7280", 
                    width: 30, 
                    height: 30, 
                    // p: 0.5, 
                    // mx: 0.3,
                    "&:hover": {
                      color: "#409BFF",
                    }
                  }}
                >
                  <PencilSquareIcon style={{ width: 16, height: 16 }} />
                </IconButton>
              </Tooltip>
            )}

            {/* Delete Icon - For Pending and Overdue only */}
            {(status === "Pending" || status === "Overdue") && (
              <Tooltip title="Delete">
                <IconButton
                  size="small"
                  onClick={(e) => handleDelete(params.row, e)}
                  sx={{
                    color: "#6B7280",
                    width: 30,
                    height: 30,
                    // p: 0.5,
                    // mx: 0.3,
                    "&:hover": {
                      color: "#EF4444",
                    },
                  }}
                >
                  <TrashIcon style={{ width: 16, height: 16 }} />
                </IconButton>
              </Tooltip>
            )}
          </Box>
        );
      },
    },
  ];

  return (
    <>
      <Box
        sx={{
          border: "1px solid #E5E7EB",
          borderRadius: "8px",
          p: 0,
          boxShadow: "none",
          fontFamily: "Open Sans",
        }}
      >
        {/* Header */}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            px: 3,
            py: 2.2,
            borderBottom: "1.5px solid #E5E7EB",
          }}
        >
          <Typography
            sx={{
              fontSize: 18,
              fontWeight: 700,
              fontFamily: "Open Sans",
              color: "#1F2937",
              letterSpacing: 0,
              ml: 0.2,
            }}
          >
            Recent Invoices
            <Typography
              component="span"
              sx={{
                fontSize: 14,
                fontWeight: 400,
                color: "#6B7280",
                ml: 1.5,
              }}
            >
              ({invoices.length} total)
            </Typography>
          </Typography>
          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            <TextField
              size="small"
              placeholder="Search invoices..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              InputProps={{
                sx: {
                  bgcolor: "#FFFFFF",
                  fontSize: 14,
                  height: 35,
                  borderRadius: "8px",
                  minWidth: 215,
                  fontFamily: "Open Sans",
                  borderRight: "none",
                  boxShadow: "none",
                  pr: 0,
                },
                startAdornment: (
                  <InputAdornment position="start">
                    <MagnifyingGlassIcon
                      style={{
                        width: 16,
                        height: 16,
                        color: "#A1A1A1",
                        marginRight: 2,
                      }}
                    />
                  </InputAdornment>
                ),
              }}
            />
            {/* <Tooltip title="Export All to Excel">
              <IconButton
                onClick={handleExportToExcel}
                sx={{
                  bgcolor: "#409BFF",
                  borderRadius: "6px",
                  width: 40,
                  height: 35,
                  ml: "-1px",
                  boxShadow: "none",
                  "&:hover": { bgcolor: "#2563EB" },
                }}
              >
                <ArrowDownTrayIcon style={{ width: 17, height: 17, color: "#fff" }} />
              </IconButton>
            </Tooltip> */}
          </Box>
        </Box>

        {/* DataGrid */}
        <Box
          sx={{
            width: "100%",
            "& .MuiDataGrid-root": {
              border: "none",
              background: "#fff",
              fontFamily: "Open Sans",
            },
          }}
        >
          <DataGrid
            rows={filteredRows}
            columns={columns}
            getRowId={(row) => row.id}
            onRowClick={handleRowClick}
            hideFooterSelectedRowCount
            disableColumnMenu
            disableRowSelectionOnClick
            autoHeight
            density="standard"
            rowHeight={56}
            columnHeaderHeight={48}
            sx={{
              border: "none",
              px: 0,
              fontFamily: "Open Sans",
              "& .MuiDataGrid-columnHeaders": {
                background: HEADER_BG,
                minHeight: 48,
                maxHeight: 48,
              },
              "& .MuiDataGrid-columnHeader": {
                pl: 3,
                pr: 2.5,
                color: HEADER_COLOR,
                fontSize: 15,
                fontWeight: 700,
                fontFamily: "Open Sans",
                letterSpacing: 0.02,
                lineHeight: "24px",
                background: HEADER_BG,
                borderTopLeftRadius: 0,
                borderTopRightRadius: 0,
              },
              "& .MuiDataGrid-columnHeaderTitle": {
                fontWeight: 700,
                fontSize: 15,
                letterSpacing: 0,
              },
              "& .MuiDataGrid-cell": {
                fontSize: 14,
                px: 2.5,
                py: 1,
                fontFamily: "Open Sans",
                letterSpacing: 0,
                lineHeight: "22px",
                backgroundColor: "transparent",
              },
              "& .MuiDataGrid-row": {
                cursor: "pointer",
                width: "100%",
                boxSizing: "border-box",
                transition: "background-color 0.15s ease",
                "&:hover": {
                  backgroundColor: "#EEF2FF",
                },
              },
              "& .MuiDataGrid-columnSeparator": {
                display: "none",
              },
              "& .MuiDataGrid-footerContainer": {
                borderTop: "1px solid #E5E7EB",
                background: HEADER_BG,
                minHeight: 43,
                maxHeight: 48,
              },
              "& .MuiTablePagination-root": {
                color: "#6B7280",
                fontSize: 13,
                fontFamily: "Open Sans",
              },
              "& .MuiDataGrid-cell:focus": {
                outline: "none",
              },
              "& .MuiDataGrid-cell:focus-within": {
                outline: "none",
              },
              "& .MuiDataGrid-columnHeader:focus": {
                outline: "none",
              },
              "& .MuiDataGrid-columnHeader:focus-within": {
                outline: "none",
              },
            }}
            initialState={{
              pagination: {
                paginationModel: { page: 0, pageSize: 5 },
              },
            }}
            // pageSizeOptions={[5, 10]}
          />
        </Box>

        {/* Search Results Info */}
        {query && (
          <Box
            sx={{
              px: 3,
              py: 1.5,
              borderTop: "1px solid #E5E7EB",
              bgcolor: "#F9FAFB",
            }}
          >
            <Typography
              sx={{
                fontSize: 13,
                fontFamily: "Open Sans",
                color: "#6B7280",
              }}
            >
              Found {filteredRows.length} result{filteredRows.length !== 1 ? 's' : ''} for "{query}"
            </Typography>
          </Box>
        )}
      </Box>

      {/* Invoice View Dialog */}
      <InvoiceViewDialog
      disableScrollLock
        open={dialogOpen}
        onClose={handleCloseDialog}
        invoiceData={selectedInvoice}
      />

      {/* Delete Confirmation Dialog */}
      <DeleteContentDialog
      disableScrollLock
        open={deleteDialogOpen}
        onClose={handleCloseDeleteDialog}
        onConfirm={handleConfirmDelete}
        title="Delete Invoice"
        message={
          invoiceToDelete
            ? `Are you sure you want to delete invoice ${invoiceToDelete.id} for ${invoiceToDelete.customer}? This action cannot be undone.`
            : "Are you sure you want to delete this invoice?"
        }
      />
    </>
  );
};

export default RecentInvoicesGrid;