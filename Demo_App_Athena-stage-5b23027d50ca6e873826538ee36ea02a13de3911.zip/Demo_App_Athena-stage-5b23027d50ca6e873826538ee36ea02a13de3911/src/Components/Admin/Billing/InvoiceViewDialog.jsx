// InvoiceViewDialog.jsx
import React, { useRef } from "react";
import {
  Dialog,
  DialogContent,
  Box,
  Typography,
  Button,
  Divider,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import {
  ArrowDownTrayIcon,
  PrinterIcon,
  PaperAirplaneIcon,
} from "@heroicons/react/24/outline";
import PaidImg from '../../../assets/Paid.png';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';


const InvoiceViewDialog = ({ open, onClose, invoiceData }) => {
  const invoiceRef = useRef(null);


  // Check if data is from grid (has 'customer') or from form preview (has 'buyerName' or full items array)
  const isGridData = invoiceData && 'customer' in invoiceData && !invoiceData.items;
  
  // Generate invoice details for GRID data (with fake detailed data)
  const generateInvoiceDetailsFromGrid = () => {
    const status = invoiceData?.status || "Paid";
    const amount = invoiceData?.amount || 2500;
    
    // Base calculation
    const subtotal = amount;
    const taxRate = 8.5;
    const taxAmount = parseFloat((subtotal * (taxRate / 100)).toFixed(2));
    const discount = status === "Paid" ? 200.00 : 0;
    const total = subtotal + taxAmount - discount;


    // Generate line items based on amount
    let items = [];
    if (amount >= 4000) {
      items = [
        {
          description: "Premium Software License",
          subDescription: "Annual enterprise license with full support",
          qty: 1,
          rate: amount * 0.70,
          amount: amount * 0.70,
        },
        {
          description: "Professional Services",
          subDescription: "Implementation and training services",
          qty: 1,
          rate: amount * 0.20,
          amount: amount * 0.20,
        },
        {
          description: "Extended Support Package",
          subDescription: "12 months of technical support and updates",
          qty: 1,
          rate: amount * 0.10,
          amount: amount * 0.10,
        },
      ];
    } else if (amount >= 2500) {
      items = [
        {
          description: "Laptop",
          subDescription: "High-performance business laptop",
          qty: 1,
          rate: amount * 0.75,
          amount: amount * 0.75,
        },
        {
          description: "Keyboard",
          subDescription: "Mechanical keyboard - Black color",
          qty: 1,
          rate: amount * 0.15,
          amount: amount * 0.15,
        },
        {
          description: "Maintenance & Support",
          subDescription: "3 months of technical support and updates",
          qty: 1,
          rate: amount * 0.10,
          amount: amount * 0.10,
        },
      ];
    } else {
      items = [
        {
          description: "Mother Board Services",
          subDescription: "Custom development",
          qty: 1,
          rate: amount * 0.60,
          amount: amount * 0.60,
        },
        {
          description: "RAM Restoration",
          subDescription: "Modern responsive design",
          qty: 1,
          rate: amount * 0.25,
          amount: amount * 0.25,
        },
        {
          description: "GUI Setup",
          subDescription: "Addition and Enhancement",
          qty: 1,
          rate: amount * 0.15,
          amount: amount * 0.15,
        },
      ];
    }


    // Status-specific data
    const statusSpecificData = {
      Paid: {
        paymentMethod: "Bank Transfer",
        paymentDate: "Oct 20, 2025",
        paymentReference: "TXN-789456",
        notes: "Thank you for your business! We appreciate your prompt payment and look forward to working with you.",
        terms: "Payment is due within 30 days. Late payments may incur a 1.5% monthly service charge.",
      },
      Pending: {
        paymentMethod: "Bank Transfer",
        paymentDate: "Awaiting Payment",
        paymentReference: "N/A",
        notes: "Please process payment at your earliest convenience. Payment instructions have been sent to your email.",
        terms: "Payment is due within 30 days of invoice date. Late payments may incur a 1.5% monthly service charge.",
      },
      Overdue: {
        paymentMethod: "Bank Transfer",
        paymentDate: "Payment Overdue",
        paymentReference: "N/A",
        notes: "URGENT: This invoice is now overdue. Please remit payment immediately to avoid service interruption.",
        terms: "This invoice is past due. A 1.5% monthly late fee has been applied. Please settle your account immediately.",
      },
    };


    return {
      invoiceNumber: invoiceData?.id || "INV-2025-010",
      issueDate: invoiceData?.date || "Oct 15, 2025",
      dueDate: invoiceData?.due || "Nov 15, 2025",
      
      // Seller info
      sellerName: "PSA Solutions",
      sellerAddress: "123 Business Avenue",
      sellerCity: "New York, NY 10001",
      sellerEmail: "contact@techcorp.com",
      sellerPhone: "+1 (555) 123-4567",
      
      // Buyer info
      buyerName: invoiceData?.customer || "Acme Corporation",
      buyerAddress: "456 Client Street",
      buyerCity: "Los Angeles, CA 90210",
      buyerEmail: invoiceData?.email || "billing@acmecorp.com",
      buyerPhone: "+1 (555) 987-6543",
      
      // Payment details
      paymentMethod: statusSpecificData[status].paymentMethod,
      paymentStatus: status,
      paymentDate: statusSpecificData[status].paymentDate,
      paymentReference: statusSpecificData[status].paymentReference,
      
      // Line items
      items: items,
      
      // Totals
      subtotal: subtotal,
      taxRate: taxRate,
      taxAmount: taxAmount,
      discount: discount,
      total: total,
      
      // Footer notes
      notes: statusSpecificData[status].notes,
      terms: statusSpecificData[status].terms,
    };
  };


  // Transform FORM PREVIEW data to match invoice format
  const transformFormDataToInvoice = () => {
    return {
      invoiceNumber: invoiceData?.id || invoiceData?.quoteNumber,
      issueDate: invoiceData?.date,
      dueDate: invoiceData?.due,
      
      // Seller info
      sellerName: invoiceData?.companyName || "PSA Solutions Inc.",
      sellerAddress: invoiceData?.companyAddress || "123 Business Ave, Suite 100",
      sellerCity: invoiceData?.companyCity || "New York, NY 10001",
      sellerEmail: invoiceData?.companyEmail || "contact@techsolutions.com",
      sellerPhone: invoiceData?.companyPhone || "(555) 123-4567",
      
      // Buyer info
      buyerName: invoiceData?.customer || invoiceData?.buyerName,
      buyerAddress: invoiceData?.address || invoiceData?.buyerAddress,
      buyerCity: "", // Can be extracted from address if needed
      buyerEmail: invoiceData?.email || invoiceData?.buyerEmail,
      buyerPhone: invoiceData?.buyerPhone || "",
      
      // Payment details
      paymentMethod: "Bank Transfer",
      paymentStatus: invoiceData?.status || invoiceData?.paymentStatus || "Pending",
      paymentDate: invoiceData?.status === "Paid" ? invoiceData?.date : "Awaiting Payment",
      paymentReference: invoiceData?.referenceId || invoiceData?.reference || "N/A",
      
      // Line items - REAL DATA FROM FORM
      items: invoiceData?.items || [],
      
      // Totals - REAL DATA FROM FORM
      subtotal: parseFloat(invoiceData?.subtotal || 0),
      taxRate: invoiceData?.taxRate || 8.5,
      taxAmount: parseFloat(invoiceData?.taxAmount || invoiceData?.tax || 0),
      discount: parseFloat(invoiceData?.discount || 0),
      total: parseFloat(invoiceData?.total || 0),
      
      // Footer notes - REAL DATA FROM FORM with defaults
      notes: invoiceData?.notes || "Thank you for your business! We appreciate your partnership.",
      terms: invoiceData?.terms || "Payment is due within 30 days. Late payments may incur a 1.5% monthly service charge.",
    };
  };


  // Get invoice details based on data source
  const invoiceDetails = isGridData 
    ? generateInvoiceDetailsFromGrid() 
    : transformFormDataToInvoice();


  
// IMPROVED PDF Download Handler - No visible stretching/flashing
const handleDownloadPDF = async () => {
  try {
    const element = invoiceRef.current;
    if (!element) return;

    // Use onclone callback to modify the CLONED element, not the original
    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff',
      scrollX: 0,
      scrollY: -window.scrollY,
      onclone: (clonedDoc) => {
        // Find the cloned invoice element
        const clonedElement = clonedDoc.querySelector('[data-invoice-content]');
        
        if (clonedElement) {
          // Modify ONLY the clone, not the original visible element
          clonedElement.style.overflow = 'visible';
          clonedElement.style.maxHeight = 'none';
          clonedElement.style.height = 'auto';
        }
      },
    });

    const imgData = canvas.toDataURL('image/png');
    
    // Calculate PDF dimensions
    const imgWidth = 210; // A4 width in mm
    const pageHeight = 297; // A4 height in mm
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    let heightLeft = imgHeight;
    let position = 0;

    const pdf = new jsPDF('p', 'mm', 'a4');
    
    // Add first page
    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    // Add additional pages if content is longer than one page
    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }

    pdf.save(`${invoiceDetails.invoiceNumber}_${invoiceDetails.buyerName.replace(/\s+/g, '_')}.pdf`);
  } catch (error) {
    console.error('Error generating PDF:', error);
    alert('Failed to generate PDF. Please try again.');
  }
};



  // Print Handler
  const handlePrint = () => {
    window.print();
  };


  // Render paid stamp based on status
  const renderStatusStamp = () => {
    const status = invoiceDetails.paymentStatus;


    if (status === "Paid") {
      return (
        <Box sx={{ display: "flex", alignItems: "flex-start", justifyContent: "flex-end" }}>
          <Box component="img" src={PaidImg} alt="Paid" sx={{ width: "140px", height: "140px", objectFit: "contain", mt: -1 }} />
        </Box>
      );
    } else if (status === "Pending") {
      return (
        <Box sx={{ display: "flex", alignItems: "flex-start", justifyContent: "flex-end" }}>
          <Box sx={{ width: "130px", height: "130px", border: "4px solid #F59E0B", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", transform: "rotate(-15deg)", mt: -1 }}>
            <Typography sx={{ fontSize: "19px", fontWeight: 800, color: "#F59E0B", fontFamily: "Open Sans", letterSpacing: "1px" }}>
              $PENDING
            </Typography>
          </Box>
        </Box>
      );
    } else if (status === "Overdue") {
      return (
        <Box sx={{ display: "flex", alignItems: "flex-start", justifyContent: "flex-end" }}>
          <Box sx={{ width: "130px", height: "130px", border: "4px solid #DC2626", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", transform: "rotate(-15deg)", mt: -1 }}>
            <Typography sx={{ fontSize: "19px", fontWeight: 800, color: "#DC2626", fontFamily: "Open Sans", letterSpacing: "1px" }}>
              $OVERDUE
            </Typography>
          </Box>
        </Box>
      );
    }
  };


  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="md"
      fullWidth
      disableScrollLock
      PaperProps={{
        sx: {
          borderRadius: "12px",
          maxWidth: "900px",
          boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
        },
      }}
    >
      <DialogContent sx={{ p: 0, position: "relative" }}>
        {/* Header with Actions */}
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", px: 4, py: 2.5, borderBottom: "1px solid #E5E7EB", bgcolor: "#fff", '@media print': { display: 'none' } }}>
          <Button
            onClick={onClose}
            startIcon={
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M19 12H5M12 19l-7-7 7-7" />
              </svg>
            }
            sx={{ color: "#4B5563", textTransform: "none", fontSize: "14px", fontWeight: 500, fontFamily: "Open Sans", "&:hover": { bgcolor: "transparent", color: "#111827" } }}
          >
            Back to Invoices
          </Button>


          <Box sx={{ display: "flex", gap: 1.5 }}>
            <Button onClick={handleDownloadPDF} startIcon={<ArrowDownTrayIcon style={{ width: 18, height: 18 }} />} sx={{ textTransform: "none", fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#374151", borderColor: "#D1D5DB", bgcolor: "#F3F4F6", px: 2, py: 0.75, "&:hover": { borderColor: "#9CA3AF", bgcolor: "#F9FAFB" } }}>
              Download PDF
            </Button>
            <Button onClick={handlePrint} startIcon={<PrinterIcon style={{ width: 18, height: 18 }} />} sx={{ textTransform: "none", fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#374151", borderColor: "#D1D5DB", bgcolor: "#F3F4F6", px: 2, py: 0.75, "&:hover": { borderColor: "#9CA3AF", bgcolor: "#F9FAFB" } }}>
              Print
            </Button>
            <Button onClick={onClose} startIcon={<PaperAirplaneIcon style={{ width: 18, height: 18 }} />} variant="contained" sx={{ textTransform: "none", fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", bgcolor: "#409BFF", px: 2.5, py: 0.75, boxShadow: "none", "&:hover": { bgcolor: "#2563EB", boxShadow: "none" } }}>
              Send Invoice
            </Button>
          </Box>
        </Box>


        {/* Invoice Content */}
        <Box ref={invoiceRef} data-invoice-content sx={{ px: 6, py: 4, bgcolor: "#FFFFFF", maxHeight: "calc(100vh - 200px)", overflowY: "auto", '@media print': { maxHeight: 'none', overflowY: 'visible' } }}>
          {/* Invoice Header */}
          <Box sx={{ display: "flex", justifyContent: "space-between", mb: 6 }}>
            <Box>
              <Typography sx={{ fontSize: "30px", fontWeight: 700, fontFamily: "Open Sans", color: "#111827", letterSpacing: "-0.5px", mb: 2 }}>
                INVOICE
              </Typography>
              <Box>
                <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", mb: 0.5 }}>
                  <span style={{ fontWeight: 600, color: "#111827" }}>Invoice Number:</span> {invoiceDetails.invoiceNumber}
                </Typography>
                <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", mb: 0.5 }}>
                  <span style={{ fontWeight: 600, color: "#111827" }}>Issue Date:</span> {invoiceDetails.issueDate}
                </Typography>
                <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans" }}>
                  <span style={{ fontWeight: 600, color: "#111827" }}>Due Date:</span> {invoiceDetails.dueDate}
                </Typography>
              </Box>
            </Box>


            <Box sx={{ textAlign: "right" }}>
              <Typography sx={{ fontSize: "19px", fontWeight: 700, fontFamily: "Open Sans", color: "#111827", mb: 1 }}>
                {invoiceDetails.sellerName}
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", lineHeight: 1.6 }}>
                {invoiceDetails.sellerAddress}
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", lineHeight: 1.6 }}>
                {invoiceDetails.sellerCity}
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", lineHeight: 1.6 }}>
                {invoiceDetails.sellerEmail}
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", lineHeight: 1.6 }}>
                {invoiceDetails.sellerPhone}
              </Typography>
            </Box>
          </Box>


          {/* Bill To and Payment Details */}
          <Box sx={{ display: "flex", justifyContent: "space-between", mb: 6, gap: 4 }}>
            {/* Bill To */}
            <Box sx={{ flex: 1 }}>
              <Typography sx={{ fontSize: "14px", fontWeight: 700, fontFamily: "Open Sans", color: "#111827", mb: 1.5 }}>
                Bill To:
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 600, color: "#111827", fontFamily: "Open Sans", mb: 0.5 }}>
                {invoiceDetails.buyerName}
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", lineHeight: 1.6 }}>
                {invoiceDetails.buyerAddress}
              </Typography>
              {invoiceDetails.buyerCity && (
                <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", lineHeight: 1.6 }}>
                  {invoiceDetails.buyerCity}
                </Typography>
              )}
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", lineHeight: 1.6 }}>
                {invoiceDetails.buyerEmail}
              </Typography>
              {invoiceDetails.buyerPhone && (
                <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", lineHeight: 1.6 }}>
                  {invoiceDetails.buyerPhone}
                </Typography>
              )}
            </Box>


            {/* Payment Details */}
            <Box sx={{ flex: 1 }}>
              <Typography sx={{ fontSize: "14px", fontWeight: 700, fontFamily: "Open Sans", color: "#111827", mb: 1.5 }}>
                Payment Details:
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", mb: 0.5 }}>
                <span style={{ fontWeight: 600, color: "#111827" }}>Payment Method:</span> {invoiceDetails.paymentMethod}
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", mb: 0.5 }}>
                <span style={{ fontWeight: 600, color: "#111827" }}>Payment Status:</span>{" "}
                <span
                  style={{
                    color:
                      invoiceDetails.paymentStatus === "Paid"
                        ? "#166534"
                        : invoiceDetails.paymentStatus === "Pending"
                        ? "#9A3412"
                        : "#991B1B",
                    fontWeight: 700,
                  }}
                >
                  {invoiceDetails.paymentStatus}
                </span>
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", mb: 0.5 }}>
                <span style={{ fontWeight: 600, color: "#111827" }}>Payment Date:</span> {invoiceDetails.paymentDate}
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans" }}>
                <span style={{ fontWeight: 600, color: "#111827" }}>Reference:</span> {invoiceDetails.paymentReference}
              </Typography>
            </Box>


            {/* Status Stamp */}
            {renderStatusStamp()}
          </Box>


          {/* Line Items Table */}
          <TableContainer sx={{ mb: 4 }}>
            <Table>
              <TableHead>
                <TableRow sx={{ bgcolor: "#F9FAFB" }}>
                  <TableCell sx={{ fontWeight: 700, fontSize: "14px", fontFamily: "Open Sans", color: "#111827", borderBottom: "2px solid #E5E7EB", py: 1.5 }}>
                    Description
                  </TableCell>
                  <TableCell align="center" sx={{ fontWeight: 700, fontSize: "14px", fontFamily: "Open Sans", color: "#111827", borderBottom: "2px solid #E5E7EB", py: 1.5 }}>
                    Qty
                  </TableCell>
                  <TableCell align="right" sx={{ fontWeight: 700, fontSize: "14px", fontFamily: "Open Sans", color: "#111827", borderBottom: "2px solid #E5E7EB", py: 1.5 }}>
                    Rate
                  </TableCell>
                  <TableCell align="right" sx={{ fontWeight: 700, fontSize: "14px", fontFamily: "Open Sans", color: "#111827", borderBottom: "2px solid #E5E7EB", py: 1.5 }}>
                    Amount
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {invoiceDetails.items.map((item, index) => (
                  <TableRow key={index}>
                    <TableCell sx={{ borderBottom: "1px solid #E5E7EB", py: 2 }}>
                      <Typography sx={{ fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#111827", mb: 0.3 }}>
                        {item.description}
                      </Typography>
                      {item.subDescription && (
                        <Typography sx={{ fontSize: "14px", fontWeight: 400, fontFamily: "Open Sans", color: "#4B5563" }}>
                          {item.subDescription}
                        </Typography>
                      )}
                    </TableCell>
                    <TableCell align="center" sx={{ borderBottom: "1px solid #E5E7EB", py: 2 }}>
                      <Typography sx={{ fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#111827" }}>
                        {item.qty}
                      </Typography>
                    </TableCell>
                    <TableCell align="right" sx={{ borderBottom: "1px solid #E5E7EB", py: 2 }}>
                      <Typography sx={{ fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#111827" }}>
                        ${parseFloat(item.rate).toFixed(2)}
                      </Typography>
                    </TableCell>
                    <TableCell align="right" sx={{ borderBottom: "1px solid #E5E7EB", py: 2 }}>
                      <Typography sx={{ fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#111827" }}>
                        ${parseFloat(item.amount).toFixed(2)}
                      </Typography>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>


          {/* Totals Section */}
          <Box sx={{ display: "flex", justifyContent: "flex-end", mb: 5 }}>
            <Box sx={{ width: "300px", bgcolor: "#F3F4F6", p: 3, borderRadius: "8px" }}>
              <Box sx={{ display: "flex", justifyContent: "space-between", mb: 1.5 }}>
                <Typography sx={{ fontSize: "14px", fontWeight: 400, fontFamily: "Open Sans", color: "#4B5563" }}>
                  Subtotal:
                </Typography>
                <Typography sx={{ fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#111827" }}>
                  ${invoiceDetails.subtotal.toFixed(2)}
                </Typography>
              </Box>
              <Box sx={{ display: "flex", justifyContent: "space-between", mb: 1.5 }}>
                <Typography sx={{ fontSize: "14px", fontWeight: 400, fontFamily: "Open Sans", color: "#4B5563" }}>
                  Tax ({invoiceDetails.taxRate}%):
                </Typography>
                <Typography sx={{ fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#111827" }}>
                  ${invoiceDetails.taxAmount.toFixed(2)}
                </Typography>
              </Box>
              {invoiceDetails.discount > 0 && (
                <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2 }}>
                  <Typography sx={{ fontSize: "14px", fontWeight: 400, fontFamily: "Open Sans", color: "#4B5563" }}>
                    Discount:
                  </Typography>
                  <Typography sx={{ fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#DC2626" }}>
                    -${invoiceDetails.discount.toFixed(2)}
                  </Typography>
                </Box>
              )}
              <Divider sx={{ mb: 2 }} />
              <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                <Typography sx={{ fontSize: "16px", fontWeight: 700, fontFamily: "Open Sans", color: "#111827" }}>
                  Total:
                </Typography>
                <Typography sx={{ fontSize: "18px", fontWeight: 700, fontFamily: "Open Sans", color: "#111827" }}>
                  ${invoiceDetails.total.toFixed(2)}
                </Typography>
              </Box>
            </Box>
          </Box>


          {/* Notes and Terms */}
          {(invoiceDetails.notes || invoiceDetails.terms) && (
            <Box sx={{ display: "flex", gap: 4, pt: 3, borderTop: "1px solid #E5E7EB" }}>
              {invoiceDetails.notes && (
                <Box sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: "14px", fontWeight: 700, fontFamily: "Open Sans", color: "#111827", mb: 1 }}>
                    Notes:
                  </Typography>
                  <Typography sx={{ fontSize: "14px", fontWeight: 400, fontFamily: "Open Sans", color: "#4B5563", lineHeight: 1.7 }}>
                    {invoiceDetails.notes}
                  </Typography>
                </Box>
              )}
              {invoiceDetails.terms && (
                <Box sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: "14px", fontWeight: 700, fontFamily: "Open Sans", color: "#111827", mb: 1 }}>
                    Terms & Conditions:
                  </Typography>
                  <Typography sx={{ fontSize: "14px", fontWeight: 400, fontFamily: "Open Sans", color: "#4B5563", lineHeight: 1.7 }}>
                    {invoiceDetails.terms}
                  </Typography>
                </Box>
              )}
            </Box>
          )}
        </Box>
      </DialogContent>
    </Dialog>
  );
};


export default InvoiceViewDialog;
