// QuoteViewDialog.jsx
import React, { useRef } from "react";
import {
  Dialog,
  DialogContent,
  Box,
  Typography,
  Button,
  Divider,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
} from "@mui/material";
import {
  ArrowDownTrayIcon,
  PrinterIcon,
  PaperAirplaneIcon,
  PencilSquareIcon,
} from "@heroicons/react/24/outline";
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { useNavigate } from 'react-router-dom';


const QuoteViewDialog = ({ open, onClose, quoteData }) => {
  const quoteRef = useRef(null);
  const navigate = useNavigate();
  
  if (!quoteData) return null;


  // Status chip config
  const statusConfig = {
    Active: { bg: "#DBEAFE", color: "#1E40AF" },
    Accepted: { bg: "#DCFCE7", color: "#166534" },
    Pending: { bg: "#FFEDD5", color: "#9A3412" },
    Rejected: { bg: "#FEE2E2", color: "#991B1B" },
    Draft: { bg: "#F3F4F6", color: "#4B5563" },
    Sent: { bg: "#E0E7FF", color: "#3730A3" },
  };


  // Use actual quoteData passed from the form
  const quoteDetails = {
    quoteNumber: quoteData.quoteNumber || quoteData.id || "QT-2025-012",
    issueDate: quoteData.issueDate ? new Date(quoteData.issueDate).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) : "Oct 15, 2025",
    dueDate: quoteData.dueDate || quoteData.expiryDate ? new Date(quoteData.dueDate || quoteData.expiryDate).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) : "Dec 15, 2025",

    // Seller info
    sellerName: "PSA Solutions",
    sellerAddress: "123 Business Avenue",
    sellerCity: "New York, NY 10001",
    sellerEmail: "contact@techcorp.com",
    sellerPhone: "+1 (555) 123-4567",

    // Buyer info - use actual data from form
    buyerName: quoteData.buyerName || "Acme Corporation",
    buyerAddress: quoteData.buyerAddress || "456 Client Street",
    buyerCity: quoteData.buyerCity || "Los Angeles, CA 90210",
    buyerEmail: quoteData.buyerEmail || "billing@acmecorp.com",
    buyerPhone: quoteData.buyerPhone || "+1 (555) 987-6543",

    // Payment details - use actual data from form
    paymentMethod: "Bank Transfer",
    paymentTerms: quoteData.paymentTerms || "Net 30",
    paymentDate: "Oct 20, 2025",
    quoteStatus: quoteData.quoteStatus || quoteData.status || "Draft",
    reference: quoteData.reference || "TXN-789456",

    // Line items - use actual items from form
    items: quoteData.items || [],

    // Totals - use actual calculations from form
    subtotal: quoteData.subtotal || 0,
    taxRate: quoteData.taxRate || 8.5,
    taxAmount: quoteData.taxAmount || 0,
    discount: quoteData.discount || 0,
    total: quoteData.total || 0,

    // Footer notes - use actual notes from form
    notes: quoteData.notes || "Thank you for your business!",
    terms: quoteData.terms || "Payment is due within 30 days.",
  };


  const handleEditQuote = () => {
    navigate('/billing-quote', { 
      state: { 
        editMode: true, 
        quoteData: quoteDetails 
      } 
    });
    onClose();
  };


  // IMPROVED PDF Download Handler - No visible stretching
  const handleDownloadPDF = async () => {
    try {
      const element = quoteRef.current;
      if (!element) return;

      // Use onclone callback to modify the CLONED element, not the original
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
        scrollX: 0,
        scrollY: -window.scrollY,
        onclone: (clonedDoc) => {
          // Find the cloned quote element
          const clonedElement = clonedDoc.querySelector('[data-quote-content]');
          
          if (clonedElement) {
            // Modify ONLY the clone, not the original visible element
            clonedElement.style.overflow = 'visible';
            clonedElement.style.maxHeight = 'none';
            clonedElement.style.height = 'auto';
          }
        },
      });

      const imgData = canvas.toDataURL('image/png');
      
      // Calculate PDF dimensions
      const imgWidth = 210; // A4 width in mm
      const pageHeight = 297; // A4 height in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      const pdf = new jsPDF('p', 'mm', 'a4');
      
      // Add first page
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      // Add additional pages if content is longer than one page
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`${quoteDetails.quoteNumber}_${quoteDetails.buyerName.replace(/\s+/g, '_')}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Failed to generate PDF. Please try again.');
    }
  };


  // Print Handler
  const handlePrint = () => {
    window.print();
  };


  return (
    <Dialog
      open={open}
      onClose={onClose}
      disableScrollLock
      maxWidth="md"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: "12px",
          maxWidth: "900px",
          boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
        },
      }}
    >
      <DialogContent sx={{ p: 0, position: "relative" }}>
        {/* Header with Actions */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            px: 4,
            py: 2.5,
            borderBottom: "1px solid #E5E7EB",
            bgcolor: "#fff",
            '@media print': {
              display: 'none',
            },
          }}
        >
          <Button
            onClick={onClose}
            startIcon={
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M19 12H5M12 19l-7-7 7-7" />
              </svg>
            }
            sx={{
              color: "#4B5563",
              textTransform: "none",
              fontSize: "14px",
              fontWeight: 500,
              fontFamily: "Open Sans",
              "&:hover": { bgcolor: "transparent", color: "#111827" },
            }}
          >
            Back to Quote
          </Button>

          <Box sx={{ display: "flex", gap: 1.5 }}>
            <Button
              onClick={handleDownloadPDF}
              startIcon={<ArrowDownTrayIcon style={{ width: 18, height: 18 }} />}
              sx={{
                textTransform: "none",
                fontSize: "14px",
                fontWeight: 600,
                fontFamily: "Open Sans",
                color: "#374151",
                borderColor: "#D1D5DB",
                bgcolor: "#F3F4F6",
                px: 2,
                py: 0.75,
                "&:hover": { borderColor: "#9CA3AF", bgcolor: "#F9FAFB" },
              }}
            >
              Download PDF
            </Button>
            <Button
              onClick={handlePrint}
              startIcon={<PrinterIcon style={{ width: 18, height: 18 }} />}
              sx={{
                textTransform: "none",
                fontSize: "14px",
                fontWeight: 600,
                fontFamily: "Open Sans",
                color: "#374151",
                borderColor: "#D1D5DB",
                bgcolor: "#F3F4F6",
                px: 2,
                py: 0.75,
                "&:hover": { borderColor: "#9CA3AF", bgcolor: "#F9FAFB" },
              }}
            >
              Print
            </Button>
            <Button
              startIcon={<PencilSquareIcon style={{ width: 18, height: 18 }} />}
              onClick={handleEditQuote}
              variant="contained"
              sx={{
                textTransform: "none",
                fontSize: "14px",
                fontWeight: 600,
                fontFamily: "Open Sans",
                bgcolor: "#409BFF",
                px: 2.5,
                py: 0.75,
                boxShadow: "none",
                "&:hover": { bgcolor: "#2563EB", boxShadow: "none" },
              }}
            >
              Edit Quote
            </Button>
            <Button
              onClick={onClose}
              startIcon={<PaperAirplaneIcon style={{ width: 18, height: 18 }} />}
              variant="contained"
              sx={{
                textTransform: "none",
                fontSize: "14px",
                fontWeight: 600,
                fontFamily: "Open Sans",
                bgcolor: "#409BFF",
                px: 2.5,
                py: 0.75,
                boxShadow: "none",
                "&:hover": { bgcolor: "#2563EB", boxShadow: "none" },
              }}
            >
              Send Quote
            </Button>
          </Box>
        </Box>

        {/* Quote Content - ADDED data-quote-content attribute */}
        <Box
          ref={quoteRef}
          data-quote-content
          sx={{
            px: 6,
            py: 4,
            bgcolor: "#FFFFFF",
            maxHeight: "calc(100vh - 200px)",
            overflowY: "auto",
            '@media print': {
              maxHeight: 'none',
              overflowY: 'visible',
            },
          }}
        >
          {/* Quote Header */}
          <Box sx={{ display: "flex", justifyContent: "space-between", mb: 6 }}>
            <Box>
              <Typography
                sx={{
                  fontSize: "30px",
                  fontWeight: 700,
                  fontFamily: "Open Sans",
                  color: "#111827",
                  letterSpacing: "-0.5px",
                  mb: 2,
                }}
              >
                QUOTE
              </Typography>
              <Box>
                <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", mb: 0.5 }}>
                  <span style={{ fontWeight: 600, color: "#111827" }}>Quote Number:</span> {quoteDetails.quoteNumber}
                </Typography>
                <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", mb: 0.5 }}>
                  <span style={{ fontWeight: 600, color: "#111827" }}>Issue Date:</span> {quoteDetails.issueDate}
                </Typography>
                <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans" }}>
                  <span style={{ fontWeight: 600, color: "#111827" }}>Due Date:</span> {quoteDetails.dueDate}
                </Typography>
              </Box>
            </Box>

            <Box sx={{ textAlign: "right" }}>
              <Typography sx={{ fontSize: "19px", fontWeight: 700, fontFamily: "Open Sans", color: "#111827", mb: 1 }}>
                {quoteDetails.sellerName}
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", lineHeight: 1.6 }}>
                {quoteDetails.sellerAddress}
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", lineHeight: 1.6 }}>
                {quoteDetails.sellerCity}
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", lineHeight: 1.6 }}>
                {quoteDetails.sellerEmail}
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", lineHeight: 1.6 }}>
                {quoteDetails.sellerPhone}
              </Typography>
            </Box>
          </Box>

          {/* Bill To and Payment Details */}
          <Box sx={{ display: "flex", justifyContent: "space-between", mb: 6, gap: 4 }}>
            {/* Bill To */}
            <Box sx={{ flex: 1 }}>
              <Typography sx={{ fontSize: "14px", fontWeight: 700, fontFamily: "Open Sans", color: "#111827", mb: 1.5 }}>
                Bill:
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 600, color: "#111827", fontFamily: "Open Sans", mb: 0.5 }}>
                {quoteDetails.buyerName}
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", lineHeight: 1.6 }}>
                {quoteDetails.buyerAddress}
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", lineHeight: 1.6 }}>
                {quoteDetails.buyerEmail}
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", lineHeight: 1.6 }}>
                {quoteDetails.buyerPhone}
              </Typography>
            </Box>

            {/* Payment Details */}
            <Box sx={{ textAlign: "right" }}>
              <Typography sx={{ fontSize: "14px", fontWeight: 700, fontFamily: "Open Sans", color: "#111827", mb: 1.5, }}>
                Payment Details:
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", mb: 0.5 }}>
                <span style={{ fontWeight: 600, color: "#111827" }}>Payment Method:</span> {quoteDetails.paymentMethod}
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", mb: 0.5, }}>
                <span style={{ fontWeight: 600, color: "#111827" }}>Payment Terms:</span> {quoteDetails.paymentTerms}
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", mb: 0.5 }}>
                <span style={{ fontWeight: 600, color: "#111827" }}>Payment Date:</span> {quoteDetails.paymentDate}
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans", mb: 0.5 }}>
                <span style={{ fontWeight: 600, color: "#111827" }}>Quote Status:</span>{" "}
                <Chip
                  label={quoteDetails.quoteStatus}
                  size="small"
                  sx={{
                    bgcolor: statusConfig[quoteDetails.quoteStatus]?.bg || "#F3F4F6",
                    color: statusConfig[quoteDetails.quoteStatus]?.color || "#4B5563",
                    fontWeight: 600,
                    fontSize: 12,
                    height: 22,
                    ml: 0.5,
                    fontFamily: "Open Sans",
                  }}
                />
              </Typography>
              <Typography sx={{ fontSize: "14px", fontWeight: 400, color: "#4B5563", fontFamily: "Open Sans" }}>
                <span style={{ fontWeight: 600, color: "#111827" }}>Reference:</span> {quoteDetails.reference}
              </Typography>
            </Box>
          </Box>

          {/* Line Items Table - Only show if items exist */}
          {quoteDetails.items && quoteDetails.items.length > 0 && (
            <TableContainer sx={{ mb: 4 }}>
              <Table>
                <TableHead>
                  <TableRow sx={{ bgcolor: "#F9FAFB" }}>
                    <TableCell
                      sx={{
                        fontWeight: 700,
                        fontSize: "14px",
                        fontFamily: "Open Sans",
                        color: "#111827",
                        borderBottom: "2px solid #E5E7EB",
                        py: 1.5,
                      }}
                    >
                      Description
                    </TableCell>
                    <TableCell
                      align="center"
                      sx={{
                        fontWeight: 700,
                        fontSize: "14px",
                        fontFamily: "Open Sans",
                        color: "#111827",
                        borderBottom: "2px solid #E5E7EB",
                        py: 1.5,
                      }}
                    >
                      Qty
                    </TableCell>
                    <TableCell
                      align="right"
                      sx={{
                        fontWeight: 700,
                        fontSize: "14px",
                        fontFamily: "Open Sans",
                        color: "#111827",
                        borderBottom: "2px solid #E5E7EB",
                        py: 1.5,
                      }}
                    >
                      Rate
                    </TableCell>
                    <TableCell
                      align="right"
                      sx={{
                        fontWeight: 700,
                        fontSize: "14px",
                        fontFamily: "Open Sans",
                        color: "#111827",
                        borderBottom: "2px solid #E5E7EB",
                        py: 1.5,
                      }}
                    >
                      Amount
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {quoteDetails.items.map((item, index) => (
                    <TableRow key={index}>
                      <TableCell sx={{ borderBottom: "1px solid #E5E7EB", py: 2 }}>
                        <Typography
                          sx={{
                            fontSize: "14px",
                            fontWeight: 600,
                            fontFamily: "Open Sans",
                            color: "#111827",
                            mb: 0.3,
                          }}
                        >
                          {item.description}
                        </Typography>
                        {item.subDescription && (
                          <Typography
                            sx={{
                              fontSize: "14px",
                              fontWeight: 400,
                              fontFamily: "Open Sans",
                              color: "#4B5563",
                            }}
                          >
                            {item.subDescription}
                          </Typography>
                        )}
                      </TableCell>
                      <TableCell align="center" sx={{ borderBottom: "1px solid #E5E7EB", py: 2 }}>
                        <Typography sx={{ fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#111827" }}>
                          {item.qty}
                        </Typography>
                      </TableCell>
                      <TableCell align="right" sx={{ borderBottom: "1px solid #E5E7EB", py: 2 }}>
                        <Typography sx={{ fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#111827" }}>
                          ${item.rate.toFixed(2)}
                        </Typography>
                      </TableCell>
                      <TableCell align="right" sx={{ borderBottom: "1px solid #E5E7EB", py: 2 }}>
                        <Typography sx={{ fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#111827" }}>
                          ${item.amount.toFixed(2)}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}

          {/* Totals Section */}
          <Box sx={{ display: "flex", justifyContent: "flex-end", mb: 5 }}>
            <Box sx={{ width: "300px", bgcolor: "#F3F4F6", p: 3, borderRadius: "8px" }}>
              <Box sx={{ display: "flex", justifyContent: "space-between", mb: 1.5 }}>
                <Typography sx={{ fontSize: "14px", fontWeight: 400, fontFamily: "Open Sans", color: "#4B5563" }}>
                  Subtotal:
                </Typography>
                <Typography sx={{ fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#111827" }}>
                  ${quoteDetails.subtotal.toFixed(2)}
                </Typography>
              </Box>
              <Box sx={{ display: "flex", justifyContent: "space-between", mb: 1.5 }}>
                <Typography sx={{ fontSize: "14px", fontWeight: 400, fontFamily: "Open Sans", color: "#4B5563" }}>
                  Tax ({quoteDetails.taxRate}%):
                </Typography>
                <Typography sx={{ fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#111827" }}>
                  ${quoteDetails.taxAmount.toFixed(2)}
                </Typography>
              </Box>
              {quoteDetails.discount > 0 && (
                <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2 }}>
                  <Typography sx={{ fontSize: "14px", fontWeight: 400, fontFamily: "Open Sans", color: "#4B5563" }}>
                    Discount:
                  </Typography>
                  <Typography sx={{ fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#DC2626" }}>
                    -${quoteDetails.discount.toFixed(2)}
                  </Typography>
                </Box>
              )}
              <Divider sx={{ mb: 2 }} />
              <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                <Typography sx={{ fontSize: "16px", fontWeight: 700, fontFamily: "Open Sans", color: "#111827" }}>
                  Total:
                </Typography>
                <Typography sx={{ fontSize: "18px", fontWeight: 700, fontFamily: "Open Sans", color: "#111827" }}>
                  ${quoteDetails.total.toFixed(2)}
                </Typography>
              </Box>
            </Box>
          </Box>

          {/* Notes and Terms - Only show if they exist */}
          {(quoteDetails.notes || quoteDetails.terms) && (
            <Box sx={{ display: "flex", gap: 4, pt: 3, borderTop: "1px solid #E5E7EB" }}>
              {quoteDetails.notes && (
                <Box sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: "14px", fontWeight: 700, fontFamily: "Open Sans", color: "#111827", mb: 1 }}>
                    Notes:
                  </Typography>
                  <Typography sx={{ fontSize: "14px", fontWeight: 400, fontFamily: "Open Sans", color: "#4B5563", lineHeight: 1.7 }}>
                    {quoteDetails.notes}
                  </Typography>
                </Box>
              )}
              {quoteDetails.terms && (
                <Box sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: "14px", fontWeight: 700, fontFamily: "Open Sans", color: "#111827", mb: 1 }}>
                    Terms & Conditions:
                  </Typography>
                  <Typography sx={{ fontSize: "14px", fontWeight: 400, fontFamily: "Open Sans", color: "#4B5563", lineHeight: 1.7 }}>
                    {quoteDetails.terms}
                  </Typography>
                </Box>
              )}
            </Box>
          )}
        </Box>
      </DialogContent>
    </Dialog>
  );
};


export default QuoteViewDialog;
