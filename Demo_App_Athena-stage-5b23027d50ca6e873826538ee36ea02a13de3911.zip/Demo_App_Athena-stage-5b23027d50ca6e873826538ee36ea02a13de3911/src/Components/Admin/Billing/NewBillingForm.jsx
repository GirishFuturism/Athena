import React, { useState, useEffect } from 'react';
import TitleBreadcrumb from "../../Shared/TitleBreadcrumb";
import { 
  Grid, 
  Box, 
  Typography, 
  Button, 
  TextField, 
  MenuItem,
  Select,
  FormControl,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from "@mui/material";
import { 
  HomeIcon, 
} from '@heroicons/react/24/solid';
import { 
  DocumentTextIcon,
  EyeIcon
} from '@heroicons/react/24/outline';
import { useNavigate, useLocation } from 'react-router-dom';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import InvoiceViewDialog from "./InvoiceViewDialog";

const NewBillingForm = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // Dialog states
  const [draftDialogOpen, setDraftDialogOpen] = useState(false);
  const [updateDialogOpen, setUpdateDialogOpen] = useState(false);
  const [sendDialogOpen, setSendDialogOpen] = useState(false);
  const [previewDialogOpen, setPreviewDialogOpen] = useState(false);
  const [previewData, setPreviewData] = useState(null);

  // Check if we're in edit mode
  const isEditMode = location.state?.isEditMode || false;
  const existingInvoice = location.state?.invoiceData || null;

  // Service options
  const serviceOptions = [
    { value: 'ram', label: 'RAM', rate: 120 },
    { value: 'keyboard', label: 'Keyboard', rate: 85 },
    { value: 'motherboard', label: 'Motherboard', rate: 1200 },
    { value: 'monitor', label: 'Monitor', rate: 500 },
    { value: 'headphones', label: 'Headphones', rate: 150 },
    { value: 'webcam', label: 'WebCam', rate: 100 },
  ];

  // Client database
  const clientDatabase = {
    client1: {
      name: 'Acme Corporation',
      address: '456 Client Street, Los Angeles, CA 90210',
      email: 'billing@acmecorp.com',
    },
    client2: {
      name: 'TechStart Inc',
      address: '789 Innovation Drive, San Francisco, CA 94105',
      email: 'sarah@techstart.com',
    },
    client3: {
      name: 'Global Solutions',
      address: '321 Enterprise Blvd, Boston, MA 02101',
      email: 'mike@global.com',
    },
  };


 // Yup Validation Schema
const validationSchema = Yup.object({
  issueDate: Yup.date()
    .required('Issue date is required')
    .typeError('Invalid date format'),
  dueDate: Yup.date()
    .required('Due date is required')
    .min(Yup.ref('issueDate'), 'Due date must be after issue date')
    .typeError('Invalid date format'),
  selectedClient: Yup.string()
    .required('Please select a client'),
  clientName: Yup.string()
    .required('Client name is required')
    .min(2, 'Client name must be at least 2 characters'),
  clientAddress: Yup.string()
    .required('Client address is required')
    .min(5, 'Address must be at least 5 characters'),
  clientEmail: Yup.string()
    .required('Client email is required')
    .email('Invalid email format'),
  items: Yup.array()
    .of(
      Yup.object({
        service: Yup.string().required('Service is required'),
        qty: Yup.number()
          .required('Quantity is required')
          .min(1, 'Quantity must be at least 1'),
        rate: Yup.number()
          .required('Rate is required')
          .min(0, 'Rate cannot be negative'),
      })
    )
    .min(1, 'At least one item is required'),
  // notes: Yup.string().required('Notes are required'), // Added validation
  // terms: Yup.string().required('Terms & conditions are required'), // Added validation
});


  // Formik initialization
  const formik = useFormik({
    initialValues: {
      invoiceNumber: isEditMode ? (existingInvoice?.id || 'INV-2025-008') : 'INV-2025-012',
      referenceId: isEditMode ? 'REF-2025-456' : '',
      issueDate: isEditMode ? '2025-10-15' : '',
      dueDate: isEditMode ? '2025-12-15' : '',
      paymentStatus: isEditMode ? 'Pending' : 'Pending',
       selectedClient: isEditMode ? 'client2' : '', 
    clientName: isEditMode ? 'TechStart Inc' : '', 
    clientAddress: isEditMode ? '789 Innovation Drive, San Francisco, CA 94105' : '',
    clientEmail: isEditMode ? 'sarah@techstart.com' : '', 
      discount: isEditMode ? 50 : 0,
      items: isEditMode
        ? [
            { id: 1, service: 'ram', qty: 2, rate: 120, amount: 240 },
            { id: 2, service: 'keyboard', qty: 5, rate: 85, amount: 425 },
            { id: 3, service: 'motherboard', qty: 1, rate: 1200, amount: 1200 },
          ]
        : [{ id: 1, service: '', qty: 0, rate: 0, amount: 0 }],
      notes: isEditMode 
        ? 'Thank you for your business! Please ensure payment is made within the specified due date to avoid late fees.' 
        : '',
      terms: isEditMode 
        ? 'Payment is due within 30 days. Late payments may incur a 5% monthly interest charge.' 
        : '',
    },
    validationSchema,
    onSubmit: (values) => {
      console.log('Form submitted:', values);
    },
  });

  // Draft Dialog Handlers
  const handleSaveAsDraft = () => {
    setDraftDialogOpen(true);
  };

  const handleCloseDraftDialog = () => {
    setDraftDialogOpen(false);
  };

  const handleConfirmSaveDraft = () => {
    console.log('Saving as draft...');
    setDraftDialogOpen(false);
    navigate('/billing');
  };

  // Update Dialog Handlers
  const handleUpdateInvoice = () => {
    setUpdateDialogOpen(true);
  };

  const handleCloseUpdateDialog = () => {
    setUpdateDialogOpen(false);
  };

  const handleConfirmUpdate = async () => {
    const errors = await formik.validateForm();
    formik.setTouched({
      issueDate: true,
      dueDate: true,
      selectedClient: true,
      clientName: true,
      clientAddress: true,
      clientEmail: true,
      items: formik.values.items.map(() => ({ service: true, qty: true, rate: true })),
     
    });

    if (Object.keys(errors).length === 0) {
      console.log('Updating invoice...');
      setUpdateDialogOpen(false);
      navigate('/billing');
    } else {
      console.log('Validation errors:', errors);
      // alert('Please fill in all required fields correctly');
      setUpdateDialogOpen(false);
    }
  };

  // Send Invoice Dialog Handlers
// Send Invoice Dialog Handlers - WITH VALIDATION
const handleSendInvoice = async () => {
  // Validate form first
  const errors = await formik.validateForm();
  formik.setTouched({
    issueDate: true,
    dueDate: true,
    selectedClient: true,
    clientName: true,
    clientAddress: true,
    clientEmail: true,
    items: formik.values.items.map(() => ({ service: true, qty: true, rate: true })),
  });

  // Only open dialog if NO errors
  if (Object.keys(errors).length === 0) {
    setSendDialogOpen(true);
  } else {
    console.log('Validation errors:', errors);
    // Optionally show a toast/alert
    // alert('Please fill in all required fields correctly');
  }
};


  const handleCloseSendDialog = () => {
    setSendDialogOpen(false);
  };

  const isLastItemValid = () => {
  if (formik.values.items.length === 0) return true;
  
  const lastItem = formik.values.items[formik.values.items.length - 1];
  return lastItem.service && lastItem.service !== '' && lastItem.qty > 0;
};
  const handleConfirmSend = async () => {
    const errors = await formik.validateForm();
    formik.setTouched({
      issueDate: true,
      dueDate: true,
      selectedClient: true,
      clientName: true,
      clientAddress: true,
      clientEmail: true,
      items: formik.values.items.map(() => ({ service: true, qty: true, rate: true })),
      
    });

    if (Object.keys(errors).length === 0) {
      console.log('Sending invoice...');
      setSendDialogOpen(false);
      navigate('/billing');
    } else {
      console.log('Validation errors:', errors);
      // alert('Please fill in all required fields correctly');
      setSendDialogOpen(false);
    }
  };

// Preview Invoice Handler - Fixed with correct calculation
const handlePreviewInvoice = async () => {
  const errors = await formik.validateForm();
  formik.setTouched({
    issueDate: true,
    dueDate: true,
    selectedClient: true,
    clientName: true,
    clientAddress: true,
    clientEmail: true,
    items: formik.values.items.map(() => ({ service: true, qty: true, rate: true })),
  });

  if (Object.keys(errors).length === 0) {
    // Filter only items with service selected and qty > 0
    const validItems = formik.values.items.filter(
      item => item.service && item.service !== '' && item.qty > 0
    );

    // Calculate totals with CORRECT order - Apply discount FIRST, then tax
    const subtotal = formik.values.items.reduce((sum, item) => sum + item.amount, 0);
    const discount = parseFloat(formik.values.discount || 0);
    const subtotalAfterDiscount = subtotal - discount;
    const taxRate = 8.5;
    const taxAmount = subtotalAfterDiscount * (taxRate / 100);
    const total = subtotalAfterDiscount + taxAmount;

    const previewInvoiceData = {
      // Basic invoice info
      id: formik.values.invoiceNumber,
      invoiceNumber: formik.values.invoiceNumber,
      date: formik.values.issueDate,
      due: formik.values.dueDate,
      reference: formik.values.referenceId,
      status: formik.values.paymentStatus,
      paymentStatus: formik.values.paymentStatus,

      // Client info
      customer: formik.values.clientName,
      buyerName: formik.values.clientName,
      address: formik.values.clientAddress,
      buyerAddress: formik.values.clientAddress,
      email: formik.values.clientEmail,
      buyerEmail: formik.values.clientEmail,
      buyerPhone: '',

      // Company info
      companyName: "PSA Solutions Inc.",
      companyAddress: "123 Business Ave, Suite 100",
      companyCity: "New York, NY 10001",
      companyEmail: "contact@techsolutions.com",
      companyPhone: "(555) 123-4567",

      // Items - Map service values to labels with subdescription
      items: validItems.map(item => {
        const serviceLabel = {
          'ram': 'RAM',
          'keyboard': 'Keyboard',
          'motherboard': 'Motherboard',
          'monitor': 'Monitor',
          'headphones': 'Headphones',
          'webcam': 'WebCam',
        }[item.service] || item.service;

        return {
          description: serviceLabel,
          subDescription: "Product details",
          qty: item.qty,
          rate: item.rate,
          amount: item.amount,
        };
      }),

      // Totals - CORRECTED
      subtotal: subtotal,
      taxRate: taxRate,
      tax: taxAmount,
      taxAmount: taxAmount,
      discount: discount,
      total: total,

      // Notes and terms
      notes: formik.values.notes,
      terms: formik.values.terms,
    };
    
    setPreviewData(previewInvoiceData);
    setPreviewDialogOpen(true);
  } else {
    console.log('Validation errors:', errors);
  }
};




  const handleClosePreview = () => {
    setPreviewDialogOpen(false);
    setPreviewData(null);
  };

  // Client Selection Handler
  const handleClientSelect = (event) => {
    const clientId = event.target.value;
    const selectedClientData = clientDatabase[clientId];
    
    if (selectedClientData) {
      formik.setValues({
        ...formik.values,
        selectedClient: clientId,
        clientName: selectedClientData.name,
        clientAddress: selectedClientData.address,
        clientEmail: selectedClientData.email,
      });
    } else {
      formik.setValues({
        ...formik.values,
        selectedClient: '',
        clientName: '',
        clientAddress: '',
        clientEmail: '',
      });
    }
  };

  // Item Management Handlers
  const handleAddItem = () => {
    const newItems = [
      ...formik.values.items,
      {
        id: formik.values.items.length + 1,
        service: '',
        qty: 0,
        rate: 0,
        amount: 0,
      },
    ];
    formik.setFieldValue('items', newItems);
  };

  const handleRemoveItem = (id) => {
    if (formik.values.items.length > 1) {
      const newItems = formik.values.items.filter((item) => item.id !== id);
      formik.setFieldValue('items', newItems);
    }
  };

  const handleItemChange = (id, field, value) => {
    const newItems = formik.values.items.map((item) => {
      if (item.id === id) {
        const updatedItem = { ...item, [field]: value };
        
        if (field === 'service') {
          const selectedService = serviceOptions.find((s) => s.value === value);
          if (selectedService) {
            updatedItem.rate = selectedService.rate;
            updatedItem.amount = selectedService.rate * (updatedItem.qty || 0);
          }
        }
        
        if (field === 'qty' || field === 'rate') {
          updatedItem.amount = (updatedItem.qty || 0) * (updatedItem.rate || 0);
        }
        
        return updatedItem;
      }
      return item;
    });
    
    formik.setFieldValue('items', newItems);
  };


// Calculate totals - FIXED
const calculateTotals = () => {
  const subtotal = formik.values.items.reduce((sum, item) => sum + item.amount, 0);
  const discount = parseFloat(formik.values.discount || 0);
  
  // Apply discount FIRST, then calculate tax
  const subtotalAfterDiscount = subtotal - discount;
  const taxRate = 0.085;
  const tax = subtotalAfterDiscount * taxRate;
  const total = subtotalAfterDiscount + tax;
  
  return {
    subtotal: subtotal.toFixed(2),
    tax: tax.toFixed(2),
    discount: discount.toFixed(2),
    total: total.toFixed(2)
  };
};

  const totals = calculateTotals();

    const menuProps = {
  disableScrollLock: true,
  PaperProps: {
    sx: {
      maxHeight: 300,
      '&::-webkit-scrollbar': {
        display: 'none',
      },
      '-ms-overflow-style': 'none',
      'scrollbar-width': 'none',
    },
  },
};
return (
  <>
    <Grid
      container
      spacing={{ xs: 1, md: 2 }}
      columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
      sx={{
        width: "100%",
        maxWidth: "100vw",
        m: 0,
        p: { xs: 0, sm: 1 },
        justifyContent: "center",
        flexGrow: 1,
      }}
    >
      <Grid
        item
        size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{
          border: "1px solid #E4E4E7",
          backgroundColor: "#fff",
          px: { xs: 1, sm: 4, md: 6, xl: 3 },
          py: { xs: 0, sm: 3 },
          boxShadow: { xs: "none", sm: "0 2px 14px rgba(116,185,255,.08)" },
        }}
      >
        {/* Breadcrumb */}
        <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
          <HomeIcon style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8,cursor:"pointer" }} onClick={() => navigate("/admin")}/>
          <TitleBreadcrumb 
            breadcrumbsData={[
              { type: "link", label: "Service Desk", to: "/admin" }, 
              { type: "link", label: "Billing", to: "/billing" },
              { type: "text", label: isEditMode ? "Edit Invoice" : "New Invoice" }, 
            ]} 
          />
        </Box>

        {/* Main Header */}
        <Box 
          sx={{ 
            mt: 2, 
            pt: 1, 
            pb: 2,
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: 2
          }}
        >
          <Typography 
            sx={{ 
              fontFamily: "Open Sans", 
              fontSize: "24px", 
              fontWeight: "700", 
              color: "#111827" 
            }}
          >
            {isEditMode ? 'Edit Invoice' : 'New Invoice'}
          </Typography>
        </Box>

        {/* Sub Header with Invoice Number and Action Buttons */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 2,
            pb: 3,
            pt: 2,
            borderTop: "1px solid #E5E7EB",
            borderBottom: "1px solid #E5E7EB",
            mb: 3,
          }}
        >
          <Typography
            sx={{
              fontFamily: "Open Sans",
              fontSize: "24px",
              fontWeight: "600",
              color: "#111827",
            }}
          >
            {isEditMode ? 'Edit Invoice' : 'New Invoice'} <span style={{ color: "#111827", fontWeight: 400 }}>#{formik.values.invoiceNumber}</span>
          </Typography>

          <Box sx={{ display: "flex", gap: 2, pt: 2 }}>
            <Button
              onClick={handleSaveAsDraft}
              startIcon={<DocumentTextIcon style={{ width: 18, height: 18 }} />}
              sx={{
                textTransform: "none",
                fontSize: "14px",
                fontWeight: 600,
                fontFamily: "Open Sans",
                color: "#374151",
                bgcolor: "#FFFFFF",
                border: "1px solid #D1D5DB",
                px: 2.5,
                py: 0.75,
                borderRadius: "6px",
                boxShadow: "0 1px 2px rgba(0, 0, 0, 0.05)",
                "&:hover": {
                  bgcolor: "#F9FAFB",
                  borderColor: "#9CA3AF",
                  boxShadow: "0 1px 3px rgba(0, 0, 0, 0.1)",
                },
              }}
            >
              Save as Draft
            </Button>
            <Button
              onClick={handlePreviewInvoice}
              startIcon={<EyeIcon style={{ width: 18, height: 18 }} />}
              sx={{
                textTransform: "none",
                fontSize: "14px",
                fontWeight: 600,
                fontFamily: "Open Sans",
                bgcolor: "#FFFFFF",
                color: "#374151",
                border: "1px solid #D1D5DB",
                px: 2.5,
                py: 0.75,
                borderRadius: "6px",
                boxShadow: "0 1px 2px rgba(0, 0, 0, 0.05)",
                "&:hover": {
                  bgcolor: "#F9FAFB",
                  borderColor: "#9CA3AF",
                  boxShadow: "0 1px 3px rgba(0, 0, 0, 0.1)",
                },
              }}
            >
              Preview Invoice
            </Button>
          </Box>
        </Box>

        {/* Main Content Area */}
        <Box sx={{ mt: 3, mb: 2, width: "100%" }}>
          <Grid container spacing={2}>
            <Grid 
              container 
              size={{ xs: 12, sm: 12, md: 8.4 }} 
              sx={{ display: "flex", flexDirection: "column", gap: 2 }}
            >
              {/* Invoice Information Section */}
              <Box
                sx={{
                  bgcolor: "#FFFFFF",
                  border: "1px solid #E5E7EB",
                  borderRadius: "8px",
                  p: 3,
                }}
              >
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontSize: "18px",
                    fontWeight: 600,
                    color: "#111827",
                    mb: 3,
                    pb: 2,
                    borderBottom: "1px solid #F3F4F6",
                  }}
                >
                  Invoice Information
                </Typography>

                <Grid container spacing={3}>
                  {/* Invoice Number */}
                  <Grid size={{ xs: 12, sm: 12, md: 6, xl: 6 }}>
                    <Typography
                      sx={{
                        fontFamily: "Open Sans",
                        fontSize: "14px",
                        fontWeight: 500,
                        color: "#111827",
                        mb: 1,
                      }}
                    >
                      Invoice Number
                    </Typography>
                    <TextField
                      fullWidth
                      name="invoiceNumber"
                      value={formik.values.invoiceNumber}
                      slotProps={{
                        input: {
                          readOnly: true,
                        },
                      }}
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          fontFamily: "Open Sans",
                          fontSize: "14px",
                          borderRadius: "6px",
                          bgcolor: "#F9FAFB",
                          '& fieldset': {
                            borderColor: "#E5E7EB",
                          },
                        },
                        '& .MuiOutlinedInput-input': {
                          py: 1.25,
                          color: "#000",
                          fontWeight: 500,
                          cursor: "not-allowed",
                        },
                      }}
                    />
                  </Grid>

                  {/* Reference ID */}
                  <Grid size={{ xs: 12, sm: 12, md: 6, xl: 6 }}>
                    <Typography
                      sx={{
                        fontFamily: "Open Sans",
                        fontSize: "14px",
                        fontWeight: 500,
                        color: "#111827",
                        mb: 1,
                      }}
                    >
                      Reference ID
                    </Typography>
                    <TextField
                      fullWidth
                      name="referenceId"
                      placeholder="Optional reference"
                      value={formik.values.referenceId}
                      onChange={formik.handleChange}
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          fontFamily: "Open Sans",
                          fontSize: "14px",
                          borderRadius: "6px",
                          '& fieldset': {
                            borderColor: "#E5E7EB",
                          },
                          '&:hover fieldset': {
                            borderColor: "#D1D5DB",
                          },
                          '&.Mui-focused fieldset': {
                            borderColor: "#409BFF",
                          },
                        },
                        '& .MuiOutlinedInput-input': {
                          py: 1.25,
                          color: "#111827",
                          '&::placeholder': {
                            color: "#9CA3AF",
                            opacity: 1,
                          },
                        },
                      }}
                    />
                  </Grid>

                  {/* Issue Date */}
                  <Grid size={{ xs: 12, sm: 12, md: 6, xl: 6 }}>
                    <Typography
                      sx={{
                        fontFamily: "Open Sans",
                        fontSize: "14px",
                        fontWeight: 500,
                        color: "#111827",
                        mb: 1,
                      }}
                    >
                      Issue Date *
                    </Typography>
                    <TextField
                      fullWidth
                      type="date"
                      name="issueDate"
                      value={formik.values.issueDate}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      error={formik.touched.issueDate && Boolean(formik.errors.issueDate)}
                      helperText={formik.touched.issueDate && formik.errors.issueDate}
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          fontFamily: "Open Sans",
                          fontSize: "14px",
                          borderRadius: "6px",
                          '& fieldset': {
                            borderColor: formik.touched.issueDate && formik.errors.issueDate ? "#EF4444" : "#E5E7EB",
                          },
                          '&:hover fieldset': {
                            borderColor: "#D1D5DB",
                          },
                          '&.Mui-focused fieldset': {
                            borderColor: "#409BFF",
                          },
                        },
                        '& .MuiOutlinedInput-input': {
                          py: 1.25,
                          color: "#111827",
                        },
                        '& .MuiFormHelperText-root': {
                          fontFamily: "Open Sans",
                          fontSize: "12px",
                        },
                      }}
                    />
                  </Grid>

                  {/* Due Date */}
                  <Grid size={{ xs: 12, sm: 12, md: 6, xl: 6 }}>
                    <Typography
                      sx={{
                        fontFamily: "Open Sans",
                        fontSize: "14px",
                        fontWeight: 500,
                        color: "#111827",
                        mb: 1,
                      }}
                    >
                      Due Date *
                    </Typography>
                    <TextField
                      fullWidth
                      type="date"
                      name="dueDate"
                      value={formik.values.dueDate}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      error={formik.touched.dueDate && Boolean(formik.errors.dueDate)}
                      helperText={formik.touched.dueDate && formik.errors.dueDate}
                      disabled={!formik.values.issueDate}
                      InputProps={{
                        inputProps: {
                          min: formik.values.issueDate || undefined
                        }
                      }}
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          fontFamily: "Open Sans",
                          fontSize: "14px",
                          borderRadius: "6px",
                          bgcolor: !formik.values.issueDate ? "#F9FAFB" : "#fff",
                          '& fieldset': {
                            borderColor: formik.touched.dueDate && formik.errors.dueDate ? "#EF4444" : "#E5E7EB",
                          },
                          '&:hover fieldset': {
                            borderColor: formik.values.issueDate ? "#D1D5DB" : "#E5E7EB",
                          },
                          '&.Mui-focused fieldset': {
                            borderColor: "#409BFF",
                          },
                        },
                        '& .MuiOutlinedInput-input': {
                          py: 1.25,
                          color: "#111827",
                        },
                        '& .MuiFormHelperText-root': {
                          fontFamily: "Open Sans",
                          fontSize: "12px",
                        },
                      }}
                    />
                  </Grid>

                  {/* Payment Status */}
                  <Grid size={{ xs: 12, sm: 12, md: 6, xl: 6 }}>
                    <Typography
                      sx={{
                        fontFamily: "Open Sans",
                        fontSize: "14px",
                        fontWeight: 500,
                        color: "#111827",
                        mb: 1,
                      }}
                    >
                      Payment Status
                    </Typography>
                    <FormControl fullWidth>
                      <Select
                      MenuProps={menuProps}
                        name="paymentStatus"
                        value={formik.values.paymentStatus}
                        onChange={formik.handleChange}
                        sx={{
                          fontFamily: "Open Sans",
                          fontSize: "14px",
                          borderRadius: "6px",
                          '& .MuiOutlinedInput-notchedOutline': {
                            borderColor: "#E5E7EB",
                          },
                          '&:hover .MuiOutlinedInput-notchedOutline': {
                            borderColor: "#D1D5DB",
                          },
                          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                            borderColor: "#409BFF",
                          },
                          '& .MuiSelect-select': {
                            py: 1.25,
                            color: "#111827",
                            fontWeight: 500,
                          },
                        }}
                      >
                        <MenuItem value="Pending" sx={{ fontFamily: "Open Sans", fontSize: "14px" }}>
                          Pending
                        </MenuItem>
                        <MenuItem value="Paid" sx={{ fontFamily: "Open Sans", fontSize: "14px" }}>
                          Paid
                        </MenuItem>
                        <MenuItem value="Overdue" sx={{ fontFamily: "Open Sans", fontSize: "14px" }}>
                          Overdue
                        </MenuItem>
                      </Select>
                    </FormControl>
                  </Grid>
                </Grid>
              </Box>

              {/* Company Information Section */}
              <Box
                sx={{
                  bgcolor: "#FFFFFF",
                  border: "1px solid #E5E7EB",
                  borderRadius: "8px",
                  p: 3,
                }}
              >
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontSize: "18px",
                    fontWeight: 600,
                    color: "#111827",
                    mb: 3,
                    pb: 2,
                    borderBottom: "1px solid #F3F4F6",
                  }}
                >
                  Company Information
                </Typography>

                <Grid container spacing={3}>
                  {/* From (Your Company) */}
                  <Grid size={{ xs: 12, sm: 12, md: 6, xl: 6 }}>
                    <Typography
                      sx={{
                        fontFamily: "Open Sans",
                        fontSize: "14px",
                        fontWeight: 500,
                        color: "#111827",
                        mb: 2,
                      }}
                    >
                      From (Your Company)
                    </Typography>
                    
                    <Box
                      sx={{
                        bgcolor: "#F9FAFB",
                        border: "1px solid #E5E7EB",
                        borderRadius: "6px",
                        p: 2.5,
                      }}
                    >
                      <Typography
                        sx={{
                          fontFamily: "Open Sans",
                          fontSize: "15px",
                          fontWeight: 600,
                          color: "#111827",
                          mb: 1,
                        }}
                      >
                        PSA Solutions Inc.
                      </Typography>
                      <Typography
                        sx={{
                          fontFamily: "Open Sans",
                          fontSize: "14px",
                          fontWeight: 400,
                          color: "#4B5563",
                          lineHeight: 1.6,
                        }}
                      >
                        123 Business Ave, Suite 100
                      </Typography>
                      <Typography
                        sx={{
                          fontFamily: "Open Sans",
                          fontSize: "14px",
                          fontWeight: 400,
                          color: "#4B5563",
                          lineHeight: 1.6,
                        }}
                      >
                        New York, NY 10001
                      </Typography>
                      <Typography
                        sx={{
                          fontFamily: "Open Sans",
                          fontSize: "14px",
                          fontWeight: 400,
                          color: "#4B5563",
                          lineHeight: 1.6,
                        }}
                      >
                        contact@techsolutions.com
                      </Typography>
                      <Typography
                        sx={{
                          fontFamily: "Open Sans",
                          fontSize: "14px",
                          fontWeight: 400,
                          color: "#4B5563",
                          lineHeight: 1.6,
                        }}
                      >
                        (555) 123-4567
                      </Typography>
                    </Box>
                  </Grid>

                  {/* Bill To (Client) */}
                  <Grid size={{ xs: 12, sm: 12, md: 6, xl: 6 }}>
                    <Typography
                      sx={{
                        fontFamily: "Open Sans",
                        fontSize: "14px",
                        fontWeight: 500,
                        color: "#111827",
                        mb: 2,
                      }}
                    >
                      Bill To (Client) *
                    </Typography>

                    {/* Select Client Dropdown */}
                    <FormControl fullWidth sx={{ mb: 2 }}>
                      <Select
                      MenuProps={menuProps}
                        name="selectedClient"
                        value={formik.values.selectedClient}
                        onChange={handleClientSelect}
                        onBlur={formik.handleBlur}
                        displayEmpty
                        error={formik.touched.selectedClient && Boolean(formik.errors.selectedClient)}
                        sx={{
                          fontFamily: "Open Sans",
                          fontSize: "14px",
                          borderRadius: "6px",
                          '& .MuiOutlinedInput-notchedOutline': {
                            borderColor: formik.touched.selectedClient && formik.errors.selectedClient ? "#EF4444" : "#E5E7EB",
                          },
                          '&:hover .MuiOutlinedInput-notchedOutline': {
                            borderColor: "#D1D5DB",
                          },
                          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                            borderColor: "#409BFF",
                          },
                          '& .MuiSelect-select': {
                            py: 1.25,
                            color: "#111827",
                            fontWeight: 500,
                          },
                        }}
                      >
                        <MenuItem value="" sx={{ fontFamily: "Open Sans", fontSize: "14px", color: "#9CA3AF" }}>
                          Select Client
                        </MenuItem>
                        <MenuItem value="client1" sx={{ fontFamily: "Open Sans", fontSize: "14px" }}>
                          Acme Corporation
                        </MenuItem>
                        <MenuItem value="client2" sx={{ fontFamily: "Open Sans", fontSize: "14px" }}>
                          TechStart Inc
                        </MenuItem>
                        <MenuItem value="client3" sx={{ fontFamily: "Open Sans", fontSize: "14px" }}>
                          Global Solutions
                        </MenuItem>
                      </Select>
                      {formik.touched.selectedClient && formik.errors.selectedClient && (
                        <Typography sx={{ color: "#EF4444", fontSize: "12px", mt: 0.5, ml: 1.5, fontFamily: "Open Sans" }}>
                          {formik.errors.selectedClient}
                        </Typography>
                      )}
                    </FormControl>

                    {/* Company Name */}
                    <TextField
                      fullWidth
                      name="clientName"
                      placeholder="Company Name"
                      slotProps={{ input: { readOnly: true } }} 
                      value={formik.values.clientName}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      error={formik.touched.clientName && Boolean(formik.errors.clientName)}
                      helperText={formik.touched.clientName && formik.errors.clientName}
                      sx={{
                        mb: 2,
                        '& .MuiOutlinedInput-root': {
                          fontFamily: "Open Sans",
                          fontSize: "14px",
                          borderRadius: "6px",
                          '& fieldset': {
                            borderColor: formik.touched.clientName && formik.errors.clientName ? "#EF4444" : "#E5E7EB",
                          },
                          '&:hover fieldset': {
                            borderColor: "#D1D5DB",
                          },
                          '&.Mui-focused fieldset': {
                            borderColor: "#409BFF",
                          },
                        },
                        '& .MuiOutlinedInput-input': {
                          py: 1.25,
                          color: "#111827",
                          '&::placeholder': {
                            color: "#9CA3AF",
                            opacity: 1,
                          },
                        },
                        '& .MuiFormHelperText-root': {
                          fontFamily: "Open Sans",
                          fontSize: "12px",
                        },
                      }}
                    />

                    {/* Address */}
                    <TextField
                      fullWidth
                      slotProps={{ input: { readOnly: true } }} 
                      name="clientAddress"
                      placeholder="Address"
                      value={formik.values.clientAddress}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      error={formik.touched.clientAddress && Boolean(formik.errors.clientAddress)}
                      helperText={formik.touched.clientAddress && formik.errors.clientAddress}
                      sx={{
                        mb: 2,
                        '& .MuiOutlinedInput-root': {
                          fontFamily: "Open Sans",
                          fontSize: "14px",
                          borderRadius: "6px",
                          '& fieldset': {
                            borderColor: formik.touched.clientAddress && formik.errors.clientAddress ? "#EF4444" : "#E5E7EB",
                          },
                          '&:hover fieldset': {
                            borderColor: "#D1D5DB",
                          },
                          '&.Mui-focused fieldset': {
                            borderColor: "#409BFF",
                          },
                        },
                        '& .MuiOutlinedInput-input': {
                          py: 1.25,
                          color: "#111827",
                          '&::placeholder': {
                            color: "#9CA3AF",
                            opacity: 1,
                          },
                        },
                        '& .MuiFormHelperText-root': {
                          fontFamily: "Open Sans",
                          fontSize: "12px",
                        },
                      }}
                    />

                    {/* Email */}
                    <TextField
                      fullWidth
                      slotProps={{ input: { readOnly: true } }} 
                      name="clientEmail"
                      placeholder="Email"
                      type="email"
                      value={formik.values.clientEmail}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      error={formik.touched.clientEmail && Boolean(formik.errors.clientEmail)}
                      helperText={formik.touched.clientEmail && formik.errors.clientEmail}
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          fontFamily: "Open Sans",
                          fontSize: "14px",
                          borderRadius: "6px",
                          '& fieldset': {
                            borderColor: formik.touched.clientEmail && formik.errors.clientEmail ? "#EF4444" : "#E5E7EB",
                          },
                          '&:hover fieldset': {
                            borderColor: "#D1D5DB",
                          },
                          '&.Mui-focused fieldset': {
                            borderColor: "#409BFF",
                          },
                        },
                        '& .MuiOutlinedInput-input': {
                          py: 1.25,
                          color: "#111827",
                          '&::placeholder': {
                            color: "#9CA3AF",
                            opacity: 1,
                          },
                        },
                        '& .MuiFormHelperText-root': {
                          fontFamily: "Open Sans",
                          fontSize: "12px",
                        },
                      }}
                    />
                  </Grid>
                </Grid>
              </Box>

              {/* Itemized List Section */}
              <Box
                sx={{
                  bgcolor: "#FFFFFF",
                  border: "1px solid #E5E7EB",
                  borderRadius: "8px",
                  p: 3,
                }}
              >
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    mb: 3,
                    pb: 2,
                    borderBottom: "1px solid #F3F4F6",
                  }}
                >
                  <Typography
                    sx={{
                      fontFamily: "Open Sans",
                      fontSize: "18px",
                      fontWeight: 600,
                      color: "#111827",
                    }}
                  >
                    Itemized List *
                  </Typography>
                 <Button
  onClick={handleAddItem}
  disabled={!isLastItemValid()}
  startIcon={
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M12 5v14M5 12h14" />
    </svg>
  }
  sx={{
    textTransform: "none",
    fontSize: "14px",
    fontWeight: 600,
    fontFamily: "Open Sans",
    color: isLastItemValid() ? "#409BFF" : "#9CA3AF",
    bgcolor: isLastItemValid() ? "#EFF6FF" : "#F3F4F6",
    borderRadius: "8px",
    border: "1px solid",
    borderColor: isLastItemValid() ? "#BFDBFE" : "#D1D5DB",
    px: 2,
    py: 0.75,
    cursor: isLastItemValid() ? "pointer" : "not-allowed",
    "&:hover": { 
      bgcolor: isLastItemValid() ? "#DBEAFE" : "#F3F4F6"
    },
  }}
>
  Add Item
</Button>

                </Box>

                <Grid container spacing={2} sx={{ mb: 2 }}>
                  <Grid size={{ xs: 12, sm: 12, md: 5, xl: 5 }}>
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 600, color: "#374151" }}>
                      Description
                    </Typography>
                  </Grid>
                  <Grid size={{ xs: 12, sm: 12, md: 2, xl: 2 }}>
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 600, color: "#374151", textAlign: "center" }}>
                      Qty
                    </Typography>
                  </Grid>
                  <Grid size={{ xs: 12, sm: 12, md: 2, xl: 2 }}>
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 600, color: "#374151", textAlign: "center" }}>
                      Rate
                    </Typography>
                  </Grid>
                  <Grid size={{ xs: 12, sm: 12, md: 2, xl: 2 }}>
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 600, color: "#374151", textAlign: "right" }}>
                      Amount
                    </Typography>
                  </Grid>
                  <Grid size={{ xs: 12, sm: 12, md: 1, xl: 1 }}></Grid>
                </Grid>

                {formik.values.items.map((item, index) => (
                  <Grid container spacing={2} key={item.id} sx={{ mb: 2 }}>
                    <Grid size={{ xs: 12, sm: 12, md: 5, xl: 5 }}>
                      <FormControl fullWidth>
                        <Select
                        MenuProps={menuProps}
                          value={item.service}
                          onChange={(e) => handleItemChange(item.id, 'service', e.target.value)}
                          onBlur={formik.handleBlur}
                          displayEmpty
                          error={formik.touched.items?.[index]?.service && !item.service}
                          sx={{
                            fontFamily: "Open Sans",
                            fontSize: "14px",
                            borderRadius: "6px",
                            '& .MuiOutlinedInput-notchedOutline': {
                              borderColor: formik.touched.items?.[index]?.service && !item.service ? "#EF4444" : "#E5E7EB",
                            },
                            '&:hover .MuiOutlinedInput-notchedOutline': {
                              borderColor: "#D1D5DB",
                            },
                            '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                              borderColor: "#409BFF",
                            },
                            '& .MuiSelect-select': {
                              py: 1.25,
                              color: "#111827",
                              fontWeight: 500,
                            },
                          }}
                        >
                          <MenuItem value="" disabled sx={{ fontFamily: "Open Sans", fontSize: "14px", color: "#9CA3AF" }}>
                            Select Service
                          </MenuItem>
                          {serviceOptions.map((service) => (
                            <MenuItem key={service.value} value={service.value} sx={{ fontFamily: "Open Sans", fontSize: "14px" }}>
                              {service.label}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Grid>

                  <Grid size={{ xs: 12, sm: 12, md: 2, xl: 2 }}>
  <TextField
    fullWidth
    type="number"
    value={item.qty === 0 ? '' : item.qty}
    onChange={(e) => {
      const value = parseFloat(e.target.value) || 0;
      // Prevent negative values
      if (value < 0) return;
      handleItemChange(item.id, 'qty', value);
    }}
    onFocus={(e) => e.target.select()}
    placeholder="0"
    inputProps={{ min: 0 }} // HTML5 validation to prevent negative
    error={formik.touched.items?.[index]?.qty && item.qty === 0}
    sx={{
      '& .MuiOutlinedInput-root': {
        fontFamily: "Open Sans",
        fontSize: "14px",
        borderRadius: "6px",
        '& fieldset': {
          borderColor: formik.touched.items?.[index]?.qty && item.qty === 0 ? "#EF4444" : "#E5E7EB",
        },
        '&:hover fieldset': {
          borderColor: "#D1D5DB",
        },
        '&.Mui-focused fieldset': {
          borderColor: "#409BFF",
        },
      },
      '& .MuiOutlinedInput-input': {
        py: 1.25,
        textAlign: "center",
        color: "#111827",
        fontWeight: 500,
        '&::placeholder': {
          color: "#9CA3AF",
          opacity: 1,
        },
      },
    }}
  />
</Grid>


                   <Grid size={{ xs: 12, sm: 12, md: 2, xl: 2 }}>
 <TextField 
    fullWidth 
    type="text" 
    value={item.rate === 0 ? '' : `$${parseFloat(item.rate).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`} 
    onChange={(e) => { 
      const value = e.target.value.replace(/[$,]/g, ''); 
      if (!/^\d*\.?\d*$/.test(value)) return; 
      const numValue = value === '' ? 0 : parseFloat(value) || 0;
      handleItemChange(item.id, 'rate', numValue); 
    }} 
    onFocus={(e) => { 
      const rawValue = e.target.value.replace(/[$,]/g, ''); 
      e.target.value = rawValue; 
      e.target.select(); 
    }} 
    onBlur={(e) => { 
      formik.handleBlur(e); 
    }} 
    name={`items[${index}].rate`}
    placeholder="$0.00" 
    inputProps={{ inputMode: 'decimal' }} 
    error={formik.touched.items?.[index]?.rate && item.rate === 0}
    sx={{ 
      '& .MuiOutlinedInput-root': { 
        fontFamily: "Open Sans", 
        fontSize: "14px", 
        borderRadius: "6px", 
        '& fieldset': { 
          borderColor: formik.touched.items?.[index]?.rate && item.rate === 0 ? "#EF4444" : "#E5E7EB" 
        }, 
        '&:hover fieldset': { borderColor: "#D1D5DB" }, 
        '&.Mui-focused fieldset': { borderColor: "#409BFF" } 
      }, 
      '& .MuiOutlinedInput-input': { 
        py: 1.25, 
        textAlign: "center", 
        color: "#111827", 
        fontWeight: 500, 
        '&::placeholder': { color: "#9CA3AF", opacity: 1 } 
      } 
    }} 
  />
</Grid>


                    <Grid size={{ xs: 12, sm: 12, md: 2, xl: 2 }}>
                      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "flex-end", height: "100%", py: 1.25 }}>
                        <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 600, color: "#111827" }}>
                          ${item.amount.toFixed(2)}
                        </Typography>
                      </Box>
                    </Grid>

                    <Grid size={{ xs: 12, sm: 12, md: 1, xl: 1 }}>
                      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100%" }}>
                        <IconButton
                          onClick={() => handleRemoveItem(item.id)}
                          disabled={formik.values.items.length === 1}
                          sx={{
                            color: formik.values.items.length === 1 ? "#D1D5DB" : "#EF4444",
                            "&:hover": {
                              bgcolor: formik.values.items.length === 1 ? "transparent" : "#FEE2E2",
                            },
                          }}
                        >
                          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" />
                          </svg>
                        </IconButton>
                      </Box>
                    </Grid>
                  </Grid>
                ))}
              </Box>

              {/* Additional Information */}
              <Box sx={{ bgcolor: "#FFFFFF", border: "1px solid #E5E7EB", borderRadius: "8px", p: 3 }}>
                <Typography sx={{ fontFamily: "Open Sans", fontSize: "18px", fontWeight: 600, color: "#111827", mb: 3, pb: 2, borderBottom: "1px solid #F3F4F6" }}>
                  Additional Information
                </Typography>
<Box sx={{ mb: 3 }}>
  <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 500, color: "#111827", mb: 1 }}>
    Notes 
  </Typography>
  <TextField
    fullWidth
    multiline
    rows={4}
    name="notes"
    placeholder="Add additional notes or messages for the client..."
    value={formik.values.notes}
    onChange={formik.handleChange}
    onBlur={formik.handleBlur}
    error={formik.touched.notes && Boolean(formik.errors.notes)}
    helperText={formik.touched.notes && formik.errors.notes}
    sx={{
      '& .MuiOutlinedInput-root': {
        fontFamily: "Open Sans",
        fontSize: "14px",
        borderRadius: "6px",
        '& fieldset': {
          borderColor: formik.touched.notes && formik.errors.notes ? "#EF4444" : "#E5E7EB"
        },
        '&:hover fieldset': {
          borderColor: "#D1D5DB"
        },
        '&.Mui-focused fieldset': {
          borderColor: "#409BFF"
        }
      },
      '& .MuiOutlinedInput-input': {
        color: "#111827",
        '&::placeholder': {
          color: "#9CA3AF",
          opacity: 1
        }
      },
      '& .MuiFormHelperText-root': {
        fontFamily: "Open Sans",
        fontSize: "12px"
      }
    }}
  />
</Box>


                <Box>
  <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 500, color: "#111827", mb: 1 }}>
    Terms & Conditions 
  </Typography>
  <TextField
    fullWidth
    multiline
    rows={4}
    name="terms"
    placeholder="Specify payment terms, service charge info, etc..."
    value={formik.values.terms}
    onChange={formik.handleChange}
    onBlur={formik.handleBlur}
    error={formik.touched.terms && Boolean(formik.errors.terms)}
    helperText={formik.touched.terms && formik.errors.terms}
    sx={{
      '& .MuiOutlinedInput-root': {
        fontFamily: "Open Sans",
        fontSize: "14px",
        borderRadius: "6px",
        '& fieldset': {
          borderColor: formik.touched.terms && formik.errors.terms ? "#EF4444" : "#E5E7EB"
        },
        '&:hover fieldset': {
          borderColor: "#D1D5DB"
        },
        '&.Mui-focused fieldset': {
          borderColor: "#409BFF"
        }
      },
      '& .MuiOutlinedInput-input': {
        color: "#111827",
        '&::placeholder': {
          color: "#9CA3AF",
          opacity: 1
        }
      },
      '& .MuiFormHelperText-root': {
        fontFamily: "Open Sans",
        fontSize: "12px"
      }
    }}
  />
</Box>

              </Box>
            </Grid>

            {/* Invoice Summary Sidebar */}
            <Grid item size={{ xs: 12, sm: 12, md: 3.6 }}>
              <Box sx={{ bgcolor: "#FFFFFF", border: "1px solid #E5E7EB", borderRadius: "8px", p: 3, position: "sticky", top: 80 }}>
                <Typography sx={{ fontFamily: "Open Sans", fontSize: "18px", fontWeight: 600, color: "#111827", mb: 3, pb: 2, borderBottom: "1px solid #F3F4F6" }}>
                  Invoice Summary
                </Typography>

                <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2.5 }}>
                  <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 400, color: "#6B7280" }}>Subtotal</Typography>
                  <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 600, color: "#111827" }}>${totals.subtotal}</Typography>
                </Box>

                <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2.5 }}>
                  <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 400, color: "#6B7280" }}>Tax (8.5%)</Typography>
                  <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 600, color: "#111827" }}>${totals.tax}</Typography>
                </Box>

                <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 3, gap: 2 }}>
                  <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 400, color: "#6B7280" }}>Discount</Typography>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <TextField
                      type="number"
                      name="discount"
                      value={formik.values.discount === 0 ? '' : formik.values.discount}
                      onChange={formik.handleChange}
                      onFocus={(e) => e.target.select()}
                      placeholder="0"
                      sx={{
                        width: "70px",
                        '& .MuiOutlinedInput-root': {
                          fontFamily: "Open Sans",
                          fontSize: "13px",
                          borderRadius: "4px",
                          '& fieldset': { borderColor: "#E5E7EB" },
                          '&:hover fieldset': { borderColor: "#D1D5DB" },
                          '&.Mui-focused fieldset': { borderColor: "#409BFF" },
                        },
                        '& .MuiOutlinedInput-input': {
                          py: 0.75,
                          px: 1,
                          textAlign: "center",
                          color: "#111827",
                          fontWeight: 500,
                          '&::placeholder': { color: "#9CA3AF", opacity: 1 },
                        },
                      }}
                    />
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: "14px", fontWeight: 600, color: "#111827" }}>
                      ${totals.discount}
                    </Typography>
                  </Box>
                </Box>

                <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", pt: 3, pb: 3, borderTop: "1px solid #E5E7EB", borderBottom: "1px solid #E5E7EB", mb: 3 }}>
                  <Typography sx={{ fontFamily: "Open Sans", fontSize: "18px", fontWeight: 700, color: "#111827" }}>Total</Typography>
                  <Typography sx={{ fontFamily: "Open Sans", fontSize: "24px", fontWeight: 700, color: "#409BFF" }}>${totals.total}</Typography>
                </Box>

                {isEditMode ? (
                  <>
                    <Button
                      fullWidth
                      onClick={handleUpdateInvoice}
                      sx={{
                        textTransform: "none",
                        fontSize: "15px",
                        fontWeight: 600,
                        fontFamily: "Open Sans",
                        bgcolor: "#409BFF",
                        color: "#FFFFFF",
                        py: 1.25,
                        borderRadius: "6px",
                        mb: 2,
                        boxShadow: "none",
                        "&:hover": { bgcolor: "#2563EB", boxShadow: "none" },
                      }}
                    >
                      Update
                    </Button>
                    <Button
                      fullWidth
                      startIcon={<DocumentTextIcon style={{ width: 18, height: 18 }} />}
                      onClick={handleSaveAsDraft}
                      sx={{
                        textTransform: "none",
                        fontSize: "15px",
                        fontWeight: 600,
                        fontFamily: "Open Sans",
                        bgcolor: "#FFFFFF",
                        color: "#374151",
                        border: "1px solid #E5E7EB",
                        py: 1.25,
                        borderRadius: "6px",
                        boxShadow: "none",
                        "&:hover": { bgcolor: "#F9FAFB", borderColor: "#D1D5DB", boxShadow: "none" },
                      }}
                    >
                      Save as Draft
                    </Button>
                  </>
                ) : (
                  <>
                    <Button
                      fullWidth
                      onClick={handleSendInvoice}
                      startIcon={
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" />
                        </svg>
                      }
                      sx={{
                        textTransform: "none",
                        fontSize: "15px",
                        fontWeight: 600,
                        fontFamily: "Open Sans",
                        bgcolor: "#409BFF",
                        color: "#FFFFFF",
                        py: 1.25,
                        borderRadius: "6px",
                        mb: 2,
                        boxShadow: "none",
                        "&:hover": { bgcolor: "#2563EB", boxShadow: "none" },
                      }}
                    >
                      Save & Send Invoice
                    </Button>
                    <Button
                      fullWidth
                      startIcon={<DocumentTextIcon style={{ width: 18, height: 18 }} />}
                      onClick={handleSaveAsDraft}
                      sx={{
                        textTransform: "none",
                        fontSize: "15px",
                        fontWeight: 600,
                        fontFamily: "Open Sans",
                        bgcolor: "#FFFFFF",
                        color: "#374151",
                        border: "1px solid #E5E7EB",
                        py: 1.25,
                        borderRadius: "6px",
                        boxShadow: "none",
                        "&:hover": { bgcolor: "#F9FAFB", borderColor: "#D1D5DB", boxShadow: "none" },
                      }}
                    >
                      Save as Draft
                    </Button>
                  </>
                )}
              </Box>
            </Grid>
          </Grid>
        </Box>
      </Grid>
    </Grid>

    {/* Dialogs */}
    <Dialog disableScrollLock open={draftDialogOpen} onClose={handleCloseDraftDialog} maxWidth="sm" fullWidth PaperProps={{ sx: { borderRadius: "12px", boxShadow: "0 8px 32px rgba(0, 0, 0, 0.12)" } }}>
      <DialogTitle sx={{ fontFamily: "Open Sans", fontSize: "20px", fontWeight: 700, color: "#111827", pb: 2 }}>
        Save Invoice as Draft?
      </DialogTitle>
      <DialogContent>
        <Typography sx={{ fontFamily: "Open Sans", fontSize: "15px", fontWeight: 400, color: "#6B7280", lineHeight: 1.6 }}>
          This invoice will be saved as a draft and can be edited later. You can find it in the drafts section of your billing dashboard.
        </Typography>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 3, pt: 2 }}>
        <Button onClick={handleCloseDraftDialog} sx={{ textTransform: "none", fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#6B7280", px: 3, py: 1, "&:hover": { bgcolor: "#F3F4F6" } }}>
          Cancel
        </Button>
        <Button onClick={handleConfirmSaveDraft} startIcon={<DocumentTextIcon style={{ width: 18, height: 18 }} />} sx={{ textTransform: "none", fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", bgcolor: "#409BFF", color: "#FFFFFF", px: 3, py: 1, "&:hover": { bgcolor: "#2563EB" } }}>
          Save as Draft
        </Button>
      </DialogActions>
    </Dialog>

    <Dialog disableScrollLock open={updateDialogOpen} onClose={handleCloseUpdateDialog} maxWidth="sm" fullWidth PaperProps={{ sx: { borderRadius: "12px", boxShadow: "0 8px 32px rgba(0, 0, 0, 0.12)" } }}>
      <DialogTitle sx={{ fontFamily: "Open Sans", fontSize: "20px", fontWeight: 700, color: "#111827", pb: 2 }}>
        Update Invoice?
      </DialogTitle>
      <DialogContent>
        <Typography sx={{ fontFamily: "Open Sans", fontSize: "15px", fontWeight: 400, color: "#6B7280", lineHeight: 1.6 }}>
          Are you sure you want to update this invoice? All changes will be saved and reflected immediately.
        </Typography>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 3, pt: 2 }}>
        <Button onClick={handleCloseUpdateDialog} sx={{ textTransform: "none", fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#6B7280", px: 3, py: 1, "&:hover": { bgcolor: "#F3F4F6" } }}>
          Cancel
        </Button>
        <Button onClick={handleConfirmUpdate} startIcon={<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 13l4 4L19 7" /></svg>} sx={{ textTransform: "none", fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", bgcolor: "#409BFF", color: "#FFFFFF", px: 3, py: 1, "&:hover": { bgcolor: "#2563EB" } }}>
          Update Invoice
        </Button>
      </DialogActions>
    </Dialog>

    <Dialog disableScrollLock open={sendDialogOpen} onClose={handleCloseSendDialog} maxWidth="sm" fullWidth PaperProps={{ sx: { borderRadius: "12px", boxShadow: "0 8px 32px rgba(0, 0, 0, 0.12)" } }}>
      <DialogTitle sx={{ fontFamily: "Open Sans", fontSize: "20px", fontWeight: 700, color: "#111827", pb: 2 }}>
        Send Invoice?
      </DialogTitle>
      <DialogContent>
        <Typography sx={{ fontFamily: "Open Sans", fontSize: "15px", fontWeight: 400, color: "#6B7280", lineHeight: 1.6 }}>
          This invoice will be saved and sent to the client via email. They will receive a notification with the invoice details and payment instructions.
        </Typography>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 3, pt: 2 }}>
        <Button onClick={handleCloseSendDialog} sx={{ textTransform: "none", fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", color: "#6B7280", px: 3, py: 1, "&:hover": { bgcolor: "#F3F4F6" } }}>
          Cancel
        </Button>
        <Button onClick={handleConfirmSend} startIcon={<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" /></svg>} sx={{ textTransform: "none", fontSize: "14px", fontWeight: 600, fontFamily: "Open Sans", bgcolor: "#409BFF", color: "#FFFFFF", px: 3, py: 1, "&:hover": { bgcolor: "#2563EB" } }}>
          Save & Send Invoice
        </Button>
      </DialogActions>
    </Dialog>

    <InvoiceViewDialog open={previewDialogOpen} onClose={handleClosePreview} invoiceData={previewData} />
  </>
);

};

export default NewBillingForm;