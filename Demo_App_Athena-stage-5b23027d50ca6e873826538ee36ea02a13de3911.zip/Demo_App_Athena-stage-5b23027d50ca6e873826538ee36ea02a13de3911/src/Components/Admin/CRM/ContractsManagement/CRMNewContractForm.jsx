import React, { useState, useEffect } from "react";
import { 
  Grid, Box, Typography, TextField, MenuItem, IconButton, 
  Button, Dialog, DialogContent, Select, FormControl, 
  FormHelperText, Checkbox, FormControlLabel 
} from "@mui/material";
import TitleBreadcrumb from "../../../Shared/TitleBreadcrumb";
import { useNavigate, useLocation } from "react-router-dom";
import { useFormik } from "formik";
import * as Yup from "yup";
import {
  HomeIcon,
  CheckCircleIcon,
  XMarkIcon,
  MagnifyingGlassIcon,
} from "@heroicons/react/24/solid";
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { parse } from 'date-fns';

const validationSchema = Yup.object({
  client: Yup.string().required("Client is required"),
  contractType: Yup.string().required("Contract Type is required"),
  contractReference: Yup.string().required("Contract Reference is required"),
  labourType: Yup.string().required("Labour Type is required"),
  startDate: Yup.date().required("Start date is required").nullable(),
  labourPeriod: Yup.string().required("Labour Period is required"),
  endDateType: Yup.string().required("End date type is required"),
});

const CRMNewContractForm = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [successDialogOpen, setSuccessDialogOpen] = useState(false);
  const [unlimitedHours, setUnlimitedHours] = useState(false);

  // Get contract data from navigation state
  const contractData = location.state?.contractData;

  // Helper function to parse date string
  const parseDate = (dateString) => {
    if (!dateString) return null;
    try {
      return parse(dateString, 'MM/dd/yyyy', new Date());
    } catch {
      return null;
    }
  };

  // Helper function to map client name to value
  const getClientValue = (clientName) => {
    const clientMap = {
      "Terry's Chocolates": "terry-chocolates",
      "Acorn Construction": "acorn-construction",
      "Freston Cakes and Bakery": "freston-cakes",
      "Futurism Technologies": "futurism-tech"
    };
    return clientMap[clientName] || "";
  };

  // Helper function to map contract type name to value
  const getContractTypeValue = (typeName) => {
    const typeMap = {
      "Gold Package": "gold",
      "Silver Package": "silver",
      "Bronze Package": "bronze"
    };
    return typeMap[typeName] || "";
  };

  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

 const formik = useFormik({
  initialValues: {
    client: contractData ? getClientValue(contractData.client) : "",
    contractType: contractData ? getContractTypeValue(contractData.contractType) : "",
    agreementSubtype: contractData ? "type1" : "",
    contractReference: contractData ? contractData.ref : "",
    labourType: "fixed",
    startDate: contractData ? parseDate(contractData.startDate) : null,
    nextCallDate: contractData ? parseDate(contractData.startDate) : null, // ✅ Now prefilled
    labourPeriod: contractData ? contractData.billingPeriod?.toLowerCase() : "",
    endDateType: "periods",
    numberOfPeriods: "12",
    hoursPerPeriod: "160",
    costPerPeriod: "",
    sla: "sla1",
    doNotCharge: false,
    pdfTemplate: "template1",
    fromAddress: "address1",
    contractEmail: "contracts@company.com",
    contractEmailCC: "admin@company.com",
    notes: "Contract also covers some laptops that we do not record on the system",
    status: contractData ? contractData.status : "",
    active: true,
    dateSent: null,
    dateReceived: null,
  },
  validationSchema,
  onSubmit: (values) => {
    console.log("Form submitted:", values);
    setSuccessDialogOpen(true);
    setTimeout(() => { 
      navigate('/crm-contract-management'); 
    }, 2000);
  },
});


  const generateReference = () => {
    const randomRef = 'CR-' + Math.random().toString(36).substring(2, 9).toUpperCase();
    formik.setFieldValue("contractReference", randomRef);
  };

  // Handler to prevent negative values and invalid characters
  const handleNumberKeyDown = (e) => {
    if (e.key === "e" || e.key === "E" || e.key === "-" || e.key === "+") {
      e.preventDefault();
    }
  };

  // Handler for hours per period input change
  const handleHoursChange = (e) => {
    const value = e.target.value;
    if (value === "" || parseFloat(value) >= 0) {
      formik.handleChange(e);
    }
  };

  // Handler for number of periods input change
  const handlePeriodsChange = (e) => {
    const value = e.target.value;
    if (value === "" || parseFloat(value) >= 0) {
      formik.handleChange(e);
    }
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <form onSubmit={formik.handleSubmit}>
        <Grid 
          container 
          spacing={{ xs: 1, md: 2 }} 
          columns={{ xs: 12, sm: 12, md: 12, xl: 12 }} 
          sx={{ 
            width: "100%", 
            maxWidth: "100vw", 
            m: 0, 
            p: { xs: 0, sm: 1 }, 
            justifyContent: "center", 
            flexGrow: 1 
          }}
        >
          <Grid 
            item 
            size={{ xs: 12, sm: 12, md: 12, xl: 12 }} 
            sx={{ 
              border: "1px solid #E4E4E7", 
              backgroundColor: "#fff", 
              px: { xs: 1, sm: 4, md: 6, xl: 3 }, 
              py: { xs: 0, sm: 3 }, 
              boxShadow: { xs: "none", sm: "0 2px 14px rgba(116,185,255,.08)" } 
            }}
          >
            
            {/* Breadcrumb */}
            <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
              <HomeIcon 
                style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8, cursor: "pointer" }} 
                onClick={() => navigate("/admin")}
              />
              <TitleBreadcrumb breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin" }, 
                { type: "link", label: "CRM", to: "/crm-contract-management" },
                { type: "link", label: "Contract", to:'/crm-contract-management'},
                { type: "text", label: contractData ? "Edit Contract" : "New" }
              ]} />
            </Box>

            {/* Title */}
            <Typography sx={{ fontSize: 24, fontWeight: 700, mb: 0.5, color: "#111827", fontFamily: 'Open Sans' }}>
              {contractData ? "Edit Contract" : "Create New Contract"}
            </Typography>

            {/* Subtitle */}
            <Typography sx={{ fontSize: 15, fontWeight: 400, mb: 4, color: "#4B5563", fontFamily: 'Open Sans' }}>
              {contractData ? "Update the contract details below" : "Fill out the form below to create a new contract"}
            </Typography>

            {/* Contract Information Section */}
            <Box sx={{ border: "1px solid #E4E4E7", borderRadius: "8px", p: 3, mb: 3 }}>
              <Typography sx={{ fontSize: 18, fontWeight: 600, mb: 2.5, color: "#000", fontFamily: 'Open Sans' }}>
                Contract Information
              </Typography>

              {/* Row 1: Client, Contract Type, Agreement Subtype */}
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item size = {{xs:12, sm:6, md:4}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Client <span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <Box sx={{ position: "relative" }}>
                    <FormControl 
                      fullWidth 
                      size="small" 
                      error={formik.touched.client && Boolean(formik.errors.client)}
                    >
                      <Select
                        name="client"
                        value={formik.values.client}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        displayEmpty
                        MenuProps={menuProps}
                        sx={{
                          fontSize: 13,
                          fontFamily: 'Open Sans',
                          backgroundColor: "#fff",
                          height: 36,
                          paddingRight: "32px",
                          "& .MuiOutlinedInput-notchedOutline": { 
                            borderColor: formik.touched.client && formik.errors.client ? "#EF4444" : "#D1D5DB" 
                          },
                          "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                          "& .MuiSelect-select": { 
                            color: formik.values.client ? "#000" : "#A1A1AA" 
                          }
                        }}
                      >
                        <MenuItem value="">Select...</MenuItem>
                        <MenuItem value="terry-chocolates">Terry's Chocolates</MenuItem>
                        <MenuItem value="acorn-construction">Acorn Construction</MenuItem>
                        <MenuItem value="freston-cakes">Freston Cakes and Bakery</MenuItem>
                        <MenuItem value="futurism-tech">Futurism Technologies</MenuItem>
                      </Select>
                      {formik.touched.client && formik.errors.client && (
                        <FormHelperText>{formik.errors.client}</FormHelperText>
                      )}
                    </FormControl>
                  </Box>
                </Grid>

                <Grid item size = {{xs:12, sm:6, md:4}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Contract Type
                  </Typography>
                  <FormControl 
                    fullWidth 
                    size="small"
                    error={formik.touched.contractType && Boolean(formik.errors.contractType)}
                  >
                    <Select
                      name="contractType"
                      value={formik.values.contractType}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& .MuiOutlinedInput-notchedOutline": { 
                          borderColor: formik.touched.contractType && formik.errors.contractType ? "#EF4444" : "#D1D5DB" 
                        },
                        "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { 
                          color: formik.values.contractType ? "#000" : "#A1A1AA" 
                        }
                      }}
                    >
                      <MenuItem value="">No Billing Description</MenuItem>
                      <MenuItem value="gold">Gold Package</MenuItem>
                      <MenuItem value="silver">Silver Package</MenuItem>
                      <MenuItem value="bronze">Bronze Package</MenuItem>
                    </Select>
                    {formik.touched.contractType && formik.errors.contractType && (
                      <FormHelperText>{formik.errors.contractType}</FormHelperText>
                    )}
                  </FormControl>
                </Grid>

                <Grid item size = {{xs:12, sm:6, md:4}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Agreement Subtype
                  </Typography>
                  <FormControl fullWidth size="small">
                    <Select
                      name="agreementSubtype"
                      value={formik.values.agreementSubtype}
                      onChange={formik.handleChange}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { 
                          color: formik.values.agreementSubtype ? "#000" : "#A1A1AA" 
                        }
                      }}
                    >
                      <MenuItem value="">*Not set*</MenuItem>
                      <MenuItem value="type1">Type 1</MenuItem>
                      <MenuItem value="type2">Type 2</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
              </Grid>

              {/* Row 2: Contract Reference with Generate Button */}
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item size = {{xs:12, sm:6, md:5}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Contract Reference <span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <Box sx={{ display: "flex", gap: 1, alignItems: "flex-start" }}>
                    <TextField 
                      fullWidth 
                      size="small" 
                      name="contractReference"
                      placeholder="Enter contract reference"
                      value={formik.values.contractReference}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      error={formik.touched.contractReference && Boolean(formik.errors.contractReference)}
                      helperText={formik.touched.contractReference && formik.errors.contractReference}
                      sx={{
                        "& .MuiOutlinedInput-root": { 
                          fontSize: 13, 
                          fontFamily: 'Open Sans', 
                          backgroundColor: "#fff", 
                          height: 36, 
                          "& fieldset": { 
                            borderColor: formik.touched.contractReference && formik.errors.contractReference ? "#EF4444" : "#D1D5DB" 
                          }, 
                          "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                          "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                        }
                      }} 
                    />
                    <Button
                      onClick={generateReference}
                      sx={{
                        backgroundColor: "#409BFF",
                        color: "#fff",
                        fontSize: 13,
                        fontWeight: 600,
                        fontFamily: 'Open Sans',
                        textTransform: "none",
                        px: 3,
                        height: 36,
                        minHeight: 36,
                        borderRadius: "6px",
                        whiteSpace: "nowrap",
                        flexShrink: 0,
                        "&:hover": { backgroundColor: "#2563EB" }
                      }}
                    >
                      Generate
                    </Button>
                  </Box>
                </Grid>
              </Grid>

              {/* Row 3: Labour Type, Start Date, Next Call Date */}
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item size = {{xs:12, sm:6, md:4}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Labour Type
                  </Typography>
                  <FormControl 
                    fullWidth 
                    size="small"
                    error={formik.touched.labourType && Boolean(formik.errors.labourType)}
                  >
                    <Select
                      name="labourType"
                      value={formik.values.labourType}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& .MuiOutlinedInput-notchedOutline": { 
                          borderColor: formik.touched.labourType && formik.errors.labourType ? "#EF4444" : "#D1D5DB" 
                        },
                        "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { 
                          color: formik.values.labourType ? "#000" : "#A1A1AA" 
                        }
                      }}
                    >
                      <MenuItem value="">Fixed</MenuItem>
                      <MenuItem value="fixed">Fixed</MenuItem>
                      <MenuItem value="hourly">Hourly</MenuItem>
                    </Select>
                    {formik.touched.labourType && formik.errors.labourType && (
                      <FormHelperText>{formik.errors.labourType}</FormHelperText>
                    )}
                  </FormControl>
                </Grid>

                <Grid item size = {{xs:12, sm:6, md:4}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Start date <span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <DatePicker
                    value={formik.values.startDate}
                    onChange={(value) => {
                      formik.setFieldValue("startDate", value);
                      // Reset next call date if it's before the new start date
                      if (formik.values.nextCallDate && value && formik.values.nextCallDate < value) {
                        formik.setFieldValue("nextCallDate", null);
                      }
                    }}
                    format="MM/dd/yyyy"
                    slotProps={{
                      textField: {
                        size: "small",
                        placeholder: "11/26/2025",
                        error: formik.touched.startDate && Boolean(formik.errors.startDate),
                        helperText: formik.touched.startDate && formik.errors.startDate,
                        sx: {
                          width: '100%',
                          "& .MuiOutlinedInput-root": {
                            fontSize: 13,
                            fontFamily: 'Open Sans',
                            height: 36,
                            backgroundColor: "#fff",
                          }
                        }
                      },
                    }}
                  />
                </Grid>

                <Grid item size = {{xs:12, sm:6, md:4}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Next Call Date
                  </Typography>
                  <DatePicker
                    value={formik.values.nextCallDate}
                    onChange={(value) => formik.setFieldValue("nextCallDate", value)}
                    format="MM/dd/yyyy"
                    minDate={formik.values.startDate || undefined}
                    slotProps={{
                      textField: {
                        size: "small",
                        placeholder: "Date",
                        sx: {
                          width: '100%',
                          "& .MuiOutlinedInput-root": {
                            fontSize: 13,
                            fontFamily: 'Open Sans',
                            height: 36,
                            backgroundColor: "#fff",
                          }
                        }
                      },
                    }}
                  />
                </Grid>
              </Grid>

              {/* Row 4: Labour Period, End date type, Number of periods */}
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item size = {{xs:12, sm:6, md:4}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Labor Period <span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <FormControl 
                    fullWidth 
                    size="small"
                    error={formik.touched.labourPeriod && Boolean(formik.errors.labourPeriod)}
                  >
                    <Select
                      name="labourPeriod"
                      value={formik.values.labourPeriod}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& .MuiOutlinedInput-notchedOutline": { 
                          borderColor: formik.touched.labourPeriod && formik.errors.labourPeriod ? "#EF4444" : "#D1D5DB" 
                        },
                        "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { 
                          color: formik.values.labourPeriod ? "#000" : "#A1A1AA" 
                        }
                      }}
                    >
                      <MenuItem value="">Yearly</MenuItem>
                      <MenuItem value="monthly">Monthly</MenuItem>
                      <MenuItem value="quarterly">Quarterly</MenuItem>
                      <MenuItem value="yearly">Yearly</MenuItem>
                    </Select>
                    {formik.touched.labourPeriod && formik.errors.labourPeriod && (
                      <FormHelperText>{formik.errors.labourPeriod}</FormHelperText>
                    )}
                  </FormControl>
                </Grid>

                <Grid item size = {{xs:12, sm:6, md:4}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    End date type
                  </Typography>
                  <FormControl 
                    fullWidth 
                    size="small"
                    error={formik.touched.endDateType && Boolean(formik.errors.endDateType)}
                  >
                    <Select
                      name="endDateType"
                      value={formik.values.endDateType}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& .MuiOutlinedInput-notchedOutline": { 
                          borderColor: formik.touched.endDateType && formik.errors.endDateType ? "#EF4444" : "#D1D5DB" 
                        },
                        "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { 
                          color: formik.values.endDateType ? "#000" : "#A1A1AA" 
                        }
                      }}
                    >
                      <MenuItem value="">Number of periods</MenuItem>
                      <MenuItem value="periods">Number of periods</MenuItem>
                      <MenuItem value="date">Specific End Date</MenuItem>
                      <MenuItem value="never">Never Ending</MenuItem>
                    </Select>
                    {formik.touched.endDateType && formik.errors.endDateType && (
                      <FormHelperText>{formik.errors.endDateType}</FormHelperText>
                    )}
                  </FormControl>
                </Grid>

                <Grid item size = {{xs:12, sm:6, md:4}}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Number of periods
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="numberOfPeriods"
                    type="number"
                    placeholder=""
                    value={formik.values.numberOfPeriods}
                    onChange={handlePeriodsChange}
                    onKeyDown={handleNumberKeyDown}
                    inputProps={{ min: 0 }}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>
              </Grid>

              {/* Row 5: Hours per Period with Unlimited checkbox */}
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6} md={4}>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Hours per Period
                  </Typography>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
                    <TextField 
                      size="small" 
                      name="hoursPerPeriod"
                      type="number"
                      placeholder="0"
                      value={unlimitedHours ? "999999" : formik.values.hoursPerPeriod}
                      onChange={handleHoursChange}
                      onKeyDown={handleNumberKeyDown}
                      disabled={unlimitedHours}
                      inputProps={{ min: 0 }}
                      sx={{
                        width: 150,
                        "& .MuiOutlinedInput-root": { 
                          fontSize: 13, 
                          fontFamily: 'Open Sans', 
                          backgroundColor: unlimitedHours ? "#F3F4F6" : "#fff", 
                          height: 36, 
                          "& fieldset": { borderColor: "#D1D5DB" }, 
                          "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                          "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                        }
                      }} 
                    />
                    <FormControlLabel
                      control={
                        <Checkbox 
                          checked={unlimitedHours}
                          onChange={(e) => {
                            setUnlimitedHours(e.target.checked);
                            if (e.target.checked) {
                              formik.setFieldValue("hoursPerPeriod", "999999");
                            } else {
                              formik.setFieldValue("hoursPerPeriod", "");
                            }
                          }}
                          sx={{
                            color: "#D1D5DB",
                            '&.Mui-checked': { color: "#409BFF" }
                          }}
                        />
                      }
                      label={
                        <Typography sx={{ fontSize: 14, fontFamily: 'Open Sans', color: "#374151" }}>
                          Unlimited
                        </Typography>
                      }
                    />
                  </Box>
                </Grid>
              </Grid>
            </Box>

            {/* Settings Section */}
            <Box sx={{ border: "1px solid #E4E4E7", borderRadius: "8px", p: 3, mb: 3 }}>
              <Typography sx={{ fontSize: 18, fontWeight: 600, mb: 1, color: "#000", fontFamily: 'Open Sans' }}>
                Settings
              </Typography>

              {/* SLA Section */}
              <Box sx={{ mb: 3 }}>
                <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 0.5, color: "#374151", fontFamily: 'Open Sans' }}>
                  Service Level Agreement
                </Typography>
                <Typography sx={{ fontSize: 13, fontWeight: 400, mb: 1, color: "#6B7280", fontFamily: 'Open Sans' }}>
                  Only applicable when setting a Contract at Ticket level using the Contract field
                </Typography>
                <FormControl fullWidth size="small" sx={{ maxWidth: 450 }}>
                  <Select
                    name="sla"
                    value={formik.values.sla}
                    onChange={formik.handleChange}
                    displayEmpty
                    MenuProps={menuProps}
                    sx={{
                      fontSize: 13,
                      fontFamily: 'Open Sans',
                      backgroundColor: "#fff",
                      height: 36,
                      "& .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                      "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                      "& .MuiSelect-select": { 
                        color: formik.values.sla ? "#000" : "#A1A1AA" 
                      }
                    }}
                  >
                    <MenuItem value="">*Do not override*</MenuItem>
                    <MenuItem value="sla1">SLA Level 1</MenuItem>
                    <MenuItem value="sla2">SLA Level 2</MenuItem>
                    <MenuItem value="sla3">SLA Level 3</MenuItem>
                  </Select>
                </FormControl>
              </Box>

              {/* Do not charge checkbox */}
              <Box sx={{ mb: 3 }}>
                <FormControlLabel
                  control={
                    <Checkbox 
                      name="doNotCharge"
                      checked={formik.values.doNotCharge}
                      onChange={formik.handleChange}
                      sx={{
                        color: "#D1D5DB",
                        '&.Mui-checked': { color: "#409BFF" }
                      }}
                    />
                  }
                  label={
                    <Typography sx={{ fontSize: 14, fontFamily: 'Open Sans', color: "#374151" }}>
                      Do not charge for items issued on this Contract
                    </Typography>
                  }
                />
              </Box>

              {/* PDF Template */}
              <Box sx={{ mb: 3 }}>
                <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                  PDF Template
                </Typography>
                <FormControl fullWidth size="small" sx={{ maxWidth: 450 }}>
                  <Select
                    name="pdfTemplate"
                    value={formik.values.pdfTemplate}
                    onChange={formik.handleChange}
                    displayEmpty
                    MenuProps={menuProps}
                    sx={{
                      fontSize: 13,
                      fontFamily: 'Open Sans',
                      backgroundColor: "#fff",
                      height: 36,
                      "& .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                      "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                      "& .MuiSelect-select": { 
                        color: formik.values.pdfTemplate ? "#000" : "#A1A1AA" 
                      }
                    }}
                  >
                    <MenuItem value="">*Default Template*</MenuItem>
                    <MenuItem value="template1">Template 1</MenuItem>
                    <MenuItem value="template2">Template 2</MenuItem>
                  </Select>
                </FormControl>
              </Box>

              {/* From Address */}
              <Box sx={{ mb: 3 }}>
                <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 0.5, color: "#374151", fontFamily: 'Open Sans' }}>
                  From Address
                </Typography>
                <Typography sx={{ fontSize: 14, fontWeight: 400, mb: 1, color: "#6B7280", fontFamily: 'Open Sans' }}>
                  Used for sending invoices. Precedence:
                </Typography>
                <Box component="ol" sx={{ pl: 2.5, mb: 1, fontSize: 14, color: "#6B7280", fontFamily: 'Open Sans' }}>
                  <li>This setting</li>
                  <li>Client-level override (if set)</li>
                  <li>Top level-level override (if set)</li>
                  <li>Global billing setting (if set)</li>
                </Box>
                <FormControl fullWidth size="small" sx={{ maxWidth: 450 }}>
                  <Select
                    name="fromAddress"
                    value={formik.values.fromAddress}
                    onChange={formik.handleChange}
                    displayEmpty
                    MenuProps={menuProps}
                    sx={{
                      fontSize: 13,
                      fontFamily: 'Open Sans',
                      backgroundColor: "#fff",
                      height: 36,
                      "& .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                      "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                      "& .MuiSelect-select": { 
                        color: formik.values.fromAddress ? "#000" : "#A1A1AA" 
                      }
                    }}
                  >
                    <MenuItem value="">*Not in use*</MenuItem>
                    <MenuItem value="address1">Primary Address</MenuItem>
                    <MenuItem value="address2">Secondary Address</MenuItem>
                  </Select>
                </FormControl>
              </Box>

              {/* Contract Email Addresses */}
              <Box sx={{ mb: 3 }}>
                <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                  Contract Email Addresses
                </Typography>
                <TextField 
                  fullWidth 
                  size="small" 
                  name="contractEmail"
                  placeholder=""
                  value={formik.values.contractEmail}
                  onChange={formik.handleChange}
                  sx={{
                    maxWidth: 450,
                    "& .MuiOutlinedInput-root": { 
                      fontSize: 13, 
                      fontFamily: 'Open Sans', 
                      backgroundColor: "#fff", 
                      height: 36, 
                      "& fieldset": { borderColor: "#D1D5DB" }, 
                      "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                      "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                    }
                  }} 
                />
              </Box>

              {/* Contract Email CC Addresses */}
              <Box>
                <Typography sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                  Contract Email CC Addresses
                </Typography>
                <TextField 
                  fullWidth 
                  size="small" 
                  name="contractEmailCC"
                  placeholder=""
                  value={formik.values.contractEmailCC}
                  onChange={formik.handleChange}
                  sx={{
                    maxWidth: 450,
                    "& .MuiOutlinedInput-root": { 
                      fontSize: 13, 
                      fontFamily: 'Open Sans', 
                      backgroundColor: "#fff", 
                      height: 36, 
                      "& fieldset": { borderColor: "#D1D5DB" }, 
                      "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                      "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                    }
                  }} 
                />
              </Box>
            </Box>

            {/* Notes Section */}
            <Box sx={{ border: "1px solid #E4E4E7", borderRadius: "8px", p: 3, mb: 3 }}>
              <Typography sx={{ fontSize: 18, fontWeight: 600, mb: 2, color: "#000", fontFamily: 'Open Sans' }}>
                Notes
              </Typography>
              <TextField 
                fullWidth 
                multiline
                rows={6}
                name="notes"
                placeholder=""
                value={formik.values.notes}
                onChange={formik.handleChange}
                sx={{
                  "& .MuiOutlinedInput-root": { 
                    fontSize: 13, 
                    fontFamily: 'Open Sans', 
                    backgroundColor: "#fff", 
                    "& fieldset": { borderColor: "#D1D5DB" }, 
                    "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                    "& textarea::placeholder": { color: "#A1A1AA", opacity: 1 }
                  }
                }} 
              />
            </Box>

            {/* Footer Section */}
            <Box sx={{ 
              position: "sticky",
              bottom: 0,
              left: 0,
              right: 0,
              bgcolor: "#fff",
              borderTop: "1px solid #E4E4E7",
              pt: 3,
              pb: 2,
              display: "flex",
              alignItems: "center",
              justifyContent: "flex-end",
              gap: 2
            }}>
              <Button
                variant="outlined"
                onClick={() => navigate('/crm-contract-management')}
                sx={{
                  px: 3,
                  py: 1,
                  fontSize: 14,
                  fontWeight: 600,
                  fontFamily: 'Open Sans',
                  textTransform: "none",
                  color: "#374151",
                  borderColor: "#D1D5DB",
                  borderRadius: "6px",
                  "&:hover": {
                    borderColor: "#9CA3AF",
                    backgroundColor: "#F9FAFB"
                  }
                }}
              >
                Cancel
              </Button>
              
              <Button
                type="submit"
                variant="contained"
                sx={{
                  px: 4,
                  py: 1,
                  fontSize: 14,
                  fontWeight: 600,
                  fontFamily: 'Open Sans',
                  textTransform: "none",
                  backgroundColor: "#409bff",
                  borderRadius: "6px",
                  boxShadow: "none",
                  "&:hover": {
                    backgroundColor: "#2563EB",
                    boxShadow: "none"
                  }
                }}
              >
                Save
              </Button>
            </Box>
          </Grid>
        </Grid>
      </form>

      {/* Success Dialog */}
      <Dialog 
        open={successDialogOpen} 
        disableScrollLock 
        PaperProps={{ 
          sx: { 
            borderRadius: "12px", 
            p: 2, 
            minWidth: "400px" 
          } 
        }}
      >
        <DialogContent>
          <Box sx={{ textAlign: "center", py: 2 }}>
            <CheckCircleIcon style={{ width: 64, height: 64, color: "#409BFF", margin: "0 auto", display: "block" }} />
            <Typography sx={{ fontSize: 20, fontWeight: 700, color: "#111827", mt: 2, fontFamily: 'Open Sans' }}>
              Contract {contractData ? "Updated" : "Created"} Successfully!
            </Typography>
            <Typography sx={{ fontSize: 14, fontWeight: 400, color: "#6B7280", mt: 1, fontFamily: 'Open Sans' }}>
              Your contract has been {contractData ? "updated" : "created"}. Redirecting...
            </Typography>
          </Box>
        </DialogContent>
      </Dialog>
    </LocalizationProvider>
  );
};

export default CRMNewContractForm;
