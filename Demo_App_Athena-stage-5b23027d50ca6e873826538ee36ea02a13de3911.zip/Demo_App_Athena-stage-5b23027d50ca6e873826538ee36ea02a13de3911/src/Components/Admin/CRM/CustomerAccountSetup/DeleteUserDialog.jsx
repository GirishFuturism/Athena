// DeleteUserDialog.jsx
import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Box,
  Typography,
  Button,
  IconButton,
} from "@mui/material";
import { XMarkIcon } from "@heroicons/react/24/outline";
import { useNavigate } from "react-router-dom";

const DeleteUserDialog = ({ open, onClose }) => {
  const navigate = useNavigate();

  const handleConfirm = () => {
    onClose?.();                
    navigate("/crm-customer");  
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="sm"
      fullWidth
      disableScrollLock
      PaperProps={{
        sx: {
          borderRadius: "12px",
        },
      }}
    >
      {/* Title row with close icon */}
      <DialogTitle
        sx={{
          px: 3,
          pt: 2.5,
          pb: 1.5,
          borderBottom: "1px solid #E5E7EB",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <Typography
          sx={{
            fontFamily: "Open Sans",
            fontSize: 22,
            fontWeight: 700,
            color: "#FF0202",
          }}
        >
          Delete User
        </Typography>

        <IconButton
          aria-label="Close"
          onClick={onClose}
          sx={{
            color: "#000000",
          }}
        >
          <XMarkIcon style={{ width: 22, height: 22 }} />
        </IconButton>
      </DialogTitle>

      {/* Content */}
      <DialogContent
        sx={{
          px: 3,
          py: 2,
          pb: 4,
          textAlign: "center",
        }}
      >
        <Typography
          sx={{
            fontFamily: "Open Sans",
            fontSize: 24,
            fontWeight: 700,
            color: "#FF0202",
            mb: 2,
            mt: 2,
          }}
        >
          Are you sure?
        </Typography>

        <Typography
          sx={{
            fontFamily: "Open Sans",
            fontSize: 14,
            color: "#000000",
            mb: 0.8,
          }}
        >
          Deleting a User is permanent and cannot be undone.
        </Typography>
        <Typography
          sx={{
            fontFamily: "Open Sans",
            fontSize: 14,
            color: "#000000",
            mb: 0.8,
          }}
        >
          All tickets, assets, and activity logs associated with this User
          will also be deleted.
        </Typography>
        <Typography
          sx={{
            fontFamily: "Open Sans",
            fontSize: 14,
            color: "#000000",
            mt: 0.5,
          }}
        >
          Are you sure that you wish to delete this User?
        </Typography>
      </DialogContent>

      {/* Actions */}
      <DialogActions
        sx={{
          px: 3,
          pt: 2,
          pb: 3,
          borderTop: "1px solid #E5E7EB",
          display: "flex",
          justifyContent: "end",
          gap: 2,
        }}
      >
        <Button
          onClick={handleConfirm}
          sx={{
            minWidth: 110,
            borderRadius: "50px",
            textTransform: "none",
            fontFamily: "Open Sans",
            fontSize: 15,
            fontWeight: 600,
            bgcolor: "#409BFF",
            color: "#FFFFFF",
            px: 4,
            py: 0.8,
            "&:hover": {
              bgcolor: "#2563EB",
            },
          }}
        >
          Yes
        </Button>

        <Button
          onClick={onClose}
          sx={{
            minWidth: 110,
            borderRadius: "50px",
            textTransform: "none",
            fontFamily: "Open Sans",
            fontSize: 15,
            fontWeight: 600,
            bgcolor: "#FF4141",
            color: "#FFFFFF",
            px: 4,
            py: 0.8,
            "&:hover": {
              bgcolor: "#DC2626",
            },
          }}
        >
          No
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeleteUserDialog;
