import React, { useState, useEffect } from 'react';
import TitleBreadcrumb from "../../../Shared/TitleBreadcrumb";
import { Grid, Box, Typography, Tabs, Tab } from "@mui/material";
import { HomeIcon } from '@heroicons/react/24/solid';
import { useNavigate, useLocation } from 'react-router-dom';
import ClientGrid from './ClientGrid';
import UsersGrid from './UsersGrid';

const CustomerAccountLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const params = new URLSearchParams(location.search);

  // Helper for initial tab state based on URL
  const getInitialTab = () => {
    if (params.get('tab') === 'users') return "users";
    if (location.hash === "#users") return "users";
    return "clients";
  };

  const [tab, setTab] = useState(getInitialTab());
  const tabValue = ["clients", "users"];

  // Sync tab with URL changes (so URLs like /crm-customer?tab=users always show Users tab)
  useEffect(() => {
    if (params.get('tab') === 'users' || location.hash === "#users") {
      setTab("users");
    } else {
      setTab("clients");
    }
    // eslint-disable-next-line
  }, [location.search, location.hash]);

  const handleTabChange = (event, newValue) => {
    setTab(newValue);
    // Update URL so breadcrumb link will always work and the page is sharable
    if (newValue === "users") {
      navigate("/crm-customer?tab=users", { replace: true });
    } else {
      navigate("/crm-customer", { replace: true });
    }
  };

  return (
    <>
      <Grid
        container
        spacing={{ xs: 1, md: 2 }}
        columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{
          width: "100%",
          maxWidth: "100vw",
          m: 0,
          p: { xs: 0, sm: 1 },
          justifyContent: "center",
          flexGrow: 1,
        }}
      >
        <Grid
          item
          size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{
            border: "1px solid #E4E4E7",
            backgroundColor: "#fff",
            px: { xs: 1, sm: 4, md: 6, xl: 3 },
            py: { xs: 0, sm: 3 },
          }}
        >
          {/* Breadcrumb */}
          <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
            <HomeIcon
              style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8, cursor: "pointer" }}
              onClick={() => navigate("/admin")}
            />
            <TitleBreadcrumb
              breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin" },
                { type: "link", label: "CRM", to: "/crm" },
                tab === "users"
                  ? { type: "link", label: "Users", to: "/crm-customer?tab=users" }
                  : { type: "text", label: "Customers", to: "" }
              ]}
            />
          </Box>

          {/* Header with Title */}
          <Box
            sx={{
              mt: 2,
              pt: 1,
              pb: 1,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: 2
            }}
          >
            <Typography
              sx={{
                fontFamily: "Open Sans",
                fontSize: "24px",
                fontWeight: "700",
                color: "#111827"
              }}
            >
              {tab === "users" ? "Users" : "Customers"}
            </Typography>
          </Box>

          {/* Tabs section */}
          <Box sx={{ pt: 1 }}>
            <Tabs
              value={tab}
              onChange={handleTabChange}
              TabIndicatorProps={{
                style: { backgroundColor: "#409BFF" },
              }}
              sx={{
                "& .MuiTab-root": {
                  color: "#6B7280",
                },
                "& .Mui-selected": {
                  color: "#409BFF",
                },
              }}
            >
              <Tab
                label="Clients"
                value={tabValue[0]}
                sx={{
                  fontWeight: 600,
                  mr: 2,
                  fontFamily: "Open Sans",
                  textTransform: "none",
                  fontSize: 15,
                  color: tab === tabValue[0] ? "#409BFF" : "#6B7280",
                }}
              />
              <Tab
                label="Users"
                value={tabValue[1]}
                sx={{
                  fontWeight: 600,
                  mr: 2,
                  fontFamily: "Open Sans",
                  textTransform: "none",
                  fontSize: 15,
                  color: tab === tabValue[1] ? "#409BFF" : "#6B7280",
                }}
              />
            </Tabs>
          </Box>

          {/* Tab Content */}
          <Box sx={{ mt: 3 }}>
            {tab === "clients" && <ClientGrid />}
            {tab === "users" && <UsersGrid />}
          </Box>
        </Grid>
      </Grid>
    </>
  );
};

export default CustomerAccountLayout;
