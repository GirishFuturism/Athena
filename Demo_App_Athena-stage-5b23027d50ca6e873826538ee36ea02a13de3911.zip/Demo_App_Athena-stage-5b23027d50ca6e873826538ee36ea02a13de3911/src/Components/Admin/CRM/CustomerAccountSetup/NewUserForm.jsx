import React, { useState } from "react";
import { Grid, Box, Typography, TextField, MenuItem, IconButton, Button, Dialog, DialogContent, Select, FormControl, FormHelperText } from "@mui/material";
import TitleBreadcrumb from "../../../Shared/TitleBreadcrumb";
import { useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import * as Yup from "yup";
import {
  HomeIcon,
  MagnifyingGlassIcon,
  XMarkIcon,
  CheckCircleIcon,
} from "@heroicons/react/24/solid";

const validationSchema = Yup.object({
  username: Yup.string().required("Username is required"),
  site: Yup.string().required("Site is required"),
  firstName: Yup.string().required("First Name is required"),
  surname: Yup.string().required("Surname is required"),
  title: Yup.string(),
  email: Yup.string().email("Invalid email").required("Email is required"),
  dateOfBirth: Yup.date().nullable(),
  phone: Yup.string()
    .matches(/^\+1 \(\d{3}\) \d{3}-\d{4}$/, "Phone must be in format +1 (555) 123-4567"),
  address1: Yup.string(),
  address2: Yup.string(),
  notes: Yup.string(),
});

const NewUserForm = () => {
  const navigate = useNavigate();
  const [successDialogOpen, setSuccessDialogOpen] = useState(false);

  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

  const formik = useFormik({
    initialValues: {
      username: "",
      site: "",
      firstName: "",
      surname: "",
      title: "",
      email: "",
      dateOfBirth: "",
      phone: "",
      address1: "",
      address2: "",
      notes: "",
    },
    validationSchema,
    onSubmit: (values) => {
      console.log("Form submitted:", values);
      setSuccessDialogOpen(true);
      setTimeout(() => { navigate('/crm-customer?tab=users'); }, 2000);
    },
  });

  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <Grid container spacing={{ xs: 1, md: 2 }} columns={{ xs: 12, sm: 12, md: 12, xl: 12 }} sx={{ width: "100%", maxWidth: "100vw", m: 0, p: { xs: 0, sm: 1 }, justifyContent: "center", flexGrow: 1 }}>
          <Grid item size={{ xs: 12, sm: 12, md: 12, xl: 12 }} sx={{ border: "1px solid #E4E4E7", backgroundColor: "#fff", px: { xs: 1, sm: 4, md: 6, xl: 3 }, py: { xs: 0, sm: 3 }, boxShadow: { xs: "none", sm: "0 2px 14px rgba(116,185,255,.08)" } }}>
            
            {/* Breadcrumb */}
            <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
              <HomeIcon style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8 }} />
              <TitleBreadcrumb breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin" },
                { type: "link", label: "Users", to: "/crm-customer?tab=users" },
                { type: "text", label: "New" }
              ]} />
            </Box>

            {/* Title */}
            <Typography sx={{ fontSize: 24, fontWeight: 700, mb: 0.5, color: "#111827", fontFamily: 'Open Sans' }}>
              Create New User
            </Typography>

            {/* Subtitle */}
            <Typography sx={{ fontSize: 15, fontWeight: 400, mb: 4, color: "#4B5563", fontFamily: 'Open Sans' }}>
              Fill out the form below to create a new user account
            </Typography>

            {/* Details Section */}
            <Box sx={{ border: "1px solid #E4E4E7", borderRadius: "8px", p: 3, mb: 3 }}>
              <Typography sx={{ fontSize: 18, fontWeight: 600, mb: 2.5, color: "#000", fontFamily: 'Open Sans' }}>
                Details
              </Typography>

              {/* Row 1: Username, Site, First Name, Surname */}
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Username <span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <Box sx={{ position: "relative" }}>
                    <TextField
                      fullWidth
                      size="small"
                      name="username"
                      placeholder="Enter a Username for this User here"
                      value={formik.values.username}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      error={formik.touched.username && Boolean(formik.errors.username)}
                      sx={{
                        "& .MuiOutlinedInput-root": {
                          fontSize: 13,
                          fontFamily: 'Open Sans',
                          backgroundColor: "#fff",
                          height: 36,
                          paddingRight: "40px",
                          "& fieldset": { borderColor: formik.touched.username && formik.errors.username ? "#EF4444" : "#D1D5DB" },
                          "&:hover fieldset": { borderColor: "#D1D5DB" },
                          "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                        }
                      }}
                    />
                    <Box sx={{ position: "absolute", right: 8, top: 8, display: "flex", gap: 0.5, alignItems: "center" }}>
                      {formik.values.username && (
                        <IconButton size="small" onClick={() => formik.setFieldValue("username", "")} sx={{ p: 0.3 }}>
                          <XMarkIcon style={{ width: 14, height: 14, color: "#71717A" }} />
                        </IconButton>
                      )}
                    </Box>
                    {formik.touched.username && formik.errors.username && (
                      <FormHelperText error sx={{ mx: 1.75, mt: 0.5 }}>
                        {formik.errors.username}
                      </FormHelperText>
                    )}
                  </Box>
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Site <span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <Box sx={{ position: "relative" }}>
                    <FormControl fullWidth size="small" error={formik.touched.site && Boolean(formik.errors.site)}>
                      <Select
                        name="site"
                        value={formik.values.site}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        displayEmpty
                        MenuProps={menuProps}
                        sx={{
                          fontSize: 13,
                          fontFamily: 'Open Sans',
                          backgroundColor: "#fff",
                          height: 36,
                          paddingRight: "32px",
                          "& .MuiOutlinedInput-notchedOutline": { borderColor: formik.touched.site && formik.errors.site ? "#EF4444" : "#D1D5DB" },
                          "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                          "& .MuiSelect-select": { color: formik.values.site ? "#000" : "#A1A1AA" }
                        }}
                      >
                        <MenuItem value="">Choose which Site the User belongs too.</MenuItem>
                        <MenuItem value="site1">Site 1</MenuItem>
                        <MenuItem value="site2">Site 2</MenuItem>
                        <MenuItem value="site3">Site 3</MenuItem>
                      </Select>
                      {formik.touched.site && formik.errors.site && (
                        <FormHelperText>{formik.errors.site}</FormHelperText>
                      )}
                    </FormControl>
                    <IconButton size="small" sx={{ position: "absolute", right: 32, top: 8, p: 0.3, pointerEvents: "none" }}>
                      <svg width="14" height="14" viewBox="0 0 20 20" fill="none">
                        <path d="M19 19L14.65 14.65M17 9C17 13.4183 13.4183 17 9 17C4.58172 17 1 13.4183 1 9C1 4.58172 4.58172 1 9 1C13.4183 1 17 4.58172 17 9Z" 
                          stroke="#71717A" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </IconButton>
                  </Box>
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    First Name
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="firstName"
                    placeholder="First Name" 
                    value={formik.values.firstName}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    error={formik.touched.firstName && Boolean(formik.errors.firstName)}
                    helperText={formik.touched.firstName && formik.errors.firstName}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: formik.touched.firstName && formik.errors.firstName ? "#EF4444" : "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Surname
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="surname"
                    placeholder="Last Name" 
                    value={formik.values.surname}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    error={formik.touched.surname && Boolean(formik.errors.surname)}
                    helperText={formik.touched.surname && formik.errors.surname}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: formik.touched.surname && formik.errors.surname ? "#EF4444" : "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>
              </Grid>

              {/* Row 2: Title, Email Address, Date of birth, Telephone Numbers */}
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Title
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="title"
                    placeholder="title..." 
                    value={formik.values.title}
                    onChange={formik.handleChange}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Email Address
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="email"
                    placeholder="Email " 
                    value={formik.values.email}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    error={formik.touched.email && Boolean(formik.errors.email)}
                    helperText={formik.touched.email && formik.errors.email}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: formik.touched.email && formik.errors.email ? "#EF4444" : "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Date of birth
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    type="date"
                    name="dateOfBirth"
                    placeholder="Date" 
                    value={formik.values.dateOfBirth}
                    onChange={formik.handleChange}
                    InputLabelProps={{ shrink: true }}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Telephone Numbers
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="phone"
                    placeholder="+1 (555) 123-4567" 
                    value={formik.values.phone}
                    onChange={(e) => {
                      let value = e.target.value.replace(/\D/g, '');
                      if (value.length > 10) value = value.slice(0, 10);
                      let formatted = '';
                      if (value.length > 0) {
                        formatted = '+1 ';
                        if (value.length <= 3) {
                          formatted += `(${value}`;
                        } else if (value.length <= 6) {
                          formatted += `(${value.slice(0, 3)}) ${value.slice(3)}`;
                        } else {
                          formatted += `(${value.slice(0, 3)}) ${value.slice(3, 6)}-${value.slice(6)}`;
                        }
                      }
                      formik.setFieldValue("phone", formatted);
                    }}
                    onBlur={formik.handleBlur}
                    error={formik.touched.phone && Boolean(formik.errors.phone)}
                    helperText={formik.touched.phone && formik.errors.phone}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: formik.touched.phone && formik.errors.phone ? "#EF4444" : "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>
              </Grid>

              {/* Row 3: Address Line 1, Address Line 2 */}
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Address Line 1
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="address1"
                    placeholder="" 
                    value={formik.values.address1}
                    onChange={formik.handleChange}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>

                <Grid item xs={12} sm={6} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600, mb: 1, color: "#374151", fontFamily: 'Open Sans' }}>
                    Address Line 2
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="address2"
                    placeholder="" 
                    value={formik.values.address2}
                    onChange={formik.handleChange}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>
              </Grid>
            </Box>

            {/* Notes Section */}
            <Box sx={{ border: "1px solid #E4E4E7", borderRadius: "8px", p: 3, mb: 3 }}>
              <Typography sx={{ fontSize: 18, fontWeight: 600, mb: 2.5, color: "#000", fontFamily: 'Open Sans' }}>
                Notes
              </Typography>

              <TextField 
                fullWidth 
                multiline
                rows={6}
                name="notes"
                placeholder="" 
                value={formik.values.notes}
                onChange={formik.handleChange}
                sx={{
                  "& .MuiOutlinedInput-root": { 
                    fontSize: 13, 
                    fontFamily: 'Open Sans', 
                    backgroundColor: "#fff", 
                    "& fieldset": { borderColor: "#D1D5DB" }, 
                    "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                    "& textarea::placeholder": { color: "#A1A1AA", opacity: 1 }
                  }
                }} 
              />
            </Box>

            {/* Footer Section */}
            <Box sx={{ position: "sticky", bottom: 0, left: 0, right: 0, bgcolor: "#fff", borderTop: "1px solid #E4E4E7", pt: 3, pb: 2, display: "flex", alignItems: "center", justifyContent: "right", flexWrap: "wrap", gap: 2 }}>
              <Box sx={{ display: "flex", gap: 2 }}>
                <Button 
                  variant="outlined" 
                  onClick={() => navigate('/crm-customer?tab=users')}
                  sx={{ 
                    px: 3, 
                    py: 1, 
                    fontSize: 15, 
                    fontWeight: 500, 
                    fontFamily: 'Open Sans', 
                    textTransform: "none", 
                    color: "#374151", 
                    borderColor: "#D1D5DB", 
                    borderRadius: "6px", 
                    "&:hover": { 
                      borderColor: "#9CA3AF", 
                      backgroundColor: "#F9FAFB" 
                    } 
                  }}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  variant="contained" 
                  sx={{ 
                    px: 3, 
                    py: 1, 
                    fontSize: 15, 
                    fontWeight: 600, 
                    fontFamily: 'Open Sans', 
                    textTransform: "none", 
                    backgroundColor: "#409BFF", 
                    borderRadius: "6px", 
                    boxShadow: "none",
                    "&:hover": {
                      backgroundColor: "#3380e8"
                    }
                  }}
                >
                  Save User
                </Button>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </form>

      {/* Success Dialog */}
      <Dialog open={successDialogOpen} disableScrollLock PaperProps={{ sx: { borderRadius: "12px", p: 2, minWidth: "400px" } }}>
        <DialogContent>
          <Box sx={{ textAlign: "center", py: 2 }}>
            <CheckCircleIcon style={{ width: 64, height: 64, color: "#409BFF", margin: "0 auto", display: "block" }} />
            <Typography sx={{ fontSize: 20, fontWeight: 700, color: "#111827", mt: 2, fontFamily: 'Open Sans' }}>
              User Created Successfully!
            </Typography>
            <Typography sx={{ fontSize: 14, fontWeight: 400, color: "#6B7280", mt: 1, fontFamily: 'Open Sans' }}>
              The new user has been created. Redirecting...
            </Typography>
          </Box>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default NewUserForm;
