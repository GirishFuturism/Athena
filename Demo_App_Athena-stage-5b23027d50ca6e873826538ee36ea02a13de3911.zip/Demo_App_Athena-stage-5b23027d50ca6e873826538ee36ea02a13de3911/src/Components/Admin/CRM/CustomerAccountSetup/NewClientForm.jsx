import React, { useState } from "react";
import { Grid, Box, Typography, TextField, MenuItem, Button, Dialog, DialogContent, Select, FormControl, FormHelperText, Checkbox, FormControlLabel } from "@mui/material";
import TitleBreadcrumb from "../../../Shared/TitleBreadcrumb";
import { useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import * as Yup from "yup";
import {
  HomeIcon,
  CheckCircleIcon,
} from "@heroicons/react/24/solid";

const validationSchema = Yup.object({
  name: Yup.string().required("Name is required"),
  email: Yup.string().email("Invalid email").required("Email Address is required"),
  phone: Yup.string()
    .matches(/^\+1 \(\d{3}\) \d{3}-\d{4}$/, "Phone must be in format +1 (555) 123-4567"),
  title: Yup.string(),
  webAccessLevel: Yup.string().required("Web Access Level is required"),
  sendWelcomeEmail: Yup.boolean(),
  reference: Yup.string(),
  relationship: Yup.string().required("Relationship is required"),
  type: Yup.string().required("Type is required"),
  accountStatus: Yup.string().required("Account Status is required"),
  nextCallDate: Yup.date().nullable(),
  notes: Yup.string(),
});

const NewClientForm = () => {
  const navigate = useNavigate();
  const [successDialogOpen, setSuccessDialogOpen] = useState(false);

  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

  const formik = useFormik({
    initialValues: {
      name: "",
      email: "",
      phone: "",
      title: "",
      webAccessLevel: "",
      sendWelcomeEmail: false,
      reference: "",
      relationship: "",
      type: "",
      accountStatus: "",
      nextCallDate: "",
      notes: "",
    },
    validationSchema,
    onSubmit: (values) => {
      console.log("Form submitted:", values);
      setSuccessDialogOpen(true);
      setTimeout(() => { navigate('/crm-customer'); }, 2000);
    },
  });

  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <Grid container spacing={{ xs: 1, md: 2 }} columns={{ xs: 12, sm: 12, md: 12, xl: 12 }} sx={{ width: "100%", maxWidth: "100vw", m: 0, p: { xs: 0, sm: 1 }, justifyContent: "center", flexGrow: 1 }}>
          <Grid item size={{ xs: 12, sm: 12, md: 12, xl: 12 }} sx={{ border: "1px solid #E4E4E7", backgroundColor: "#fff", px: { xs: 1, sm: 4, md: 6, xl: 3 }, py: { xs: 0, sm: 3 }, boxShadow: { xs: "none", sm: "0 2px 14px rgba(116,185,255,.08)" } }}>
            
            {/* Breadcrumb */}
            <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
              <HomeIcon style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8 }} />
              <TitleBreadcrumb breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin" },
                { type: "link", label: "Clients", to: "/crm-customer" },
                { type: "text", label: "New" }
              ]} />
            </Box>

            {/* Title */}
            <Typography sx={{ fontSize: 24, fontWeight: 700, mb: 0.5, color: "#111827", fontFamily: 'Open Sans' }}>
              Create New Client
            </Typography>

            {/* Subtitle */}
            <Typography sx={{ fontSize: 15, fontWeight: 400, mb: 4, color: "#4B5563", fontFamily: 'Open Sans' }}>
              Fill out the form below to create a new client account
            </Typography>

            {/* Main Contact Section */}
            <Box sx={{ border: "1px solid #E4E4E7", borderRadius: "8px", p: 3, mb: 3 }}>
              <Typography sx={{ fontSize: 18, fontWeight: 600, mb: 2.5, color: "#000", fontFamily: 'Open Sans' }}>
                Main Contact
              </Typography>

              {/* Row 1: Name, Email Address, Phone Number, Title */}
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 14, fontWeight: 400, mb: 1, color: "#71717A", fontFamily: 'Open Sans' }}>
                    Name
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    name="name"
                    placeholder="Enter the Users name"
                    value={formik.values.name}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    error={formik.touched.name && Boolean(formik.errors.name)}
                    helperText={formik.touched.name && formik.errors.name}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& fieldset": { borderColor: formik.touched.name && formik.errors.name ? "#EF4444" : "#D1D5DB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }}
                  />
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 14, fontWeight: 400, mb: 1, color: "#71717A", fontFamily: 'Open Sans' }}>
                    Email Address
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="email"
                    placeholder="Enter the Users Email Address" 
                    value={formik.values.email}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    error={formik.touched.email && Boolean(formik.errors.email)}
                    helperText={formik.touched.email && formik.errors.email}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: formik.touched.email && formik.errors.email ? "#EF4444" : "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 14, fontWeight: 400, mb: 1, color: "#71717A", fontFamily: 'Open Sans' }}>
                    Phone Number
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="phone"
                    placeholder="Enter the Users Telephone Number" 
                    value={formik.values.phone}
                    onChange={(e) => {
                      let value = e.target.value.replace(/\D/g, '');
                      if (value.length > 10) value = value.slice(0, 10);
                      let formatted = '';
                      if (value.length > 0) {
                        formatted = '+1 ';
                        if (value.length <= 3) {
                          formatted += `(${value}`;
                        } else if (value.length <= 6) {
                          formatted += `(${value.slice(0, 3)}) ${value.slice(3)}`;
                        } else {
                          formatted += `(${value.slice(0, 3)}) ${value.slice(3, 6)}-${value.slice(6)}`;
                        }
                      }
                      formik.setFieldValue("phone", formatted);
                    }}
                    onBlur={formik.handleBlur}
                    error={formik.touched.phone && Boolean(formik.errors.phone)}
                    helperText={formik.touched.phone && formik.errors.phone}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: formik.touched.phone && formik.errors.phone ? "#EF4444" : "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 14, fontWeight: 400, mb: 1, color: "#71717A", fontFamily: 'Open Sans' }}>
                    Title
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="title"
                    placeholder="" 
                    value={formik.values.title}
                    onChange={formik.handleChange}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>
              </Grid>

              {/* Row 2: Web Access Level and Send Welcome Email Checkbox */}
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 14, fontWeight: 400, mb: 1, color: "#71717A", fontFamily: 'Open Sans' }}>
                    Web Access Level <span style={{ color: '#EF4444' }}>*</span>
                  </Typography>
                  <FormControl fullWidth size="small" error={formik.touched.webAccessLevel && Boolean(formik.errors.webAccessLevel)}>
                    <Select
                      name="webAccessLevel"
                      value={formik.values.webAccessLevel}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& .MuiOutlinedInput-notchedOutline": { borderColor: formik.touched.webAccessLevel && formik.errors.webAccessLevel ? "#EF4444" : "#D1D5DB" },
                        "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { color: formik.values.webAccessLevel ? "#000" : "#A1A1AA" }
                      }}
                    >
                      <MenuItem value="">This Users Tickets</MenuItem>
                      <MenuItem value="no_access">No Access Ticket</MenuItem>
                      <MenuItem value="user_tickets">This User Tickets</MenuItem>
                      <MenuItem value="site_tickets">Site Tickets</MenuItem>
                    </Select>
                    {formik.touched.webAccessLevel && formik.errors.webAccessLevel && (
                      <FormHelperText>{formik.errors.webAccessLevel}</FormHelperText>
                    )}
                  </FormControl>
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1, display: 'flex', alignItems: 'flex-end' }}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        name="sendWelcomeEmail"
                        checked={formik.values.sendWelcomeEmail}
                        onChange={formik.handleChange}
                        sx={{
                          color: "#D1D5DB",
                          '&.Mui-checked': {
                            color: "#409BFF",
                          },
                        }}
                      />
                    }
                    label={
                      <Typography sx={{ fontSize: 14, fontWeight: 400, color: "#374151", fontFamily: 'Open Sans' }}>
                        Send Welcome Email
                      </Typography>
                    }
                    sx={{ mb: 0 }}
                  />
                </Grid>
              </Grid>

              {/* Row 3: Reference, Relationship, Type, Account Status */}
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 14, fontWeight: 400, mb: 1, color: "#71717A", fontFamily: 'Open Sans' }}>
                    Reference
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    name="reference"
                    placeholder="" 
                    value={formik.values.reference}
                    onChange={formik.handleChange}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 14, fontWeight: 400, mb: 1, color: "#71717A", fontFamily: 'Open Sans' }}>
                    Relationship
                  </Typography>
                  <FormControl fullWidth size="small" error={formik.touched.relationship && Boolean(formik.errors.relationship)}>
                    <Select
                      name="relationship"
                      value={formik.values.relationship}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& .MuiOutlinedInput-notchedOutline": { borderColor: formik.touched.relationship && formik.errors.relationship ? "#EF4444" : "#D1D5DB" },
                        "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { color: formik.values.relationship ? "#000" : "#A1A1AA" }
                      }}
                    >
                      <MenuItem value="">Select...</MenuItem>
                      <MenuItem value="customer">Customer</MenuItem>
                      <MenuItem value="prospect">Prospect</MenuItem>
                    </Select>
                    {formik.touched.relationship && formik.errors.relationship && (
                      <FormHelperText>{formik.errors.relationship}</FormHelperText>
                    )}
                  </FormControl>
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 14, fontWeight: 400, mb: 1, color: "#71717A", fontFamily: 'Open Sans' }}>
                    Type
                  </Typography>
                  <FormControl fullWidth size="small" error={formik.touched.type && Boolean(formik.errors.type)}>
                    <Select
                      name="type"
                      value={formik.values.type}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& .MuiOutlinedInput-notchedOutline": { borderColor: formik.touched.type && formik.errors.type ? "#EF4444" : "#D1D5DB" },
                        "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { color: formik.values.type ? "#000" : "#A1A1AA" }
                      }}
                    >
                      <MenuItem value="">Choose a Type to Categorise this Client</MenuItem>
                      <MenuItem value="construction">Construction</MenuItem>
                      <MenuItem value="education">Education</MenuItem>
                      <MenuItem value="finance">Finance</MenuItem>
                      <MenuItem value="food">Food</MenuItem>
                      <MenuItem value="manufacturing">Manufacturing</MenuItem>
                    </Select>
                    {formik.touched.type && formik.errors.type && (
                      <FormHelperText>{formik.errors.type}</FormHelperText>
                    )}
                  </FormControl>
                </Grid>

                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 14, fontWeight: 400, mb: 1, color: "#71717A", fontFamily: 'Open Sans' }}>
                    Account Status
                  </Typography>
                  <FormControl fullWidth size="small" error={formik.touched.accountStatus && Boolean(formik.errors.accountStatus)}>
                    <Select
                      name="accountStatus"
                      value={formik.values.accountStatus}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      displayEmpty
                      MenuProps={menuProps}
                      sx={{
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& .MuiOutlinedInput-notchedOutline": { borderColor: formik.touched.accountStatus && formik.errors.accountStatus ? "#EF4444" : "#D1D5DB" },
                        "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                        "& .MuiSelect-select": { color: formik.values.accountStatus ? "#000" : "#A1A1AA" }
                      }}
                    >
                      <MenuItem value="">Allowed</MenuItem>
                      <MenuItem value="allowed">Allowed</MenuItem>
                      <MenuItem value="stopped">Stopped</MenuItem>
                    </Select>
                    {formik.touched.accountStatus && formik.errors.accountStatus && (
                      <FormHelperText>{formik.errors.accountStatus}</FormHelperText>
                    )}
                  </FormControl>
                </Grid>
              </Grid>

              {/* Row 4: Next Call Date */}
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6} md={3} sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 14, fontWeight: 400, mb: 1, color: "#71717A", fontFamily: 'Open Sans' }}>
                    Next Call Date
                  </Typography>
                  <TextField 
                    fullWidth 
                    size="small" 
                    type="date"
                    name="nextCallDate"
                    placeholder="Date" 
                    value={formik.values.nextCallDate}
                    onChange={formik.handleChange}
                    InputLabelProps={{ shrink: true }}
                    sx={{
                      "& .MuiOutlinedInput-root": { 
                        fontSize: 13, 
                        fontFamily: 'Open Sans', 
                        backgroundColor: "#fff", 
                        height: 36, 
                        "& fieldset": { borderColor: "#D1D5DB" }, 
                        "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }} 
                  />
                </Grid>
              </Grid>
            </Box>

            {/* Notes Section */}
            <Box sx={{ border: "1px solid #E4E4E7", borderRadius: "8px", p: 3, mb: 3 }}>
              <Typography sx={{ fontSize: 18, fontWeight: 600, mb: 2.5, color: "#000", fontFamily: 'Open Sans' }}>
                Notes
              </Typography>

              <TextField 
                fullWidth 
                multiline
                rows={6}
                name="notes"
                placeholder="" 
                value={formik.values.notes}
                onChange={formik.handleChange}
                sx={{
                  "& .MuiOutlinedInput-root": { 
                    fontSize: 13, 
                    fontFamily: 'Open Sans', 
                    backgroundColor: "#fff", 
                    "& fieldset": { borderColor: "#D1D5DB" }, 
                    "&:hover fieldset": { borderColor: "#D1D5DB" }, 
                    "& textarea::placeholder": { color: "#A1A1AA", opacity: 1 }
                  }
                }} 
              />
            </Box>

            {/* Footer Section */}
            <Box sx={{ position: "sticky", bottom: 0, left: 0, right: 0, bgcolor: "#fff", borderTop: "1px solid #E4E4E7", pt: 3, pb: 2, display: "flex", alignItems: "center", justifyContent: "right", flexWrap: "wrap", gap: 2 }}>
              <Box sx={{ display: "flex", gap: 2 }}>
                <Button 
                  variant="outlined" 
                  onClick={() => navigate('/crm-customer')}
                  sx={{ 
                    px: 3, 
                    py: 1, 
                    fontSize: 15, 
                    fontWeight: 500, 
                    fontFamily: 'Open Sans', 
                    textTransform: "none", 
                    color: "#374151", 
                    borderColor: "#D1D5DB", 
                    borderRadius: "6px", 
                    "&:hover": { 
                      borderColor: "#9CA3AF", 
                      backgroundColor: "#F9FAFB" 
                    } 
                  }}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  variant="contained" 
                  sx={{ 
                    px: 3, 
                    py: 1, 
                    fontSize: 15, 
                    fontWeight: 600, 
                    fontFamily: 'Open Sans', 
                    textTransform: "none", 
                    backgroundColor: "#409BFF", 
                    borderRadius: "6px", 
                    boxShadow: "none",
                    "&:hover": {
                      backgroundColor: "#3380e8"
                    }
                  }}
                >
                  Save Client
                </Button>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </form>

      {/* Success Dialog */}
      <Dialog open={successDialogOpen} disableScrollLock PaperProps={{ sx: { borderRadius: "12px", p: 2, minWidth: "400px" } }}>
        <DialogContent>
          <Box sx={{ textAlign: "center", py: 2 }}>
            <CheckCircleIcon style={{ width: 64, height: 64, color: "#409BFF", margin: "0 auto", display: "block" }} />
            <Typography sx={{ fontSize: 20, fontWeight: 700, color: "#111827", mt: 2, fontFamily: 'Open Sans' }}>
              Client Created Successfully!
            </Typography>
            <Typography sx={{ fontSize: 14, fontWeight: 400, color: "#6B7280", mt: 1, fontFamily: 'Open Sans' }}>
              The new client has been created. Redirecting...
            </Typography>
          </Box>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default NewClientForm;
