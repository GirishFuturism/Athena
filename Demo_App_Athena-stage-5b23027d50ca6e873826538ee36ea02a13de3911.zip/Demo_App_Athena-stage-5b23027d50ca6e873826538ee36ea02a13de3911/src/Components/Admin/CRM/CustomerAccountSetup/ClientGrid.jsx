import React, { useState } from "react";
import {
  Box,
  Typography,
  TextField,
  InputAdornment,
  Button,
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { MagnifyingGlassIcon } from "@heroicons/react/24/outline";
import { PlusIcon } from "@heroicons/react/24/solid";
import { initialClientRows } from "../../../../Data/CrmCustomerData";
import { useNavigate } from "react-router-dom";
import Avatar from "@mui/material/Avatar";

const HEADER_BG = "#F9FAFB";
const HEADER_COLOR = "#111827";

const ClientGrid = () => {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [clients, setClients] = useState(initialClientRows);

  // Enhanced search functionality
  const filteredRows = clients.filter((row) => {
    const searchQuery = query.toLowerCase().trim();

    if (!searchQuery) return true;

    return (
      row.accountManager.name.toLowerCase().includes(searchQuery) ||
      row.clientName.toLowerCase().includes(searchQuery) ||
      row.openTickets.toString().includes(searchQuery) ||
      row.openOpportunities.toString().includes(searchQuery) ||
      row.nextCallDate.toLowerCase().includes(searchQuery)
    );
  });

  const handleRowClick = (params) => {
    console.log("Row clicked:", params.row);
    // Navigate to client details page
    navigate("/crm-client-details", { state: { clientData: params.row } });
  };

  const columns = [
    {
      field: "accountManager",
      headerName: "Account Manager",
      minWidth: 200,
      flex: 0.25,
      headerAlign: "left",
      renderCell: (params) => (
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Avatar
            src={params.value.avatar}
            alt={params.value.name}
            sx={{
              width: 36,
              height: 36,
              border: "2px solid #E5E7EB",
            }}
          />
          <Typography
            sx={{
              fontWeight: 600,
              fontSize: 14,
              color: "#111827",
              fontFamily: "Open Sans",
            }}
          >
            {params.value.name}
          </Typography>
        </Box>
      ),
    },
    {
      field: "clientName",
      headerName: "Client Name",
      minWidth: 180,
      flex: 0.22,
      renderCell: (params) => (
        <Typography
          sx={{
            fontWeight: 600,
            fontSize: 14,
            color: "#374151",
            fontFamily: "Open Sans",
            pt: 1,
          }}
        >
          {params.value}
        </Typography>
      ),
    },
    {
      field: "openTickets",
      headerName: "Open Tickets",
      minWidth: 140,
      flex: 0.15,
      align: "left",
      headerAlign: "left",
      renderCell: (params) => (
        <Typography
          sx={{
            fontWeight: 600,
            fontSize: 14,
            color: "#374151",
            fontFamily: "Open Sans",
            pt: 1,
            pl: 0.8,
          }}
        >
          {params.value}
        </Typography>
      ),
    },
    {
      field: "openOpportunities",
      headerName: "Open Opportunities",
      minWidth: 180,
      flex: 0.18,
      align: "left",
      headerAlign: "left",
      renderCell: (params) => (
        <Typography
          sx={{
            fontWeight: 600,
            fontSize: 14,
            color: "#374151",
            fontFamily: "Open Sans",
            pt: 1,
            pl: 0.8,
          }}
        >
          {params.value}
        </Typography>
      ),
    },
    {
      field: "nextCallDate",
      headerName: "Next Call Date",
      minWidth: 150,
      flex: 0.16,
      renderCell: (params) => (
        <Typography
          sx={{
            fontWeight: 600,
            fontSize: 14,
            color: "#374151",
            fontFamily: "Open Sans",
            pt: 1,
            pl: 0.8,
          }}
        >
          {params.value}
        </Typography>
      ),
    },
  ];

  return (
    <Box
      sx={{
        border: "1px solid #E5E7EB",
        borderRadius: "8px",
        p: 0,
        boxShadow: "none",
        fontFamily: "Open Sans",
      }}
    >
      {/* Header */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          px: 3,
          py: 2.2,
          borderBottom: "1.5px solid #E5E7EB",
        }}
      >
        <Typography
          sx={{
            fontSize: 18,
            fontWeight: 700,
            fontFamily: "Open Sans",
            color: "#1F2937",
            letterSpacing: 0,
            ml: 0.2,
          }}
        >
          Client Directory
        </Typography>
        <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
          <TextField
            size="small"
            placeholder="Search Customers..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            InputProps={{
              sx: {
                bgcolor: "#FFFFFF",
                fontSize: 14,
                height: 35,
                borderRadius: "8px",
                minWidth: 215,
                fontFamily: "Open Sans",
                borderRight: "none",
                boxShadow: "none",
                pr: 0,
              },
              startAdornment: (
                <InputAdornment position="start">
                  <MagnifyingGlassIcon
                    style={{
                      width: 16,
                      height: 16,
                      color: "#A1A1A1",
                      marginRight: 2,
                    }}
                  />
                </InputAdornment>
              ),
            }}
          />
          <Button
            onClick={()=>navigate("/crm-new-client")}
            variant="contained"
            startIcon={<PlusIcon style={{ width: 16, height: 16 }} />}
            sx={{
              bgcolor: "#409BFF",
              color: "#fff",
              textTransform: "none",
              fontFamily: "Open Sans",
              fontWeight: 600,
              fontSize: 14,
              height: 35,
              borderRadius: "6px",
              boxShadow: "none",
              px: 2,
              "&:hover": {
                bgcolor: "#2563EB",
                boxShadow: "none",
              },
            }}
          >
            Add New Client
          </Button>
        </Box>
      </Box>

      {/* DataGrid */}
      <Box
        sx={{
          width: "100%",
          "& .MuiDataGrid-root": {
            border: "none",
            background: "#fff",
            fontFamily: "Open Sans",
          },
        }}
      >
        <DataGrid
          rows={filteredRows}
          columns={columns}
          getRowId={(row) => row.id}
          onRowClick={handleRowClick}
          hideFooterSelectedRowCount
          disableColumnMenu
          disableRowSelectionOnClick
          autoHeight
          density="standard"
          rowHeight={56}
          columnHeaderHeight={48}
          sx={{
            border: "none",
            px: 0,
            fontFamily: "Open Sans",
            "& .MuiDataGrid-columnHeaders": {
              background: HEADER_BG,
              minHeight: 48,
              maxHeight: 48,
            },
            "& .MuiDataGrid-columnHeader": {
              pl: 3,
              pr: 2.5,
              color: HEADER_COLOR,
              fontSize: 15,
              fontWeight: 700,
              fontFamily: "Open Sans",
              letterSpacing: 0.02,
              lineHeight: "24px",
              background: HEADER_BG,
              borderTopLeftRadius: 0,
              borderTopRightRadius: 0,
            },
            "& .MuiDataGrid-columnHeaderTitle": {
              fontWeight: 700,
              fontSize: 15,
              letterSpacing: 0,
            },
            "& .MuiDataGrid-cell": {
              fontSize: 14,
              px: 2.5,
              py: 1,
              fontFamily: "Open Sans",
              letterSpacing: 0,
              lineHeight: "22px",
              backgroundColor: "transparent",
            },
            "& .MuiDataGrid-row": {
              cursor: "pointer",
              width: "100%",
              boxSizing: "border-box",
              transition: "background-color 0.15s ease",
              "&:hover": {
                backgroundColor: "#EEF2FF",
              },
            },
            "& .MuiDataGrid-columnSeparator": {
              display: "none",
            },
            "& .MuiDataGrid-footerContainer": {
              borderTop: "1px solid #E5E7EB",
              background: HEADER_BG,
              minHeight: 43,
              maxHeight: 48,
            },
            "& .MuiTablePagination-root": {
              color: "#6B7280",
              fontSize: 13,
              fontFamily: "Open Sans",
            },
            "& .MuiDataGrid-cell:focus": {
              outline: "none",
            },
            "& .MuiDataGrid-cell:focus-within": {
              outline: "none",
            },
            "& .MuiDataGrid-columnHeader:focus": {
              outline: "none",
            },
            "& .MuiDataGrid-columnHeader:focus-within": {
              outline: "none",
            },
          }}
          initialState={{
            pagination: {
              paginationModel: { page: 0, pageSize: 5 },
            },
          }}
          // pageSizeOptions={[5, 10]}
        />
      </Box>

      {/* Search Results Info */}
      {query && (
        <Box
          sx={{
            px: 3,
            py: 1.5,
            borderTop: "1px solid #E5E7EB",
            bgcolor: "#F9FAFB",
          }}
        >
          <Typography
            sx={{
              fontSize: 13,
              fontFamily: "Open Sans",
              color: "#6B7280",
            }}
          >
            Found {filteredRows.length} result
            {filteredRows.length !== 1 ? "s" : ""} for "{query}"
          </Typography>
        </Box>
      )}
    </Box>
  );
};

export default ClientGrid;
