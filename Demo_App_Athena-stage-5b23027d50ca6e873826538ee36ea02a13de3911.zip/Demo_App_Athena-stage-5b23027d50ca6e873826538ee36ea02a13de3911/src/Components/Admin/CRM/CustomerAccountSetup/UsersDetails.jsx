import React, { useState } from "react";
import TitleBreadcrumb from "../../../Shared/TitleBreadcrumb";
import {
  Grid,
  Box,
  Typography,
  Avatar,
  Button,
  Tabs,
  Tab,
  Chip,
  List,
  ListItem,
  ListItemText,
  TextField,
} from "@mui/material";
import {
  HomeIcon,
  PencilIcon,
  TrashIcon,
  CalendarIcon,
  DocumentTextIcon,
  ChartBarIcon,
  PlusIcon,
  ExclamationTriangleIcon,
  TicketIcon,
  ClockIcon,
  CalendarDaysIcon,
  EnvelopeIcon,
  PhoneIcon,
  XMarkIcon,
  CheckIcon,
} from "@heroicons/react/24/solid";
import { useNavigate, useLocation } from "react-router-dom";
import DeleteUserDialog from "./DeleteUserDialog";
import { Formik, Form } from "formik";
import * as Yup from "yup";

// Validation Schema
const userValidationSchema = Yup.object({
  fullName: Yup.string()
    .required("Full name is required")
    .min(2, "Name must be at least 2 characters"),
  email: Yup.string()
    .required("Email is required")
    .email("Invalid email address"),
  phone: Yup.string()
    .required("Phone number is required")
    .matches(
      /^[\+]?1?[\s.-]?\(?([0-9]{3})\)?[\s.-]?([0-9]{3})[\s.-]?([0-9]{4})$/,
      "Phone must be in US format (e.g., (123) 456-7890)"
    )
    .test('is-valid-us-phone', 'Phone must be a valid 10-digit US number', function(value) {
      if (!value) return false;
      // Remove all non-digit characters
      const digitsOnly = value.replace(/\D/g, '');
      // US phone numbers should have exactly 10 digits, or 11 if starting with 1
      return digitsOnly.length === 10 || (digitsOnly.length === 11 && digitsOnly.startsWith('1'));
    }),
  siteName: Yup.string().required("Site name is required"),
  clientName: Yup.string().required("Client name is required"),
  role: Yup.string().required("Role is required"),
  department: Yup.string().required("Department is required"),
});

// Helper function to auto-format phone numbers
const formatPhoneNumber = (value) => {
  if (!value) return value;
  
  // Remove all non-digit characters
  const phoneNumber = value.replace(/[^\d]/g, '');
  
  // Get length of digits
  const phoneNumberLength = phoneNumber.length;
  
  // Don't format if empty
  if (phoneNumberLength === 0) return '';
  
  // Format based on length
  if (phoneNumberLength < 4) {
    return phoneNumber;
  }
  
  if (phoneNumberLength < 7) {
    return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3)}`;
  }
  
  // Limit to 10 digits and format as (XXX) XXX-XXXX
  return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3, 6)}-${phoneNumber.slice(6, 10)}`;
};



const UserDetails = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
const [lastEditDate, setLastEditDate] = useState(null);
const [hasBeenEdited, setHasBeenEdited] = useState(false);

  const userData = location.state?.userData;

  const [activeTab, setActiveTab] = useState(0);

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  // User information - initial values
  const initialUserInfo = {
    fullName: userData?.userName?.name || "John Doe",
    avatar: userData?.userName?.avatar || "https://i.pravatar.cc/150?img=1",
    email: userData?.emailAddress || "user@example.com",
    phone: userData?.phoneNumber || "+1 (555) 123-4567",
    siteName: userData?.siteName || "Main Office",
    clientName: userData?.clientName || "Tech Corp",
    id: userData?.id || "USR-2024-001",
    status: "Active",
    createdOn: userData?.createdOn || "02 Nov 2025",
    role: "End User",
    department: "IT Department",
  };

  const handleEditToggle = () => {
    setIsEditMode(!isEditMode);
  };

  const handleSaveUser = (values) => {
   const now = new Date();
  const formattedDate = now.toLocaleDateString('en-GB', { 
    day: '2-digit', 
    month: 'short', 
    year: 'numeric' 
  });
  
  setLastEditDate(formattedDate);
  setHasBeenEdited(true);
  setIsEditMode(false);
  };

  // Ticket data for overview tab
  const ticketData = [
    {
      id: "2298",
      date: "11/20/2025 14:30",
      status: "Opened",
      statusColor: "#DBEAFE",
      description:
        "Laptop screen flickering issue reported. Awaiting diagnostics.",
    },
    {
      id: "2289",
      date: "11/18/2025 09:15",
      status: "In Progress",
      statusColor: "#FEF3C7",
      description: "Password reset request for email access being processed.",
    },
    {
      id: "2276",
      date: "11/15/2025 16:45",
      status: "Resolved",
      statusColor: "#D1FAE5",
      description:
        "Software installation completed successfully for Adobe Creative Suite.",
    },
    {
      id: "2265",
      date: "11/10/2025 11:20",
      status: "Resolved",
      statusColor: "#D1FAE5",
      description: "VPN access issue fixed. User can now connect remotely.",
    },
    {
      id: "2254",
      date: "11/05/2025 13:00",
      status: "Waiting for Customer",
      statusColor: "#E0E7FF",
      description:
        "Awaiting user confirmation for new hardware specifications.",
    },
  ];

  // Derive counts from ticket data
  const openTicketsCount = ticketData.filter((t) => t.status === "Opened").length;
  const totalTicketsCount = ticketData.length;
  const openLast30DaysCount = ticketData.filter(
    (t) => t.status === "Opened" || t.status === "In Progress"
  ).length;

  // Overview stats
  const overviewStats = [
    {
      label: "Open Tickets",
      value: openTicketsCount,
      iconBg: "#FEE2E2",
      iconColor: "#DC2626",
      Icon: ExclamationTriangleIcon,
    },
    {
      label: "Total Tickets",
      value: totalTicketsCount,
      iconBg: "#DCFCE7",
      iconColor: "#16A34A",
      Icon: TicketIcon,
    },
    {
      label: "Open in last 30 days",
      value: openLast30DaysCount,
      iconBg: "#DBEAFE",
      iconColor: "#2563EB",
      Icon: TicketIcon,
    },
  ];

  // Recent Activity data
  const recentActivities = [
    { text: "New ticket created - Screen flickering", time: "2 hours ago", color: "#3B82F6" },
    { text: "Password reset completed", time: "1 day ago", color: "#10B981" },
    { text: "Software installed successfully", time: "3 days ago", color: "#8B5CF6" },
    { text: "VPN access granted", time: "5 days ago", color: "#F59E0B" },
    { text: "Hardware request submitted", time: "1 week ago", color: "#EF4444" },
    { text: "Profile information updated", time: "2 weeks ago", color: "#6B7280" },
    { text: "Training session completed", time: "3 weeks ago", color: "#10B981" },
    { text: "Access level modified", time: "1 month ago", color: "#8B5CF6" },
  ];

  return (
    <>
      <Grid
        container
        spacing={{ xs: 1, md: 2 }}
        columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{
          width: "100%",
          maxWidth: "100vw",
          m: 0,
          p: { xs: 0, sm: 1 },
          justifyContent: "center",
          flexGrow: 1,
        }}
      >
        <Grid
          item
          size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{
            border: "1px solid #E4E4E7",
            backgroundColor: "#fff",
            px: { xs: 1, sm: 4, md: 6, xl: 3 },
            py: { xs: 0, sm: 3 },
          }}
        >
          {/* Breadcrumb */}
          <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
            <HomeIcon
              style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8, cursor: "pointer" }}
              onClick={() => navigate("/admin")}
            />
           <TitleBreadcrumb
              breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin" },
                { type: "link", label: "Users", to: "/crm-customer?tab=users" }, 
                { type: "text", label: "User Details", to: "" }
              ]}
            />
          </Box>

          {/* Header Section */}
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              mt: 3,
              mb: 3,
              flexWrap: "wrap",
              rowGap: 2,
            }}
          >
            {/* Left: Avatar + text */}
            <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
              <Avatar
                src={initialUserInfo.avatar}
                alt={initialUserInfo.fullName}
                sx={{
                  width: 64,
                  height: 64,
                  border: "3px solid #E5E7EB",
                }}
              />
              <Box>
                {/* Title */}
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontSize: 24,
                    fontWeight: 700,
                    color: "#111827",
                    lineHeight: 1.2,
                  }}
                >
                  {initialUserInfo.fullName}
                </Typography>

                {/* Subtitle line */}
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontSize: 16,
                    fontWeight: 400,
                    color: "#4B5563",
                    mt: 0.3,
                  }}
                >
                  {initialUserInfo.role} • {initialUserInfo.clientName}
                </Typography>

                {/* Status + ID row */}
                <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mt: 0.6 }}>
                  <Chip
                    label="Active"
                    sx={{
                      height: 28,
                      borderRadius: "999px",
                      bgcolor: "#DCFCE7",
                      color: "#166534",
                      fontFamily: "Open Sans",
                      fontSize: 13,
                      fontWeight: 600,
                      px: 1.5,
                    }}
                  />
                  <Typography
                    sx={{
                      fontFamily: "Open Sans",
                      fontSize: 14,
                      fontWeight: 500,
                      color: "#6B7280",
                    }}
                  >
                    ID: {initialUserInfo.id}
                  </Typography>
                </Box>
              </Box>
            </Box>

            {/* Right: Edit / Delete buttons */}
            <Box sx={{ display: "flex", gap: 1.5 }}>
              {!isEditMode ? (
                <Button
                  variant="contained"
                  onClick={handleEditToggle}
                  startIcon={<PencilIcon style={{ width: 16, height: 16 }} />}
                  sx={{
                    bgcolor: "#409BFF",
                    color: "#fff",
                    textTransform: "none",
                    fontFamily: "Open Sans",
                    fontWeight: 600,
                    fontSize: 14,
                    px: 2.5,
                    py: 1,
                    borderRadius: "6px",
                    boxShadow: "none",
                    "&:hover": {
                      bgcolor: "#2563EB",
                      boxShadow: "none",
                    },
                  }}
                >
                  Edit
                </Button>
              ) : (
                <Button
                  variant="contained"
                  onClick={handleEditToggle}
                  startIcon={<XMarkIcon style={{ width: 16, height: 16 }} />}
                  sx={{
                    bgcolor: "#6B7280",
                    color: "#fff",
                    textTransform: "none",
                    fontFamily: "Open Sans",
                    fontWeight: 600,
                    fontSize: 14,
                    px: 2.5,
                    py: 1,
                    borderRadius: "6px",
                    boxShadow: "none",
                    "&:hover": {
                      bgcolor: "#4B5563",
                      boxShadow: "none",
                    },
                  }}
                >
                  Cancel
                </Button>
              )}

              <Button
                variant="contained"
                onClick={() => setDeleteOpen(true)}
                startIcon={<TrashIcon style={{ width: 16, height: 16 }} />}
                sx={{
                  bgcolor: "#EF4444",
                  color: "#fff",
                  textTransform: "none",
                  fontFamily: "Open Sans",
                  fontWeight: 600,
                  fontSize: 14,
                  px: 2.5,
                  py: 1,
                  borderRadius: "6px",
                  boxShadow: "none",
                  "&:hover": {
                    bgcolor: "#DC2626",
                    boxShadow: "none",
                  },
                }}
              >
                Delete
              </Button>
            </Box>
          </Box>

          {/* User Information Section with Formik */}
          <Formik
            initialValues={initialUserInfo}
            validationSchema={userValidationSchema}
            onSubmit={handleSaveUser}
            enableReinitialize
          >
            {({ values, errors, touched, handleChange, handleBlur, handleSubmit }) => (
              <Form onSubmit={handleSubmit}>
                <Grid
                  container
                  spacing={3}
                  columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
                  sx={{ mb: 3 }}
                >
                  <Grid item size={{ xs: 12, sm: 12, md: 12, xl: 12 }}>
                    <Box
                      sx={{
                        bgcolor: "#F9FAFB",
                        p: 3,
                        borderRadius: "8px",
                      }}
                    >
                      {/* Header with Save button */}
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                          mb: 3,
                        }}
                      >
                        <Typography
                          sx={{
                            fontFamily: "Open Sans",
                            fontSize: 18,
                            fontWeight: 700,
                            color: "#111827",
                          }}
                        >
                          User Information
                        </Typography>

                        {isEditMode && (
                          <Button
                            type="submit"
                            variant="contained"
                            startIcon={<CheckIcon style={{ width: 16, height: 16 }} />}
                            sx={{
                              bgcolor: "#10B981",
                              color: "#fff",
                              textTransform: "none",
                              fontFamily: "Open Sans",
                              fontWeight: 600,
                              fontSize: 14,
                              px: 3,
                              py: 1,
                              borderRadius: "6px",
                              boxShadow: "none",
                              "&:hover": {
                                bgcolor: "#059669",
                                boxShadow: "none",
                              },
                            }}
                          >
                            Save Changes
                          </Button>
                        )}
                      </Box>

                      {/* Content Grid */}
                      <Grid
                        container
                        spacing={3}
                        columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
                      >
                        {/* Row 1 */}
                        <Grid item size={{ xs: 12, sm: 4, md: 3, xl: 3 }}>
                          <Typography
                            sx={{
                              fontFamily: "Open Sans",
                              fontSize: 13,
                              fontWeight: 600,
                              color: "#6B7280",
                              mb: 0.5,
                            }}
                          >
                            Full Name
                          </Typography>
                          {!isEditMode ? (
                            <Typography
                              sx={{
                                fontFamily: "Open Sans",
                                fontSize: 14,
                                fontWeight: 600,
                                color: "#111827",
                                wordBreak: "break-word",
                              }}
                            >
                              {values.fullName}
                            </Typography>
                          ) : (
                            <TextField
                              fullWidth
                              name="fullName"
                              value={values.fullName}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              error={touched.fullName && Boolean(errors.fullName)}
                              helperText={touched.fullName && errors.fullName}
                              size="small"
                              sx={{
                                "& .MuiOutlinedInput-root": {
                                  fontFamily: "Open Sans",
                                  fontSize: 14,
                                },
                              }}
                            />
                          )}
                        </Grid>

                        <Grid item size={{ xs: 12, sm: 4, md: 3, xl: 3 }}>
                          <Typography
                            sx={{
                              fontFamily: "Open Sans",
                              fontSize: 13,
                              fontWeight: 600,
                              color: "#6B7280",
                              mb: 0.5,
                            }}
                          >
                            Email Address
                          </Typography>
                          {!isEditMode ? (
                            <Typography
                              sx={{
                                fontFamily: "Open Sans",
                                fontSize: 14,
                                fontWeight: 600,
                                color: "#2563EB",
                                wordBreak: "break-all",
                              }}
                            >
                              {values.email}
                            </Typography>
                          ) : (
                            <TextField
                              fullWidth
                              name="email"
                              value={values.email}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              error={touched.email && Boolean(errors.email)}
                              helperText={touched.email && errors.email}
                              size="small"
                              sx={{
                                "& .MuiOutlinedInput-root": {
                                  fontFamily: "Open Sans",
                                  fontSize: 14,
                                },
                              }}
                            />
                          )}
                        </Grid>

                        <Grid item size={{ xs: 12, sm: 4, md: 3, xl: 3 }}>
                          <Typography
                            sx={{
                              fontFamily: "Open Sans",
                              fontSize: 13,
                              fontWeight: 600,
                              color: "#6B7280",
                              mb: 0.5,
                            }}
                          >
                            Phone Number
                          </Typography>
                          {!isEditMode ? (
                            <Typography
                              sx={{
                                fontFamily: "Open Sans",
                                fontSize: 14,
                                fontWeight: 600,
                                color: "#111827",
                              }}
                            >
                              {values.phone}
                            </Typography>
                          ) : (
                            <TextField
  fullWidth
  name="phone"
  value={values.phone}
  onChange={(e) => {
    const formatted = formatPhoneNumber(e.target.value);
    handleChange({ target: { name: 'phone', value: formatted } });
  }}
  onBlur={handleBlur}
  error={touched.phone && Boolean(errors.phone)}
  helperText={touched.phone && errors.phone}
  placeholder="(123) 456-7890"
  size="small"
  inputProps={{
    maxLength: 14, 
  }}
  sx={{
    "& .MuiOutlinedInput-root": {
      fontFamily: "Open Sans",
      fontSize: 14,
    },
  }}
/>

                          )}
                        </Grid>

                        <Grid item size={{ xs: 12, sm: 4, md: 3, xl: 3 }}>
                          <Typography
                            sx={{
                              fontFamily: "Open Sans",
                              fontSize: 13,
                              fontWeight: 600,
                              color: "#6B7280",
                              mb: 0.5,
                            }}
                          >
                            Site Name
                          </Typography>
                          {!isEditMode ? (
                            <Typography
                              sx={{
                                fontFamily: "Open Sans",
                                fontSize: 14,
                                fontWeight: 600,
                                color: "#111827",
                                wordBreak: "break-word",
                              }}
                            >
                              {values.siteName}
                            </Typography>
                          ) : (
                            <TextField
                              fullWidth
                              name="siteName"
                              value={values.siteName}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              error={touched.siteName && Boolean(errors.siteName)}
                              helperText={touched.siteName && errors.siteName}
                              size="small"
                              sx={{
                                "& .MuiOutlinedInput-root": {
                                  fontFamily: "Open Sans",
                                  fontSize: 14,
                                },
                              }}
                            />
                          )}
                        </Grid>

                        {/* Row 2 */}
                        <Grid item size={{ xs: 12, sm: 4, md: 3, xl: 3 }}>
                          <Typography
                            sx={{
                              fontFamily: "Open Sans",
                              fontSize: 13,
                              fontWeight: 600,
                              color: "#6B7280",
                              mb: 0.5,
                            }}
                          >
                            Client Name
                          </Typography>
                          {!isEditMode ? (
                            <Typography
                              sx={{
                                fontFamily: "Open Sans",
                                fontSize: 14,
                                fontWeight: 600,
                                color: "#111827",
                              }}
                            >
                              {values.clientName}
                            </Typography>
                          ) : (
                            <TextField
                              fullWidth
                              name="clientName"
                              value={values.clientName}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              error={touched.clientName && Boolean(errors.clientName)}
                              helperText={touched.clientName && errors.clientName}
                              size="small"
                              sx={{
                                "& .MuiOutlinedInput-root": {
                                  fontFamily: "Open Sans",
                                  fontSize: 14,
                                },
                              }}
                            />
                          )}
                        </Grid>

                        <Grid item size={{ xs: 12, sm: 4, md: 3, xl: 3 }}>
                          <Typography
                            sx={{
                              fontFamily: "Open Sans",
                              fontSize: 13,
                              fontWeight: 600,
                              color: "#6B7280",
                              mb: 0.5,
                            }}
                          >
                            Role
                          </Typography>
                          {!isEditMode ? (
                            <Typography
                              sx={{
                                fontFamily: "Open Sans",
                                fontSize: 14,
                                fontWeight: 600,
                                color: "#111827",
                              }}
                            >
                              {values.role}
                            </Typography>
                          ) : (
                            <TextField
                              fullWidth
                              name="role"
                              value={values.role}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              error={touched.role && Boolean(errors.role)}
                              helperText={touched.role && errors.role}
                              size="small"
                              sx={{
                                "& .MuiOutlinedInput-root": {
                                  fontFamily: "Open Sans",
                                  fontSize: 14,
                                },
                              }}
                            />
                          )}
                        </Grid>

                        <Grid item size={{ xs: 12, sm: 4, md: 3, xl: 3 }}>
                          <Typography
                            sx={{
                              fontFamily: "Open Sans",
                              fontSize: 13,
                              fontWeight: 600,
                              color: "#6B7280",
                              mb: 0.5,
                            }}
                          >
                            Department
                          </Typography>
                          {!isEditMode ? (
                            <Typography
                              sx={{
                                fontFamily: "Open Sans",
                                fontSize: 14,
                                fontWeight: 600,
                                color: "#111827",
                              }}
                            >
                              {values.department}
                            </Typography>
                          ) : (
                            <TextField
                              fullWidth
                              name="department"
                              value={values.department}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              error={touched.department && Boolean(errors.department)}
                              helperText={touched.department && errors.department}
                              size="small"
                              sx={{
                                "& .MuiOutlinedInput-root": {
                                  fontFamily: "Open Sans",
                                  fontSize: 14,
                                },
                              }}
                            />
                          )}
                        </Grid>

                        <Grid item size={{ xs: 12, sm: 4, md: 3, xl: 3 }}>
  <Typography
    sx={{
      fontFamily: "Open Sans",
      fontSize: 13,
      fontWeight: 600,
      color: "#6B7280",
      mb: 0.5,
    }}
  >
    {hasBeenEdited ? "Edited On" : "Created On"}
  </Typography>
  <Typography
    sx={{
      fontFamily: "Open Sans",
      fontSize: 14,
      fontWeight: 600,
      color: hasBeenEdited ? "#10B981" : "#111827",
    }}
  >
    {hasBeenEdited ? lastEditDate : values.createdOn}
  </Typography>
</Grid>

                      </Grid>
                    </Box>
                  </Grid>
                </Grid>
              </Form>
            )}
          </Formik>

          {/* Main Content Area - Tabs and Sidebar */}
          <Grid
            container
            spacing={1.5}
            columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
            sx={{ mt: 0 }}
          >
            {/* Left Column - Tabs */}
            <Grid item size={{ xs: 12, sm: 12, md: 12, xl: 9 }}>
              <Box
                sx={{
                  border: "1px solid #E5E7EB",
                  borderRadius: "8px",
                  bgcolor: "#fff",
                }}
              >
                <Tabs
                  value={activeTab}
                  onChange={handleTabChange}
                  TabIndicatorProps={{
                    style: { backgroundColor: "#409BFF" },
                  }}
                  sx={{
                    borderBottom: "1px solid #E5E7EB",
                    px: 2,
                    "& .MuiTab-root": {
                      color: "#6B7280",
                      textTransform: "none",
                      fontFamily: "Open Sans",
                      fontSize: 15,
                      fontWeight: 600,
                      minHeight: 48,
                    },
                    "& .Mui-selected": {
                      color: "#409BFF",
                    },
                  }}
                >
                  <Tab label="Overview" />
                  <Tab label="Tickets" />
                  <Tab label="Assets" />
                  <Tab label="Activity Log" />
                </Tabs>

                <Box sx={{ p: 3 }}>
                  {activeTab === 0 && (
                    <Box>
                      {/* Stats Cards */}
                      <Grid
                        container
                        spacing={2.5}
                        columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
                        sx={{ mb: 3 }}
                      >
                        {overviewStats.map((stat, index) => {
                          const IconComponent = stat.Icon;
                          return (
                            <Grid
                              key={index}
                              item
                              size={{ xs: 12, sm: 12, md: 4, xl: 4 }}
                            >
                              <Box
                                sx={{
                                  borderRadius: "14px",
                                  border: "1px solid #E5E7EB",
                                  bgcolor: "#FFFFFF",
                                  px: 2.5,
                                  py: 2,
                                  display: "flex",
                                  alignItems: "flex-start",
                                  justifyContent: "space-between",
                                  transition: 'box-shadow 0.3s cubic-bezier(0.4, 0, 0.2, 1), transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                                  '&:hover': {
                                  boxShadow: '0 8px 24px rgba(67, 144, 248, 0.25)',
                                  transform: 'translateY(-5px)',
                                  borderColor: '#4390F8',
                                  }
                                }}
                              >
                                {/* Left content */}
                                <Box>
                                  <Typography
                                    sx={{
                                      fontFamily: "Open Sans",
                                      fontSize: 14,
                                      fontWeight: 600,
                                      color: "#4B5563",
                                      mb: 1,
                                    }}
                                  >
                                    {stat.label}
                                  </Typography>

                                  <Typography
                                    sx={{
                                      fontFamily: "Open Sans",
                                      fontSize: 24,
                                      fontWeight: 700,
                                      color: "#111827",
                                      mb: 1,
                                    }}
                                  >
                                    {stat.value}
                                  </Typography>

                                  {index === 0 && (
                                    <Typography
                                      sx={{
                                        fontFamily: "Open Sans",
                                        fontSize: 13,
                                        fontWeight: 500,
                                        color: "#DC2626",
                                      }}
                                    >
                                      1 High Priority
                                    </Typography>
                                  )}
                                </Box>

                                {/* Right icon tile */}
                                <Box
                                  sx={{
                                    width: 52,
                                    height: 52,
                                    borderRadius: "16px",
                                    bgcolor: stat.iconBg,
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                  }}
                                >
                                  <IconComponent
                                    style={{
                                      width: 26,
                                      height: 26,
                                      color: stat.iconColor,
                                    }}
                                  />
                                </Box>
                              </Box>
                            </Grid>
                          );
                        })}
                      </Grid>

                      {/* Ticket List with Scroll */}
                      <Box
                        sx={{
                          mt: 3,
                          maxHeight: 520,
                          pr: 2,
                          overflowY: "auto",
                          "&::-webkit-scrollbar": { width: "6px" },
                          "&::-webkit-scrollbar-track": {
                            bgcolor: "#F3F4F6",
                            borderRadius: "10px",
                          },
                          "&::-webkit-scrollbar-thumb": {
                            bgcolor: "#D1D5DB",
                            borderRadius: "10px",
                            "&:hover": { bgcolor: "#9CA3AF" },
                          },
                        }}
                      >
                        {ticketData.map((ticket, index) => (
                          <Box
                            key={index}
                            sx={{
                              border: "1px solid #E5E7EB",
                              borderRadius: "8px",
                              p: 2.5,
                              mb: 2,
                              bgcolor: "#fff",
                              transition: "all 0.2s",
                              "&:hover": {
                                boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
                              },
                            }}
                          >
                            <Box
                              sx={{
                                display: "flex",
                                justifyContent: "space-between",
                                mb: 1.5,
                              }}
                            >
                              <Box sx={{ display: "flex", alignItems: "center", gap: 3 }}>
                                <Typography
                                  sx={{
                                    fontFamily: "Open Sans",
                                    fontSize: 18,
                                    fontWeight: 700,
                                    color: "#111827",
                                  }}
                                >
                                  {ticket.id}
                                </Typography>
                                <Typography
                                  sx={{
                                    fontFamily: "Open Sans",
                                    fontSize: 13,
                                    color: "#6B7280",
                                  }}
                                >
                                  {ticket.date}
                                </Typography>
                              </Box>
                              <Chip
                                label={ticket.status}
                                sx={{
                                  bgcolor: ticket.statusColor,
                                  color: "#374151",
                                  fontFamily: "Open Sans",
                                  fontWeight: 600,
                                  fontSize: 12,
                                  height: 26,
                                  borderRadius: "6px",
                                }}
                              />
                            </Box>
                            <Typography
                              sx={{
                                fontFamily: "Open Sans",
                                fontSize: 14,
                                color: "#4B5563",
                                lineHeight: 1.5,
                              }}
                            >
                              {ticket.description}
                            </Typography>
                          </Box>
                        ))}
                      </Box>
                    </Box>
                  )}

                  {activeTab === 1 && (
                    <Typography
                      sx={{
                        fontFamily: "Open Sans",
                        fontSize: 14,
                        color: "#6B7280",
                      }}
                    >
                      All tickets for this user will be displayed here
                    </Typography>
                  )}
                  {activeTab === 2 && (
                    <Typography
                      sx={{
                        fontFamily: "Open Sans",
                        fontSize: 14,
                        color: "#6B7280",
                      }}
                    >
                      Assets assigned to this user will be displayed here
                    </Typography>
                  )}
                  {activeTab === 3 && (
                    <Typography
                      sx={{
                        fontFamily: "Open Sans",
                        fontSize: 14,
                        color: "#6B7280",
                      }}
                    >
                      Complete activity log will be displayed here
                    </Typography>
                  )}
                </Box>
              </Box>
            </Grid>

            {/* Right Column - Quick Actions + Recent Activity */}
            <Grid item size={{ xs: 12, sm: 12, md: 12, xl: 3 }}>
              {/* Quick Actions */}
              <Box
                sx={{
                  borderRadius: "14px",
                  border: "1px solid #E5E7EB",
                  bgcolor: "#FFFFFF",
                  p: 2.5,
                  mb: 1.4,
                }}
              >
                {/* Title */}
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontSize: 18,
                    fontWeight: 700,
                    color: "#111827",
                    mb: 2.5,
                  }}
                >
                  Quick Actions
                </Typography>

                {/* Action items */}
                <Box sx={{ display: "flex", flexDirection: "column", gap: 1.75, mb: 2.5 }}>
                  {/* Schedule Meeting */}
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                    <CalendarDaysIcon style={{ width: 20, height: 20, color: "#6B7280" }} />
                    <Typography
                      sx={{
                        fontFamily: "Open Sans",
                        fontSize: 14,
                        fontWeight: 500,
                        color: "#374151",
                      }}
                    >
                      Schedule Meeting
                    </Typography>
                  </Box>

                  {/* Send Email */}
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                    <EnvelopeIcon style={{ width: 20, height: 20, color: "#6B7280" }} />
                    <Typography
                      sx={{
                        fontFamily: "Open Sans",
                        fontSize: 14,
                        fontWeight: 500,
                        color: "#374151",
                      }}
                    >
                      Send Email
                    </Typography>
                  </Box>

                  {/* Call User */}
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                    <PhoneIcon style={{ width: 18, height: 18, color: "#6B7280" }} />
                    <Typography
                      sx={{
                        fontFamily: "Open Sans",
                        fontSize: 14,
                        fontWeight: 500,
                        color: "#374151",
                      }}
                    >
                      Call User
                    </Typography>
                  </Box>
                </Box>

                {/* Create New Ticket button */}
                <Button
                  fullWidth
                  onClick={() => navigate("/new-ticket")}
                  startIcon={<PlusIcon style={{ width: 18, height: 18 }} />}
                  sx={{
                    mt: 0.5,
                    justifyContent: "center",
                    textTransform: "none",
                    fontFamily: "Open Sans",
                    fontSize: 15,
                    fontWeight: 600,
                    color: "#409BFF",
                    bgcolor: "#EFF6FF",
                    py: 1.2,
                    borderRadius: "10px",
                    boxShadow: "none",
                    "&:hover": {
                      bgcolor: "#E0E7FF",
                      boxShadow: "none",
                    },
                  }}
                >
                  Create New Ticket
                </Button>
              </Box>

              {/* Recent Activity */}
              <Box
                sx={{
                  border: "1px solid #E5E7EB",
                  borderRadius: "8px",
                  p: 2.5,
                  bgcolor: "#fff",
                }}
              >
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontSize: 16,
                    fontWeight: 700,
                    color: "#111827",
                    mb: 2,
                  }}
                >
                  Recent Activity
                </Typography>

                <Box
                  sx={{
                    maxHeight: 420,
                    overflowY: "auto",
                    "&::-webkit-scrollbar": { width: "6px" },
                    "&::-webkit-scrollbar-track": {
                      bgcolor: "#F3F4F6",
                      borderRadius: "10px",
                    },
                    "&::-webkit-scrollbar-thumb": {
                      bgcolor: "#D1D5DB",
                      borderRadius: "10px",
                      "&:hover": { bgcolor: "#9CA3AF" },
                    },
                  }}
                >
                  <List sx={{ p: 0 }}>
                    {recentActivities.map((activity, index) => (
                      <ListItem
                        key={index}
                        sx={{
                          px: 0,
                          py: 1.5,
                          borderBottom:
                            index !== recentActivities.length - 1 ? "1px solid #F3F4F6" : "none",
                          display: "flex",
                          alignItems: "flex-start",
                          gap: 1.5,
                        }}
                      >
                        <Box
                          sx={{
                            width: 8,
                            height: 8,
                            borderRadius: "50%",
                            bgcolor: activity.color,
                            mt: 0.8,
                            flexShrink: 0,
                          }}
                        />
                        <ListItemText
                          primary={activity.text}
                          secondary={activity.time}
                          primaryTypographyProps={{
                            sx: {
                              fontFamily: "Open Sans",
                              fontSize: 14,
                              fontWeight: 600,
                              color: "#111827",
                              lineHeight: 1.4,
                            },
                          }}
                          secondaryTypographyProps={{
                            sx: {
                              fontFamily: "Open Sans",
                              fontSize: 12,
                              color: "#9CA3AF",
                              mt: 0.3,
                            },
                          }}
                        />
                      </ListItem>
                    ))}
                  </List>
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <DeleteUserDialog open={deleteOpen} onClose={() => setDeleteOpen(false)} />
    </>
  );
};

export default UserDetails;
