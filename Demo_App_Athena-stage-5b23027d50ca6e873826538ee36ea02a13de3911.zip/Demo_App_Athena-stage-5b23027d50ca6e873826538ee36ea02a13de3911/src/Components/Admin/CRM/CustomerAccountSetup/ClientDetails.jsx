import React, { useState } from "react";
import TitleBreadcrumb from "../../../Shared/TitleBreadcrumb";
import {
  Grid,
  Box,
  Typography,
  Avatar,
  Button,
  Tabs,
  Tab,
  Chip,
  List,
  ListItem,
  ListItemText,
  TextField,
} from "@mui/material";
import {
  HomeIcon,
  PencilIcon,
  TrashIcon,
  CalendarIcon,
  DocumentTextIcon,
  ChartBarIcon,
  PlusIcon,
  ExclamationTriangleIcon,
  TicketIcon,
  ClockIcon,
  CalendarDaysIcon,
  XMarkIcon,
  CheckIcon,
} from "@heroicons/react/24/solid";
import { useNavigate, useLocation } from "react-router-dom";
import DeleteClientDialog from "./DeleteClientDialog";
import { Formik, Form } from "formik";
import * as Yup from "yup";

// Validation Schema for Client
const clientValidationSchema = Yup.object({
  companyName: Yup.string()
    .required("Company name is required")
    .min(2, "Company name must be at least 2 characters"),
  email: Yup.string()
    .required("Email is required")
    .email("Invalid email address"),
  phone: Yup.string()
    .required("Phone number is required")
    .matches(
      /^[\+]?1?[\s.-]?\(?([0-9]{3})\)?[\s.-]?([0-9]{3})[\s.-]?([0-9]{4})$/,
      "Phone must be in US format (e.g., (123) 456-7890)"
    )
    .test('is-valid-us-phone', 'Phone must be a valid 10-digit US number', function(value) {
      if (!value) return false;
      const digitsOnly = value.replace(/\D/g, '');
      return digitsOnly.length === 10 || (digitsOnly.length === 11 && digitsOnly.startsWith('1'));
    }),
  address: Yup.string().required("Address is required"),
  industry: Yup.string().required("Industry is required"),
  accountManager: Yup.string().required("Account manager is required"),
});

const ClientDetails = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [lastEditDate, setLastEditDate] = useState(null);
  const [hasBeenEdited, setHasBeenEdited] = useState(false);
  const clientData = location.state?.clientData;

  const [activeTab, setActiveTab] = useState(0);

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const getCompanyLogoUrl = (companyName = "Client") => {
    const encoded = encodeURIComponent(companyName.trim() || "Client");
    return `https://api.dicebear.com/7.x/initials/svg?seed=${encoded}`;
  };

  // Helper function to auto-format phone numbers
  const formatPhoneNumber = (value) => {
    if (!value) return value;
    const phoneNumber = value.replace(/[^\d]/g, '');
    const phoneNumberLength = phoneNumber.length;
    
    if (phoneNumberLength === 0) return '';
    if (phoneNumberLength < 4) return phoneNumber;
    if (phoneNumberLength < 7) {
      return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3)}`;
    }
    return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3, 6)}-${phoneNumber.slice(6, 10)}`;
  };

  const handleEditToggle = () => {
    setIsEditMode(!isEditMode);
  };

  const handleSaveClient = (values) => {
    console.log("Saved client data:", values);
    
    // Get current date in the format "DD MMM YYYY"
    const now = new Date();
    const formattedDate = now.toLocaleDateString('en-GB', { 
      day: '2-digit', 
      month: 'short', 
      year: 'numeric' 
    });
    
    setLastEditDate(formattedDate);
    setHasBeenEdited(true);
    setIsEditMode(false);
    
    // Here you would typically make an API call to save the data
  };

  // Client info
  const clientInfo = {
    companyName: clientData?.clientName || "Tech Solutions Inc.",
    email: "contact@techsolutions.com",
    address: "123 Business Ave, San Francisco, CA",
    industry: "Technology",
    phone: "(415) 555-0123",
    accountManager: clientData?.accountManager?.name || "Emily Rodriguez",
    activeSince: "Jan 2024",
  };

  // Primary contact
// Primary contact - Use Account Manager data from grid
const primaryContact = {
  name: clientData?.accountManager?.name || "Emily Rodriguez",
  title: "Account Manager", // or clientData?.accountManager?.title if you add it to grid data
  email: clientData?.accountManager?.email || "emily.rodriguez@company.com",
  avatar: clientData?.accountManager?.avatar || "https://i.pravatar.cc/150?img=1",
};

  // Ticket data
  const ticketData = [
    {
      id: "2301",
      date: "11/20/2025 15:30",
      status: "Opened",
      statusColor: "#DBEAFE",
      description: "Network connectivity issues affecting entire office. Priority investigation required.",
    },
    {
      id: "2294",
      date: "11/18/2025 10:15",
      status: "In Progress",
      statusColor: "#FEF3C7",
      description: "Server maintenance scheduled for weekend deployment.",
    },
    {
      id: "2287",
      date: "11/15/2025 14:20",
      status: "Resolved",
      statusColor: "#D1FAE5",
      description: "Software license renewal completed successfully for 50 users.",
    },
    {
      id: "2279",
      date: "11/12/2025 09:45",
      status: "Resolved",
      statusColor: "#D1FAE5",
      description: "Email server configuration updated and tested.",
    },
    {
      id: "2271",
      date: "11/08/2025 16:00",
      status: "Waiting for Customer",
      statusColor: "#E0E7FF",
      description: "Awaiting approval for new hardware procurement request.",
    },
  ];

  const openTicketsCount = ticketData.filter((t) => t.status === "Opened").length;
  const totalTicketsCount = ticketData.length;
  const openLast30DaysCount = ticketData.filter(
    (t) => t.status === "Opened" || t.status === "In Progress"
  ).length;

  const overviewStats = [
    {
      label: "Open Tickets",
      value: openTicketsCount,
      iconBg: "#FEE2E2",
      iconColor: "#DC2626",
      Icon: ExclamationTriangleIcon,
    },
    {
      label: "Total Tickets",
      value: totalTicketsCount,
      iconBg: "#DCFCE7",
      iconColor: "#16A34A",
      Icon: TicketIcon,
    },
    {
      label: "Open in last 30 days",
      value: openLast30DaysCount,
      iconBg: "#DBEAFE",
      iconColor: "#2563EB",
      Icon: TicketIcon,
    },
  ];

  const recentActivities = [
    { text: "New ticket created - Network issue", time: "2 hours ago", color: "#3B82F6" },
    { text: "Server maintenance scheduled", time: "1 day ago", color: "#10B981" },
    { text: "License renewal completed", time: "3 days ago", color: "#8B5CF6" },
    { text: "Email configuration updated", time: "5 days ago", color: "#F59E0B" },
    { text: "Hardware request submitted", time: "1 week ago", color: "#EF4444" },
    { text: "Contract renewal discussion", time: "2 weeks ago", color: "#6B7280" },
    { text: "Quarterly review completed", time: "3 weeks ago", color: "#10B981" },
    { text: "New service agreement signed", time: "1 month ago", color: "#8B5CF6" },
  ];

  return (
    <>
      <Grid container spacing={{ xs: 1, md: 2 }} columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{ width: "100%", maxWidth: "100vw", m: 0, p: { xs: 0, sm: 1 }, justifyContent: "center", flexGrow: 1 }}>
        <Grid item size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{ border: "1px solid #E4E4E7", backgroundColor: "#fff", px: { xs: 1, sm: 4, md: 6, xl: 3 }, py: { xs: 0, sm: 3 } }}>
          
          {/* Breadcrumb */}
          <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
            <HomeIcon style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8, cursor: "pointer" }}
              onClick={() => navigate("/admin")} />
            <TitleBreadcrumb breadcrumbsData={[
              { type: "link", label: "Service Desk", to: "/admin" },
              { type: "link", label: "Customers", to: "/crm-customer" },
              { type: "text", label: "Client Details", to: "" },
            ]} />
          </Box>

          {/* Header Section */}
          <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mt: 3, mb: 3, flexWrap: "wrap", rowGap: 2 }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
              <Avatar src={getCompanyLogoUrl(clientInfo.companyName)} alt={clientInfo.companyName}
                sx={{ width: 64, height: 64, border: "3px solid #E5E7EB" }} />
              <Box>
                <Typography sx={{ fontFamily: "Open Sans", fontSize: 24, fontWeight: 700, color: "#111827", lineHeight: 1.2 }}>
                  {clientInfo.companyName}
                </Typography>
                <Typography sx={{ fontFamily: "Open Sans", fontSize: 16, fontWeight: 400, color: "#4B5563", mt: 0.3 }}>
                  {clientInfo.industry} • {clientData?.openTickets || 0} Open Tickets
                </Typography>
                <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mt: 0.6 }}>
                  <Chip label="Active" sx={{ height: 28, borderRadius: "999px", bgcolor: "#DCFCE7", color: "#166534",
                    fontFamily: "Open Sans", fontSize: 13, fontWeight: 600, px: 1.5 }} />
                  <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, fontWeight: 500, color: "#6B7280" }}>
                    Account Manager: {clientInfo.accountManager}
                  </Typography>
                </Box>
              </Box>
            </Box>

            <Box sx={{ display: "flex", gap: 1.5 }}>
              {!isEditMode ? (
                <Button variant="contained" onClick={handleEditToggle}
                  startIcon={<PencilIcon style={{ width: 16, height: 16 }} />}
                  sx={{ bgcolor: "#409BFF", color: "#fff", textTransform: "none", fontFamily: "Open Sans",
                    fontWeight: 600, fontSize: 14, px: 2.5, py: 1, borderRadius: "6px", boxShadow: "none",
                    "&:hover": { bgcolor: "#2563EB", boxShadow: "none" } }}>
                  Edit
                </Button>
              ) : (
                <Button variant="contained" onClick={handleEditToggle}
                  startIcon={<XMarkIcon style={{ width: 16, height: 16 }} />}
                  sx={{ bgcolor: "#6B7280", color: "#fff", textTransform: "none", fontFamily: "Open Sans",
                    fontWeight: 600, fontSize: 14, px: 2.5, py: 1, borderRadius: "6px", boxShadow: "none",
                    "&:hover": { bgcolor: "#4B5563", boxShadow: "none" } }}>
                  Cancel
                </Button>
              )}
              <Button variant="contained" onClick={() => setDeleteOpen(true)}
                startIcon={<TrashIcon style={{ width: 16, height: 16 }} />}
                sx={{ bgcolor: "#EF4444", color: "#fff", textTransform: "none", fontFamily: "Open Sans",
                  fontWeight: 600, fontSize: 14, px: 2.5, py: 1, borderRadius: "6px", boxShadow: "none",
                  "&:hover": { bgcolor: "#DC2626", boxShadow: "none" } }}>
                Delete
              </Button>
            </Box>
          </Box>

          {/* Client Information with Formik */}
          <Formik initialValues={clientInfo} validationSchema={clientValidationSchema}
            onSubmit={handleSaveClient} enableReinitialize>
            {({ values, errors, touched, handleChange, handleBlur, handleSubmit }) => (
              <Form onSubmit={handleSubmit}>
                <Grid container spacing={3} columns={{ xs: 12, sm: 12, md: 12, xl: 12 }} sx={{ mb: 3 }}>
                  <Grid item size={{ xs: 12, sm: 12, md: 12, xl: 12 }}>
                    <Box sx={{ bgcolor: "#F9FAFB", p: 3, borderRadius: "8px" }}>
                      
                      {/* Header */}
                      <Box sx={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 4, mb: 3, flexWrap: "wrap" }}>
                        <Typography sx={{ fontFamily: "Open Sans", fontSize: 18, fontWeight: 700, color: "#111827" }}>
                          Client Information
                        </Typography>
                        
                        <Box sx={{ display: "flex", alignItems: "center", gap: 3 }}>
                          {isEditMode && (
                            <Button type="submit" variant="contained"
                              startIcon={<CheckIcon style={{ width: 16, height: 16 }} />}
                              sx={{ bgcolor: "#10B981", color: "#fff", textTransform: "none", fontFamily: "Open Sans",
                                fontWeight: 600, fontSize: 14, px: 3, py: 1, borderRadius: "6px", boxShadow: "none",
                                "&:hover": { bgcolor: "#059669", boxShadow: "none" } }}>
                              Save Changes
                            </Button>
                          )}
                          <Typography sx={{ fontFamily: "Open Sans", fontSize: 18, fontWeight: 700, color: "#111827" }}>
                            Primary Contact
                          </Typography>
                        </Box>
                      </Box>

                      {/* Content Row */}
                      <Box sx={{ display: "flex", justifyContent: "space-between", gap: 4, flexWrap: { xs: "wrap", md: "nowrap" } }}>
                        
                        {/* Left - Client Info */}
                        <Box sx={{ flex: 1, minWidth: 0 }}>
                          <Grid container spacing={3} columns={{ xs: 12, sm: 12, md: 12, xl: 12 }} sx={{ mb: 2 }}>
                            
                            {/* Company Name */}
                            <Grid item size={{ xs: 12, sm: 4, md: 4, xl: 4 }}>
                              <Typography sx={{ fontFamily: "Open Sans", fontSize: 13, fontWeight: 600, color: "#6B7280", mb: 0.5 }}>
                                Company Name
                              </Typography>
                              {!isEditMode ? (
                                <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, fontWeight: 600, color: "#111827", wordBreak: "break-word" }}>
                                  {values.companyName}
                                </Typography>
                              ) : (
                                <TextField fullWidth name="companyName" value={values.companyName} onChange={handleChange}
                                  onBlur={handleBlur} error={touched.companyName && Boolean(errors.companyName)}
                                  helperText={touched.companyName && errors.companyName} size="small"
                                  sx={{ "& .MuiOutlinedInput-root": { fontFamily: "Open Sans", fontSize: 14 } }} />
                              )}
                            </Grid>

                            {/* Email */}
                            <Grid item size={{ xs: 12, sm: 4, md: 4, xl: 4 }}>
                              <Typography sx={{ fontFamily: "Open Sans", fontSize: 13, fontWeight: 600, color: "#6B7280", mb: 0.5 }}>
                                Email
                              </Typography>
                              {!isEditMode ? (
                                <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, fontWeight: 600, color: "#111827", wordBreak: "break-all" }}>
                                  {values.email}
                                </Typography>
                              ) : (
                                <TextField fullWidth name="email" value={values.email} onChange={handleChange}
                                  onBlur={handleBlur} error={touched.email && Boolean(errors.email)}
                                  helperText={touched.email && errors.email} size="small"
                                  sx={{ "& .MuiOutlinedInput-root": { fontFamily: "Open Sans", fontSize: 14 } }} />
                              )}
                            </Grid>

                            {/* Address */}
                            <Grid item size={{ xs: 12, sm: 4, md: 4, xl: 4 }}>
                              <Typography sx={{ fontFamily: "Open Sans", fontSize: 13, fontWeight: 600, color: "#6B7280", mb: 0.5 }}>
                                Address
                              </Typography>
                              {!isEditMode ? (
                                <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, fontWeight: 600, color: "#111827", wordBreak: "break-word" }}>
                                  {values.address}
                                </Typography>
                              ) : (
                                <TextField fullWidth name="address" value={values.address} onChange={handleChange}
                                  onBlur={handleBlur} error={touched.address && Boolean(errors.address)}
                                  helperText={touched.address && errors.address} size="small"
                                  sx={{ "& .MuiOutlinedInput-root": { fontFamily: "Open Sans", fontSize: 14 } }} />
                              )}
                            </Grid>
                          </Grid>

                          {/* Row 2 */}
                          <Grid container spacing={3} columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}>
                            
                            {/* Industry */}
                            <Grid item size={{ xs: 12, sm: 4, md: 4, xl: 4 }}>
                              <Typography sx={{ fontFamily: "Open Sans", fontSize: 13, fontWeight: 600, color: "#6B7280", mb: 0.5 }}>
                                Industry
                              </Typography>
                              {!isEditMode ? (
                                <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, fontWeight: 600, color: "#111827" }}>
                                  {values.industry}
                                </Typography>
                              ) : (
                                <TextField fullWidth name="industry" value={values.industry} onChange={handleChange}
                                  onBlur={handleBlur} error={touched.industry && Boolean(errors.industry)}
                                  helperText={touched.industry && errors.industry} size="small"
                                  sx={{ "& .MuiOutlinedInput-root": { fontFamily: "Open Sans", fontSize: 14 } }} />
                              )}
                            </Grid>

                            {/* Phone */}
                            <Grid item size={{ xs: 12, sm: 4, md: 4, xl: 4 }}>
                              <Typography sx={{ fontFamily: "Open Sans", fontSize: 13, fontWeight: 600, color: "#6B7280", mb: 0.5 }}>
                                Phone
                              </Typography>
                              {!isEditMode ? (
                                <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, fontWeight: 600, color: "#111827" }}>
                                  {values.phone}
                                </Typography>
                              ) : (
                                <TextField fullWidth name="phone" value={values.phone}
                                  onChange={(e) => {
                                    const formatted = formatPhoneNumber(e.target.value);
                                    handleChange({ target: { name: 'phone', value: formatted } });
                                  }}
                                  onBlur={handleBlur} error={touched.phone && Boolean(errors.phone)}
                                  helperText={touched.phone && errors.phone} placeholder="(123) 456-7890"
                                  size="small" inputProps={{ maxLength: 14 }}
                                  sx={{ "& .MuiOutlinedInput-root": { fontFamily: "Open Sans", fontSize: 14 } }} />
                              )}
                            </Grid>

                            {/* Account Manager */}
                            <Grid item size={{ xs: 12, sm: 4, md: 4, xl: 4 }}>
                              <Typography sx={{ fontFamily: "Open Sans", fontSize: 13, fontWeight: 600, color: "#6B7280", mb: 0.5 }}>
                                Account Manager
                              </Typography>
                              {!isEditMode ? (
                                <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, fontWeight: 600, color: "#111827" }}>
                                  {values.accountManager}
                                </Typography>
                              ) : (
                                <TextField fullWidth name="accountManager" value={values.accountManager}
                                  onChange={handleChange} onBlur={handleBlur}
                                  error={touched.accountManager && Boolean(errors.accountManager)}
                                  helperText={touched.accountManager && errors.accountManager} size="small"
                                  sx={{ "& .MuiOutlinedInput-root": { fontFamily: "Open Sans", fontSize: 14 } }} />
                              )}
                            </Grid>
                          </Grid>

                          {/* Active Since / Edited On */}
                          <Grid container spacing={3} columns={{ xs: 12, sm: 12, md: 12, xl: 12 }} sx={{ mt: 2 }}>
                            <Grid item size={{ xs: 12, sm: 4, md: 4, xl: 4 }}>
                              <Typography sx={{ fontFamily: "Open Sans", fontSize: 13, fontWeight: 600, color: "#6B7280", mb: 0.5 }}>
                                {hasBeenEdited ? "Edited On" : "Active Since"}
                              </Typography>
                              <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, fontWeight: 600,
                                color: hasBeenEdited ? "#10B981" : "#111827" }}>
                                {hasBeenEdited ? lastEditDate : values.activeSince}
                              </Typography>
                            </Grid>
                          </Grid>
                        </Box>

                        {/* Right - Primary Contact */}
                        <Box sx={{ width: { xs: "100%", md: 280 }, mt: { xs: 3, md: 0 },
                          display: "flex", justifyContent: { xs: "flex-start", md: "flex-end" } }}>
                          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
                            <Avatar src={primaryContact.avatar} alt={primaryContact.name} sx={{ width: 60, height: 60 }} />
                            <Box>
                              <Typography sx={{ fontFamily: "Open Sans", fontSize: 16, fontWeight: 700, color: "#111827" }}>
                                {primaryContact.name}
                              </Typography>
                              <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, color: "#6B7280", mt: 0.3 }}>
                                {primaryContact.title}
                              </Typography>
                              <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, color: "#409BFF", mt: 0.3, wordBreak: "break-all" }}>
                                {primaryContact.email}
                              </Typography>
                            </Box>
                          </Box>
                        </Box>
                      </Box>
                    </Box>
                  </Grid>
                </Grid>
              </Form>
            )}
          </Formik>

          {/* Tabs Section */}
          <Grid container spacing={1.5} columns={{ xs: 12, sm: 12, md: 12, xl: 12 }} sx={{ mt: 0 }}>
            <Grid item size={{ xs: 12, sm: 12, md: 12, xl: 9 }}>
              <Box sx={{ border: "1px solid #E5E7EB", borderRadius: "8px", bgcolor: "#fff" }}>
                <Tabs value={activeTab} onChange={handleTabChange}
                  TabIndicatorProps={{ style: { backgroundColor: "#409BFF" } }}
                  sx={{ borderBottom: "1px solid #E5E7EB", px: 2,
                    "& .MuiTab-root": { color: "#6B7280", textTransform: "none", fontFamily: "Open Sans",
                      fontSize: 15, fontWeight: 600, minHeight: 48 },
                    "& .Mui-selected": { color: "#409BFF" } }}>
                  <Tab label="Overview" />
                  <Tab label="Tickets" />
                  <Tab label="Opportunities" />
                  <Tab label="Contacts" />
                </Tabs>

                <Box sx={{ p: 3 }}>
                  {activeTab === 0 && (
                    <Box>
                      <Grid container spacing={2.5} columns={{ xs: 12, sm: 12, md: 12, xl: 12 }} sx={{ mb: 3 }}>
                        {overviewStats.map((stat, index) => {
                          const IconComponent = stat.Icon;
                          return (
                            <Grid key={index} item size={{ xs: 12, sm: 12, md: 4, xl: 4 }}>
                              <Box sx={{ borderRadius: "14px", border: "1px solid #E5E7EB", bgcolor: "#FFFFFF",
                                px: 2.5, py: 2, display: "flex", alignItems: "flex-start", justifyContent: "space-between",transition: 'box-shadow 0.3s cubic-bezier(0.4, 0, 0.2, 1), transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
      '&:hover': {
        boxShadow: '0 8px 24px rgba(67, 144, 248, 0.25)',
        transform: 'translateY(-5px)',
        borderColor: '#4390F8',
      } }}>
                                <Box>
                                  <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, fontWeight: 600, color: "#4B5563", mb: 1 }}>
                                    {stat.label}
                                  </Typography>
                                  <Typography sx={{ fontFamily: "Open Sans", fontSize: 24, fontWeight: 700, color: "#111827", mb: 1 }}>
                                    {stat.value}
                                  </Typography>
                                  {index === 0 && (
                                    <Typography sx={{ fontFamily: "Open Sans", fontSize: 13, fontWeight: 500, color: "#DC2626" }}>
                                      1 High Priority
                                    </Typography>
                                  )}
                                </Box>
                                <Box sx={{ width: 52, height: 52, borderRadius: "16px", bgcolor: stat.iconBg,
                                  display: "flex", alignItems: "center", justifyContent: "center" }}>
                                  <IconComponent style={{ width: 26, height: 26, color: stat.iconColor }} />
                                </Box>
                              </Box>
                            </Grid>
                          );
                        })}
                      </Grid>

                      <Box sx={{ mt: 3, maxHeight: 520, pr: 2, overflowY: "auto",
                        "&::-webkit-scrollbar": { width: "6px" },
                        "&::-webkit-scrollbar-track": { bgcolor: "#F3F4F6", borderRadius: "10px" },
                        "&::-webkit-scrollbar-thumb": { bgcolor: "#D1D5DB", borderRadius: "10px",
                          "&:hover": { bgcolor: "#9CA3AF" } } }}>
                        {ticketData.map((ticket, index) => (
                          <Box key={index} sx={{ border: "1px solid #E5E7EB", borderRadius: "8px", p: 2.5, mb: 2,
                            bgcolor: "#fff", transition: "all 0.2s",
                            "&:hover": { boxShadow: "0 2px 8px rgba(0,0,0,0.08)" } }}>
                            <Box sx={{ display: "flex", justifyContent: "space-between", mb: 1.5 }}>
                              <Box sx={{ display: "flex", alignItems: "center", gap: 3 }}>
                                <Typography sx={{ fontFamily: "Open Sans", fontSize: 18, fontWeight: 700, color: "#111827" }}>
                                  {ticket.id}
                                </Typography>
                                <Typography sx={{ fontFamily: "Open Sans", fontSize: 13, color: "#6B7280" }}>
                                  {ticket.date}
                                </Typography>
                              </Box>
                              <Chip label={ticket.status} sx={{ bgcolor: ticket.statusColor, color: "#374151",
                                fontFamily: "Open Sans", fontWeight: 600, fontSize: 12, height: 26, borderRadius: "6px" }} />
                            </Box>
                            <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, color: "#4B5563", lineHeight: 1.5 }}>
                              {ticket.description}
                            </Typography>
                          </Box>
                        ))}
                      </Box>
                    </Box>
                  )}
                  {activeTab === 1 && (
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, color: "#6B7280" }}>
                      All tickets for this client will be displayed here
                    </Typography>
                  )}
                  {activeTab === 2 && (
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, color: "#6B7280" }}>
                      Opportunities and deals will be displayed here
                    </Typography>
                  )}
                  {activeTab === 3 && (
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, color: "#6B7280" }}>
                      Contact list will be displayed here
                    </Typography>
                  )}
                </Box>
              </Box>
            </Grid>

            {/* Right Sidebar */}
            <Grid item size={{ xs: 12, sm: 12, md: 12, xl: 3 }}>
              <Box sx={{ borderRadius: "14px", border: "1px solid #E5E7EB", bgcolor: "#FFFFFF", p: 2.5, mb: 1.4 }}>
                <Typography sx={{ fontFamily: "Open Sans", fontSize: 18, fontWeight: 700, color: "#111827", mb: 2.5 }}>
                  Quick Actions
                </Typography>
                <Box sx={{ display: "flex", flexDirection: "column", gap: 1.75, mb: 2.5 }}>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                    <CalendarDaysIcon style={{ width: 20, height: 20, color: "#6B7280" }} />
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, fontWeight: 500, color: "#374151" }}>
                      Schedule Meeting
                    </Typography>
                  </Box>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                    <DocumentTextIcon style={{ width: 20, height: 20, color: "#6B7280" }} />
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, fontWeight: 500, color: "#374151" }}>
                      Create Proposal
                    </Typography>
                  </Box>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                    <ChartBarIcon style={{ width: 20, height: 20, color: "#6B7280" }} />
                    <Typography sx={{ fontFamily: "Open Sans", fontSize: 14, fontWeight: 500, color: "#374151" }}>
                      View Reports
                    </Typography>
                  </Box>
                </Box>
                <Button fullWidth
                  startIcon={<PlusIcon style={{ width: 18, height: 18 }} />}
                  sx={{ mt: 0.5, justifyContent: "center", textTransform: "none", fontFamily: "Open Sans",
                    fontSize: 15, fontWeight: 600, color: "#409BFF", bgcolor: "#EFF6FF", py: 1.2,
                    borderRadius: "10px", boxShadow: "none",
                    "&:hover": { bgcolor: "#E0E7FF", boxShadow: "none" } }}>
                  Create Opportunity
                </Button>
              </Box>

              <Box sx={{ border: "1px solid #E5E7EB", borderRadius: "8px", p: 2.5, bgcolor: "#fff" }}>
                <Typography sx={{ fontFamily: "Open Sans", fontSize: 16, fontWeight: 700, color: "#111827", mb: 2 }}>
                  Recent Activity
                </Typography>
                <Box sx={{ maxHeight: 420, overflowY: "auto",
                  "&::-webkit-scrollbar": { width: "6px" },
                  "&::-webkit-scrollbar-track": { bgcolor: "#F3F4F6", borderRadius: "10px" },
                  "&::-webkit-scrollbar-thumb": { bgcolor: "#D1D5DB", borderRadius: "10px",
                    "&:hover": { bgcolor: "#9CA3AF" } } }}>
                  <List sx={{ p: 0 }}>
                    {recentActivities.map((activity, index) => (
                      <ListItem key={index} sx={{ px: 0, py: 1.5,
                        borderBottom: index !== recentActivities.length - 1 ? "1px solid #F3F4F6" : "none",
                        display: "flex", alignItems: "flex-start", gap: 1.5 }}>
                        <Box sx={{ width: 8, height: 8, borderRadius: "50%", bgcolor: activity.color, mt: 0.8, flexShrink: 0 }} />
                        <ListItemText primary={activity.text} secondary={activity.time}
                          primaryTypographyProps={{
                            sx: { fontFamily: "Open Sans", fontSize: 14, fontWeight: 600, color: "#111827", lineHeight: 1.4 }
                          }}
                          secondaryTypographyProps={{
                            sx: { fontFamily: "Open Sans", fontSize: 12, color: "#9CA3AF", mt: 0.3 }
                          }} />
                      </ListItem>
                    ))}
                  </List>
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <DeleteClientDialog open={deleteOpen} onClose={() => setDeleteOpen(false)} />
    </>
  );
};

export default ClientDetails;
