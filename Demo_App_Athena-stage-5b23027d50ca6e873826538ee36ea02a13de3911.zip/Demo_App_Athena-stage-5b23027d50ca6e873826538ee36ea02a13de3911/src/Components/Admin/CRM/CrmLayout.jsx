import React, { useState } from 'react';
import TitleBreadcrumb from "../../Shared/TitleBreadcrumb";
import { Grid, Box, Typography, Button, IconButton, Card, CardContent, Avatar } from "@mui/material";
import { 
  HomeIcon, 
  PlusIcon, 
  RectangleGroupIcon,
  ArrowPathIcon,
  ArrowDownTrayIcon,
  EllipsisHorizontalIcon,
  UserIcon,
  EyeIcon,
  ChatBubbleLeftRightIcon,
  UserGroupIcon,
  ShoppingBagIcon,
  BriefcaseIcon,
  ClipboardDocumentListIcon,
  BuildingOfficeIcon
} from '@heroicons/react/24/solid';
import { useNavigate } from 'react-router-dom';

const CrmLayout = () => {
  const navigate = useNavigate();

  // Stats data
  const statsData = [
    { value: '1,247', label: 'Total Customers' },
    { value: '89', label: 'Active Opportunities' },
    { value: '156', label: 'New Leads' },
    { value: '$2.4M', label: 'Pipeline Value' }
  ];

  // Feature cards data with navigation paths
  const featureCards = [
    {
      icon: UserIcon,
      title: 'Customer Account Setup',
      description: 'Create and manage customer profiles with company and contact details.',
      buttonText: 'Manage Accounts',
      iconBg: '#DBEAFE',
      iconColor: '#409BFF',
      path: '/crm-customer'
    },
    {
      icon: EyeIcon,
      title: 'View Selection',
      description: 'Switch between list, grid, or detailed views for CRM data.',
      buttonText: 'Customize View',
      iconBg: '#DBEAFE',
      iconColor: '#409BFF',
      path: "/crm-view"
    },
    // {
    //   icon: ChatBubbleLeftRightIcon,
    //   title: 'Communication & Activities',
    //   description: 'Track all interactions, calls, meetings, and emails in one place.',
    //   buttonText: 'View Activities',
    //   iconBg: '#DBEAFE',
    //   iconColor: '#409BFF',
    //   path: null 
    // },
    {
      icon: UserGroupIcon,
      title: 'Contracts Management',
      description: 'Manage all customer and vendor contacts with linked accounts.',
      buttonText: 'Manage Contracts',
      iconBg: '#DBEAFE',
      iconColor: '#409BFF',
      path: '/crm-contract-management'
    },
    {
      icon: BuildingOfficeIcon,
      title: 'Vendors',
      description: 'Add and organize vendor details, relationships, and linked clients.',
      buttonText: 'View Vendors',
      iconBg: '#DBEAFE',
      iconColor: '#409BFF',
      path: "/crm-vendors"
    },
    {
      icon: BriefcaseIcon,
      title: 'Opportunities Management',
      description: 'Track deals, manage sales pipelines, and monitor conversion progress.',
      buttonText: 'View Opportunities',
      iconBg: '#DBEAFE',
      iconColor: '#409BFF',
      path: "/crm-opportunities" 
    },
    {
      icon: ClipboardDocumentListIcon,
      title: 'Leads Management',
      description: 'Manage leads, track sources, and monitor conversion stages.',
      buttonText: 'Manage Leads',
      iconBg: '#DBEAFE',
      iconColor: '#409BFF',
      path: "/crm-leads"
    }
  ];

  // Handle card click navigation
  const handleCardClick = (path) => {
    if (path) {
      navigate(path);
    }
  };

  return (
    <>
      <Grid
        container
        spacing={{ xs: 1, md: 2 }}
        columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{
          width: "100%",
          maxWidth: "100vw",
          m: 0,
          p: { xs: 0, sm: 1 },
          justifyContent: "center",
          flexGrow: 1,
        }}
      >
        <Grid
          item
          size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{
            border: "1px solid #E4E4E7",
            backgroundColor: "#fff",
            px: { xs: 1, sm: 4, md: 6, xl: 3 },
            py: { xs: 0, sm: 3 },
          }}
        >
          {/* Breadcrumb */}
          <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
            <HomeIcon style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8, cursor: "pointer" }} onClick={() => navigate("/admin")}/>
            <TitleBreadcrumb 
              breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin" }, 
                { type: "text", label: "CRM", to: "" }
              ]} 
            />
          </Box>

          {/* Header with Title */}
          <Box 
            sx={{ 
              mt: 2, 
              pt: 1, 
              pb: 1,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: 2
            }}
          >
            <Typography 
              sx={{ 
                fontFamily: "Open Sans", 
                fontSize: "24px", 
                fontWeight: "700", 
                color: "#111827" 
              }}
            >
              Customer Relationship Management (CRM)
            </Typography>
          </Box>

          {/* CRM Overview Section - Single Box */}
          <Box 
            sx={{ 
              mt: 3, 
              mb: 3,
              border: '1px solid #E4E4E7',
              borderRadius: '8px',
              backgroundColor: '#fff',
              p: 3,
              transition: 'all 0.3s ease-in-out',
                      '&:hover': {
                        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)' ,
                        // transform:  'translateY(-2px)'
                      }
            }}
          >
            {/* Section Title */}
            <Typography 
              sx={{ 
                fontFamily: "Open Sans", 
                fontSize: "20px", 
                fontWeight: "600", 
                color: "#111827",
                mb: 4
              }}
            >
              CRM Overview
            </Typography>

            {/* Stats in One Row */}
            <Box 
              sx={{ 
                display: 'flex',
                justifyContent: 'space-around',
                alignItems: 'center',
                flexWrap: 'wrap',
                gap: { xs: 3, sm: 2 }
              }}
            >
              {statsData.map((stat, index) => (
                <Box
                  key={index}
                  sx={{
                    textAlign: 'center',
                    minWidth: { xs: '120px', sm: '150px' },
                    flex: { xs: '1 1 45%', sm: '1 1 auto' }
                  }}
                >
                  <Typography
                    sx={{
                      fontFamily: "Open Sans",
                      fontSize: { xs: '32px', sm: '36px', md: '32px' },
                      fontWeight: "700",
                      color: '#3B82F6',
                      mb: 1,
                      lineHeight: 1.2
                    }}
                  >
                    {stat.value}
                  </Typography>
                  <Typography
                    sx={{
                      fontFamily: "Open Sans",
                      fontSize: '15px',
                      fontWeight: "400",
                      color: '#6B7280',
                      letterSpacing: '0.02em'
                    }}
                  >
                    {stat.label}
                  </Typography>
                </Box>
              ))}
            </Box>
          </Box>

          {/* Description Text */}
          <Box sx={{ mb: 4 }}>
            <Typography
              sx={{
                fontFamily: "Open Sans",
                fontSize: '15px',
                fontWeight: "400",
                color: '#4B5563',
                lineHeight: 1.6,
                textAlign: 'left'
              }}
            >
              Manage all your customer relationships, sales processes, and business opportunities in one centralized platform.
            </Typography>
          </Box>

          {/* Feature Cards Grid */}
          <Grid 
            container 
            spacing={3}
            sx={{
              justifyContent: 'center'
            }}
          >
            {featureCards.map((card, index) => {
              const IconComponent = card.icon;
              return (
                <Grid item size={{ xs: 12, sm: 12, md: 4, xl: 4 }} key={index}>
                  <Card
                    onClick={() => handleCardClick(card.path)}
                    sx={{
                      height: '100%',
                      display: 'flex',
                      flexDirection: 'column',
                      border: '1px solid #E5E7EB',
                      borderRadius: '8px',
                      boxShadow: 'none',
                      cursor:  "pointer",
                      transition: 'all 0.3s ease-in-out',
                      '&:hover': {
                        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)' ,
                        transform:  'translateY(-2px)'
                      }
                    }}
                  >
                    <CardContent
                      sx={{
                        p: 3,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        textAlign: 'center',
                        flexGrow: 1
                      }}
                    >
                      {/* Icon Circle */}
                      <Box
                        sx={{
                          width: 56,
                          height: 56,
                          borderRadius: '50%',
                          backgroundColor: card.iconBg,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          mb: 2
                        }}
                      >
                        <IconComponent
                          style={{
                            width: 28,
                            height: 28,
                            color: card.iconColor
                          }}
                        />
                      </Box>

                      {/* Title */}
                      <Typography
                        sx={{
                          fontFamily: "Open Sans",
                          fontSize: '16px',
                          fontWeight: "600",
                          color: '#111827',
                          mb: 1.5,
                          lineHeight: 1.4
                        }}
                      >
                        {card.title}
                      </Typography>

                      {/* Description */}
                      <Typography
                        sx={{
                          fontFamily: "Open Sans",
                          fontSize: '14px',
                          fontWeight: "400",
                          color: '#4B5563',
                          mb: 3,
                          lineHeight: 1.6,
                          flexGrow: 1
                        }}
                      >
                        {card.description}
                      </Typography>

                      {/* Button */}
                      <Button
                        variant="contained"
                        fullWidth
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCardClick(card.path);
                        }}
                        sx={{
                          fontFamily: "Open Sans",
                          fontSize: '15px',
                          fontWeight: "500",
                          textTransform: 'none',
                          backgroundColor: '#409BFF',
                          color: '#fff',
                          py: 1,
                          borderRadius: '8px',
                          boxShadow: 'none',
                          '&:hover': {
                            backgroundColor: '#2563EB',
                            boxShadow: 'none'
                          }
                        }}
                      >
                        {card.buttonText}
                      </Button>
                    </CardContent>
                  </Card>
                </Grid>
              );
            })}
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};

export default CrmLayout;