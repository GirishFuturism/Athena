import React, { useState } from 'react';
import TitleBreadcrumb from "../../../Shared/TitleBreadcrumb";
import { 
  Grid, 
  Box, 
  Typography, 
  Button, 
  Checkbox, 
  FormControlLabel,
  TextField,
  MenuItem,
  Collapse
} from "@mui/material";
import { 
  HomeIcon, 
  ChevronDownIcon,
  ChevronUpIcon
} from '@heroicons/react/24/solid';
import { useNavigate } from 'react-router-dom';

const ViewSelection = () => {
  const navigate = useNavigate();

  // MenuProps configuration for all dropdowns
  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

  // Accordion states
  const [expandedSections, setExpandedSections] = useState({
    views: false,
    lists: false,
    filterProfiles: false,
    columnProfiles: false
  });

  // Form states
  const [allowGrouping, setAllowGrouping] = useState(false);
  const [defaultView, setDefaultView] = useState('Opportunities by Status');
  const [defaultList, setDefaultList] = useState('My Open Leads');
  const [defaultColumnProfile, setDefaultColumnProfile] = useState('Salesperson View');
  const [defaultFilterProfile, setDefaultFilterProfile] = useState('This Weeks Plan');
  const [openTicketFilter, setOpenTicketFilter] = useState('Open Opportunities');

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const viewOptions = [
    'Opportunities by Status',
    'All Opportunities',
    'My Opportunities',
    'Team Opportunities',
    'My Lists'
  ];

  const listOptions = [
    'Unassigned',
    'Todays Plan',
    'My Open Leads',
    'My Unqualified Leads',
    'Tomorrows Plan',
    'Activities Calendar',
    'This Weeks Plan',
    'Next Weeks Plan',
    'My HOT Sales',
    'My Approved Quotes'
  ];

  const columnProfileOptions = [
    'Salesperson View',
    'Manager View',
    'Executive View',
    'Custom View'
  ];

  const filterProfileOptions = [
    'This Weeks Plan',
    'This Month',
    'This Quarter',
    'All Time'
  ];

  const openTicketFilterOptions = [
    'Open Opportunities',
    'Closed Opportunities',
    'All Opportunities',
    'Hot Leads'
  ];

  return (
    <>
      <Grid
        container
        spacing={{ xs: 1, md: 2 }}
        columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{
          width: "100%",
          maxWidth: "100vw",
          m: 0,
          p: { xs: 0, sm: 1 },
          justifyContent: "center",
          flexGrow: 1,
        }}
      >
        <Grid
          item
          size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{
            border: "1px solid #E4E4E7",
            backgroundColor: "#fff",
            px: { xs: 1, sm: 4, md: 6, xl: 3 },
            py: { xs: 0, sm: 3 },
          }}
        >
          {/* Breadcrumb */}
          <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
            <HomeIcon 
              style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8, cursor: "pointer" }} 
              onClick={() => navigate("/admin")}
            />
            <TitleBreadcrumb 
              breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin"},
                { type: "link", label: "CRM", to:'/crm' },
                { type: "text", label: "View"}
              ]} 
            />
          </Box>

          {/* Header with Title */}
          <Box 
            sx={{ 
              mt: 2, 
              pt: 1, 
              pb: 3,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: 2
            }}
          >
            <Typography 
              sx={{ 
                fontFamily: "Open Sans", 
                fontSize: "24px", 
                fontWeight: "700", 
                color: "#111827" 
              }}
            >
              View
            </Typography>
          </Box>

          {/* Accordion Sections */}
          <Box sx={{ mb: 3 }}>
            {/* Views Section */}
            <Box 
              sx={{ 
                borderBottom: "1px solid #E5E7EB",
                py: 2
              }}
            >
              <Box
                onClick={() => toggleSection('views')}
                sx={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  cursor: 'pointer',
                  '&:hover': {
                    backgroundColor: '#F9FAFB'
                  },
                  px: 2,
                  py: 1,
                  borderRadius: '6px'
                }}
              >
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontSize: "16px",
                    fontWeight: "600",
                    color: "#374151"
                  }}
                >
                  Views
                </Typography>
                {expandedSections.views ? (
                  <ChevronUpIcon style={{ width: 20, height: 20, color: "#6B7280" }} />
                ) : (
                  <ChevronDownIcon style={{ width: 20, height: 20, color: "#6B7280" }} />
                )}
              </Box>

              <Collapse in={expandedSections.views}>
                <Box sx={{ px: 2, py: 3 }}>
                  <Typography
                    sx={{
                      fontFamily: "Open Sans",
                      fontSize: "14px",
                      fontWeight: "600",
                      color: "#374151",
                      mb: 1
                    }}
                  >
                    Default View
                  </Typography>
                  <Typography
                    sx={{
                      fontFamily: "Open Sans",
                      fontSize: "12px",
                      fontWeight: "400",
                      color: "#6B7280",
                      mb: 2
                    }}
                  >
                    This can be overridden per Agent in the Agent preferences
                  </Typography>
                  <TextField
                    select
                    fullWidth
                    value={defaultView}
                    onChange={(e) => setDefaultView(e.target.value)}
                    InputProps={{
                      sx: {
                        fontFamily: "Open Sans",
                        fontSize: 14,
                        height: "40px",
                      },
                    }}
                    SelectProps={{
                      MenuProps: menuProps,
                    }}
                  >
                    {viewOptions.map((option) => (
                      <MenuItem key={option} value={option}>
                        {option}
                      </MenuItem>
                    ))}
                  </TextField>

                  {/* Conditional Default List Dropdown - Shows when "My Lists" is selected */}
                  {defaultView === 'My Lists' && (
                    <Box sx={{ mt: 3 }}>
                      <Typography
                        sx={{
                          fontFamily: "Open Sans",
                          fontSize: "14px",
                          fontWeight: "600",
                          color: "#374151",
                          mb: 1
                        }}
                      >
                        Default List
                      </Typography>
                      <Typography
                        sx={{
                          fontFamily: "Open Sans",
                          fontSize: "12px",
                          fontWeight: "400",
                          color: "#6B7280",
                          mb: 2
                        }}
                      >
                        This can be overridden per Agent in the Agent preferences
                      </Typography>
                      <TextField
                        select
                        fullWidth
                        value={defaultList}
                        onChange={(e) => setDefaultList(e.target.value)}
                        InputProps={{
                          sx: {
                            fontFamily: "Open Sans",
                            fontSize: 14,
                            height: "40px",
                          },
                        }}
                        SelectProps={{
                          MenuProps: menuProps,
                        }}
                      >
                        {listOptions.map((option) => (
                          <MenuItem key={option} value={option}>
                            {option}
                          </MenuItem>
                        ))}
                      </TextField>
                    </Box>
                  )}
                </Box>
              </Collapse>
            </Box>

            {/* Lists Section */}
            <Box 
              sx={{ 
                borderBottom: "1px solid #E5E7EB",
                py: 2
              }}
            >
              <Box
                onClick={() => toggleSection('lists')}
                sx={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  cursor: 'pointer',
                  '&:hover': {
                    backgroundColor: '#F9FAFB'
                  },
                  px: 2,
                  py: 1,
                  borderRadius: '6px'
                }}
              >
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontSize: "16px",
                    fontWeight: "600",
                    color: "#374151"
                  }}
                >
                  Lists
                </Typography>
                {expandedSections.lists ? (
                  <ChevronUpIcon style={{ width: 20, height: 20, color: "#6B7280" }} />
                ) : (
                  <ChevronDownIcon style={{ width: 20, height: 20, color: "#6B7280" }} />
                )}
              </Box>

              <Collapse in={expandedSections.lists}>
                <Box sx={{ px: 2, py: 3 }}>
                  <Typography
                    sx={{
                      fontFamily: "Open Sans",
                      fontSize: "14px",
                      fontWeight: "400",
                      color: "#6B7280",
                      mb: 2
                    }}
                  >
                    Configure the Lists which appears when in "My Lists" view.
                  </Typography>

                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={allowGrouping}
                        onChange={(e) => setAllowGrouping(e.target.checked)}
                        sx={{
                          "&.Mui-checked": {
                            color: "#409BFF",
                          },
                        }}
                      />
                    }
                    label={
                      <Typography
                        sx={{
                          fontSize: 14,
                          fontFamily: "Open Sans",
                          color: "#374151",
                        }}
                      >
                        Allow grouping of lists
                      </Typography>
                    }
                    sx={{ mb: 3 }}
                  />

                  <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
                    <Button
                      onClick={() => navigate('/configure-list')}
                      sx={{
                        backgroundColor: "#409BFF",
                        color: "#FFFFFF",
                        fontFamily: "Open Sans",
                        fontSize: "14px",
                        fontWeight: 600,
                        textTransform: "none",
                        px: 3,
                        py: 1,
                        borderRadius: "20px",
                        "&:hover": {
                          backgroundColor: "#2563EB",
                        },
                      }}
                    >
                      Configure Lists
                    </Button>
                  </Box>
                </Box>
              </Collapse>
            </Box>

            {/* Filter Profiles Section */}
            <Box 
              sx={{ 
                borderBottom: "1px solid #E5E7EB",
                py: 2
              }}
            >
              <Box
                onClick={() => toggleSection('filterProfiles')}
                sx={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  cursor: 'pointer',
                  '&:hover': {
                    backgroundColor: '#F9FAFB'
                  },
                  px: 2,
                  py: 1,
                  borderRadius: '6px'
                }}
              >
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontSize: "16px",
                    fontWeight: "600",
                    color: "#374151"
                  }}
                >
                  Filter Profiles
                </Typography>
                {expandedSections.filterProfiles ? (
                  <ChevronUpIcon style={{ width: 20, height: 20, color: "#6B7280" }} />
                ) : (
                  <ChevronDownIcon style={{ width: 20, height: 20, color: "#6B7280" }} />
                )}
              </Box>

              <Collapse in={expandedSections.filterProfiles}>
                <Box sx={{ px: 2, py: 3 }}>
                  <Typography
                    sx={{
                      fontFamily: "Open Sans",
                      fontSize: "14px",
                      fontWeight: "400",
                      color: "#6B7280",
                      mb: 3
                    }}
                  >
                    Configure Filter Profiles to restrict the items visible in lists
                  </Typography>

                  <Button
                    onClick={() => navigate('/configure-filter')}
                    sx={{
                      backgroundColor: "#409BFF",
                      color: "#FFFFFF",
                      fontFamily: "Open Sans",
                      fontSize: "14px",
                      fontWeight: 600,
                      textTransform: "none",
                      px: 3,
                      py: 1,
                      borderRadius: "20px",
                      mb: 3,
                      "&:hover": {
                        backgroundColor: "#2563EB",
                      },
                    }}
                  >
                    Configure Filter Profiles
                  </Button>

                  <Typography
                    sx={{
                      fontFamily: "Open Sans",
                      fontSize: "14px",
                      fontWeight: "600",
                      color: "#374151",
                      mb: 1
                    }}
                  >
                    Default Filter Profile
                  </Typography>
                  <Typography
                    sx={{
                      fontFamily: "Open Sans",
                      fontSize: "12px",
                      fontWeight: "400",
                      color: "#6B7280",
                      mb: 2
                    }}
                  >
                    This can be overridden per Agent in the Agent preferences
                  </Typography>
                  <TextField
                    select
                    fullWidth
                    value={defaultFilterProfile}
                    onChange={(e) => setDefaultFilterProfile(e.target.value)}
                    InputProps={{
                      sx: {
                        fontFamily: "Open Sans",
                        fontSize: 14,
                        height: "40px",
                      },
                    }}
                    SelectProps={{
                      MenuProps: menuProps,
                    }}
                    sx={{ mb: 3 }}
                  >
                    {filterProfileOptions.map((option) => (
                      <MenuItem key={option} value={option}>
                        {option}
                      </MenuItem>
                    ))}
                  </TextField>

                  <Typography
                    sx={{
                      fontFamily: "Open Sans",
                      fontSize: "14px",
                      fontWeight: "600",
                      color: "#374151",
                      mb: 1
                    }}
                  >
                    Filter Profile for Open Ticket (Including SLA Hold) widgets
                  </Typography>
                  <Typography
                    sx={{
                      fontFamily: "Open Sans",
                      fontSize: "12px",
                      fontWeight: "400",
                      color: "#6B7280",
                      mb: 2
                    }}
                  >
                    This determines the filter profile used for 'Open Tickets' count in Clients, Sites, Users and Assets
                  </Typography>
                  <TextField
                    select
                    fullWidth
                    value={openTicketFilter}
                    onChange={(e) => setOpenTicketFilter(e.target.value)}
                    InputProps={{
                      sx: {
                        fontFamily: "Open Sans",
                        fontSize: 14,
                        height: "40px",
                      },
                    }}
                    SelectProps={{
                      MenuProps: menuProps,
                    }}
                  >
                    {openTicketFilterOptions.map((option) => (
                      <MenuItem key={option} value={option}>
                        {option}
                      </MenuItem>
                    ))}
                  </TextField>
                </Box>
              </Collapse>
            </Box>

            {/* Column Profiles Section */}
            <Box 
              sx={{ 
                py: 2
              }}
            >
              <Box
                onClick={() => toggleSection('columnProfiles')}
                sx={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  cursor: 'pointer',
                  '&:hover': {
                    backgroundColor: '#F9FAFB'
                  },
                  px: 2,
                  py: 1,
                  borderRadius: '6px'
                }}
              >
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontSize: "16px",
                    fontWeight: "600",
                    color: "#374151"
                  }}
                >
                  Column Profiles
                </Typography>
                {expandedSections.columnProfiles ? (
                  <ChevronUpIcon style={{ width: 20, height: 20, color: "#6B7280" }} />
                ) : (
                  <ChevronDownIcon style={{ width: 20, height: 20, color: "#6B7280" }} />
                )}
              </Box>

              <Collapse in={expandedSections.columnProfiles}>
                <Box sx={{ px: 2, py: 3 }}>
                  <Typography
                    sx={{
                      fontFamily: "Open Sans",
                      fontSize: "14px",
                      fontWeight: "400",
                      color: "#6B7280",
                      mb: 3
                    }}
                  >
                    Configure Column Profiles to show the data you require in lists
                  </Typography>

                  <Button
                    onClick={() => navigate("/configure-column-profile")}
                    sx={{
                      backgroundColor: "#409bff",
                      color: "#FFFFFF",
                      fontFamily: "Open Sans",
                      fontSize: "14px",
                      fontWeight: 600,
                      textTransform: "none",
                      px: 3,
                      py: 1,
                      borderRadius: "20px",
                      mb: 3,
                      "&:hover": {
                        backgroundColor: "#2563EB",
                      },
                    }}
                  >
                    Configure Column Profiles
                  </Button>

                  <Typography
                    sx={{
                      fontFamily: "Open Sans",
                      fontSize: "14px",
                      fontWeight: "600",
                      color: "#374151",
                      mb: 1
                    }}
                  >
                    Default Column Profile
                  </Typography>
                  <Typography
                    sx={{
                      fontFamily: "Open Sans",
                      fontSize: "12px",
                      fontWeight: "400",
                      color: "#6B7280",
                      mb: 2
                    }}
                  >
                    This can be overridden per Agent in the Agent preferences
                  </Typography>
                  <TextField
                    select
                    fullWidth
                    value={defaultColumnProfile}
                    onChange={(e) => setDefaultColumnProfile(e.target.value)}
                    InputProps={{
                      sx: {
                        fontFamily: "Open Sans",
                        fontSize: 14,
                        height: "40px",
                      },
                    }}
                    SelectProps={{
                      MenuProps: menuProps,
                    }}
                  >
                    {columnProfileOptions.map((option) => (
                      <MenuItem key={option} value={option}>
                        {option}
                      </MenuItem>
                    ))}
                  </TextField>
                </Box>
              </Collapse>
            </Box>
          </Box>

        </Grid>
      </Grid>
    </>
  );
};

export default ViewSelection;
