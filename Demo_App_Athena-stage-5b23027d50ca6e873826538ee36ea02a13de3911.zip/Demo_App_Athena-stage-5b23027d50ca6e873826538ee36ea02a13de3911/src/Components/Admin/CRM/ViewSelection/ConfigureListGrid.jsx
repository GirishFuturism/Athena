import React, { useState } from 'react';
import TitleBreadcrumb from "../../../Shared/TitleBreadcrumb";
import { 
  Grid, 
  Box, 
  Typography, 
  IconButton,
  TextField,
  InputAdornment,
} from "@mui/material";
import { 
  ArrowPathIcon,
  HomeIcon,
  MagnifyingGlassIcon,
} from '@heroicons/react/24/solid';
import { useNavigate } from 'react-router-dom';
import { DataGrid } from '@mui/x-data-grid';

const ConfigureListGrid = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);

  // Sample data matching the image structure
  const [listData, setListData] = useState([
    { id: 1, sequence: 1, name: 'Unassigned', use: 'Opportunities', listGroup: 'My Schedule/Unassigned' },
    { id: 2, sequence: 22, name: 'My Open Leads', use: 'Opportunities', listGroup: 'Leads' },
    { id: 3, sequence: 11, name: 'Todays Plan', use: 'Opportunities', listGroup: 'My Schedule/Unassigned' },
    { id: 4, sequence: 25, name: 'My Unqualified Leads', use: 'Opportunities', listGroup: 'Leads' },
    { id: 5, sequence: 20, name: 'Tomorrows Plan', use: 'Opportunities', listGroup: 'My Schedule/Unassigned' },
    { id: 6, sequence: 39, name: 'Activities Calendar', use: 'Opportunities', listGroup: 'My Sales' },
    { id: 7, sequence: 43, name: 'This Weeks Plan', use: 'Opportunities', listGroup: 'My Schedule/Unassigned' },
    { id: 8, sequence: 21, name: 'Next Weeks Plan', use: 'Opportunities', listGroup: 'My Schedule/Unassigned' },
    { id: 9, sequence: 66, name: 'My HOT Sales', use: 'Opportunities', listGroup: 'My Sales' },
    { id: 10, sequence: 55, name: 'My Approved Quotes', use: 'Opportunities', listGroup: 'My Sales' },
  ]);

  // Handle refresh with animation
  const handleRefresh = () => {
    setLoading(true);
    // Simulate refresh - replace with actual API call
    setTimeout(() => {
      console.log('Data refreshed');
      setLoading(false);
    }, 1000);
  };

  // Filter logic
  const filteredData = listData.filter((row) => {
    const matchesSearch = 
      row.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      row.use.toLowerCase().includes(searchQuery.toLowerCase()) ||
      row.listGroup.toLowerCase().includes(searchQuery.toLowerCase()) ||
      row.sequence.toString().includes(searchQuery);
    return matchesSearch;
  });

  // DataGrid columns matching the image
  const columns = [
    {
      field: 'sequence',
      headerName: 'Sequence',
      width: 120,
      renderCell: (params) => (
        <Typography sx={{ fontSize: '14px', fontWeight: 600, color: '#111827', fontFamily: 'Open Sans', pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'name',
      headerName: 'Name',
      flex: 1,
      minWidth: 200,
      renderCell: (params) => (
        <Typography sx={{ fontSize: '14px', fontWeight: 600, color: '#111827', fontFamily: 'Open Sans', pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'use',
      headerName: 'Use',
      flex: 1,
      minWidth: 180,
      renderCell: (params) => (
        <Typography sx={{ fontSize: '14px', fontWeight: 400, color: '#6B7280', fontFamily: 'Open Sans', pt: 2 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'listGroup',
      headerName: 'List Group',
      flex: 1.5,
      minWidth: 250,
      renderCell: (params) => (
        <Typography sx={{ fontSize: '14px', fontWeight: 400, color: '#6B7280', fontFamily: 'Open Sans', pt: 2 }}>
          {params.value}
        </Typography>
      ),
    },
  ];

  return (
    <>
      <Grid
        container
        spacing={{ xs: 1, md: 2 }}
        columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{
          width: "100%",
          maxWidth: "100vw",
          m: 0,
          p: { xs: 0, sm: 1 },
          justifyContent: "center",
          flexGrow: 1,
        }}
      >
        <Grid
          item
          size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{
            border: "1px solid #E4E4E7",
            backgroundColor: "#fff",
            px: { xs: 1, sm: 4, md: 6, xl: 3 },
            py: { xs: 0, sm: 3 },
          }}
        >
          {/* Breadcrumb */}
          <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
            <HomeIcon 
              style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8, cursor: "pointer" }} 
              onClick={() => navigate("/admin")}
            />
            <TitleBreadcrumb 
              breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin"},
                { type: "link", label: "CRM", to:'/crm'},
                { type: "link", label: "View", to:'/crm-view'},
                { type: "text", label: "Configure List"}
              ]} 
            />
          </Box>

          {/* Header with Title and Refresh Button */}
          <Box 
            sx={{ 
              mt: 2, 
              pt: 1, 
              pb: 3,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: 2
            }}
          >
            <Typography 
              sx={{ 
                fontFamily: "Open Sans", 
                fontSize: "24px", 
                fontWeight: "700", 
                color: "#111827" 
              }}
            >
              Configure List
            </Typography>

            <IconButton
              onClick={handleRefresh}
              disabled={loading}
              sx={{
                backgroundColor: '#409BFF',
                color: '#FFFFFF',
                width: 38,
                height: 38,
                borderRadius: '6px',
                transition: "transform 0.3s ease",
                animation: loading ? "spin 1s linear infinite" : "none",
                "@keyframes spin": {
                  "0%": { transform: "rotate(0deg)" },
                  "100%": { transform: "rotate(360deg)" },
                },
                '&:hover': {
                  backgroundColor: '#2563EB'
                },
                '&:disabled': {
                  backgroundColor: '#93C5FD',
                  color: '#FFFFFF'
                }
              }}
            >
              <ArrowPathIcon style={{ width: 18, height: 18 }} />
            </IconButton>
          </Box>

          {/* DataGrid Container */}
             <Box
                          sx={{
                         backgroundColor: '#FFFFFF',
              border: '1px solid #E5E7EB',
              borderRadius: '8px',
              p: 2.5,
              display: 'flex',
              flexDirection: 'column',
                          }}
                        >
            {/* Search Box */}
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', mb: 2.5 }}>
              <TextField
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                size="small"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <MagnifyingGlassIcon style={{ width: 18, height: 18, color: '#9CA3AF' }} />
                    </InputAdornment>
                  ),
                }}
                sx={{
                  width: 220,
                  '& .MuiOutlinedInput-root': {
                    height: 36,
                    fontSize: '14px',
                    fontFamily: 'Open Sans',
                    borderRadius: '6px',
                    backgroundColor: '#FFFFFF',
                    '& fieldset': {
                      borderColor: '#E5E7EB',
                    },
                    '&:hover fieldset': {
                      borderColor: '#D1D5DB',
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: '#409BFF',
                    }
                  }
                }}
              />
            </Box>

            {/* DataGrid */}
            <Box
              sx={{
                width: '100%',
                flexGrow: 1,
                overflowX: 'auto',
                
                '-ms-overflow-style': 'none',
                'scrollbar-width': 'none',
                '&::-webkit-scrollbar': { display: 'none' }
              }}
            >
              <DataGrid
                rows={filteredData}
                columns={columns}
                initialState={{
                  pagination: {
                    paginationModel: { page: 0, pageSize: 7 },
                  },
                }}
                disableRowSelectionOnClick
                sx={{
                  border: 'none',
                  fontFamily: 'Open Sans',
                  '& .MuiDataGrid-columnHeader': {
                    backgroundColor: '#F9FAFB',
                    borderBottom: '1px solid #E5E7EB',
                  },
                  '& .MuiDataGrid-columnHeaderTitle': {
                    fontSize: '14px',
                    fontWeight: 700,
                    color: '#111827',
                    fontFamily: 'Open Sans',
                  },
                  '& .MuiDataGrid-cell': {
                    fontSize: '14px',
                    color: '#111827',
                    fontFamily: 'Open Sans',
                    borderBottom: '1px solid #F3F4F6',
                  },
                  '& .MuiDataGrid-row': {
                    cursor: 'pointer',
                    '&:hover': {
                      backgroundColor: '#EEF2FF',
                    },
                  },
                  '& .MuiDataGrid-columnSeparator': {
                    display: 'none',
                  },
                  '& .MuiDataGrid-footerContainer': {
                    borderTop: '1px solid #E5E7EB',
                    backgroundColor: '#F9FAFB',
                  },
                  "& .MuiDataGrid-cell:focus": {
                    outline: "none",
                  },
                  "& .MuiDataGrid-cell:focus-within": {
                    outline: "none",
                  },
                  "& .MuiDataGrid-columnHeader:focus": {
                    outline: "none",
                  },
                  "& .MuiDataGrid-columnHeader:focus-within": {
                    outline: "none",
                  },
                }}
              />
            </Box>
          </Box>
        </Grid>
      </Grid>
    </>
  );
};

export default ConfigureListGrid;
