import React, { useState } from "react";
import { Grid, Box, Typography, TextField, MenuItem, Button, Dialog, DialogContent, Select, FormControl, FormHelperText, Radio, RadioGroup, FormControlLabel, Chip } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import * as Yup from "yup";
import { CheckCircleIcon, ChartBarIcon, HomeIcon } from "@heroicons/react/24/solid";
import ReactQuill from "react-quill-new";
import 'react-quill-new/dist/quill.snow.css';
import TitleBreadcrumb from "../../../Shared/TitleBreadcrumb";

const labelOptions = ["Hot", "Warm", "Cold"];

const validationSchema = Yup.object({
  ticketType: Yup.string().required("Ticket Type is required"),
  summary: Yup.string().required("Summary is required"),
  details: Yup.string()
    .required("Details are required")
    .test('not-empty', 'Details are required', (value) => {
      return value && value.replace(/<[^>]*>/g, '').trim().length > 0;
    }),
  companyName: Yup.string().when('contactType', {
    is: 'new',
    then: (schema) => schema.required("Company Name is required"),
  }),
  contactName: Yup.string().when('contactType', {
    is: 'new',
    then: (schema) => schema.required("Contact Name is required"),
  }),
  email: Yup.string()
    .email("Invalid email format")
    .when('contactType', {
      is: 'new',
      then: (schema) => schema.required("Email Address is required"),
    }),
  contactTitle: Yup.string(),
  potentialValue: Yup.number()
    .typeError("Potential Value must be a number")
    .positive("Must be positive")
    .nullable(),
  targetDate: Yup.date().nullable(),
  ticketTags: Yup.array(),
  labels: Yup.string(),
});

const NewOpportunityForm = () => {
  const navigate = useNavigate();
  const [successDialogOpen, setSuccessDialogOpen] = useState(false);
  const [contactType, setContactType] = useState("new");
  const [tagInput, setTagInput] = useState("");

  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

  const formik = useFormik({
    initialValues: {
      ticketType: "",
      summary: "",
      details: "",
      companyName: "",
      contactName: "",
      email: "",
      contactTitle: "",
      potentialValue: "",
      targetDate: "",
      ticketTags: [],
      labels: "",
      contactType: "new",
    },
    validationSchema,
    onSubmit: (values) => {
      console.log("Form submitted:", values);
      setSuccessDialogOpen(true);
      setTimeout(() => {
        navigate('/crm-opportunities');
      }, 2000);
    },
  });

  const handleContactTypeChange = (event) => {
    const value = event.target.value;
    setContactType(value);
    formik.setFieldValue('contactType', value);
  };

  const handleTagKeyPress = (event) => {
    if (event.key === 'Enter' && tagInput.trim()) {
      event.preventDefault();
      if (!formik.values.ticketTags.includes(tagInput.trim())) {
        formik.setFieldValue('ticketTags', [...formik.values.ticketTags, tagInput.trim()]);
      }
      setTagInput("");
    }
  };

  const handleDeleteTag = (tagToDelete) => {
    formik.setFieldValue(
      'ticketTags',
      formik.values.ticketTags.filter(tag => tag !== tagToDelete)
    );
  };

  // Handle Cancel button - reset form and navigate
  const handleCancel = () => {
    formik.resetForm();
    navigate('/crm-opportunities');
  };


// NEW - Hides only for "quick-quote"
const showAdditionalFields = formik.values.ticketType !== "quick-quote";


  // Quill editor configuration
  const quillModules = {
    toolbar: [
      ['bold', 'italic', 'underline'],
      [{ 'align': [] }],
      [{ 'list': 'ordered' }, { 'list': 'bullet' }],
      ['link'],
      ['clean']
    ]
  };

  const quillFormats = [
    'bold', 'italic', 'underline', 'align', 'list', 'bullet', 'link'
  ];

  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <Grid
          container
          spacing={{ xs: 1, md: 2 }}
          columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{
            width: "100%",
            maxWidth: "100vw",
            m: 0,
            p: { xs: 0, sm: 1 },
            justifyContent: "center",
            flexGrow: 1
          }}
        >
          <Grid
            item
            size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
            sx={{
              border: "1px solid #E4E4E7",
              backgroundColor: "#fff",
              px: { xs: 1, sm: 4, md: 6, xl: 3 },
              py: { xs: 0, sm: 3 },
              boxShadow: { xs: "none", sm: "0 2px 14px rgba(116,185,255,.08)" }
            }}
          >
            {/* Breadcrumb */}
            <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
              <HomeIcon 
                style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8, cursor: "pointer" }} 
                onClick={() => navigate("/admin")}
              />
              <TitleBreadcrumb 
                breadcrumbsData={[
                  { type: "link", label: "Service Desk", to: "/admin" }, 
                  { type: "link", label: "CRM", to: "/crm" },
                  { type: "link", label: "Opportunities", to: "/crm-opportunities" },
                  { type: "text", label: "New Opportunities", to: "" }
                ]} 
              />
            </Box>
           
            {/* Header */}
            <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
              <Box
                sx={{
                  width: 40,
                  height: 40,
                  borderRadius: "50%",
                  backgroundColor: "#409bff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  mr: 2
                }}
              >
                <ChartBarIcon style={{ width: 24, height: 24, color: "#fff" }} />
              </Box>
              <Typography
                sx={{
                  fontSize: 24,
                  fontWeight: 700,
                  color: "#111827",
                  fontFamily: 'Open Sans'
                }}
              >
                New Opportunity
              </Typography>
            </Box>

            {/* Opportunity Type Section */}
            <Box sx={{ border: "1px solid #E4E4E7", borderRadius: "8px", p: 3, mb: 3 }}>
              <Typography
                sx={{
                  fontSize: 18,
                  fontWeight: 600,
                  mb: 2,
                  color: "#000",
                  fontFamily: 'Open Sans'
                }}
              >
                Opportunity type
              </Typography>

              <Typography
                sx={{
                  fontSize: 16,
                  fontWeight: 600,
                  mb: 1,
                  color: "#374151",
                  fontFamily: 'Open Sans'
                }}
              >
                Ticket Type <span style={{ color: '#EF4444' }}>*</span>
              </Typography>

              <FormControl
                fullWidth
                size="small"
                error={formik.touched.ticketType && Boolean(formik.errors.ticketType)}
              >
                <Select
                  name="ticketType"
                  value={formik.values.ticketType}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  displayEmpty
                  MenuProps={menuProps}
                  sx={{
                    fontSize: 13,
                    fontFamily: 'Open Sans',
                    backgroundColor: "#fff",
                    height: 36,
                    "& .MuiOutlinedInput-notchedOutline": {
                      borderColor: formik.touched.ticketType && formik.errors.ticketType
                        ? "#EF4444"
                        : "#D1D5DB"
                    },
                    "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                    "& .MuiSelect-select": {
                      color: formik.values.ticketType ? "#000" : "#A1A1AA"
                    }
                  }}
                >
                  <MenuItem value="" disabled>
                    Select your ticket type
                  </MenuItem>
                  <MenuItem value="lead">Lead</MenuItem>
                  <MenuItem value="opportunity">Opportunity</MenuItem>
                  <MenuItem value="quick-quote">Quick Quote</MenuItem>
                </Select>
                {formik.touched.ticketType && formik.errors.ticketType && (
                  <FormHelperText>{formik.errors.ticketType}</FormHelperText>
                )}
              </FormControl>
            </Box>

            {/* Opportunity Details Section */}
            <Box sx={{ border: "1px solid #E4E4E7", borderRadius: "8px", p: 3, mb: 3, backgroundColor: "#fff" }}>
              <Typography
                sx={{
                  fontSize: 18,
                  fontWeight: 600,
                  mb: 2.5,
                  color: "#000",
                  fontFamily: 'Open Sans'
                }}
              >
                Opportunity details
              </Typography>

              <Box sx={{ mb: 3 }}>
                <Typography
                  sx={{
                    fontSize: 16,
                    fontWeight: 600,
                    mb: 1,
                    color: "#000",
                    fontFamily: 'Open Sans'
                  }}
                >
                  Summary<span style={{ color: '#EF4444' }}>*</span>
                </Typography>
                <TextField
                  fullWidth
                  size="small"
                  name="summary"
                  value={formik.values.summary}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  error={formik.touched.summary && Boolean(formik.errors.summary)}
                  helperText={formik.touched.summary && formik.errors.summary}
                  placeholder="Brief description of the opportunity"
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      fontSize: 13,
                      fontFamily: 'Open Sans',
                      backgroundColor: "#fff",
                      height: 36,
                      "& fieldset": {
                        borderColor: formik.touched.summary && formik.errors.summary
                          ? "#EF4444"
                          : "#D1D5DB"
                      },
                      "&:hover fieldset": { borderColor: "#D1D5DB" },
                      "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                    }
                  }}
                />
              </Box>

              <Box>
                <Typography
                  sx={{
                    fontSize: 16,
                    fontWeight: 600,
                    mb: 1,
                    color: "#000",
                    fontFamily: 'Open Sans'
                  }}
                >
                  Details<span style={{ color: '#EF4444' }}>*</span>
                </Typography>

                <Box
                  sx={{
                    border: formik.touched.details && formik.errors.details
                      ? "1px solid #EF4444"
                      : "1px solid #D1D5DB",
                    borderRadius: "4px",
                    '& .quill': {
                      fontFamily: 'Open Sans',
                    },
                    '& .ql-container': {
                      minHeight: '150px',
                      fontSize: '13px',
                      fontFamily: 'Open Sans',
                      borderBottomLeftRadius: '4px',
                      borderBottomRightRadius: '4px',
                    },
                    '& .ql-editor': {
                      minHeight: '150px',
                    },
                    '& .ql-toolbar': {
                      borderTopLeftRadius: '4px',
                      borderTopRightRadius: '4px',
                      backgroundColor: '#F2F8FF',
                      borderColor: formik.touched.details && formik.errors.details
                        ? "#EF4444"
                        : "#D1D5DB",
                    },
                    '& .ql-stroke': {
                      stroke: '#000',
                    },
                    '& .ql-fill': {
                      fill: '#000',
                    },
                    '& .ql-picker-label': {
                      color: '#000',
                    }
                  }}
                >
                  <ReactQuill
                    theme="snow"
                    value={formik.values.details}
                    onChange={(value) => formik.setFieldValue("details", value)}
                    onBlur={() => formik.setFieldTouched("details", true)}
                    modules={quillModules}
                    formats={quillFormats}
                    placeholder="Please provide a detailed description and include screenshots where possible"
                  />
                </Box>
                {formik.touched.details && formik.errors.details && (
                  <Typography sx={{ fontSize: 12, color: "#EF4444", mt: 0.5, ml: 1.5 }}>
                    {formik.errors.details}
                  </Typography>
                )}
              </Box>
            </Box>

            {/* Contact Details Section */}
            <Box sx={{ border: "1px solid #E4E4E7", borderRadius: "8px", p: 3, mb: 3 }}>
              <Typography
                sx={{
                  fontSize: 18,
                  fontWeight: 600,
                  mb: 2.5,
                  color: "#000",
                  fontFamily: 'Open Sans'
                }}
              >
                Contact details
              </Typography>

              <RadioGroup
                value={contactType}
                onChange={handleContactTypeChange}
                sx={{ mb: 3 }}
              >
                <Box sx={{ display: "flex", gap: 3 }}>
                  <FormControlLabel
                    value="new"
                    control={
                      <Radio
                        sx={{
                          color: "#D1D5DB",
                          '&.Mui-checked': { color: "#4390F8" }
                        }}
                      />
                    }
                    label={
                      <Typography sx={{ fontSize: 14, fontWeight: 500, fontFamily: 'Open Sans' }}>
                        New Contact
                      </Typography>
                    }
                  />
                </Box>
              </RadioGroup>

              <Grid container spacing={2}>
                <Grid item size={{ xs: 12, sm: 12, md: 3, xl: 3 }}>
                  <Typography
                    sx={{
                      fontSize: 16,
                      fontWeight: 600,
                      mb: 1,
                      color: "#374151",
                      fontFamily: 'Open Sans'
                    }}
                  >
                    Company Name{contactType === 'new' && <span style={{ color: '#EF4444' }}>*</span>}
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    name="companyName"
                    value={formik.values.companyName}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    error={formik.touched.companyName && Boolean(formik.errors.companyName)}
                    helperText={formik.touched.companyName && formik.errors.companyName}
                    disabled={contactType === 'existing'}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& fieldset": {
                          borderColor: formik.touched.companyName && formik.errors.companyName
                            ? "#EF4444"
                            : "#D1D5DB"
                        },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }}
                  />
                </Grid>

                <Grid item size={{ xs: 12, sm: 12, md: 3, xl: 3 }}>
                  <Typography
                    sx={{
                      fontSize: 16,
                      fontWeight: 600,
                      mb: 1,
                      color: "#374151",
                      fontFamily: 'Open Sans'
                    }}
                  >
                    Contact Name{contactType === 'new' && <span style={{ color: '#EF4444' }}>*</span>}
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    name="contactName"
                    value={formik.values.contactName}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    error={formik.touched.contactName && Boolean(formik.errors.contactName)}
                    helperText={formik.touched.contactName && formik.errors.contactName}
                    disabled={contactType === 'existing'}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& fieldset": {
                          borderColor: formik.touched.contactName && formik.errors.contactName
                            ? "#EF4444"
                            : "#D1D5DB"
                        },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }}
                  />
                </Grid>

                <Grid item size={{ xs: 12, sm: 12, md: 3, xl: 3 }}>
                  <Typography
                    sx={{
                      fontSize: 16,
                      fontWeight: 600,
                      mb: 1,
                      color: "#374151",
                      fontFamily: 'Open Sans'
                    }}
                  >
                    Email Address{contactType === 'new' && <span style={{ color: '#EF4444' }}>*</span>}
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    name="email"
                    type="email"
                    value={formik.values.email}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    error={formik.touched.email && Boolean(formik.errors.email)}
                    helperText={formik.touched.email && formik.errors.email}
                    disabled={contactType === 'existing'}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& fieldset": {
                          borderColor: formik.touched.email && formik.errors.email
                            ? "#EF4444"
                            : "#D1D5DB"
                        },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }}
                  />
                </Grid>

                <Grid item size={{ xs: 12, sm: 12, md: 3, xl: 3 }}>
                  <Typography
                    sx={{
                      fontSize: 16,
                      fontWeight: 600,
                      mb: 1,
                      color: "#374151",
                      fontFamily: 'Open Sans'
                    }}
                  >
                    Contact Title
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    name="contactTitle"
                    value={formik.values.contactTitle}
                    onChange={formik.handleChange}
                    disabled={contactType === 'existing'}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        fontSize: 13,
                        fontFamily: 'Open Sans',
                        backgroundColor: "#fff",
                        height: 36,
                        "& fieldset": { borderColor: "#D1D5DB" },
                        "&:hover fieldset": { borderColor: "#D1D5DB" },
                        "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                      }
                    }}
                  />
                </Grid>
              </Grid>
            </Box>

            {/* Additional Fields Section - Only show when "opportunity" is selected */}
            {showAdditionalFields && (
              <Box sx={{ border: "1px solid #E4E4E7", borderRadius: "8px", p: 3, mb: 3 }}>
                <Grid container spacing={2}>
                  <Grid item size={{ xs: 12, sm: 12, md: 3, xl: 3 }}>
                    <Typography
                      sx={{
                        fontSize: 16,
                        fontWeight: 600,
                        mb: 1,
                        color: "#374151",
                        fontFamily: 'Open Sans'
                      }}
                    >
                      Potential Value
                    </Typography>
                    <TextField
                      fullWidth
                      size="small"
                      name="potentialValue"
                      type="number"
                      value={formik.values.potentialValue}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      error={formik.touched.potentialValue && Boolean(formik.errors.potentialValue)}
                      helperText={formik.touched.potentialValue && formik.errors.potentialValue}
                      sx={{
                        "& .MuiOutlinedInput-root": {
                          fontSize: 13,
                          fontFamily: 'Open Sans',
                          backgroundColor: "#fff",
                          height: 36,
                          "& fieldset": {
                            borderColor: formik.touched.potentialValue && formik.errors.potentialValue
                              ? "#EF4444"
                              : "#D1D5DB"
                          },
                          "&:hover fieldset": { borderColor: "#D1D5DB" }
                        }
                      }}
                    />
                  </Grid>

                  <Grid item size={{ xs: 12, sm: 12, md: 3, xl: 3 }}>
                    <Typography
                      sx={{
                        fontSize: 16,
                        fontWeight: 600,
                        mb: 1,
                        color: "#374151",
                        fontFamily: 'Open Sans'
                      }}
                    >
                      Target Date
                    </Typography>
                    <TextField
                      fullWidth
                      size="small"
                      name="targetDate"
                      type="date"
                      value={formik.values.targetDate}
                      onChange={formik.handleChange}
                      InputLabelProps={{ shrink: true }}
                      sx={{
                        "& .MuiOutlinedInput-root": {
                          fontSize: 13,
                          fontFamily: 'Open Sans',
                          backgroundColor: "#fff",
                          height: 36,
                          "& fieldset": { borderColor: "#D1D5DB" },
                          "&:hover fieldset": { borderColor: "#D1D5DB" }
                        }
                      }}
                    />
                  </Grid>

                  <Grid item size={{ xs: 12, sm: 12, md: 3, xl: 3 }}>
                    <Typography
                      sx={{
                        fontSize: 16,
                        fontWeight: 600,
                        mb: 1,
                        color: "#374151",
                        fontFamily: 'Open Sans'
                      }}
                    >
                      Ticket Tags
                    </Typography>
                    <Box>
                      <TextField
                        fullWidth
                        size="small"
                        value={tagInput}
                        onChange={(e) => setTagInput(e.target.value)}
                        onKeyPress={handleTagKeyPress}
                        placeholder="Type and press 'Enter' to add a Tag"
                        sx={{
                          "& .MuiOutlinedInput-root": {
                            fontSize: 13,
                            fontFamily: 'Open Sans',
                            backgroundColor: "#fff",
                            height: 36,
                            "& fieldset": { borderColor: "#D1D5DB" },
                            "&:hover fieldset": { borderColor: "#D1D5DB" },
                            "& input::placeholder": { color: "#A1A1AA", opacity: 1 }
                          }
                        }}
                      />
                      {formik.values.ticketTags.length > 0 && (
                        <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1, mt: 1 }}>
                          {formik.values.ticketTags.map((tag, index) => (
                            <Chip
                              key={index}
                              label={tag}
                              onDelete={() => handleDeleteTag(tag)}
                              sx={{
                                fontSize: 12,
                                fontFamily: 'Open Sans',
                                backgroundColor: "#EFF6FF",
                                color: "#1E40AF"
                              }}
                            />
                          ))}
                        </Box>
                      )}
                    </Box>
                  </Grid>

                  <Grid item size={{ xs: 12, sm: 12, md: 3, xl: 3 }}>
                    <Typography
                      sx={{
                        fontSize: 16,
                        fontWeight: 600,
                        mb: 1,
                        color: "#374151",
                        fontFamily: 'Open Sans'
                      }}
                    >
                      Labels
                    </Typography>
                    <FormControl fullWidth size="small">
                      <Select
                        name="labels"
                        value={formik.values.labels}
                        onChange={formik.handleChange}
                        displayEmpty
                        MenuProps={menuProps}
                        sx={{
                          fontSize: 13,
                          fontFamily: 'Open Sans',
                          backgroundColor: "#fff",
                          height: 36,
                          "& .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                          "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                          "& .MuiSelect-select": {
                            color: formik.values.labels ? "#000" : "#A1A1AA"
                          }
                        }}
                      >
                        <MenuItem value="">Select Label</MenuItem>
                        {labelOptions.map((label) => (
                          <MenuItem key={label} value={label.toLowerCase()}>
                            {label}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Grid>
                </Grid>
              </Box>
            )}

            {/* Footer Section */}
            <Box
              sx={{
                position: "sticky",
                bottom: 0,
                left: 0,
                right: 0,
                bgcolor: "#fff",
                borderTop: "1px solid #E4E4E7",
                pt: 3,
                pb: 2,
                display: "flex",
                alignItems: "center",
                justifyContent: "right",
                flexWrap: "wrap",
                gap: 2
              }}
            >
              <Button
                type="button"
                variant="outlined"
                onClick={handleCancel}
                sx={{
                  px: 4,
                  height: 44,
                  borderRadius: '16px',
                  border: '1px solid #E5E7EB',
                  fontFamily: 'Open Sans',
                  backgroundColor: '#FF4141',
                  color: '#fff',
                  fontSize: '14px',
                  fontWeight: 600,
                  textTransform: 'none',
                  '&:hover': {
                    backgroundColor: '#DC2626',
                    border: '1px solid #DC2626'
                  }
                }}
              >
                Cancel
              </Button>

              <Button
                type="submit"
                variant="contained"
                sx={{
                  px: 4,
                  py: 1,
                  fontSize: 15,
                  fontWeight: 600,
                  borderRadius: '16px',
                  fontFamily: 'Open Sans',
                  textTransform: "none",
                  backgroundColor: "#409bff",
                  boxShadow: "none",
                  "&:hover": {
                    backgroundColor: "#2563EB"
                  }
                }}
              >
                Submit
              </Button>
            </Box>
          </Grid>
        </Grid>
      </form>

      {/* Success Dialog */}
      <Dialog
        open={successDialogOpen}
        disableScrollLock
        PaperProps={{
          sx: {
            borderRadius: "12px",
            p: 2,
            minWidth: "400px"
          }
        }}
      >
        <DialogContent>
          <Box sx={{ textAlign: "center", py: 2 }}>
            <CheckCircleIcon
              style={{
                width: 64,
                height: 64,
                color: "#409bff",
                margin: "0 auto",
                display: "block"
              }}
            />
            <Typography
              sx={{
                fontSize: 20,
                fontWeight: 700,
                color: "#111827",
                mt: 2,
                fontFamily: 'Open Sans'
              }}
            >
              Opportunity Created Successfully!
            </Typography>
            <Typography
              sx={{
                fontSize: 14,
                fontWeight: 400,
                color: "#6B7280",
                mt: 1,
                fontFamily: 'Open Sans'
              }}
            >
              Your opportunity has been created. Redirecting...
            </Typography>
          </Box>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default NewOpportunityForm;
