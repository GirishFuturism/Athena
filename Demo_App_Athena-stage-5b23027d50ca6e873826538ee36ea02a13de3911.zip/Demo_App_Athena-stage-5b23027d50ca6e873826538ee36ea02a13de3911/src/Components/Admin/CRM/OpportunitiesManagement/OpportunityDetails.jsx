import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import {
  Grid,
  Box,
  Typography,
  Tabs,
  Tab,
  Chip,
  Paper,
  Avatar,
  IconButton,
  Divider,
  Button,
  TextField,
  Select,
  MenuItem,
  FormControl,
  Dialog
} from "@mui/material";
import TitleBreadcrumb from "../../../Shared/TitleBreadcrumb";
import {
  HomeIcon,
  PencilSquareIcon,
  PlusIcon,
  ExclamationTriangleIcon,
  ArrowUturnLeftIcon,
  CheckCircleIcon,
} from "@heroicons/react/24/solid";
import AddBillingDialog from "../../TicketManagement/AddBillingDialog";
import AddExpenseDialog from "../../TicketManagement/AddExpenseDialog";
import DeleteContentDialog from "../../TicketManagement/DeleteContentDialog";
import EditBillDialog from "../../TicketManagement/EditBillDialog";
import EditExpenseDialog from "../../TicketManagement/EditExpenseDialog";

// ===== OPTIMIZED TABLE ROW COMPONENTS =====
// Wrapped with React.memo to prevent re-renders when props don't change
const BillingTableRow = React.memo(({ item, index, isLast, onEdit, onDelete }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <tr
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        backgroundColor: isHovered ? "#E2E2E2D4" : "#FFFFFF",
        transition: "background-color 0.2s ease",
      }}
    >
      <td style={{ padding: "12px 16px", fontSize: 14, color: "#000", borderBottom: isLast ? "none" : "1px solid #E5E7EB" }}>
        {item.chargeType}
      </td>
      <td style={{ padding: "12px 16px", fontSize: 14, color: "#000", borderBottom: isLast ? "none" : "1px solid #E5E7EB" }}>
        {item.actualTime}
      </td>
      <td style={{ padding: "12px 16px", fontSize: 14, color: "#000", borderBottom: isLast ? "none" : "1px solid #E5E7EB" }}>
        {item.billableTime}
      </td>
      <td style={{ padding: "12px 16px", fontSize: 14, color: "#000", borderBottom: isLast ? "none" : "1px solid #E5E7EB" }}>
        {item.overriding}
      </td>
      <td style={{ borderBottom: isLast ? "none" : "1px solid #E5E7EB", width: "80px" }}>
        {isHovered && (
          <Box sx={{ display: "flex", gap: 1 }}>
            <IconButton size="small" onClick={onEdit} sx={{ p: 0.5 }}>
              <PencilSquareIcon style={{ width: 18, height: 18, color: "#6B7280" }} />
            </IconButton>
            <IconButton size="small" onClick={onDelete} sx={{ p: 0.5 }}>
              <span className="material-symbols-outlined" style={{ fontSize: 18, color: "#EF4444" }}>delete</span>
            </IconButton>
          </Box>
        )}
      </td>
    </tr>
  );
});

BillingTableRow.displayName = 'BillingTableRow';

const ExpenseTableRow = React.memo(({ expense, index, isLast, onEdit, onDelete }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <tr
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        backgroundColor: isHovered ? "#E2E2E2D4" : "#FFFFFF",
        transition: "background-color 0.2s ease",
      }}
    >
      <td style={{ padding: "12px 16px", fontSize: 14, color: "#000", borderBottom: isLast ? "none" : "1px solid #E5E7EB" }}>{expense.agent}</td>
      <td style={{ padding: "12px 16px", fontSize: 14, color: "#000", borderBottom: isLast ? "none" : "1px solid #E5E7EB" }}>{expense.description}</td>
      <td style={{ padding: "12px 16px", fontSize: 14, color: "#000", borderBottom: isLast ? "none" : "1px solid #E5E7EB" }}>{expense.cost}</td>
      <td style={{ padding: "12px 16px", fontSize: 14, color: "#000", borderBottom: isLast ? "none" : "1px solid #E5E7EB" }}>{expense.expenseType}</td>
      <td style={{ padding: "12px 16px", fontSize: 14, color: "#000", borderBottom: isLast ? "none" : "1px solid #E5E7EB" }}>{expense.dateAdded}</td>
      <td style={{ padding: "12px 16px", fontSize: 14, color: "#000", borderBottom: isLast ? "none" : "1px solid #E5E7EB" }}>{expense.reviewed}</td>
      <td style={{ borderBottom: isLast ? "none" : "1px solid #E5E7EB", width: "80px" }}>
        {isHovered && (
          <Box sx={{ display: "flex", gap: 1 }}>
            <IconButton size="small" onClick={onEdit} sx={{ p: 0.5 }}>
              <PencilSquareIcon style={{ width: 18, height: 18, color: "#6B7280" }} />
            </IconButton>
            <IconButton size="small" onClick={onDelete} sx={{ p: 0.5 }}>
              <span className="material-symbols-outlined" style={{ fontSize: 18, color: "#EF4444" }}>delete</span>
            </IconButton>
          </Box>
        )}
      </td>
    </tr>
  );
});

ExpenseTableRow.displayName = 'ExpenseTableRow';

// ===== ISOLATED TIMER COMPONENT =====
// Timer is separated to prevent parent re-renders
const TimerDisplay = React.memo(({ isRunning, onToggle }) => {
  const [timerSeconds, setTimerSeconds] = useState(0);
  const intervalRef = useRef(null);

  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => {
        setTimerSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isRunning]);

  const formatTime = useCallback((seconds) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${String(hrs).padStart(2, "0")}:${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  }, []);

  return (
    <Box sx={{ textAlign: "center", mb: 2.5 }}>
      <Typography sx={{ fontSize: 14, color: "#6B7280", mb: 1, fontFamily: "Open Sans" }}>Timer</Typography>
      <Typography sx={{ fontSize: 24, fontWeight: 600, mb: 1.5, fontFamily: "Open Sans", color: "#111827" }}>
        {formatTime(timerSeconds)}
      </Typography>
      <button
        onClick={onToggle}
        style={{
          backgroundColor: isRunning ? "#EF4444" : "#10B981",
          color: "#fff",
          border: "none",
          padding: "8px 40px",
          borderRadius: "6px",
          fontWeight: 500,
          cursor: "pointer",
          fontFamily: "Open Sans",
          fontSize: "14px",
        }}
      >
        {isRunning ? "STOP" : "START"}
      </button>
    </Box>
  );
});

TimerDisplay.displayName = 'TimerDisplay';

const OpportunityDetails = () => {
  const location = useLocation();
  const navigate = useNavigate();
  
  const opportunityGridData = location.state?.opportunityData || {};

  // Basic State declarations
  const [tab, setTab] = useState("progressFeed");
  const [contactDetailsOpen, setContactDetailsOpen] = useState(true);
  const [opportunityInfoOpen, setOpportunityInfoOpen] = useState(true);
  const [isTimerRunning, setIsTimerRunning] = useState(true);

  // Dialog States for Billing
  const [addBillingDialogOpen, setAddBillingDialogOpen] = useState(false);
  const [editBillingDialogOpen, setEditBillingDialogOpen] = useState(false);
  const [deleteBillingDialogOpen, setDeleteBillingDialogOpen] = useState(false);
  const [selectedBillingItem, setSelectedBillingItem] = useState(null);
  const [selectedBillingIndex, setSelectedBillingIndex] = useState(null);

  // Dialog States for Expense
  const [addExpenseDialogOpen, setAddExpenseDialogOpen] = useState(false);
  const [editExpenseDialogOpen, setEditExpenseDialogOpen] = useState(false);
  const [deleteExpenseDialogOpen, setDeleteExpenseDialogOpen] = useState(false);
  const [selectedExpenseItem, setSelectedExpenseItem] = useState(null);
  const [selectedExpenseIndex, setSelectedExpenseIndex] = useState(null);

  // Qualify mode states
  const [isQualifyMode, setIsQualifyMode] = useState(false);
  const [openSuccessDialog, setOpenSuccessDialog] = useState(false);
  const [qualifyForm, setQualifyForm] = useState({
    companyName: '',
    contactName: '',
    conversionProbability: '',
    potentialValue: '',
    opportunityType: '',
    employeeCount: '',
    linkedin: '',
    website: '',
    startDate: '',
    targetDate: ''
  });
  const [initialQualifyForm, setInitialQualifyForm] = useState({});

  // MenuProps for dropdowns - Memoized to prevent recreation
  const menuProps = useMemo(() => ({
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  }), []);

  // Contact details editable states
  const [contactData, setContactData] = useState({
    companyName: opportunityGridData.company || "Not set",
    contactName: opportunityGridData.contact || "Not set",
    emailAddress: opportunityGridData.contact ? `${opportunityGridData.contact.toLowerCase().replace(' ', '.')}@${opportunityGridData.company?.toLowerCase().replace(/[^a-z0-9]/g, '')}.com` : "Not set",
    phoneNumber: "01234 567 890",
    contactTitle: "Not set",
    contactAddress: "Not set"
  });

  // Opportunity info editable states
  const [opportunityData, setOpportunityData] = useState({
    firstContact: opportunityGridData.expectedClose || new Date().toLocaleString(),
    createdBy: opportunityGridData.owner || "Not set",
    type: "Lead",
    workflow: "Lead Management",
    status: opportunityGridData.status || "New",
    team: "Leads",
    assignedAgent: opportunityGridData.owner || "Not set",
    additionalAgents: "Not set",
    timeRecorded: "00:03",
    attemptsMade: "Not set",
    potentialValue: opportunityGridData.value ? `$${opportunityGridData.value.toFixed(2)}` : "Not set",
    targetDate: opportunityGridData.expectedClose || "Not set",
    conversionProbability: opportunityGridData.probability || "Not set",
    ticketTags: "Not set",
    linkedin: `https://linkedin.com/company/${opportunityGridData.company?.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
    website: `https://${opportunityGridData.company?.toLowerCase().replace(/[^a-z0-9]/g, '')}.com`
  });

  // Sales Info editable states
  const [salesInfo, setSalesInfo] = useState({
    opportunityType: opportunityGridData.title?.includes("Managed Service") ? "New Managed Service" : "Hardware",
    currentITManagement: "Not set",
    employeeCount: "6-10",
    industry: "Food and Drink",
    howDidTheyHear: "Google Search",
    requirements: "Not set",
    siteReportNotes: "Not set"
  });

  // Editing states
  const [editingField, setEditingField] = useState(null);
  const [editingValue, setEditingValue] = useState("");
  const [editingSalesField, setEditingSalesField] = useState(null);
  const [editingSalesValue, setEditingSalesValue] = useState("");

  // Billing and expense data
  const [chargeTypes, setChargeTypes] = useState([
    { chargeType: "Travel", actualTime: "01:30", billableTime: "04:00", overriding: "Yes" },
    { chargeType: "Remote Support", actualTime: "00:30", billableTime: "04:50", overriding: "Yes" },
  ]);

  const [expenses, setExpenses] = useState([
    { agent: "John Doe", description: "Travel Expense", cost: "$50.00", expenseType: "Travel", dateAdded: "12/08/2025", reviewed: "Yes" },
  ]);

  // ===== MEMOIZED CALLBACK FUNCTIONS =====
  const handleToggleTimer = useCallback(() => setIsTimerRunning(!isTimerRunning), [isTimerRunning]);


// In OpportunityDetails.jsx - Update the handleAddBilling function

const handleAddBilling = useCallback((newBillingData) => {
  const newBilling = {
    chargeType: newBillingData.chargeType || "New Charge",
    actualTime: newBillingData.timeTaken || newBillingData.actualTime || "00:00",  // ✅ Handle both field names
    billableTime: newBillingData.timeTaken || newBillingData.billableTime || "00:00", // ✅ Handle both field names
    overriding: newBillingData.overriding || "No"
  };
  
  setChargeTypes(prev => [...prev, newBilling]);
  setAddBillingDialogOpen(false);
}, []);

  const handleEditBillingClick = useCallback((item, index) => {
    setSelectedBillingItem(item);
    setSelectedBillingIndex(index);
    setEditBillingDialogOpen(true);
  }, []);

// In OpportunityDetails.jsx - Update the handleUpdateBilling function

const handleUpdateBilling = useCallback((updatedBillingData) => {
  setChargeTypes(prev => {
    const updated = [...prev];
    updated[selectedBillingIndex] = {
      chargeType: updatedBillingData.chargeType || selectedBillingItem.chargeType,
      actualTime: updatedBillingData.timeTaken || updatedBillingData.actualTime || selectedBillingItem.actualTime,  // ✅ Handle both field names
      billableTime: updatedBillingData.timeTaken || updatedBillingData.billableTime || selectedBillingItem.billableTime,  // ✅ Handle both field names
      overriding: updatedBillingData.overriding || selectedBillingItem.overriding
    };
    return updated;
  });
  setEditBillingDialogOpen(false);
  setSelectedBillingItem(null);
  setSelectedBillingIndex(null);
}, [selectedBillingItem, selectedBillingIndex]);


  const handleDeleteBillingClick = useCallback((item, index) => {
    setSelectedBillingItem(item);
    setSelectedBillingIndex(index);
    setDeleteBillingDialogOpen(true);
  }, []);

  const handleConfirmDeleteBilling = useCallback(() => {
    setChargeTypes(prev => prev.filter((_, i) => i !== selectedBillingIndex));
    setDeleteBillingDialogOpen(false);
    setSelectedBillingItem(null);
    setSelectedBillingIndex(null);
  }, [selectedBillingIndex]);

  // Expense Dialog Handlers - Memoized
// In OpportunityDetails.jsx - Update the handleAddExpense function

const handleAddExpense = useCallback((newExpenseData) => {
  const newExpense = {
    agent: newExpenseData.agent || newExpenseData.agentName || "Unknown Agent",  // ✅ Handle both field names
    description: newExpenseData.description || newExpenseData.expenseDescription || "No description",  // ✅ Handle both field names
    cost: newExpenseData.cost || newExpenseData.expenseCost || "$0.00",  // ✅ Handle both field names
    expenseType: newExpenseData.expenseType || newExpenseData.type || "General",  // ✅ Handle both field names
    dateAdded: newExpenseData.dateAdded || newExpenseData.date || new Date().toLocaleDateString(),  // ✅ Handle both field names
    reviewed: newExpenseData.reviewed || "No"
  };
  
  setExpenses(prev => [...prev, newExpense]);
  setAddExpenseDialogOpen(false);
}, []);


  const handleEditExpenseClick = useCallback((expense, index) => {
    setSelectedExpenseItem(expense);
    setSelectedExpenseIndex(index);
    setEditExpenseDialogOpen(true);
  }, []);

// In OpportunityDetails.jsx - Update the handleUpdateExpense function

const handleUpdateExpense = useCallback((updatedExpenseData) => {
  setExpenses(prev => {
    const updated = [...prev];
    updated[selectedExpenseIndex] = {
      agent: updatedExpenseData.agent || updatedExpenseData.agentName || selectedExpenseItem.agent,  // ✅ Handle both field names
      description: updatedExpenseData.description || updatedExpenseData.expenseDescription || selectedExpenseItem.description,  // ✅ Handle both field names
      cost: updatedExpenseData.cost || updatedExpenseData.expenseCost || selectedExpenseItem.cost,  // ✅ Handle both field names
      expenseType: updatedExpenseData.expenseType || updatedExpenseData.type || selectedExpenseItem.expenseType,  // ✅ Handle both field names
      dateAdded: updatedExpenseData.dateAdded || updatedExpenseData.date || selectedExpenseItem.dateAdded,  // ✅ Handle both field names
      reviewed: updatedExpenseData.reviewed || selectedExpenseItem.reviewed
    };
    return updated;
  });
  setEditExpenseDialogOpen(false);
  setSelectedExpenseItem(null);
  setSelectedExpenseIndex(null);
}, [selectedExpenseItem, selectedExpenseIndex]);


  const handleDeleteExpenseClick = useCallback((expense, index) => {
    setSelectedExpenseItem(expense);
    setSelectedExpenseIndex(index);
    setDeleteExpenseDialogOpen(true);
  }, []);

  const handleConfirmDeleteExpense = useCallback(() => {
    setExpenses(prev => prev.filter((_, i) => i !== selectedExpenseIndex));
    setDeleteExpenseDialogOpen(false);
    setSelectedExpenseItem(null);
    setSelectedExpenseIndex(null);
  }, [selectedExpenseIndex]);

  // Handle field editing - Memoized
  const handleFieldClick = useCallback((fieldName, currentValue) => {
    setEditingField(fieldName);
    setEditingValue(currentValue);
  }, []);

  const handleSaveField = useCallback((section, fieldName) => {
    if (section === "contact") {
      setContactData(prev => ({ ...prev, [fieldName]: editingValue }));
    } else if (section === "opportunity") {
      setOpportunityData(prev => ({ ...prev, [fieldName]: editingValue }));
    }
    setEditingField(null);
    setEditingValue("");
  }, [editingValue]);

  const handleKeyPress = useCallback((e, section, fieldName) => {
    if (e.key === "Enter") handleSaveField(section, fieldName);
    else if (e.key === "Escape") {
      setEditingField(null);
      setEditingValue("");
    }
  }, [handleSaveField]);

  // Editable Field Component - Memoized
  const EditableField = React.memo(({ label, value, fieldName, section, isLink = false, color = "#111827" }) => {
    const isEditing = editingField === `${section}-${fieldName}`;
    
    return (
      <Box>
        <Typography sx={{ fontSize: 12, color: "#6B7280", fontFamily: "Open Sans", mb: 0.5 }}>{label}</Typography>
        {isEditing ? (
          <TextField
            autoFocus
            fullWidth
            size="small"
            value={editingValue}
            onChange={(e) => setEditingValue(e.target.value)}
            onBlur={() => handleSaveField(section, fieldName)}
            onKeyDown={(e) => handleKeyPress(e, section, fieldName)}
            sx={{
              "& .MuiOutlinedInput-root": {
                fontSize: 14,
                fontFamily: "Open Sans",
                fontWeight: 600,
                height: "32px",
                "& input": { padding: "6px 10px" }
              }
            }}
          />
        ) : (
          <Typography
            onClick={() => handleFieldClick(`${section}-${fieldName}`, value)}
            sx={{
              fontSize: 14,
              fontWeight: 600,
              fontFamily: "Open Sans",
              color: color,
              cursor: "pointer",
              wordBreak: "break-word",
              transition: "all 0.2s ease",
              "&:hover": {
                backgroundColor: "#F3F4F6",
                padding: "4px 8px",
                margin: "-4px -8px",
                borderRadius: "4px",
              }
            }}
          >
            {value}
          </Typography>
        )}
      </Box>
    );
  });

  EditableField.displayName = 'EditableField';

  // Editable Sales Field Component - Memoized
  const EditableSalesField = React.memo(({ label, value, fieldName, options = null, isTextArea = false }) => {
    const isEditing = editingSalesField === fieldName;
    
    const handleSalesChange = useCallback((newValue) => {
      setSalesInfo(prev => ({ ...prev, [fieldName]: newValue }));
      setEditingSalesField(null);
      setEditingSalesValue("");
    }, [fieldName]);
    
    return (
      <Box sx={{ mb: 3 }}>
        <Typography sx={{ fontSize: 14, fontWeight: 400, fontFamily: "Open Sans", color: "#6B7280", mb: 1 }}>{label}</Typography>
        
        {isEditing && options ? (
          <FormControl fullWidth size="small">
            <Select
              autoFocus
              value={editingSalesValue}
              onChange={(e) => handleSalesChange(e.target.value)}
              MenuProps={menuProps}
              sx={{
                fontSize: 14,
                fontFamily: "Open Sans",
                fontWeight: 600,
                height: "40px",
                "& .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
                "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#409BFF" },
                "&.Mui-focused .MuiOutlinedInput-notchedOutline": { borderColor: "#409BFF" }
              }}
            >
              {options.map((option) => (
                <MenuItem key={option} value={option} sx={{ fontFamily: "Open Sans", fontSize: 14, py: 1 }}>
                  {option}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        ) : isEditing && !options ? (
          <TextField
            autoFocus
            fullWidth
            multiline={isTextArea}
            rows={isTextArea ? 3 : 1}
            size="small"
            value={editingSalesValue}
            onChange={(e) => setEditingSalesValue(e.target.value)}
            onBlur={() => handleSalesChange(editingSalesValue)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !isTextArea) {
                handleSalesChange(editingSalesValue);
              } else if (e.key === "Escape") {
                setEditingSalesField(null);
                setEditingSalesValue("");
              }
            }}
            sx={{
              "& .MuiOutlinedInput-root": {
                fontSize: 14,
                fontFamily: "Open Sans",
                fontWeight: 600
              }
            }}
          />
        ) : (
          <Typography
            onClick={() => {
              setEditingSalesField(fieldName);
              setEditingSalesValue(value);
            }}
            sx={{
              fontSize: 16,
              fontWeight: 600,
              fontFamily: "Open Sans",
              color: "#111827",
              cursor: "pointer",
              padding: "4px 8px",
              margin: "-4px -8px",
              borderRadius: "4px",
              "&:hover": { backgroundColor: "#F3F4F6" }
            }}
          >
            {value}
          </Typography>
        )}
      </Box>
    );
  });

  EditableSalesField.displayName = 'EditableSalesField';

  // Get status color for chip - Memoized
  const getStatusColor = useCallback((status) => {
    const statusColors = {
      "Qualified": "#6366F1",
      "New": "#84CC16",
      "Quote Sent": "#8B5CF6",
      "Quote Raised": "#3B82F6",
      "Approved": "#10B981",
      "In Progress": "#0EA5E9"
    };
    return statusColors[status] || "#6366F1";
  }, []);

  const handleTabChange = useCallback((event, newValue) => setTab(newValue), []);
  const handleBack = useCallback(() => navigate("/crm-opportunities"), [navigate]);

  const tabValue = useMemo(() => ["progressFeed", "billing", "salesInfo"], []);

  return (
    <>
      <Grid
        container
        spacing={{ xs: 1, md: 2 }}
        columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{
          width: "100%",
          maxWidth: "100vw",
          m: 0,
          p: { xs: 0, sm: 1 },
          justifyContent: "center",
          flexGrow: 1,
        }}
      >
        <Grid
          size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
          sx={{
            border: "1px solid #E4E4E7",
            backgroundColor: "#fff",
            px: { xs: 1, sm: 4, md: 6, xl: 3 },
            py: { xs: 0, sm: 3 },
            boxShadow: { xs: "none", sm: "0 2px 14px rgba(116,185,255,.08)" },
          }}
        >
          {/* Breadcrumb */}
          <Box sx={{ mb: { xs: 1, sm: 2 }, display: "flex", alignItems: "center" }}>
            <HomeIcon style={{ width: 18, height: 18, color: "#4390F8", marginRight: 8, cursor: "pointer" }} onClick={() => navigate("/admin")} />
            <TitleBreadcrumb
              breadcrumbsData={[
                { type: "link", label: "Service Desk", to: "/admin" },
                { type: "link", label: "Opportunities", to: "/crm-opportunities" },
                { type: "text", label: "Opportunity Details" },
              ]}
            />
          </Box>

          {/* Title */}
          <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 3 }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <IconButton size="small" onClick={handleBack} sx={{ color: "#4390F8", p: 0.7, border: "1px solid #409BFF" }}>
                <ArrowUturnLeftIcon style={{ width: 20, height: 20 }} />
              </IconButton>
              <Typography sx={{ fontWeight: 700, fontFamily: "Open Sans", fontSize: "24px", color: "#111827" }}>
                [ID:OP-{opportunityGridData.id || "0001"}] {opportunityGridData.title || "Opportunity Details"}
              </Typography>
              <PencilSquareIcon style={{ width: 24, height: 24, color: "#9A9A9A" }} />
            </Box>
            
            {["New", "Quote Sent", "Quote Raised", "Approved"].includes(opportunityData.status) && (
              <Button
                variant="contained"
                onClick={() => {
                  const formData = {
                    companyName: contactData.companyName,
                    contactName: contactData.contactName,
                    conversionProbability: opportunityData.conversionProbability,
                    potentialValue: opportunityData.potentialValue,
                    opportunityType: salesInfo.opportunityType,
                    employeeCount: salesInfo.employeeCount,
                    linkedin: opportunityData.linkedin,
                    website: opportunityData.website,
                    startDate: '',
                    targetDate: opportunityData.targetDate
                  };
                  setQualifyForm(formData);
                  setInitialQualifyForm(formData);
                  setIsQualifyMode(true);
                }}
                sx={{
                  backgroundColor: "#409BFF",
                  color: "#fff",
                  textTransform: "none",
                  fontFamily: "Open Sans",
                  fontWeight: 600,
                  fontSize: 14,
                  px: 3,
                  py: 1,
                  borderRadius: "6px",
                  "&:hover": {
                    backgroundColor: "#2563EB",
                  },
                }}
              >
                Qualify
              </Button>
            )}
          </Box>

          {/* Main Content Grid */}
          <Grid container spacing={1.5} sx={{ alignItems: "flex-start" }}>
            {/* Left Section - Tabs */}
            <Grid size={{ xs: 12, sm: 12, md: 12, lg: 12, xl: 9 }}>
              {/* Tabs */}
              <Box sx={{ mb: 2 }}>
                <Tabs
                  value={tab}
                  onChange={handleTabChange}
                  TabIndicatorProps={{ style: { backgroundColor: "#409BFF" } }}
                  sx={{
                    "& .MuiTab-root": { color: "#6B7280" },
                    "& .Mui-selected": { color: "#409BFF" },
                  }}
                >
                  <Tab label="Progress Feed" value={tabValue[0]} sx={{ fontWeight: 600, mr: 2, fontFamily: "Open Sans", textTransform: "none", fontSize: 15, color: tab === tabValue[0] ? "#409BFF" : "#6B7280" }} />
                  <Tab label="Billing" value={tabValue[1]} sx={{ fontWeight: 600, mr: 2, fontFamily: "Open Sans", textTransform: "none", fontSize: 15, color: tab === tabValue[1] ? "#409BFF" : "#6B7280" }} />
                  <Tab label="Sales Info" value={tabValue[2]} sx={{ fontWeight: 600, mr: 2, fontFamily: "Open Sans", textTransform: "none", fontSize: 15, color: tab === tabValue[2] ? "#409BFF" : "#6B7280" }} />
                </Tabs>
              </Box>

              {/* Tab Content */}
              {tab === tabValue[0] && (
                <>
                  {/* Progress Feed - Status Box with Qualify Form */}
                  <Box sx={{ border: "1px solid #E5E7EB", borderRadius: "8px", p: 2.5, backgroundColor: "#FFFFFF", boxShadow: "0px 1px 2px 0px #0000000D", mb: 2 }}>
                    <Box sx={{ display: "flex", gap: 2 }}>
                      <Avatar src={opportunityGridData.ownerAvatar || "https://randomuser.me/api/portraits/men/20.jpg"} sx={{ width: 40, height: 40 }}>
                        {opportunityGridData.owner?.split(' ').map(n => n[0]).join('') || "BW"}
                      </Avatar>
                      <Box sx={{ flex: 1 }}>
                        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 1 }}>
                          <Typography sx={{ fontWeight: 500, fontFamily: "Open Sans", fontSize: 16, color: "#111827" }}>
                            {opportunityGridData.owner || "Bruce Wayne"} (You)
                          </Typography>
                          <Typography sx={{ fontSize: 14, color: "#929292", fontFamily: "Open Sans" }}>
                            {new Date().toLocaleString()}
                          </Typography>
                        </Box>
                        <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1 }}>
                          <span className="material-symbols-outlined" style={{ fontSize: 16, color: "#6366F1" }}>double_arrow</span>
                          <Typography sx={{ fontSize: 14, fontWeight: 600, fontFamily: "Open Sans", color: "#111827" }}>
                            {opportunityData.status}
                          </Typography>
                          <span className="material-symbols-outlined" style={{ fontSize: 16, color: "#9CA3AF" }}>schedule</span>
                        </Box>
                        <Chip
                          label={opportunityData.status}
                          size="small"
                          sx={{ backgroundColor: getStatusColor(opportunityData.status), color: "#FFFFFF", fontWeight: 600, fontFamily: "Open Sans", fontSize: 13, height: 24, mb: 1 }}
                        />

                        {/* Qualify Form - Only show when in qualify mode */}
                        {isQualifyMode && ["New", "Quote Sent", "Quote Raised", "Approved"].includes(opportunityData.status) && (
                          <Box sx={{ mt: 3, pt: 3, borderTop: "1px solid #E5E7EB" }}>
                            <Typography sx={{ fontSize: 16, fontWeight: 600, fontFamily: "Open Sans", color: "#111827", mb: 2 }}>
                              Company Details
                            </Typography>

                            <Grid container spacing={2}>
                              {/* Company Name */}
                              <Grid size={{ xs: 12, sm: 6 }}>
                                <Typography sx={{ fontSize: 14, fontWeight: 400, fontFamily: "Open Sans", color: "#374151", mb: 1 }}>
                                  Company Name
                                </Typography>
                                <TextField
                                  fullWidth
                                  size="small"
                                  value={qualifyForm.companyName}
                                  onChange={(e) => setQualifyForm({ ...qualifyForm, companyName: e.target.value })}
                                  sx={{ "& .MuiOutlinedInput-root": { fontSize: 14, fontFamily: "Open Sans" } }}
                                />
                              </Grid>

                              {/* Contact Name */}
                              <Grid size={{ xs: 12, sm: 6 }}>
                                <Typography sx={{ fontSize: 14, fontWeight: 400, fontFamily: "Open Sans", color: "#374151", mb: 1 }}>
                                  Contact Name
                                </Typography>
                                <TextField
                                  fullWidth
                                  size="small"
                                  value={qualifyForm.contactName}
                                  onChange={(e) => setQualifyForm({ ...qualifyForm, contactName: e.target.value })}
                                  sx={{ "& .MuiOutlinedInput-root": { fontSize: 14, fontFamily: "Open Sans" } }}
                                />
                              </Grid>

                              {/* Conversion Probability */}
                              <Grid size={{ xs: 12, sm: 6 }}>
                                <Typography sx={{ fontSize: 14, fontWeight: 400, fontFamily: "Open Sans", color: "#374151", mb: 1 }}>
                                  Conversion Probability <span style={{ color: "#EF4444" }}>*</span>
                                </Typography>
                                <TextField
                                  fullWidth
                                  size="small"
                                  type="number"
                                  value={qualifyForm.conversionProbability}
                                  onChange={(e) => setQualifyForm({ ...qualifyForm, conversionProbability: e.target.value })}
                                  sx={{ "& .MuiOutlinedInput-root": { fontSize: 14, fontFamily: "Open Sans" } }}
                                />
                              </Grid>

                              {/* Potential Value */}
                              <Grid size={{ xs: 12, sm: 6 }}>
                                <Typography sx={{ fontSize: 14, fontWeight: 400, fontFamily: "Open Sans", color: "#374151", mb: 1 }}>
                                  Potential Value
                                </Typography>
                                <TextField
                                  fullWidth
                                  size="small"
                                  value={qualifyForm.potentialValue}
                                  onChange={(e) => setQualifyForm({ ...qualifyForm, potentialValue: e.target.value })}
                                  sx={{ "& .MuiOutlinedInput-root": { fontSize: 14, fontFamily: "Open Sans" } }}
                                />
                              </Grid>

                              {/* What kind of opportunity */}
                              <Grid size={{ xs: 12, sm: 6 }}>
                                <Typography sx={{ fontSize: 14, fontWeight: 400, fontFamily: "Open Sans", color: "#374151", mb: 1 }}>
                                  What kind of opportunity is this?
                                </Typography>
                                <FormControl fullWidth size="small">
                                  <Select
                                    value={qualifyForm.opportunityType}
                                    onChange={(e) => setQualifyForm({ ...qualifyForm, opportunityType: e.target.value })}
                                    displayEmpty
                                    MenuProps={menuProps}
                                    sx={{ fontSize: 14, fontFamily: "Open Sans", "& .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" } }}
                                  >
                                    <MenuItem value="">-</MenuItem>
                                    <MenuItem value="Training">Training</MenuItem>
                                    <MenuItem value="Hardware">Hardware</MenuItem>
                                    <MenuItem value="New Managed Service">New Managed Service</MenuItem>
                                    <MenuItem value="Upsell">Upsell</MenuItem>
                                  </Select>
                                </FormControl>
                                <Typography sx={{ fontSize: 12, color: "#409BFF", fontFamily: "Open Sans", mt: 0.5 }}>
                                  Company details found
                                </Typography>
                              </Grid>

                              {/* How many employees */}
                              <Grid size={{ xs: 12, sm: 6 }}>
                                <Typography sx={{ fontSize: 14, fontWeight: 400, fontFamily: "Open Sans", color: "#374151", mb: 1 }}>
                                  How many employees? <span style={{ color: "#EF4444" }}>*</span>
                                </Typography>
                                <FormControl fullWidth size="small">
                                  <Select
                                    value={qualifyForm.employeeCount}
                                    onChange={(e) => setQualifyForm({ ...qualifyForm, employeeCount: e.target.value })}
                                    displayEmpty
                                    MenuProps={menuProps}
                                    sx={{ fontSize: 14, fontFamily: "Open Sans", "& .MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" } }}
                                  >
                                    <MenuItem value="">-</MenuItem>
                                    <MenuItem value="1">1</MenuItem>
                                    <MenuItem value="2">2</MenuItem>
                                    <MenuItem value="3-5">3-5</MenuItem>
                                    <MenuItem value="6-10">6-10</MenuItem>
                                    <MenuItem value="11-20">11-20</MenuItem>
                                    <MenuItem value="21-50">21-50</MenuItem>
                                    <MenuItem value="51-100">51-100</MenuItem>
                                  </Select>
                                </FormControl>
                              </Grid>

                              {/* LinkedIn */}
                              <Grid size={{ xs: 12, sm: 6 }}>
                                <Typography sx={{ fontSize: 14, fontWeight: 400, fontFamily: "Open Sans", color: "#374151", mb: 1 }}>
                                  LinkedIn
                                </Typography>
                                <TextField
                                  fullWidth
                                  size="small"
                                  value={qualifyForm.linkedin}
                                  onChange={(e) => setQualifyForm({ ...qualifyForm, linkedin: e.target.value })}
                                  sx={{ "& .MuiOutlinedInput-root": { fontSize: 14, fontFamily: "Open Sans" } }}
                                />
                              </Grid>

                              {/* Website */}
                              <Grid size={{ xs: 12, sm: 6 }}>
                                <Typography sx={{ fontSize: 14, fontWeight: 400, fontFamily: "Open Sans", color: "#374151", mb: 1 }}>
                                  Website
                                </Typography>
                                <TextField
                                  fullWidth
                                  size="small"
                                  value={qualifyForm.website}
                                  onChange={(e) => setQualifyForm({ ...qualifyForm, website: e.target.value })}
                                  sx={{ "& .MuiOutlinedInput-root": { fontSize: 14, fontFamily: "Open Sans" } }}
                                />
                              </Grid>

                              {/* Start Date */}
                              <Grid size={{ xs: 12, sm: 6 }}>
                                <Typography sx={{ fontSize: 14, fontWeight: 400, fontFamily: "Open Sans", color: "#374151", mb: 1 }}>
                                  Start Date
                                </Typography>
                                <TextField
                                  fullWidth
                                  size="small"
                                  type="date"
                                  value={qualifyForm.startDate}
                                  onChange={(e) => setQualifyForm({ ...qualifyForm, startDate: e.target.value })}
                                  InputLabelProps={{ shrink: true }}
                                  sx={{ "& .MuiOutlinedInput-root": { fontSize: 14, fontFamily: "Open Sans" } }}
                                />
                              </Grid>

                              {/* Target Date */}
                              <Grid size={{ xs: 12, sm: 6 }}>
                                <Typography sx={{ fontSize: 14, fontWeight: 400, fontFamily: "Open Sans", color: "#374151", mb: 1 }}>
                                  Target Date
                                </Typography>
                                <TextField
                                  fullWidth
                                  size="small"
                                  type="date"
                                  value={qualifyForm.targetDate}
                                  onChange={(e) => setQualifyForm({ ...qualifyForm, targetDate: e.target.value })}
                                  InputLabelProps={{ shrink: true }}
                                  sx={{ "& .MuiOutlinedInput-root": { fontSize: 14, fontFamily: "Open Sans" } }}
                                />
                              </Grid>
                            </Grid>

                            {/* Action Buttons */}
                            <Box sx={{ display: "flex", gap: 2, justifyContent: "flex-end", mt: 3 }}>
                              <Button
                                variant="outlined"
                                onClick={() => {
                                  setQualifyForm(initialQualifyForm);
                                  setIsQualifyMode(false);
                                }}
                                sx={{
                                  color: "#6B7280",
                                  borderColor: "#D1D5DB",
                                  textTransform: "none",
                                  fontFamily: "Open Sans",
                                  fontWeight: 500,
                                  fontSize: 14,
                                  px: 3,
                                  py: 1,
                                  "&:hover": { borderColor: "#9CA3AF", backgroundColor: "#F9FAFB" },
                                }}
                              >
                                Discard
                              </Button>
                              <Button
                                variant="contained"
                                onClick={() => {
                                  setContactData({
                                    ...contactData,
                                    companyName: qualifyForm.companyName,
                                    contactName: qualifyForm.contactName,
                                  });
                                  setOpportunityData({
                                    ...opportunityData,
                                    status: "Qualified",
                                    conversionProbability: qualifyForm.conversionProbability,
                                    potentialValue: qualifyForm.potentialValue,
                                    linkedin: qualifyForm.linkedin,
                                    website: qualifyForm.website,
                                    targetDate: qualifyForm.targetDate,
                                  });
                                  setSalesInfo({
                                    ...salesInfo,
                                    opportunityType: qualifyForm.opportunityType,
                                    employeeCount: qualifyForm.employeeCount,
                                  });
                                  setIsQualifyMode(false);
                                  setOpenSuccessDialog(true);
                                }}
                                sx={{
                                  backgroundColor: "#10B981",
                                  color: "#fff",
                                  textTransform: "none",
                                  fontFamily: "Open Sans",
                                  fontWeight: 500,
                                  fontSize: 14,
                                  px: 3,
                                  py: 1,
                                  "&:hover": { backgroundColor: "#059669" },
                                }}
                              >
                                Save
                              </Button>
                            </Box>
                          </Box>
                        )}
                      </Box>
                    </Box>
                  </Box>

                  {/* Opened Status Box */}
                  <Box sx={{ border: "1px solid #E5E7EB", borderRadius: "8px", p: 2.5, backgroundColor: "#FFFFFF", boxShadow: "0px 1px 2px 0px #0000000D", mb: 2 }}>
                    <Box sx={{ display: "flex", gap: 2 }}>
                      <Avatar src={opportunityGridData.ownerAvatar || "https://randomuser.me/api/portraits/men/20.jpg"} sx={{ width: 40, height: 40 }}>
                        {opportunityGridData.owner?.split(' ').map(n => n[0]).join('') || "BW"}
                      </Avatar>
                      <Box sx={{ flex: 1 }}>
                        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 1 }}>
                          <Typography sx={{ fontWeight: 500, fontFamily: "Open Sans", fontSize: 16, color: "#111827" }}>
                            {opportunityGridData.owner || "Bruce Wayne"} (You)
                          </Typography>
                          <Typography sx={{ fontSize: 14, color: "#929292", fontFamily: "Open Sans" }}>
                            {new Date().toLocaleString()}
                          </Typography>
                        </Box>
                        <Box sx={{ display: "flex", gap: 1, mb: 2 }}>
                          <Chip label="Opened" size="small" sx={{ backgroundColor: "#DBEAFE", color: "#1E40AF", fontWeight: 600, fontFamily: "Open Sans", fontSize: 13, height: 24 }} />
                          <Chip label="New" size="small" sx={{ backgroundColor: "#84CC16", color: "#FFFFFF", fontWeight: 600, fontFamily: "Open Sans", fontSize: 13, height: 24 }} />
                        </Box>

                        {/* Contact Information Box */}
                        <Box sx={{ mt: 2, p: 2, backgroundColor: "#F9FAFB", borderRadius: "8px", border: "1px solid #E5E7EB" }}>
                          <Box sx={{ mb: 1.5 }}>
                            <Typography sx={{ fontSize: 14, fontWeight: 600, fontFamily: "Open Sans", color: "#374151", mb: 0.5 }}>Company</Typography>
                            <Typography sx={{ fontSize: 14, fontFamily: "Open Sans", color: "#111827" }}>{opportunityGridData.company || "Not set"}</Typography>
                          </Box>
                          <Box sx={{ mb: 1.5 }}>
                            <Typography sx={{ fontSize: 14, fontWeight: 600, fontFamily: "Open Sans", color: "#374151", mb: 0.5 }}>Contact</Typography>
                            <Typography sx={{ fontSize: 14, fontFamily: "Open Sans", color: "#111827" }}>{opportunityGridData.contact || "Not set"}</Typography>
                          </Box>
                          <Box sx={{ mb: 1.5 }}>
                            <Typography sx={{ fontSize: 14, fontWeight: 600, fontFamily: "Open Sans", color: "#374151", mb: 0.5 }}>Email</Typography>
                            <Typography sx={{ fontSize: 14, fontFamily: "Open Sans", color: "#111827" }}>{contactData.emailAddress}</Typography>
                          </Box>
                          <Box sx={{ mb: 1.5 }}>
                            <Typography sx={{ fontSize: 14, fontWeight: 600, fontFamily: "Open Sans", color: "#374151", mb: 0.5 }}>Expected Close</Typography>
                            <Typography sx={{ fontSize: 14, fontFamily: "Open Sans", color: "#111827" }}>{opportunityGridData.expectedClose || "Not set"}</Typography>
                          </Box>
                          <Box>
                            <Typography sx={{ fontSize: 14, fontWeight: 600, fontFamily: "Open Sans", color: "#374151", mb: 0.5 }}>Opportunity Value</Typography>
                            <Typography sx={{ fontSize: 14, fontFamily: "Open Sans", color: "#10B981", fontWeight: 600 }}>
                              ${opportunityGridData.value ? opportunityGridData.value.toFixed(2) : "0.00"}
                            </Typography>
                          </Box>
                        </Box>
                      </Box>
                    </Box>
                  </Box>
                </>
              )}

              {/* BILLING TAB */}
              {tab === tabValue[1] && (
                <>
                  <Grid sx={{ border: "1px solid #E5E7EB", p: 3, boxShadow: "0px 1px 2px 0px #0000000D" }} size={{ xs: 12, sm: 12, md: 12, lg: 12, xl: 12 }}>
                    <Box>
                      <Typography sx={{ fontSize: 14, color: "#000", fontFamily: "Open Sans", mb: 3 }}>
                        The table below shows the time logged for each Charge Type. When edited the time entries remain but the time allocated towards billing is overridden.
                      </Typography>

                      {/* Bill Section */}
                      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 2 }}>
                        <Typography sx={{ fontSize: 19, fontWeight: 700, color: "#409BFF", fontFamily: "Open Sans" }}>
                          Bill
                        </Typography>
                        <Button
                          variant="contained"
                          startIcon={<PlusIcon style={{ width: 16, height: 16 }} />}
                          onClick={() => setAddBillingDialogOpen(true)}
                          sx={{
                            backgroundColor: "#409BFF",
                            color: "#fff",
                            textTransform: "none",
                            fontFamily: "Open Sans",
                            fontWeight: 400,
                            fontSize: 14,
                            px: 2,
                            py: 0.75,
                            borderRadius: "6px",
                            "&:hover": { backgroundColor: "#2563EB" },
                          }}
                        >
                          Add
                        </Button>
                      </Box>

                      {/* Charge Types Table */}
                      <Box sx={{ borderRadius: 1, overflow: "hidden", mb: 3 }}>
                        <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: "Open Sans" }}>
                          <thead style={{ backgroundColor: "#F0F0F0" }}>
                            <tr>
                              <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 14, fontWeight: 600, color: "#00000099" }}>
                                Change Type
                              </th>
                              <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 14, fontWeight: 600, color: "#00000099" }}>
                                Actual Time
                              </th>
                              <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 14, fontWeight: 600, color: "#00000099" }}>
                                Contract/Billable Time
                              </th>
                              <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 14, fontWeight: 600, color: "#00000099" }}>
                                Overriding Actual Time
                              </th>
                              <th style={{ padding: "12px 16px", width: "80px" }}></th>
                            </tr>
                          </thead>
                          <tbody>
                            {chargeTypes.map((item, index) => (
                              <BillingTableRow
                                key={index}
                                item={item}
                                index={index}
                                isLast={index === chargeTypes.length - 1}
                                onEdit={() => handleEditBillingClick(item, index)}
                                onDelete={() => handleDeleteBillingClick(item, index)}
                              />
                            ))}
                          </tbody>
                        </table>
                      </Box>

                      <Divider sx={{ my: 3 }} />

                      {/* Expenses Section */}
                      <Box sx={{ mb: 3 }}>
                        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
                          <Typography sx={{ fontSize: 19, fontWeight: 700, color: "#409BFF", fontFamily: "Open Sans" }}>
                            Expenses
                          </Typography>
                          <Button
                            variant="contained"
                            startIcon={<PlusIcon style={{ width: 16, height: 16 }} />}
                            onClick={() => setAddExpenseDialogOpen(true)}
                            sx={{
                              backgroundColor: "#409BFF",
                              color: "#fff",
                              textTransform: "none",
                              fontFamily: "Open Sans",
                              fontWeight: 400,
                              fontSize: 14,
                              px: 2,
                              py: 0.75,
                              borderRadius: "6px",
                              "&:hover": { backgroundColor: "#2563EB" },
                            }}
                          >
                            Add
                          </Button>
                        </Box>

                        {/* Expenses Table */}
                        <Box sx={{ borderRadius: 1, overflow: "hidden" }}>
                          <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: "Open Sans" }}>
                            <thead style={{ backgroundColor: "#F0F0F0" }}>
                              <tr>
                                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 14, fontWeight: 600, color: "#00000099" }}>
                                  Agents
                                </th>
                                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 14, fontWeight: 600, color: "#00000099" }}>
                                  Description
                                </th>
                                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 14, fontWeight: 600, color: "#00000099" }}>
                                  Cost
                                </th>
                                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 14, fontWeight: 600, color: "#00000099" }}>
                                  Expenses type
                                </th>
                                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 14, fontWeight: 600, color: "#00000099" }}>
                                  Date Added
                                </th>
                                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 14, fontWeight: 600, color: "#00000099" }}>
                                  Reviewed
                                </th>
                                <th style={{ padding: "12px 16px", width: "80px" }}></th>
                              </tr>
                            </thead>
                            <tbody>
                              {expenses.map((expense, index) => (
                                <ExpenseTableRow
                                  key={index}
                                  expense={expense}
                                  index={index}
                                  isLast={index === expenses.length - 1}
                                  onEdit={() => handleEditExpenseClick(expense, index)}
                                  onDelete={() => handleDeleteExpenseClick(expense, index)}
                                />
                              ))}
                            </tbody>
                          </table>
                        </Box>
                      </Box>
                    </Box>
                  </Grid>

                  {/* Invoice Details Section */}
                  <Grid size={{ xs: 12, sm: 12, md: 12, lg: 12, xl: 12 }} sx={{ mt: 3 }}>
                    <Box sx={{ border: "1px solid #E5E7EB", borderRadius: 1, p: 3, backgroundColor: "#FFFFFF", boxShadow: "0px 1px 2px 0px #0000000D" }}>
                      <Box sx={{ display: "flex", alignItems: "center", mb: 3, gap: 2 }}>
                        <Typography sx={{ fontSize: 14, color: "#000", fontFamily: "Open Sans", fontWeight: 400 }}>
                          Amount of hours invoiced so far:
                        </Typography>
                        <Typography sx={{ fontSize: 14, color: "#000", fontFamily: "Open Sans", fontWeight: 600 }}>
                          00:00
                        </Typography>
                      </Box>

                      <Box sx={{ mb: 3 }}>
                        <Box sx={{ display: "flex", alignItems: "flex-start", gap: 1.5 }}>
                          <input
                            type="checkbox"
                            id="invoice-separately"
                            style={{ width: 16, height: 16, marginTop: 2, cursor: "pointer", accentColor: "#409BFF" }}
                          />
                          <Box>
                            <label htmlFor="invoice-separately" style={{ fontSize: 14, color: "#000", fontFamily: "Open Sans", fontWeight: 400, cursor: "pointer", display: "block", marginBottom: 4 }}>
                              Invoice this Ticket separately
                            </label>
                            <Typography sx={{ fontSize: 12, color: "#9E9E9E", fontFamily: "Open Sans" }}>
                              This Ticket will be put onto its own invoice
                            </Typography>
                          </Box>
                        </Box>
                      </Box>

                      <Box sx={{ mb: 3 }}>
                        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                          <Typography sx={{ fontSize: 14, color: "#000", fontFamily: "Open Sans", fontWeight: 400, mb: 1 }}>
                            Invoice to this Client:
                          </Typography>
                          <select
                            style={{
                              flex: 0.2,
                              padding: "10px 12px",
                              border: "1px solid #D1D5DB",
                              borderRadius: "6px",
                              fontSize: 14,
                              fontFamily: "Open Sans",
                              color: "#9CA3AF",
                              backgroundColor: "#FFFFFF",
                              cursor: "pointer",
                              appearance: "none",
                              backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%239CA3AF'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E")`,
                              backgroundRepeat: "no-repeat",
                              backgroundPosition: "right 12px center",
                              backgroundSize: "20px",
                              paddingRight: "40px",
                              marginLeft: "90px",
                            }}
                            defaultValue=""
                          >
                            <option value="" disabled>Not set</option>
                            <option value="client1">Client 1</option>
                            <option value="client2">Client 2</option>
                          </select>
                          <IconButton size="small" sx={{ border: "1px solid #D1D5DB", borderRadius: "6px", p: 1.5, "&:hover": { backgroundColor: "#F9FAFB" } }}>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6B7280" strokeWidth="2">
                            <circle cx="11" cy="11" r="8" />
                              <path d="m21 21-4.35-4.35" />
                            </svg>
                          </IconButton>
                        </Box>
                      </Box>

                      <Box>
                        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                          <Typography sx={{ fontSize: 14, color: "#000", fontFamily: "Open Sans", fontWeight: 400, mb: 1 }}>
                            Purchase Order Number:
                          </Typography>
                          <select
                            style={{
                              flex: 0.2,
                              padding: "10px 12px",
                              border: "1px solid #D1D5DB",
                              borderRadius: "6px",
                              fontSize: 14,
                              fontFamily: "Open Sans",
                              color: "#9CA3AF",
                              backgroundColor: "#FFFFFF",
                              cursor: "pointer",
                              appearance: "none",
                              backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%239CA3AF'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E")`,
                              backgroundRepeat: "no-repeat",
                              backgroundPosition: "right 12px center",
                              backgroundSize: "20px",
                              paddingRight: "40px",
                              marginLeft: "60px",
                            }}
                            defaultValue=""
                          >
                            <option value="" disabled>Not set</option>
                            <option value="po1">PO-001</option>
                            <option value="po2">PO-002</option>
                          </select>
                          <IconButton size="small" sx={{ border: "1px solid #D1D5DB", borderRadius: "6px", p: 1.5, "&:hover": { backgroundColor: "#F9FAFB" } }}>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6B7280" strokeWidth="2">
                             <circle cx="11" cy="11" r="8" />
                              <path d="m21 21-4.35-4.35" />
                            </svg>
                          </IconButton>
                        </Box>
                        <Typography sx={{ fontSize: 12, color: "#9CA3AF", fontFamily: "Open Sans", maxWidth: "230px" }}>
                          This is a free text field that is not linked to the Purchase Orders feature
                        </Typography>
                      </Box>
                    </Box>
                  </Grid>
                </>
              )}

              {/* SALES INFO TAB */}
              {tab === tabValue[2] && (
                <Box sx={{ border: "1px solid #E5E7EB", borderRadius: "8px", p: 3, backgroundColor: "#FFFFFF", boxShadow: "0px 1px 2px 0px #0000000D" }}>
                  <EditableSalesField label="What kind of opportunity is this?" value={salesInfo.opportunityType} fieldName="opportunityType" options={["Hardware", "New Managed Service", "Training", "Upsell"]} />
                  <Divider sx={{ my: 2.5 }} />
                  <EditableSalesField label="How are they managing their IT currently?" value={salesInfo.currentITManagement} fieldName="currentITManagement" />
                  <Divider sx={{ my: 2.5 }} />
                  <EditableSalesField label="How many employees?" value={salesInfo.employeeCount} fieldName="employeeCount" options={["1", "2", "3-5", "6-10", "11-20", "21-50", "51-100"]} />
                  <Divider sx={{ my: 2.5 }} />
                  <EditableSalesField label="What industry are they in?" value={salesInfo.industry} fieldName="industry" options={["Agriculture", "Food and Drink", "Construction", "Education", "Energy", "Entertainment", "Healthcare"]} />
                  <Divider sx={{ my: 2.5 }} />
                  <EditableSalesField label="How did they hear?" value={salesInfo.howDidTheyHear} fieldName="howDidTheyHear" options={["Google Search", "Outbound Marketing", "Referral Program", "Upsell", "Word of Mouth"]} />
                  <Divider sx={{ my: 2.5 }} />
                  <EditableSalesField label="Requirements" value={salesInfo.requirements} fieldName="requirements" isTextArea={true} />
                  <Divider sx={{ my: 2.5 }} />
                  <EditableSalesField label="Site Report Notes" value={salesInfo.siteReportNotes} fieldName="siteReportNotes" isTextArea={true} />
                </Box>
              )}
            </Grid>

            {/* Right Section - Sticky Sidebar */}
            <Grid size={{ xs: 12, sm: 12, md: 12, lg: 12, xl: 3 }}>
              <Box sx={{ position: "sticky", top: 16 }}>
                <Paper sx={{ p: 2.5, border: "1px solid #E4E4E7" }} elevation={0}>
                  {/* Timer Section - Now Isolated */}
                  <TimerDisplay isRunning={isTimerRunning} onToggle={handleToggleTimer} />

                  <Divider sx={{ my: 2.5 }} />

                  {/* Contact Details Accordion */}
                  <Box sx={{ mb: 2 }}>
                    <Box onClick={() => setContactDetailsOpen(!contactDetailsOpen)} sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer", mb: contactDetailsOpen ? 2 : 0 }}>
                      <Typography sx={{ fontWeight: 600, fontSize: 16, fontFamily: "Open Sans", color: "#111827" }}>Contact details</Typography>
                      <IconButton size="small" sx={{ p: 0 }}>
                        {contactDetailsOpen ? (
                          <span className="material-symbols-outlined" style={{ fontSize: 20, color: "#6B7280" }}>expand_less</span>
                        ) : (
                          <span className="material-symbols-outlined" style={{ fontSize: 20, color: "#6B7280" }}>expand_more</span>
                        )}
                      </IconButton>
                    </Box>

                    {contactDetailsOpen && (
                      <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                        <EditableField label="Company Name" value={contactData.companyName} fieldName="companyName" section="contact" />
                        <EditableField label="Contact Name" value={contactData.contactName} fieldName="contactName" section="contact" />
                        <EditableField label="Email Address" value={contactData.emailAddress} fieldName="emailAddress" section="contact" isLink={true} color="#3B82F6" />
                        <EditableField label="Phone Number" value={contactData.phoneNumber} fieldName="phoneNumber" section="contact" isLink={true} color="#3B82F6" />
                        <EditableField label="Contact Title" value={contactData.contactTitle} fieldName="contactTitle" section="contact" />
                        <EditableField label="Contact Address" value={contactData.contactAddress} fieldName="contactAddress" section="contact" />
                      </Box>
                    )}
                  </Box>

                  <Divider sx={{ my: 2.5 }} />

                  {/* Opportunity Information Accordion */}
                  <Box>
                    <Box onClick={() => setOpportunityInfoOpen(!opportunityInfoOpen)} sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer", mb: opportunityInfoOpen ? 2 : 0 }}>
                      <Typography sx={{ fontWeight: 600, fontSize: 16, fontFamily: "Open Sans", color: "#111827" }}>Opportunity information</Typography>
                      <IconButton size="small" sx={{ p: 0 }}>
                        {opportunityInfoOpen ? (
                          <span className="material-symbols-outlined" style={{ fontSize: 20, color: "#6B7280" }}>expand_less</span>
                        ) : (
                          <span className="material-symbols-outlined" style={{ fontSize: 20, color: "#6B7280" }}>expand_more</span>
                        )}
                      </IconButton>
                    </Box>

                    {opportunityInfoOpen && (
                      <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                        <EditableField label="First Contact" value={opportunityData.firstContact} fieldName="firstContact" section="opportunity" />
                        <EditableField label="Created by" value={opportunityData.createdBy} fieldName="createdBy" section="opportunity" />
                        <EditableField label="Type" value={opportunityData.type} fieldName="type" section="opportunity" isLink={true} color="#3B82F6" />
                        <EditableField label="Workflow" value={opportunityData.workflow} fieldName="workflow" section="opportunity" isLink={true} color="#3B82F6" />

                        {/* Status Chip */}
                        <Box>
                          <Typography sx={{ fontSize: 12, color: "#6B7280", fontFamily: "Open Sans", mb: 0.5 }}>Status</Typography>
                          <Chip label={opportunityData.status} size="small" sx={{ backgroundColor: getStatusColor(opportunityData.status), color: "#FFFFFF", fontWeight: 600, fontFamily: "Open Sans", fontSize: 12, height: 24 }} />
                        </Box>

                        <EditableField label="Team" value={opportunityData.team} fieldName="team" section="opportunity" isLink={true} color="#3B82F6" />

                        {/* Assigned Agent with Avatar */}
                        <Box>
                          <Typography sx={{ fontSize: 12, color: "#6B7280", fontFamily: "Open Sans", mb: 0.5 }}>Assigned Agent</Typography>
                          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                            <Avatar src={opportunityGridData.ownerAvatar || "https://randomuser.me/api/portraits/men/32.jpg"} sx={{ width: 24, height: 24 }}>
                              {opportunityGridData.owner?.split(' ').map(n => n[0]).join('') || "KL"}
                            </Avatar>
                            <Typography sx={{ fontSize: 14, fontWeight: 600, fontFamily: "Open Sans", color: "#3B82F6", cursor: "pointer" }}>
                              {opportunityGridData.owner || "Kerry Last"}
                            </Typography>
                          </Box>
                        </Box>

                        <EditableField label="Additional Agents" value={opportunityData.additionalAgents} fieldName="additionalAgents" section="opportunity" />
                        <EditableField label="Time Recorded" value={opportunityData.timeRecorded} fieldName="timeRecorded" section="opportunity" />
                        <EditableField label="Attempts Made" value={opportunityData.attemptsMade} fieldName="attemptsMade" section="opportunity" />
                        <EditableField label="Potential Value" value={opportunityData.potentialValue} fieldName="potentialValue" section="opportunity" />
                        <EditableField label="Target Date" value={opportunityData.targetDate} fieldName="targetDate" section="opportunity" />
                        <EditableField label="Conversion Probability" value={opportunityData.conversionProbability} fieldName="conversionProbability" section="opportunity" color="#10B981" />
                        <EditableField label="Ticket Tags" value={opportunityData.ticketTags} fieldName="ticketTags" section="opportunity" />
                        <EditableField label="LinkedIn" value={opportunityData.linkedin} fieldName="linkedin" section="opportunity" isLink={true} color="#3B82F6" />
                        <EditableField label="Website" value={opportunityData.website} fieldName="website" section="opportunity" isLink={true} color="#3B82F6" />
                      </Box>
                    )}
                  </Box>
                </Paper>
              </Box>
            </Grid>
          </Grid>
        </Grid>
      </Grid>

      {/* ALL DIALOGS */}
      <AddBillingDialog
  open={addBillingDialogOpen}
  onClose={() => setAddBillingDialogOpen(false)}
  onSave={handleAddBilling} />

<EditBillDialog
  open={editBillingDialogOpen}
  onClose={() => setEditBillingDialogOpen(false)}
  onSave={handleUpdateBilling}  // ✅ Keep onSave to match EditBillDialog's prop
  initialData={selectedBillingItem}
/>

      <DeleteContentDialog
        open={deleteBillingDialogOpen}
        onClose={() => {
          setDeleteBillingDialogOpen(false);
          setSelectedBillingItem(null);
          setSelectedBillingIndex(null);
        }}
        onConfirm={handleConfirmDeleteBilling}
        title="Delete Billing Item"
        message="Are you sure you want to delete this billing item? This action cannot be undone."
      />

<AddExpenseDialog
  open={addExpenseDialogOpen}
  onClose={() => setAddExpenseDialogOpen(false)}
  onSave={handleAddExpense}  
/>

<EditExpenseDialog
  open={editExpenseDialogOpen}
  onClose={() => setEditExpenseDialogOpen(false)}
  onSave={handleUpdateExpense}  
  initialData={selectedExpenseItem}
/>
      <DeleteContentDialog
        open={deleteExpenseDialogOpen}
        onClose={() => {
          setDeleteExpenseDialogOpen(false);
          setSelectedExpenseItem(null);
          setSelectedExpenseIndex(null);
        }}
        onConfirm={handleConfirmDeleteExpense}
        title="Delete Expense Item"
        message="Are you sure you want to delete this expense item? This action cannot be undone."
      />

      {/* Success Dialog */}
      <Dialog
        open={openSuccessDialog}
        onClose={() => setOpenSuccessDialog(false)}
        PaperProps={{ sx: { borderRadius: "8px", p: 2, minWidth: "400px" } }}
      >
        <Box sx={{ textAlign: "center", p: 2 }}>
          <Box
            sx={{
              width: 56,
              height: 56,
              borderRadius: "50%",
              backgroundColor: "#D1FAE5",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 auto 16px",
            }}
          >
            <span className="material-symbols-outlined" style={{ fontSize: 32, color: "#10B981" }}>
              check_circle
            </span>
          </Box>
          <Typography sx={{ fontSize: 20, fontWeight: 600, fontFamily: "Open Sans", color: "#111827", mb: 1 }}>
            Qualification Saved
          </Typography>
          <Typography sx={{ fontSize: 14, fontFamily: "Open Sans", color: "#6B7280", mb: 3 }}>
            The opportunity has been successfully qualified with the provided information.
          </Typography>
          <Button
            variant="contained"
            onClick={() => setOpenSuccessDialog(false)}
            sx={{
              backgroundColor: "#10B981",
              color: "#fff",
              textTransform: "none",
              fontFamily: "Open Sans",
              fontWeight: 500,
              fontSize: 14,
              px: 4,
              py: 1,
              "&:hover": { backgroundColor: "#059669" },
            }}
          >
            OK
          </Button>
        </Box>
      </Dialog>
    </>
  );
};

export default OpportunityDetails;
