import React, { useState, forwardRef, useImperativeHandle } from "react";
import { Box, Avatar, Chip, IconButton, Tooltip } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { useNavigate } from "react-router-dom";
import { StarIcon as StarIconSolid } from '@heroicons/react/24/solid';
import { StarIcon as StarIconOutline } from '@heroicons/react/24/outline';
import { opportunitiesData } from "../../../../Data/OpportunitiesData";


const OpportunitiesGrid = forwardRef(({ onSelectionChange }, ref) => {
  const navigate = useNavigate();
  const [rows, setRows] = useState(opportunitiesData);
  const [loading, setLoading] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]);
  const [gridKey, setGridKey] = useState(0);


  // Expose refresh and download functions to parent
  useImperativeHandle(ref, () => ({
    handleRefresh: () => {
      setLoading(true);
      setTimeout(() => {
        setGridKey(prev => prev + 1);
        setRows([...opportunitiesData]);
        setLoading(false);
      }, 300);
    },
    handleDownload: () => {
      console.log("Downloading opportunities data...");
      // Implement CSV/Excel download logic here
    }
  }));


  const handleStarToggle = (e, id) => {
    e.stopPropagation();
    setRows(prevRows =>
      prevRows.map(row =>
        row.id === id ? { ...row, starred: !row.starred } : row
      )
    );
  };


  const handleSelectionModelChange = (newSelection) => {
    setSelectedRows(newSelection);
    if (onSelectionChange) {
      onSelectionChange(newSelection.length);
    }
  };

  // Handle row click - navigate to opportunity details
  const handleRowClick = (params) => {
    navigate('/opportunity-details', { 
      state: { opportunityData: params.row } 
    });
  };


  const getStatusColor = (status) => {
    const statusColors = {
      "Qualified": "#6366F1",
      "New": "#84CC16",
      "Quote Sent": "#8B5CF6",
      "Quote Raised": "#3B82F6",
      "Approved": "#84CC16",
      "In Progress": "#0EA5E9"
    };
    return statusColors[status] || "#6B7280";
  };


  const getProbabilityColor = (probability) => {
    if (probability === "Not Set") return "#6B7280";
    const percent = parseInt(probability);
    if (percent >= 75) return "#10B981";
    if (percent >= 50) return "#F59E0B";
    if (percent >= 25) return "#3B82F6";
    return "#EF4444";
  };


  const columns = [
    {
      field: "title",
      headerName: "Title",
      flex: 1.5,
      minWidth: 250,
      renderCell: (params) => (
        <Tooltip title={params.value} placement="top">
          <Box sx={{ 
            fontSize: "14px", 
            fontWeight: 500, 
            color: "#3B82F6",
            fontFamily: "Open Sans",
            cursor: "pointer",
            textDecoration: "none",
            '&:hover': {
              textDecoration: "underline"
            },
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap"
          }}>
            {params.value}
          </Box>
        </Tooltip>
      ),
    },
    {
      field: "status",
      headerName: "Status",
      width: 140,
      renderCell: (params) => (
        <Chip
          label={params.value}
          sx={{
            height: 24,
            fontSize: "13px",
            fontWeight: 600,
            fontFamily: "Open Sans",
            backgroundColor: getStatusColor(params.value),
            color: "#fff",
            borderRadius: "6px"
          }}
        />
      ),
    },
    {
      field: "probability",
      headerName: "Probability",
      width: 120,
      renderCell: (params) => (
        <Box sx={{ 
          fontSize: "14px", 
          fontWeight: 600,
          color: getProbabilityColor(params.value),
          fontFamily: "Open Sans"
        }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: "value",
      headerName: "Value",
      width: 120,
      renderCell: (params) => (
        <Box sx={{ 
          fontSize: "14px", 
          fontWeight: 500, 
          color: "#111827",
          fontFamily: "Open Sans"
        }}>
          {params.value.toFixed(2)}
        </Box>
      ),
    },
    {
      field: "company",
      headerName: "Company",
      flex: 1,
      minWidth: 180,
      renderCell: (params) => (
        <Tooltip title={params.value} placement="top">
          <Box sx={{ 
            fontSize: "14px", 
            fontWeight: 500, 
            color: "#111827",
            fontFamily: "Open Sans",
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap"
          }}>
            {params.value}
          </Box>
        </Tooltip>
      ),
    },
    {
      field: "contact",
      headerName: "Contact",
      flex: 1,
      minWidth: 150,
      renderCell: (params) => (
        <Box sx={{ 
          fontSize: "14px", 
          fontWeight: 500, 
          color: "#111827",
          fontFamily: "Open Sans"
        }}>
          {params.value}
        </Box>
      ),
    },
    {
      field: "expectedClose",
      headerName: "Expected Close",
      width: 140,
      renderCell: (params) => (
        <Box sx={{ 
          fontSize: "14px", 
          fontWeight: 500, 
          color: "#6B7280",
          fontFamily: "Open Sans"
        }}>
          {params.value || "-"}
        </Box>
      ),
    },
    {
      field: "opportunity",
      headerName: "Opportunity Value",
      width: 160,
      renderCell: (params) => (
        <Box sx={{ 
          fontSize: "14px", 
          fontWeight: 600, 
          color: "#10B981",
          fontFamily: "Open Sans"
        }}>
          {params.value.toFixed(2)}
        </Box>
      ),
    },
 
    {
      field: "owner",
      headerName: "Owner",
      width: 180,
      renderCell: (params) => (
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Avatar
            src={params.row.ownerAvatar}
            alt={params.value}
            sx={{
              width: 32,
              height: 32,
              fontSize: "12px",
              fontWeight: 600,
              bgcolor: "#4390F8"
            }}
          >
            {params.value.split(' ').map(n => n[0]).join('')}
          </Avatar>
          <Box sx={{ 
            fontSize: "14px", 
            fontWeight: 500, 
            color: "#111827",
            fontFamily: "Open Sans"
          }}>
            {params.value}
          </Box>
        </Box>
      ),
    },
  ];


  return (
    <Box sx={{ 
      width: "100%", 
      overflowX: "auto",
      "-ms-overflow-style": "none",
      "scrollbar-width": "none",
      "&::-webkit-scrollbar": { display: "none" }
    }}>
      <DataGrid
        key={gridKey}
        rows={rows}
        columns={columns}
        disableRowSelectionOnClick
        loading={loading}
        onRowClick={handleRowClick}
        onRowSelectionModelChange={handleSelectionModelChange}
        initialState={{
          pagination: {
            paginationModel: { page: 0, pageSize: 10 }
          }
        }}
        sx={{
          border: "none",
          fontFamily: "Open Sans",
          minHeight: 500,
          "& .MuiDataGrid-columnHeader": {
            backgroundColor: "#F9FAFB",
            borderBottom: "2px solid #E5E7EB"
          },
          "& .MuiDataGrid-columnHeaderTitle": {
            fontSize: "14px",
            fontWeight: 700,
            color: "#111827",
            fontFamily: "Open Sans"
          },
          "& .MuiDataGrid-cell": {
            fontSize: "14px",
            fontWeight: 500,
            color: "#374151",
            fontFamily: "Open Sans",
            borderBottom: "1px solid #F3F4F6"
          },
          "& .MuiDataGrid-row": {
            cursor: "pointer",
            "&:hover": {
              backgroundColor: "#EEF2FF"
            },
            "&.Mui-selected": {
              backgroundColor: "#EFF6FF !important",
              "&:hover": {
                backgroundColor: "#DBEAFE !important"
              }
            }
          },
          "& .MuiCheckbox-root": {
            color: "#D1D5DB",
            "&.Mui-checked": {
              color: "#4390F8"
            }
          },
          "& .MuiDataGrid-columnSeparator": {
            display: "none"
          },
          "& .MuiDataGrid-cell:focus": {
            outline: "none"
          },
          "& .MuiDataGrid-cell:focus-within": {
            outline: "none"
          },
          "& .MuiDataGrid-columnHeader:focus": {
            outline: "none"
          },
          "& .MuiDataGrid-columnHeader:focus-within": {
            outline: "none"
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "2px solid #E5E7EB",
            backgroundColor: "#F9FAFB"
          }
        }}
      />
    </Box>
  );
});


OpportunitiesGrid.displayName = "OpportunitiesGrid";


export default OpportunitiesGrid;
