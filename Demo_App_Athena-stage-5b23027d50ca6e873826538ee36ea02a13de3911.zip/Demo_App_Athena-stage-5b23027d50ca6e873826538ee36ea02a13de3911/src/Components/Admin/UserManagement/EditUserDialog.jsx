import React, { useState, useEffect, useRef } from 'react';
import {
  Dialog,
  DialogContent,
  Box,
  Typography,
  TextField,
  Select,
  MenuItem,
  FormControl,
  Button,
  Avatar,
  IconButton,
  Divider
} from '@mui/material';
import { XMarkIcon, CameraIcon } from '@heroicons/react/24/solid';

const EditUserDialog = ({ open, onClose, user, onSave }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    role: '',
    avatar: ''
  });

  // Create a ref for the hidden file input
  const fileInputRef = useRef(null);

  // Populate form when user changes
  useEffect(() => {
    if (user) {
      setFormData({
        name: user.name || '',
        email: user.email || '',
        phone: user.phone || '+1 (555) 123-4567',
        role: user.role || '',
        avatar: user.avatar || ''
      });
    }
  }, [user]);

  // Handle input changes
  const handleChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Handle camera icon click - trigger file input
  const handleAvatarClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  // Handle file upload and preview
  const handleFileChange = (event) => {
    const file = event.target.files?.[0];
    
    if (!file) {
      return;
    }

    // Validate file type (optional)
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      alert('Please select a valid image file (JPG, PNG, GIF, or WEBP)');
      return;
    }

    // Validate file size (optional - 5MB limit)
    const maxSize = 5 * 1024 * 1024; // 5MB in bytes
    if (file.size > maxSize) {
      alert('File size must be less than 5MB');
      return;
    }

    // Create preview URL using FileReader
    const reader = new FileReader();
    
    reader.onload = (e) => {
      // Update avatar with the preview URL
      setFormData(prev => ({
        ...prev,
        avatar: e.target.result
      }));
    };

    reader.onerror = () => {
      alert('Error reading file. Please try again.');
    };

    // Read the file as Data URL for preview
    reader.readAsDataURL(file);
  };

  // Handle save
  const handleSave = () => {
    onSave({
      ...user,
      ...formData
    });
    onClose();
  };

  // Handle cancel
  const handleCancel = () => {
    onClose();
  };

  if (!user) return null;

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="sm"
      fullWidth
      disableScrollLock
    >
      {/* Header */}
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          p: 3,
          pb: 2
        }}
      >
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '22px',
            fontWeight: 600,
            color: '#111827'
          }}
        >
          Edit User
        </Typography>
        <IconButton
          onClick={onClose}
          sx={{
            width: 40,
            height: 40,
            '&:hover': {
              backgroundColor: '#F3F4F6'
            }
          }}
        >
          <XMarkIcon style={{ width: 40, height: 40, color: '#000' }} />
        </IconButton>
      </Box>
      
      {/* Tab - User Info */}
      <Box sx={{ px: 3 }}>
        <Box
          sx={{
            display: 'inline-block',
            pb: 1,
            borderBottom: '2px solid #409BFF'
          }}
        >
          <Typography
            sx={{
              fontFamily: 'Open Sans',
              fontSize: '14px',
              fontWeight: 700,
              color: '#409BFF'
            }}
          >
            User Info
          </Typography>
        </Box>
      </Box>

      <DialogContent sx={{ p: 5, pt: 2 }}>
        {/* Avatar Section with Upload Functionality */}
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 2,
            mb: 2
          }}
        >
          <Box sx={{ position: 'relative' }}>
            <Avatar
              src={formData.avatar}
              alt={formData.name}
              sx={{
                width: 64,
                height: 64
              }}
            />
            {/* Camera Icon - Clickable */}
            <Box
              onClick={handleAvatarClick}
              sx={{
                position: 'absolute',
                bottom: 0,
                right: 0,
                width: 24,
                height: 24,
                borderRadius: '50%',
                backgroundColor: '#E5E7EB',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                border: '2px solid #FFFFFF',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                '&:hover': {
                  backgroundColor: '#D1D5DB',
                  transform: 'scale(1.1)'
                },
                '&:active': {
                  transform: 'scale(0.95)'
                }
              }}
            >
              <CameraIcon style={{ width: 12, height: 12, color: '#6B7280' }} />
            </Box>
            
            {/* Hidden File Input */}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/jpg,image/png,image/gif,image/webp"
              onChange={handleFileChange}
              style={{ display: 'none' }}
            />
          </Box>
          <Box>
            <Typography
              sx={{
                fontFamily: 'Open Sans',
                fontSize: '18px',
                fontWeight: 600,
                color: '#000000',
              }}
            >
              {formData.name}
            </Typography>
            <Typography
              sx={{
                fontFamily: 'Open Sans',
                fontSize: '14px',
                fontWeight: 400,
                color: '#4B5563'
              }}
            >
              {formData.role === 'Admin' ? 'Administrator' : formData.role}
            </Typography>
          </Box>
        </Box>

        {/* Full Name Field */}
        <Box sx={{ mb: 2.5 }}>
          <Typography
            sx={{
              fontFamily: 'Open Sans',
              fontSize: '14px',
              fontWeight: 600,
              color: '#374151',
              mb: 1
            }}
          >
            Full Name
          </Typography>
          <TextField
            fullWidth
            value={formData.name}
            onChange={(e) => handleChange('name', e.target.value)}
            placeholder="Enter full name"
            sx={{
              '& .MuiOutlinedInput-root': {
                height: 44,
                fontSize: '14px',
                fontFamily: 'Open Sans',
                borderRadius: '8px',
                backgroundColor: '#fff',
                '& fieldset': {
                  borderColor: '#E5E7EB'
                },
                '&:hover fieldset': {
                  borderColor: '#D1D5DB'
                },
                '&.Mui-focused': {
                  backgroundColor: '#FFFFFF',
                },
                '&.Mui-focused fieldset': {
                  borderColor: '#409BFF'
                }
              },
              '& .MuiOutlinedInput-input': {
                color: '#111827',
                '&::placeholder': {
                  color: '#9CA3AF',
                  opacity: 1
                }
              }
            }}
          />
        </Box>

        {/* Email Address Field */}
        <Box sx={{ mb: 2.5 }}>
          <Typography
            sx={{
              fontFamily: 'Open Sans',
              fontSize: '14px',
              fontWeight: 600,
              color: '#374151',
              mb: 1
            }}
          >
            Email Address
          </Typography>
          <TextField
            fullWidth
            value={formData.email}
            onChange={(e) => handleChange('email', e.target.value)}
            placeholder="Enter email address"
            sx={{
              '& .MuiOutlinedInput-root': {
                height: 44,
                fontSize: '14px',
                fontFamily: 'Open Sans',
                borderRadius: '8px',
                backgroundColor: '#fff',
                '& fieldset': {
                  borderColor: '#E5E7EB'
                },
                '&:hover fieldset': {
                  borderColor: '#D1D5DB'
                },
                '&.Mui-focused': {
                  backgroundColor: '#FFFFFF',
                },
                '&.Mui-focused fieldset': {
                  borderColor: '#409BFF'
                }
              },
              '& .MuiOutlinedInput-input': {
                color: '#111827',
                '&::placeholder': {
                  color: '#9CA3AF',
                  opacity: 1
                }
              }
            }}
          />
        </Box>

        {/* Phone Number Field */}
        <Box sx={{ mb: 2.5 }}>
          <Typography
            sx={{
              fontFamily: 'Open Sans',
              fontSize: '14px',
              fontWeight: 600,
              color: '#374151',
              mb: 1
            }}
          >
            Phone Number
          </Typography>
          <TextField
            fullWidth
            value={formData.phone}
            onChange={(e) => handleChange('phone', e.target.value)}
            placeholder="Enter phone number"
            sx={{
              '& .MuiOutlinedInput-root': {
                height: 44,
                fontSize: '14px',
                fontFamily: 'Open Sans',
                borderRadius: '8px',
                backgroundColor: '#fff',
                '& fieldset': {
                  borderColor: '#E5E7EB'
                },
                '&:hover fieldset': {
                  borderColor: '#D1D5DB'
                },
                '&.Mui-focused': {
                  backgroundColor: '#FFFFFF',
                },
                '&.Mui-focused fieldset': {
                  borderColor: '#409BFF'
                }
              },
              '& .MuiOutlinedInput-input': {
                color: '#111827',
                '&::placeholder': {
                  color: '#9CA3AF',
                  opacity: 1
                }
              }
            }}
          />
        </Box>

        {/* Role Field */}
        <Box sx={{ mb: 3 }}>
          <Typography
            sx={{
              fontFamily: 'Open Sans',
              fontSize: '14px',
              fontWeight: 600,
              color: '#374151',
              mb: 1
            }}
          >
            Role
          </Typography>
          <FormControl fullWidth>
            <Select
              value={formData.role}
              onChange={(e) => handleChange('role', e.target.value)}
              sx={{
                height: 44,
                fontSize: '14px',
                fontFamily: 'Open Sans',
                borderRadius: '8px',
                backgroundColor: '#fff',
                color: '#111827',
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: '#E5E7EB'
                },
                '&:hover .MuiOutlinedInput-notchedOutline': {
                  borderColor: '#D1D5DB'
                },
                '&.Mui-focused': {
                  backgroundColor: '#FFFFFF',
                },
                '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                  borderColor: '#409BFF'
                }
              }}
            >
              <MenuItem value="Admin">Admin</MenuItem>
              <MenuItem value="Manager">Manager</MenuItem>
              <MenuItem value="Staff">Staff</MenuItem>
            </Select>
          </FormControl>
        </Box>

        {/* Action Buttons */}
        <Box
          sx={{
            display: 'flex',
            gap: 2,
            justifyContent: 'flex-end',
            pt: 1
          }}
        >
          <Button
            onClick={handleSave}
            variant="contained"
            sx={{
              px: 5,
              height: 44,
              borderRadius: '16px',
              backgroundColor: '#409BFF',
              color: '#FFFFFF',
              fontFamily: 'Open Sans',
              fontSize: '14px',
              fontWeight: 600,
              textTransform: 'none',
              boxShadow: 'none',
              '&:hover': {
                backgroundColor: '#2563EB',
                boxShadow: 'none'
              }
            }}
          >
            Save
          </Button>

          <Button
            onClick={handleCancel}
            variant="outlined"
            sx={{
              px: 4,
              height: 44,
              borderRadius: '16px',
              border: '1px solid #E5E7EB',
              fontFamily: 'Open Sans',
              backgroundColor: '#FF4141',
              color: '#fff',
              fontSize: '14px',
              fontWeight: 600,
              textTransform: 'none',
              '&:hover': {
                backgroundColor: '#DC2626',
                border: '1px solid #DC2626'
              }
            }}
          >
            Cancel
          </Button>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default EditUserDialog;
