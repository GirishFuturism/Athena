import React from 'react';
import { Box, Typography, Chip } from '@mui/material';

const RoleDefinitions = () => {
  const roles = [
     {
      title: 'Manager',
      description: 'Team oversight and reporting access',
      userCount: 10,
      userCountColor: '#DCFCE7',
      userCountTextColor: '#166534',
      permissions: [
        { label: 'Tickets', bgColor: '#DCFCE7', textColor: '#166534' },
        { label: 'Finance', bgColor: '#DCFCE7', textColor: '#166534' },
        { label: 'Contracts', bgColor: '#DCFCE7', textColor: '#166534' },
        { label: 'Reports', bgColor: '#DCFCE7', textColor: '#166534' },
        { label: 'Settings', bgColor: '#DCFCE7', textColor: '#166534' }
      ]
    },
    {
      title: 'Administrator',
      description: 'Full system access and user management',
      userCount: 3,
      userCountColor: '#F3E8FF',
      userCountTextColor: '#6B21A8',
      permissions: [
        { label: 'Tickets', bgColor: '#DCFCE7', textColor: '#166534' },
        { label: 'Finance', bgColor: '#DCFCE7', textColor: '#166534' },
        { label: 'Contracts', bgColor: '#DCFCE7', textColor: '#166534' },
        { label: 'Reports', bgColor: '#DCFCE7', textColor: '#166534' },
        
      ]
    },
    {
      title: 'Agents',
      description: 'Ticket management and basic operations',
      userCount: 18,
      userCountColor: '#DBEAFE',
      userCountTextColor: '#1E40AF',
      permissions: [
        { label: 'Tickets', bgColor: '#DCFCE7', textColor: '#166534' },
        { label: 'Contracts', bgColor: '#DCFCE7', textColor: '#166534' },
        { label: 'Reports', bgColor: '#DCFCE7', textColor: '#166534' }
      ]
    },
   
  ];

  return (
    <Box
      sx={{
        backgroundColor: '#FFFFFF',
        border: '1px solid #E5E7EB',
        borderRadius: '8px',
        p: 2.5,
        display: 'flex',
        flexDirection: 'column'
      }}
    >
      {/* Header */}
      <Typography
        sx={{
          fontFamily: 'Open Sans',
          fontSize: '18px',
          fontWeight: '700',
          color: '#111827',
          mb: 2.5
        }}
      >
        Role Definitions
      </Typography>

      {/* Role Cards */}
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {roles.map((role, index) => (
          <Box
            key={index}
            sx={{
              border: '1px solid #E5E7EB',
              borderRadius: '8px',
              p: 2,
              backgroundColor: '#FFFFFF',
              '&:hover': {
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.08)',
                transition: 'box-shadow 0.2s ease-in-out'
              }
            }}
          >
            {/* Role Title and User Count */}
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                mb: 1
              }}
            >
              <Typography
                sx={{
                  fontFamily: 'Open Sans',
                  fontSize: '16px',
                  fontWeight: '600',
                  color: '#111827'
                }}
              >
                {role.title}
              </Typography>
              <Chip
                label={`${role.userCount} users`}
                sx={{
                  backgroundColor: role.userCountColor,
                  color: role.userCountTextColor,
                  fontFamily: 'Open Sans',
                  fontSize: '12px',
                  fontWeight: '600',
                  height: '25px',
                  '& .MuiChip-label': {
                    px: 1.5
                  }
                }}
              />
            </Box>

            {/* Role Description */}
            <Typography
              sx={{
                fontFamily: 'Open Sans',
                fontSize: '15px',
                fontWeight: '400',
                color: '#6B7280',
                mb: 2
              }}
            >
              {role.description}
            </Typography>

            {/* Permissions */}
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
              {role.permissions.map((permission, permIndex) => (
                <Chip
                  key={permIndex}
                  label={permission.label}
                  sx={{
                    backgroundColor: permission.bgColor,
                    color: permission.textColor,
                    fontFamily: 'Open Sans',
                    fontSize: '13px',
                    fontWeight: '500',
                    height: '28px',
                    border: 'none',
                    borderRadius:"8px",
                    '& .MuiChip-label': {
                      px: 1.8
                    }
                  }}
                />
              ))}
            </Box>
          </Box>
        ))}
      </Box>
    </Box>
  );
};

export default RoleDefinitions;