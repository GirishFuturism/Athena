import React, { useState } from 'react';
import { Box, Typography, TextField, Select, MenuItem, FormControl, InputAdornment, Avatar, IconButton, Chip } from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import { MagnifyingGlassIcon, PencilSquareIcon, TrashIcon } from '@heroicons/react/24/solid';
import DeleteContentDialog from "../TicketManagement/DeleteContentDialog";
import EditUserDialog from "./EditUserDialog";

const UserListGrid = ({ newUser }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('All Roles');
  const [statusFilter, setStatusFilter] = useState('All Status');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState(null);
  const [userToEdit, setUserToEdit] = useState(null);

  // Sample user data with random user API - Only 6 users (using state now)
  const [users, setUsers] = useState([
    {
      id: 1,
      name: 'Sarah Johnson',
      email: 'sarah.johnson@company.com',
      phone: '+1 (555) 123-4567',
      role: 'Admin',
      status: 'Active',
      avatar: 'https://randomuser.me/api/portraits/women/1.jpg'
    },
    {
      id: 2,
      name: 'Michael Chen',
      email: 'michael.chen@company.com',
      phone: '+1 (555) 234-5678',
      role: 'Manager',
      status: 'Pending',
      avatar: 'https://randomuser.me/api/portraits/men/2.jpg'
    },
    {
      id: 3,
      name: 'David Rodriguez',
      email: 'david.rodriguez@company.com',
      phone: '+1 (555) 345-6789',
      role: 'Staff',
      status: 'Inactive',
      avatar: 'https://randomuser.me/api/portraits/men/3.jpg'
    },
    {
      id: 4,
      name: 'Emily Davis',
      email: 'emily.davis@company.com',
      phone: '+1 (555) 456-7890',
      role: 'Staff',
      status: 'Active',
      avatar: 'https://randomuser.me/api/portraits/women/4.jpg'
    },
    {
      id: 5,
      name: 'James Smith',
      email: 'james.smith@company.com',
      phone: '+1 (555) 567-8901',
      role: 'Admin',
      status: 'Active',
      avatar: 'https://randomuser.me/api/portraits/men/5.jpg'
    },
    {
      id: 6,
      name: 'Linda Martinez',
      email: 'linda.martinez@company.com',
      phone: '+1 (555) 678-9012',
      role: 'Manager',
      status: 'Active',
      avatar: 'https://randomuser.me/api/portraits/women/6.jpg'
    },
  ]);

  // Add new user to the top of the list when newUser prop changes
  React.useEffect(() => {
    if (newUser) {
      setUsers(prevUsers => [newUser, ...prevUsers]);
    }
  }, [newUser]);

  // MenuProps to hide scrollbar and disable scroll lock
  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': {
          display: 'none',
        },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

  // Handle edit icon click - open dialog
  const handleEditClick = (user) => {
    setUserToEdit(user);
    setEditDialogOpen(true);
  };

  // Handle edit save
  const handleEditSave = (updatedUser) => {
    setUsers(users.map((user) =>
      user.id === updatedUser.id ? updatedUser : user
    ));
    console.log('Updated user:', updatedUser);
  };

  // Handle delete icon click - open dialog
  const handleDeleteClick = (user) => {
    setUserToDelete(user);
    setDeleteDialogOpen(true);
  };

  // Handle delete confirmation
  const handleDeleteConfirm = () => {
    if (userToDelete) {
      setUsers(users.filter((user) => user.id !== userToDelete.id));
      console.log('Deleted user:', userToDelete);
    }
    setDeleteDialogOpen(false);
    setUserToDelete(null);
  };

  // Handle delete cancel
  const handleDeleteCancel = () => {
    setDeleteDialogOpen(false);
    setUserToDelete(null);
  };

  // Filter logic
  const filteredUsers = users.filter((user) => {
    const matchesSearch = user.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          user.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          user.status.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRole = roleFilter === 'All Roles' || user.role === roleFilter;
    const matchesStatus = statusFilter === 'All Status' || user.status === statusFilter;
    return matchesSearch && matchesRole && matchesStatus;
  });

  // DataGrid columns
  const columns = [
    {
      field: 'name',
      headerName: 'User Name',
      flex: 1,
      minWidth: 200,
      renderCell: (params) => (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, pt: 1.5 }}>
          <Avatar
            src={params.row.avatar}
            alt={params.value}
            sx={{ width: 36, height: 36 }}
          />
          <Typography sx={{ fontSize: '14px', fontWeight: 600, color: '#111827', fontFamily: 'Open Sans' }}>
            {params.value}
          </Typography>
        </Box>
      ),
    },
    {
      field: 'email',
      headerName: 'Email',
      flex: 1.5,
      minWidth: 250,
      renderCell: (params) => (
        <Typography sx={{ fontSize: '14px', fontWeight: 400, color: '#6B7280', fontFamily: 'Open Sans', pt: 2 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'role',
      headerName: 'Role',
      width: 130,
      renderCell: (params) => (
        <Typography sx={{ fontSize: '14px', fontWeight: 600, color: '#111827', fontFamily: 'Open Sans', pt: 1.5 }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'status',
      headerName: 'Status',
      width: 150,
      renderCell: (params) => {
        const statusConfig = {
          Active: { bgColor: '#D1FAE5', textColor: '#166534' },
          Pending: { bgColor: '#EDE4A1', textColor: '#987805' },
          Inactive: { bgColor: '#FFD8E4', textColor: '#A20606' }
        };
        const config = statusConfig[params.value] || statusConfig.Active;
        
        return (
          <Box>
            <Chip
              label={params.value}
              sx={{
                backgroundColor: config.bgColor,
                color: config.textColor,
                fontFamily: 'Open Sans',
                fontSize: '13px',
                fontWeight: 600,
                height: '28px',
                borderRadius: '14px',
                '& .MuiChip-label': {
                  px: 2
                }
              }}
            />
          </Box>
        );
      },
    },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 120,
      sortable: false,
      renderCell: (params) => (
        <Box sx={{ display: 'flex', alignItems: 'center', pt: 1.5 }}>
          <IconButton
           onClick={(event) => {
          event.stopPropagation();
          handleEditClick(params.row);
        }}
            sx={{
              width: 32,
              height: 32,
              '&:hover': {
                backgroundColor: '#F3F4F6'
              }
            }}
          >
            <PencilSquareIcon style={{ width: 16, height: 16, color: '#6B7280' }} />
          </IconButton>
          <IconButton
            onClick={(event) => {
          event.stopPropagation();
          handleDeleteClick(params.row);
        }}
            sx={{
              width: 32,
              height: 32,
              '&:hover': {
                backgroundColor: '#FEE2E2'
              }
            }}
          >
            <TrashIcon style={{ width: 16, height: 16, color: '#6B7280' }} />
          </IconButton>
        </Box>
      ),
    }
  ];

  return (
    <Box
      sx={{
        backgroundColor: '#FFFFFF',
        border: '1px solid #E5E7EB',
        borderRadius: '8px',
        p: 2.5,
        display: 'flex',
        flexDirection: 'column',
        height: '100%'
      }}
    >
      {/* Header with Search and Filters */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2.5, flexWrap: 'wrap', gap: 2 }}>
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '18px',
            fontWeight: '700',
            color: '#111827'
          }}
        >
          User List
        </Typography>

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, flexWrap: 'wrap' }}>
          {/* Search Box */}
          <TextField
            placeholder="Search users..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            size="small"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <MagnifyingGlassIcon style={{ width: 18, height: 18, color: '#9CA3AF' }} />
                </InputAdornment>
              ),
            }}
            sx={{
              width: 220,
              '& .MuiOutlinedInput-root': {
                height: 36,
                fontSize: '14px',
                fontFamily: 'Open Sans',
                borderRadius: '6px',
                backgroundColor: '#FFFFFF',
                '& fieldset': {
                  borderColor: '#E5E7EB',
                },
                '&:hover fieldset': {
                  borderColor: '#D1D5DB',
                },
                '&.Mui-focused fieldset': {
                  borderColor: '#409BFF',
                }
              }
            }}
          />

          {/* All Roles Dropdown */}
          <FormControl size="small" sx={{ minWidth: 130 }}>
            <Select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              MenuProps={menuProps}
              sx={{
                height: 36,
                fontSize: '14px',
                fontWeight: 400,
                color: '#111827',
                borderRadius: '6px',
                fontFamily: 'Open Sans',
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: '#E5E7EB',
                },
                '&:hover .MuiOutlinedInput-notchedOutline': {
                  borderColor: '#D1D5DB',
                },
                '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                  borderColor: '#409BFF',
                }
              }}
            >
              <MenuItem value="All Roles">All Roles</MenuItem>
              <MenuItem value="Admin">Admin</MenuItem>
              <MenuItem value="Manager">Manager</MenuItem>
              <MenuItem value="Staff">Staff</MenuItem>
            </Select>
          </FormControl>

          {/* All Status Dropdown */}
          <FormControl size="small" sx={{ minWidth: 130 }}>
            <Select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              MenuProps={menuProps}
              sx={{
                height: 36,
                fontSize: '14px',
                fontWeight: 400,
                color: '#111827',
                borderRadius: '6px',
                fontFamily: 'Open Sans',
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: '#E5E7EB',
                },
                '&:hover .MuiOutlinedInput-notchedOutline': {
                  borderColor: '#D1D5DB',
                },
                '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                  borderColor: '#409BFF',
                }
              }}
            >
              <MenuItem value="All Status">All Status</MenuItem>
              <MenuItem value="Active">Active</MenuItem>
              <MenuItem value="Pending">Pending</MenuItem>
              <MenuItem value="Inactive">Inactive</MenuItem>
            </Select>
          </FormControl>
        </Box>
      </Box>

      {/* DataGrid */}
      <Box
        sx={{
          width: '100%',
          flexGrow: 1,
          overflowX: 'auto',
          '-ms-overflow-style': 'none',
          'scrollbar-width': 'none',
          '&::-webkit-scrollbar': { display: 'none' }
        }}
      >
        <DataGrid
         onRowClick={(params) => handleEditClick(params.row)}
          rows={filteredUsers}
          columns={columns}
          initialState={{
            pagination: {
              paginationModel: { page: 0, pageSize: 7 },
            },
          }}
          // pageSizeOptions={[5, 7, 10]}
          disableRowSelectionOnClick
          sx={{
            border: 'none',
            fontFamily: 'Open Sans',
            '& .MuiDataGrid-columnHeader': {
              backgroundColor: '#F9FAFB',
              borderBottom: '1px solid #E5E7EB',
            },
            '& .MuiDataGrid-columnHeaderTitle': {
              fontSize: '14px',
              fontWeight: 700,
              color: '#111827',
              fontFamily: 'Open Sans',
            },
            '& .MuiDataGrid-cell': {
              fontSize: '14px',
              color: '#111827',
              fontFamily: 'Open Sans',
              borderBottom: '1px solid #F3F4F6',
            },
            '& .MuiDataGrid-row': {
              cursor: 'pointer',
              '&:hover': {
                backgroundColor: '#EEF2FF',
              },
            },
            '& .MuiDataGrid-columnSeparator': {
              display: 'none',
            },
            '& .MuiDataGrid-footerContainer': {
              borderTop: '1px solid #E5E7EB',
              backgroundColor: '#F9FAFB',
            },
            "& .MuiDataGrid-cell:focus": {
              outline: "none",
            },
            "& .MuiDataGrid-cell:focus-within": {
              outline: "none",
            },
            "& .MuiDataGrid-columnHeader:focus": {
              outline: "none",
            },
            "& .MuiDataGrid-columnHeader:focus-within": {
              outline: "none",
            },
          }}
        />
      </Box>

      {/* Edit User Dialog */}
      <EditUserDialog
      disableScrollLock
        open={editDialogOpen}
        onClose={() => setEditDialogOpen(false)}
        user={userToEdit}
        onSave={handleEditSave}
      />

      {/* Delete Confirmation Dialog */}
      <DeleteContentDialog
      disableScrollLock
        open={deleteDialogOpen}
        onClose={handleDeleteCancel}
        onConfirm={handleDeleteConfirm}
        title="Delete User"
        message={
          userToDelete
            ? `Are you sure you want to delete ${userToDelete.name}? This action cannot be undone.`
            : "Are you sure you want to delete this user?"
        }
      />
    </Box>
  );
};

export default UserListGrid;