import React, { useState } from 'react';
import {
  Dialog,
  Box,
  Typography,
  IconButton,
  Checkbox,
  Button,
  Divider
} from '@mui/material';
import { XMarkIcon } from '@heroicons/react/24/solid';

const MANAGE_COLUMNS = [
  { key: 'role', label: 'Roles' },
  { key: 'read', label: 'Read' },
  { key: 'write', label: 'Write' }
];

const ManageRoleDialog = ({ open, onClose, onSave }) => {
  const [permissions, setPermissions] = useState({
    'Admin': { read: true, write: true },
    'Manager': { read: true, write: false },
    'Staff': { read: true, write: false }
  });

  const handleCheckboxChange = (role, permission) => {
    setPermissions(prev => ({
      ...prev,
      [role]: {
        ...prev[role],
        [permission]: !prev[role][permission]
      }
    }));
  };

  const handleSave = () => {
    onSave(permissions);
    onClose();
  };

  
  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="sm"
      fullWidth
      disableScrollLock
      PaperProps={{
        sx: {
          borderRadius: '12px',
          minWidth: 400
        }
      }}
    >
      {/* Header */}
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          px: 3,
          pt: 3,
          pb: 2
        }}
      >
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '22px',
            fontWeight: 600,
            color: '#111827'
          }}
        >
          Role Permissions
        </Typography>
        <IconButton
          onClick={onClose}
          sx={{
            width: 40,
            height: 40,
            '&:hover': {
              backgroundColor: '#F3F4F6'
            }
          }}
        >
          <XMarkIcon style={{ width: 20, height: 20, color: '#010611ff' }} />
        </IconButton>
      </Box>

      <Divider sx={{ borderColor: '#E5E7EB' }} />

      {/* Table */}
      <Box sx={{ px: 3, py: 3 }}>
        {/* Table Header */}
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '2fr 1fr 1fr',
            alignItems: 'center',
            gap: 0,
            backgroundColor: '#F9FAFB',
            borderRadius: '1px',
            mb: 0.5,
            px: 2,
            py: 1.3,
            border: '1px solid #E5E7EB'
          }}
        >
          {MANAGE_COLUMNS.map((col) => (
            <Typography
              key={col.key}
              sx={{
                fontFamily: 'Open Sans',
                fontSize: '14px',
                fontWeight: 700,
                color: '#374151',
                textAlign: col.key === 'role' ? 'left' : 'center'
              }}
            >
              {col.label}
            </Typography>
          ))}
        </Box>

        {/* Role Rows */}
        {Object.keys(permissions).map((role, idx) => (
          <Box
            key={role}
            sx={{
              display: 'grid',
              gridTemplateColumns: '2fr 1fr 1fr',
              alignItems: 'center',
              background: idx % 2 === 1 ? "#fff" : "#fff",
              borderRadius: 0,
              px: 2,
              py: 1.2,
              borderBottom: idx === Object.keys(permissions).length - 1 ? "none" : "1px solid #E5E7EB",
              borderLeft: '1px solid #E5E7EB',
              borderRight: '1px solid #E5E7EB',
              fontFamily: "Open Sans",
              '&:hover': {
                background: '#D3E0F6C7',
                cursor: 'pointer'
              }
            }}
          >
            <Typography
              sx={{
                fontFamily: 'Open Sans',
                fontSize: '14px',
                fontWeight: 500,
                color: '#111827'
              }}
            >
              {role}
            </Typography>
            {['read', 'write'].map((perm) => (
              <Box sx={{ display: 'flex', justifyContent: 'center' }} key={perm}>
                <Checkbox
                  checked={permissions[role][perm]}
                  onChange={() => handleCheckboxChange(role, perm)}
                  sx={{
                    color: '#D1D5DB',
                    '&.Mui-checked': { color: '#409BFF' },
                    '& .MuiSvgIcon-root': { fontSize: 20 }
                  }}
                />
              </Box>
            ))}
          </Box>
        ))}
      </Box>

      <Divider sx={{ borderColor: '#E5E7EB', mt: 1, mb: 2 }} />

      {/* Actions */}
      <Box
        sx={{
          display: 'flex',
          gap: 2,
          justifyContent: 'flex-end',
          px: 3,
          pb: 3
        }}
      >
        <Button
          onClick={handleSave}
          variant="contained"
          sx={{
            px: 4,
            height: 44,
            borderRadius: '16px',
            backgroundColor: '#409BFF',
            color: '#FFFFFF',
            fontFamily: 'Open Sans',
            fontSize: '14px',
            fontWeight: 600,
            textTransform: 'none',
            boxShadow: 'none',
            '&:hover': {
              backgroundColor: '#2563EB',
              boxShadow: 'none'
            }
          }}
        >
          Update
        </Button>
        <Button
          onClick={onClose}
          variant="outlined"
          sx={{
            px: 4,
            height: 44,
            borderRadius: '16px',
            border: '1px solid #E5E7EB',
            color: '#fff',
            fontFamily: 'Open Sans',
            fontSize: '14px',
            fontWeight: 600,
            backgroundColor: "#FF4141",
            textTransform: 'none',
            '&:hover': {
              borderColor: '#D1D5DB',
              backgroundColor: '#c71f1fff'
            }
          }}
        >
          Cancel
        </Button>
      </Box>
    </Dialog>
  );
};

export default ManageRoleDialog;