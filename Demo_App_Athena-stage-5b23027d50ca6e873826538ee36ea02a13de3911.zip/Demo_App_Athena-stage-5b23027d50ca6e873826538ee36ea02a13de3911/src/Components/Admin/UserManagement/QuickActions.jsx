import React, { useState } from 'react';
import { Box, Typography, Button, Divider } from '@mui/material';
import { 
  UserPlusIcon, 
  UserGroupIcon, 
  EnvelopeIcon, 
  ArrowDownTrayIcon 
} from '@heroicons/react/24/solid';
import ManageRoleDialog from './ManageRoleDialog';
import AddUserDialog from './AddUserDialog';

const QuickActions = ({ onAddUser }) => {
  const [activeButton, setActiveButton] = useState(0);
  const [manageRoleDialogOpen, setManageRoleDialogOpen] = useState(false);
  const [addUserDialogOpen, setAddUserDialogOpen] = useState(false);

  const actionButtons = [
    { 
      icon: UserPlusIcon, 
      label: 'Add New User', 
      onClick: () => {
        setActiveButton(0);
        setAddUserDialogOpen(true);
        console.log('Add New User clicked');
      }
    },
    { 
      icon: UserGroupIcon, 
      label: 'Role Permissions', 
      onClick: () => {
        setActiveButton(1);
        setManageRoleDialogOpen(true);
        console.log('Manage Roles clicked');
      }
    },
    { 
      icon: EnvelopeIcon, 
      label: 'Send Invitations', 
      onClick: () => {
        setActiveButton(2);
        console.log('Send Invitations clicked');
      }
    },
    { 
      icon: ArrowDownTrayIcon, 
      label: 'Export Users', 
      onClick: () => {
        setActiveButton(3);
        console.log('Export Users clicked');
      }
    }
  ];

  const statistics = [
    { label: 'Total Users', value: 30, color: '#111827' },
    { label: 'Active Users', value: 18, color: '#10B981' },
    { label: 'Pending Invites', value: 5, color: '#987805' },
    { label: 'Inactivated', value: 7, color: '#EF4444' }
  ];

  // Handle save permissions
  const handleSavePermissions = (permissions) => {
    console.log('Updated permissions:', permissions);
  };

  // Handle save new user
  const handleSaveUser = (newUser) => {
    if (onAddUser) {
      onAddUser(newUser);
    }
    console.log('New user added:', newUser);
  };

  return (
    <>
      <Box
        sx={{
          backgroundColor: '#FFFFFF',
          border: '1px solid #E5E7EB',
          borderRadius: '8px',
          p: 2.5,
          display: 'flex',
          flexDirection: 'column'
        }}
      >
        {/* Quick Actions Header */}
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '18px',
            fontWeight: '700',
            color: '#111827',
            mb: 2.5
          }}
        >
          Quick Actions
        </Typography>

        {/* Action Buttons */}
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5, mb: 3 }}>
          {actionButtons.map((button, index) => {
            const IconComponent = button.icon;
            const isActive = activeButton === index;
            
            return (
              <Button
                key={index}
                onClick={button.onClick}
                startIcon={
                  <IconComponent 
                    style={{ 
                      width: 20, 
                      height: 20, 
                      color: isActive ? '#FFFFFF' : '#6B7280' 
                    }} 
                  />
                }
                sx={{
                  width: '100%',
                  backgroundColor: isActive ? '#409BFF' : '#F3F4F6',
                  color: isActive ? '#FFFFFF' : '#374151',
                  textTransform: 'none',
                  fontFamily: 'Open Sans',
                  fontSize: '16px',
                  fontWeight: '500',
                  py: 1.25,
                  px: 2,
                  borderRadius: '6px',
                  justifyContent: 'flex-start',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease-in-out',
                  '&:hover': {
                    backgroundColor: isActive ? '#2563EB' : '#E5E7EB',
                    transform: 'translateY(-1px)',
                    boxShadow: isActive 
                      ? '0 4px 6px rgba(59, 130, 246, 0.3)' 
                      : '0 2px 4px rgba(0, 0, 0, 0.1)',
                  },
                  '&:active': {
                    transform: 'translateY(0)',
                    boxShadow: 'none',
                  }
                }}
              >
                {button.label}
              </Button>
            );
          })}
        </Box>

        {/* Divider */}
        <Divider sx={{ mb: 2, borderColor: '#E5E7EB' }} />

        {/* User Statistics Header */}
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '16px',
            fontWeight: '700',
            color: '#111827',
            mb: 2.5
          }}
        >
          User Statistics
        </Typography>

        {/* Statistics List */}
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {statistics.map((stat, index) => (
            <Box
              key={index}
              sx={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}
            >
              <Typography
                sx={{
                  fontFamily: 'Open Sans',
                  fontSize: '14px',
                  fontWeight: '600',
                  color: '#4B5563'
                }}
              >
                {stat.label}
              </Typography>
              <Typography
                sx={{
                  fontFamily: 'Open Sans',
                  fontSize: '16px',
                  fontWeight: '700',
                  color: stat.color
                }}
              >
                {stat.value}
              </Typography>
            </Box>
          ))}
        </Box>
      </Box>

      {/* Add User Dialog */}
      <AddUserDialog
        open={addUserDialogOpen}
        disableScrollLock
        onClose={() => setAddUserDialogOpen(false)}
        onSave={handleSaveUser}
      />

      {/* Manage Role Dialog */}
      <ManageRoleDialog
        open={manageRoleDialogOpen}
        disableScrollLock
        onClose={() => setManageRoleDialogOpen(false)}
        onSave={handleSavePermissions}
      />
    </>
  );
};

export default QuickActions;
