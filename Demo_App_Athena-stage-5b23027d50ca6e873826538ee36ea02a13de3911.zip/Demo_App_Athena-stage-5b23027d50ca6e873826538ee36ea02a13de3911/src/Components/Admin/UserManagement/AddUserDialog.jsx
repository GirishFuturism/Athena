import React, { useState } from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import {
  Dialog,
  DialogContent,
  Box,
  Typography,
  TextField,
  Select,
  MenuItem,
  FormControl,
  Button,
  Avatar,
  IconButton,
  FormHelperText
} from '@mui/material';
import { XMarkIcon, CameraIcon } from '@heroicons/react/24/solid';

// Validation Schema
const validationSchema = Yup.object({
  name: Yup.string()
    .min(2, 'Name must be at least 2 characters')
    .max(50, 'Name must be less than 50 characters')
    .required('Full name is required'),
  email: Yup.string()
    .email('Invalid email address')
    .required('Email address is required'),
  phone: Yup.string()
    .matches(
      /^\+1 \(\d{3}\) \d{3}-\d{4}$/,
      'Phone number must be in format +1 (555) 123-4567'
    )
    .required('Phone number is required'),
  role: Yup.string()
    .oneOf(['Admin', 'Manager', 'Staff'], 'Invalid role selected')
    .required('Role is required'),
  avatar: Yup.string()
});

const AddUserDialog = ({ open, onClose, onSave }) => {
  const [avatarPreview, setAvatarPreview] = useState(null);

  // Formik initialization
  const formik = useFormik({
    initialValues: {
      name: '',
      email: '',
      phone: '',
      role: 'Admin',
      avatar: ''
    },
    validationSchema: validationSchema,
    onSubmit: (values) => {
      // Create new user object
      const newUser = {
        id: Date.now(),
        name: values.name,
        email: values.email,
        phone: values.phone,
        role: values.role,
        status: 'Active',
        avatar: avatarPreview || 'https://randomuser.me/api/portraits/lego/1.jpg'
      };

      onSave(newUser);
      handleCancel();
    },
  });

  // Handle phone number formatting (US format)
// Handle phone number formatting (US format with +1)
const formatPhoneNumber = (value) => {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '').substring(0, 10);
  
  const len = digits.length;
  
  if (len === 0) return '';
  if (len < 4) return `+1 (${digits}`;
  if (len < 7) return `+1 (${digits.substring(0,3)}) ${digits.substring(3)}`;
  return `+1 (${digits.substring(0,3)}) ${digits.substring(3,6)}-${digits.substring(6)}`;
};

const handlePhoneChange = (e) => {
  const formatted = formatPhoneNumber(e.target.value);
  formik.setFieldValue('phone', formatted);
};




  // const handlePhoneChange = (e) => {
  //   const formatted = formatPhoneNumber(e.target.value);
  //   formik.setFieldValue('phone', formatted);
  // };

  // Handle avatar upload
  const handleAvatarUpload = (event) => {
    const file = event.target.files[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result);
        formik.setFieldValue('avatar', reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle cancel
  const handleCancel = () => {
    formik.resetForm();
    setAvatarPreview(null);
    onClose();
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="sm"
      fullWidth
      disableScrollLock
    >
      {/* Header */}
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          p: 3,
          pb: 2
        }}
      >
        <Typography
          sx={{
            fontFamily: 'Open Sans',
            fontSize: '22px',
            fontWeight: 600,
            color: '#111827'
          }}
        >
          Add User
        </Typography>
        <IconButton
          onClick={handleCancel}
          sx={{
            width: 40,
            height: 40,
            '&:hover': {
              backgroundColor: '#F3F4F6'
            }
          }}
        >
          <XMarkIcon style={{ width: 24, height: 24, color: '#000' }} />
        </IconButton>
      </Box>
       
      {/* Tab - User Info */}
      <Box sx={{ px: 3 }}>
        <Box
          sx={{
            display: 'inline-block',
            pb: 1,
            borderBottom: '2px solid #409BFF'
          }}
        >
          <Typography
            sx={{
              fontFamily: 'Open Sans',
              fontSize: '14px',
              fontWeight: 700,
              color: '#409BFF'
            }}
          >
            User Info
          </Typography>
        </Box>
      </Box>

      <DialogContent sx={{ p: 3, pt: 2 }}>
        <form onSubmit={formik.handleSubmit}>
          {/* Avatar Section */}
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 2,
              mb: 3
            }}
          >
            <Box sx={{ position: 'relative' }}>
              <Avatar
                src={avatarPreview || ''}
                alt={formik.values.name}
                sx={{
                  width: 64,
                  height: 64,
                  backgroundColor: '#E5E7EB',
                  fontSize: '24px',
                  fontWeight: 600
                }}
              >
                {!avatarPreview && formik.values.name ? formik.values.name.charAt(0).toUpperCase() : ''}
              </Avatar>
              <input
                accept="image/*"
                style={{ display: 'none' }}
                id="avatar-upload"
                type="file"
                onChange={handleAvatarUpload}
              />
              <label htmlFor="avatar-upload">
                <Box
                  sx={{
                    position: 'absolute',
                    bottom: 0,
                    right: 0,
                    width: 24,
                    height: 24,
                    borderRadius: '50%',
                    backgroundColor: '#409BFF',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    border: '2px solid #FFFFFF',
                    cursor: 'pointer',
                    '&:hover': {
                      backgroundColor: '#2563EB'
                    }
                  }}
                >
                  <CameraIcon style={{ width: 12, height: 12, color: '#FFFFFF' }} />
                </Box>
              </label>
            </Box>
            <Box>
              <Typography
                sx={{
                  fontFamily: 'Open Sans',
                  fontSize: '18px',
                  fontWeight: 600,
                  color: '#111827'
                }}
              >
                {formik.values.name || 'User Name'}
              </Typography>
              <Typography
                sx={{
                  fontFamily: 'Open Sans',
                  fontSize: '14px',
                  fontWeight: 400,
                  color: '#6B7280'
                }}
              >
                {formik.values.role}
              </Typography>
            </Box>
          </Box>

          {/* Full Name Field */}
          <Box sx={{ mb: 2.5 }}>
            <Typography
              sx={{
                fontFamily: 'Open Sans',
                fontSize: '14px',
                fontWeight: 600,
                color: '#374151',
                mb: 1
              }}
            >
              Full Name <span style={{ color: '#EF4444' }}>*</span>
            </Typography>
            <TextField
              fullWidth
              name="name"
              value={formik.values.name}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              error={formik.touched.name && Boolean(formik.errors.name)}
              placeholder="Enter full name"
              sx={{
                '& .MuiOutlinedInput-root': {
                  height: 44,
                  fontSize: '14px',
                  fontFamily: 'Open Sans',
                  borderRadius: '8px',
                  backgroundColor: '#fff',
                  '& fieldset': {
                    borderColor: formik.touched.name && formik.errors.name ? '#EF4444' : '#E5E7EB'
                  },
                  '&:hover fieldset': {
                    borderColor: formik.touched.name && formik.errors.name ? '#EF4444' : '#D1D5DB'
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: formik.touched.name && formik.errors.name ? '#EF4444' : '#409BFF'
                  }
                },
                '& .MuiOutlinedInput-input': {
                  color: '#111827',
                  '&::placeholder': {
                    color: '#9CA3AF',
                    opacity: 1
                  }
                }
              }}
            />
            {formik.touched.name && formik.errors.name && (
              <FormHelperText error sx={{ fontFamily: 'Open Sans', fontSize: '12px', mt: 0.5 }}>
                {formik.errors.name}
              </FormHelperText>
            )}
          </Box>

          {/* Email Address Field */}
          <Box sx={{ mb: 2.5 }}>
            <Typography
              sx={{
                fontFamily: 'Open Sans',
                fontSize: '14px',
                fontWeight: 600,
                color: '#374151',
                mb: 1
              }}
            >
              Email Address <span style={{ color: '#EF4444' }}>*</span>
            </Typography>
            <TextField
              fullWidth
              type="email"
              name="email"
              value={formik.values.email}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              error={formik.touched.email && Boolean(formik.errors.email)}
              placeholder="Enter email address"
              sx={{
                '& .MuiOutlinedInput-root': {
                  height: 44,
                  fontSize: '14px',
                  fontFamily: 'Open Sans',
                  borderRadius: '8px',
                  backgroundColor: '#fff',
                  '& fieldset': {
                    borderColor: formik.touched.email && formik.errors.email ? '#EF4444' : '#E5E7EB'
                  },
                  '&:hover fieldset': {
                    borderColor: formik.touched.email && formik.errors.email ? '#EF4444' : '#D1D5DB'
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: formik.touched.email && formik.errors.email ? '#EF4444' : '#409BFF'
                  }
                },
                '& .MuiOutlinedInput-input': {
                  color: '#111827',
                  '&::placeholder': {
                    color: '#9CA3AF',
                    opacity: 1
                  }
                }
              }}
            />
            {formik.touched.email && formik.errors.email && (
              <FormHelperText error sx={{ fontFamily: 'Open Sans', fontSize: '12px', mt: 0.5 }}>
                {formik.errors.email}
              </FormHelperText>
            )}
          </Box>

          {/* Phone Number Field */}
          <Box sx={{ mb: 2.5 }}>
            <Typography
              sx={{
                fontFamily: 'Open Sans',
                fontSize: '14px',
                fontWeight: 600,
                color: '#374151',
                mb: 1
              }}
            >
              Phone Number <span style={{ color: '#EF4444' }}>*</span>
            </Typography>
           <TextField
  fullWidth
  name="phone"
  value={formik.values.phone}
  onChange={handlePhoneChange}
  onBlur={formik.handleBlur}
  error={formik.touched.phone && Boolean(formik.errors.phone)}
  placeholder="+1 (555) 123-4567"
  sx={{
    '& .MuiOutlinedInput-root': {
      height: 44,
      fontSize: '14px',
      fontFamily: 'Open Sans',
      borderRadius: '8px',
      backgroundColor: '#fff',
      '& fieldset': {
        borderColor: formik.touched.phone && formik.errors.phone ? '#EF4444' : '#E5E7EB'
      },
      '&:hover fieldset': {
        borderColor: formik.touched.phone && formik.errors.phone ? '#EF4444' : '#D1D5DB'
      },
      '&.Mui-focused fieldset': {
        borderColor: formik.touched.phone && formik.errors.phone ? '#EF4444' : '#409BFF'
      }
    },
    '& .MuiOutlinedInput-input': {
      color: '#111827',
      '&::placeholder': {
        color: '#9CA3AF',
        opacity: 1
      }
    }
  }}
/>

            {formik.touched.phone && formik.errors.phone && (
              <FormHelperText error sx={{ fontFamily: 'Open Sans', fontSize: '12px', mt: 0.5 }}>
                {formik.errors.phone}
              </FormHelperText>
            )}
          </Box>

          {/* Role Field */}
          <Box sx={{ mb: 3 }}>
            <Typography
              sx={{
                fontFamily: 'Open Sans',
                fontSize: '14px',
                fontWeight: 600,
                color: '#374151',
                mb: 1
              }}
            >
              Role <span style={{ color: '#EF4444' }}>*</span>
            </Typography>
            <FormControl fullWidth error={formik.touched.role && Boolean(formik.errors.role)}>
              <Select
                name="role"
                value={formik.values.role}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                sx={{
                  height: 44,
                  fontSize: '14px',
                  fontFamily: 'Open Sans',
                  borderRadius: '8px',
                  backgroundColor: '#fff',
                  color: '#111827',
                  '& .MuiOutlinedInput-notchedOutline': {
                    borderColor: formik.touched.role && formik.errors.role ? '#EF4444' : '#E5E7EB'
                  },
                  '&:hover .MuiOutlinedInput-notchedOutline': {
                    borderColor: formik.touched.role && formik.errors.role ? '#EF4444' : '#D1D5DB'
                  },
                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                    borderColor: formik.touched.role && formik.errors.role ? '#EF4444' : '#409BFF'
                  }
                }}
              >
                <MenuItem value="Admin">Admin</MenuItem>
                <MenuItem value="Manager">Manager</MenuItem>
                <MenuItem value="Staff">Staff</MenuItem>
              </Select>
              {formik.touched.role && formik.errors.role && (
                <FormHelperText sx={{ fontFamily: 'Open Sans', fontSize: '12px', mt: 0.5 }}>
                  {formik.errors.role}
                </FormHelperText>
              )}
            </FormControl>
          </Box>

          {/* Action Buttons */}
          <Box
            sx={{
              display: 'flex',
              gap: 2,
              justifyContent: 'flex-end',
              pt: 1
            }}
          >
            <Button
              type="submit"
              variant="contained"
              sx={{
                px: 5,
                height: 44,
                borderRadius: '16px',
                backgroundColor: '#409BFF',
                color: '#FFFFFF',
                fontFamily: 'Open Sans',
                fontSize: '14px',
                fontWeight: 600,
                textTransform: 'none',
                boxShadow: 'none',
                '&:hover': {
                  backgroundColor: '#2563EB',
                  boxShadow: 'none'
                }
              }}
            >
              Save
            </Button>

            <Button
              onClick={handleCancel}
              variant="outlined"
              type="button"
              sx={{
                px: 4,
                height: 44,
                borderRadius: '16px',
                border: '1px solid #E5E7EB',
                fontFamily: 'Open Sans',
                backgroundColor: '#FF4141',
                color: '#fff',
                fontSize: '14px',
                fontWeight: 600,
                textTransform: 'none',
                '&:hover': {
                  backgroundColor: '#DC2626',
                  border: '1px solid #DC2626'
                }
              }}
            >
              Cancel
            </Button>
          </Box>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddUserDialog;
