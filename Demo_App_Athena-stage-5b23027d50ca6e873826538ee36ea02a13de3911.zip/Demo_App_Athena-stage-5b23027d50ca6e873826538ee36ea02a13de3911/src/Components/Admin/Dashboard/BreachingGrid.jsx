import React, { useState } from "react";
import { Box, Typography, IconButton, LinearProgress, Menu, MenuItem } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import RefreshIcon from "@mui/icons-material/Refresh";
import NorthEastIcon from "@mui/icons-material/NorthEast";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import { useNavigate } from "react-router-dom";

const initialRows = [
  { id: 1, summary: "System not opening", slaTime: "-48:02" },
  { id: 2, summary: "4wtre", slaTime: "-27:43" },
  { id: 3, summary: "Azure Access Issue", slaTime: "-33:04" },
  { id: 4, summary: "Can not log into Outlook online", slaTime: "-33:07" },
  { id: 5, summary: "Can't login to Outlook", slaTime: "-48:50" },
  { id: 6, summary: "Excel startup error.", slaTime: "-33:04" },
];

const BreachingGrid = () => {
  const [rows, setRows] = useState(initialRows);
  const [loading, setLoading] = useState(false);
  const [key, setKey] = useState(0);
  const [anchorEl, setAnchorEl] = useState(null);
  const navigate = useNavigate();

  const open = Boolean(anchorEl);

  const columns = [
    {
      field: "summary",
      headerName: "Summary",
      flex: 1,
    },
    {
      field: "slaTime",
      headerName: "SLA Time Left",
      flex: 0.6,
      sortable: false,
      renderCell: (params) => {
        const getSLAData = (time) => {
          const hours = Math.abs(parseInt(time.split(":")[0]));

          if (hours >= 40) {
            return {
              percent: Math.min(hours + 60, 100),
              color: "#FFBFB1",
              bgColor: "#F3F4F6",
              textColor: "#FF0202",
            };
          } else if (hours >= 30) {
            return {
              percent: hours + 20,
              color: "#FFCE9D",
              bgColor: "#F3F4F6",
              textColor: "#C56A032",
            };
          } else {
            return {
              percent: hours + 30,
              color: "#FFCE9D",
              bgColor: "#F3F4F6",
              textColor: "#C56A03",
            };
          }
        };

        const slaData = getSLAData(params.value);

        return (
          <Box sx={{ width: "100%", position: "relative", pt: 1.5 }}>
            <LinearProgress
              variant="determinate"
              value={slaData.percent}
              sx={{
                height: 22,
                borderRadius: "6px",
                backgroundColor: slaData.bgColor,
                "& .MuiLinearProgress-bar": {
                  backgroundColor: slaData.color,
                  borderRadius: "6px",
                },
              }}
            />
            <Typography
              sx={{
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                fontSize: "12px",
                fontWeight: 700,
                color: slaData.textColor,
                fontFamily: "Open Sans",
                pt: 1.5,
              }}
            >
              {params.value}
            </Typography>
          </Box>
        );
      },
    },
  ];

  const handleRefresh = async () => {
    setLoading(true);

    try {
      setTimeout(() => {
        setRows([...initialRows]);
        setKey((prev) => prev + 1);
        setLoading(false);
      }, 300);
    } catch (error) {
      console.error("Error refreshing data:", error);
      setLoading(false);
    }
  };

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleOpenList = () => {
    handleMenuClose();
    navigate("/ticket-management");
  };

  const handleExportToCSV = () => {
    handleMenuClose();

    // Prepare CSV data
    const headers = ["ID", "Summary", "SLA Time Left"];
    const csvRows = [
      headers.join(","),
      ...rows.map((row) => 
        [row.id, `"${row.summary}"`, row.slaTime].join(",")
      ),
    ];

    const csvString = csvRows.join("\n");

    // Create Blob and download
    const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `breaching-tickets-${new Date().toISOString().split("T")[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    // Show success message (optional)
    console.log(`Downloaded ${rows.length} tickets to CSV successfully!`);
  };

  return (
    <Box
      sx={{
        background: "#fff",
        borderRadius: "12px",
        p: 0,
        boxShadow: "0 6px 20px #EEF3FE70",
        width: "100%",
        display: "flex",
        flexDirection: "column",
        position: "relative",
        border: "1px solid #E5E7EB",
         transition: 'all 0.3s ease-in-out',
        '&:hover': {
                        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.4)' ,
                        // transform:  'translateY(-2px)'
                      }
      }}
    >
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          pt: 2.5,
          px: 2.5,
        }}
      >
        <Typography
          sx={{
            fontSize: "16px",
            fontWeight: 600,
            fontFamily: "Open Sans",
            color: "#4390F8",
          }}
        >
          Tickets Breaching SLA
        </Typography>

        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <IconButton
            onClick={handleRefresh}
            disabled={loading}
            sx={{
              width: 32,
              height: 32,
              borderRadius: "8px",
              background: loading ? "#93c5fd" : "#4390F8",
              "&:hover": { background: "#3380e8" },
              transition: "transform 0.3s ease",
              animation: loading ? "spin 1s linear infinite" : "none",
              "@keyframes spin": {
                "0%": { transform: "rotate(0deg)" },
                "100%": { transform: "rotate(360deg)" },
              },
            }}
          >
            <RefreshIcon sx={{ color: "#fff", fontSize: 20 }} />
          </IconButton>
          <IconButton
            sx={{
              width: 32,
              height: 32,
              borderRadius: "8px",
              background: "#4390F8",
              "&:hover": { background: "#3380e8" },
            }}
          >
            <NorthEastIcon sx={{ color: "#fff", fontSize: 20 }} />
          </IconButton>
          <IconButton
            onClick={handleMenuOpen}
            sx={{
              width: 32,
              height: 32,
              borderRadius: "8px",
              background: "#4390F8",
              "&:hover": { background: "#3380e8" },
            }}
          >
            <MoreHorizIcon sx={{ color: "#fff", fontSize: 20 }} />
          </IconButton>
        </Box>
      </Box>

      {/* Context Menu */}
      <Menu
        anchorEl={anchorEl}
        open={open}
        onClose={handleMenuClose}
        disableScrollLock={true}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        PaperProps={{
          sx: {
            borderRadius: "8px",
            boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
            minWidth: 180,
            mt: 1,
            maxHeight: 300,
            '&::-webkit-scrollbar': { display: 'none' },
            '-ms-overflow-style': 'none',
            'scrollbar-width': 'none',
          },
        }}
      >
        <MenuItem
          onClick={handleOpenList}
          sx={{
            fontFamily: "Open Sans",
            fontSize: "14px",
            py: 1.5,
            "&:hover": {
              background: "#EEF2FF",
            },
          }}
        >
          Open List
        </MenuItem>
        <MenuItem
          onClick={handleExportToCSV}
          sx={{
            fontFamily: "Open Sans",
            fontSize: "14px",
            py: 1.5,
            "&:hover": {
              background: "#EEF2FF",
            },
          }}
        >
          Export to CSV
        </MenuItem>
      </Menu>

      <Box sx={{ width: "100%" }}>
        <DataGrid
          key={key}
          rows={rows}
          columns={columns}
          checkboxSelection
          disableRowSelectionOnClick
          hideFooter
          autoHeight
          loading={loading}
          sx={{
            border: "none",
            fontFamily: "Open Sans",
            "& .MuiDataGrid-columnHeaders": {
              background: "#FAFAFA",
            },
            "& .MuiDataGrid-columnHeaderTitle": {
              fontSize: "14px",
              fontWeight: 600,
              color: "#1C1C1E",
              fontFamily: "Open Sans",
            },
            "& .MuiDataGrid-cell": {
              fontSize: "14px",
              fontWeight: 400,
              fontFamily: "Open Sans",
              color: "#000000",
            },
            "& .MuiDataGrid-row": {
              cursor: "pointer",
              "&:hover": {
                background: "#EEF2FF",
              },
              "&.Mui-selected": {
                background: "#E3F2FD !important",
                "&:hover": {
                  background: "#E3F2FD !important",
                },
              },
            },
            "& .MuiCheckbox-root": {
              color: "#D1D5DB",
              "&.Mui-checked": {
                color: "#4390F8",
              },
            },
            "& .MuiDataGrid-columnSeparator": {
              display: "none",
            },
            "& .MuiDataGrid-cell:focus": {
              outline: "none",
            },
            "& .MuiDataGrid-cell:focus-within": {
              outline: "none",
            },
            "& .MuiDataGrid-columnHeader:focus": {
              outline: "none",
            },
            "& .MuiDataGrid-columnHeader:focus-within": {
              outline: "none",
            },
          }}
        />
      </Box>
    </Box>
  );
};

export default BreachingGrid;
