import React from "react";
import { PieChart, Pie, Cell, Tooltip } from "recharts";
import { Box, Typography } from "@mui/material";

// Keep your original percent
const PERCENT = 92;

// Original geometry preserved
const CHART_WIDTH = 300;
const CHART_HEIGHT = 212;
const cx = 150;
const cy = 148;
const iR = 86;
const oR = 110;

// Original color segments
const chartData = [
  { value: 33, color: "#B2F6E6" },
  { value: 33, color: "#59ECBE" },
  { value: 33, color: "#14D397" },
];

const RADIAN = Math.PI / 180;

function renderNeedle({ value, cx, cy, iR, oR }) {
  const total = 100;
  const angle = 180 * (1 - value / total);
  const length = (iR + oR) / 2 + 6;
  const sin = Math.sin(-RADIAN * angle);
  const cos = Math.cos(-RADIAN * angle);
  const r = 8;

  const x0 = cx;
  const y0 = cy;
  const xba = x0 + r * sin;
  const yba = y0 - r * cos;
  const xbb = x0 - r * sin;
  const ybb = y0 + r * cos;
  const xp = x0 + length * cos;
  const yp = y0 + length * sin;

  return (
    <>
      <circle cx={x0} cy={y0} r={r} fill="#221A2C" />
      <path d={`M${xba} ${yba}L${xbb} ${ybb} L${xp} ${yp} Z`} fill="#221A2C" stroke="none" />
    </>
  );
}

// Custom Tooltip Component
// Custom Tooltip Component (MUI-like)
const CustomTooltip = ({ active, payload }) => {
  if (active && payload && payload.length) {
    return (
      <Box
        sx={{
          bgcolor: "#fff",
          color: "#1a1a1a",
          px: 2,
          py: 1.2,
          borderRadius: "8px",
          boxShadow: 3,
          fontFamily: "Open Sans",
          fontSize: 14,
          fontWeight: 500,
          minWidth: 120,
          pointerEvents: 'all', // MUI Tooltip feels responsive to mouse
        }}
      >
        <Typography
          sx={{
            fontSize: 15,
            fontWeight: 700,
            color: "#409BFF",
            lineHeight: 1,
            mb: 0.5,
            fontFamily: "Open Sans",
          }}
        >
          Customer Satisfaction
        </Typography>
        <Typography
          sx={{
            fontSize: 20,
            fontWeight: 700,
            color: "#10B981",
            fontFamily: "Open Sans",
            letterSpacing: 0.1,
          }}
        >
          {PERCENT}%
        </Typography>
        {/* Optional: Show a label or extra context */}
        <Typography
          sx={{
            fontSize: 13,
            fontWeight: 400,
            color: "#6B7280",
            mt: 0.2,
            fontFamily: "Open Sans",
          }}
        >
          CSAT Rating
        </Typography>
      </Box>
    );
  }
  return null;
};


export default function CustomerSatisfactionGauge() {
  return (
    <Box
      sx={{
        width: "100%",
        minWidth: 0,
        background: "#fff",
        borderRadius: "12px",
        boxShadow: "0 6px 20px #EEF3FE70",
        border: "1px solid #E5E7EB",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        p: 0,
         transition: 'all 0.3s ease-in-out',
        '&:hover': {
                        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.4)' ,
                        // transform:  'translateY(-2px)'
                      }
      }}
    >
      {/* Title */}
      <Typography
        sx={{
          fontFamily: "Open Sans",
          fontWeight: 600,
          fontSize: 16,
          color: "#409BFF",
          alignSelf: "flex-start",
          mt: 3,
          mb: 1,
          ml: 2.5,
        }}
      >
        Customer Satisfaction
      </Typography>

      {/* Chart wrapper */}
      <Box
        sx={{
          width: CHART_WIDTH,
          height: CHART_HEIGHT,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          overflow: "hidden",
          '& *:focus': {
            outline: 'none !important',
          },
          '& svg': {
            outline: 'none !important',
          },
          userSelect: 'none',
          WebkitUserSelect: 'none',
          MozUserSelect: 'none',
          msUserSelect: 'none',
        }}
        onMouseDown={(e) => e.preventDefault()}
      >
        <PieChart width={CHART_WIDTH} height={CHART_HEIGHT}>
          <Pie
            dataKey="value"
            startAngle={180}
            endAngle={0}
            data={chartData}
            cx={cx}
            cy={cy}
            innerRadius={iR}
            outerRadius={oR}
            stroke="none"
            isAnimationActive={false}
          >
            {chartData.map((entry, i) => (
              <Cell key={i} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip content={<CustomTooltip />} cursor={false} />
          {renderNeedle({
            value: PERCENT,
            cx,
            cy,
            iR,
            oR,
          })}
        </PieChart>
      </Box>

      {/* Percentage */}
      <Typography
        sx={{
          fontFamily: "Open Sans",
          fontWeight: 700,
          fontSize: 35,
          color: "#10B981",
          textAlign: "center",
          lineHeight: 1.15,
          mt: 1,
          mb: 0.4,
          userSelect: 'none',
        }}
      >
        {PERCENT}%
      </Typography>

      {/* Label */}
      <Typography
        sx={{
          fontFamily: "Open Sans",
          fontWeight: 600,
          color: "#4B5563",
          fontSize: 18,
          mt: 0.5,
          mb: 1.5,
          userSelect: 'none',
        }}
      >
        CSAT Rating
      </Typography>

      {/* Smiley Icon */}
      <Box 
        sx={{ 
          mb: 2,
          '& svg': {
            outline: 'none !important',
          },
          userSelect: 'none',
        }}
      >
        <svg width="40" height="36" viewBox="0 0 34 34">
          <circle cx="17" cy="17" r="17" fill="#23DF9C" />
          <circle cx="12.5" cy="14" r="1.9" fill="#fff" />
          <circle cx="21.5" cy="14" r="1.9" fill="#fff" />
          <path
            d="M12.8 21q4.1 2.1 8.2 0"
            stroke="#fff"
            strokeWidth="2"
            fill="none"
            strokeLinecap="round"
          />
        </svg>
      </Box>
    </Box>
  );
}
