import React, { useState, useMemo } from "react";
import {
  Box,
  Typography,
  Select,
  MenuItem,
  FormControl,
  OutlinedInput,
} from "@mui/material";
import { PieChart } from "@mui/x-charts/PieChart";

// Sample overview data expanded with technician, priority, client
const overviewData = {
  "7": [
    { id: 1, value: 142, label: "Open", color: "#3B82F6", technician: "tech1", priority: "critical", client: "client1" },
    { id: 2, value: 89, label: "In Progress", color: "#F59E0B", technician: "tech2", priority: "high", client: "client2" },
    { id: 3, value: 234, label: "Closed", color: "#10B981", technician: "tech1", priority: "medium", client: "client2" },
  ],
  "30": [
    { id: 1, value: 320, label: "Open", color: "#3B82F6", technician: "tech1", priority: "critical", client: "client1" },
    { id: 2, value: 180, label: "In Progress", color: "#F59E0B", technician: "tech2", priority: "low", client: "client1" },
    { id: 3, value: 450, label: "Closed", color: "#10B981", technician: "tech2", priority: "high", client: "client2" },
  ],
};

// Unique dropdown values from data
const technicianOptions = [
  { value: "all", label: "All Agents" },
  { value: "tech1", label: "Agent 1" },
  { value: "tech2", label: "Agent 2" },
];
const priorityOptions = [
  { value: "all", label: "All Priorities" },
  { value: "critical", label: "Critical" },
  { value: "high", label: "High" },
  { value: "medium", label: "Medium" },
  { value: "low", label: "Low" },
];
const clientOptions = [
  { value: "all", label: "All Clients" },
  { value: "client1", label: "Client 1" },
  { value: "client2", label: "Client 2" },
];
const periodOptions = [
  { value: "7", label: "Last 7 days" },
  { value: "30", label: "Last 30 days" },
];

const OverviewPie = () => {
  const [period, setPeriod] = useState("7");
  const [technician, setTechnician] = useState("all");
  const [priority, setPriority] = useState("all");
  const [client, setClient] = useState("all");

  // Filtered pie chart data based on dropdowns
  const data = useMemo(() => {
    return overviewData[period]
      .filter(d =>
        (technician === "all" || d.technician === technician) &&
        (priority === "all" || d.priority === priority) &&
        (client === "all" || d.client === client)
      )
      .map(({ id, value, label, color }) => ({ id, value, label, color }));
  }, [period, technician, priority, client]);

  // ✅ Calculate total for percentage
  const total = useMemo(() => {
    return data.reduce((sum, item) => sum + item.value, 0);
  }, [data]);

  // Common MenuProps to hide scrollbar and disable scroll lock
  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

  return (
    <Box
      sx={{
        background: "#fff",
        borderRadius: "12px",
        boxShadow: "0 6px 20px #EEF3FE70",
        display: "flex",
        flexDirection: "column",
        position: "relative",
        border: "1px solid #E5E7EB",
        transition: 'all 0.3s ease-in-out',
        '&:hover': {
                        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.4)' ,
                        // transform:  'translateY(-2px)'
                      }
      }}
    >
      {/* Header with Title and Filters */}
      <Box sx={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        pt: 2.5, pb: 2, px: 2.5,
      }}>
        <Typography sx={{
          fontSize: "16px",
          fontWeight: 600,
          fontFamily: "Open Sans",
          color: "#4390F8",
        }}>
          Tickets Overview
        </Typography>
        <Box sx={{
          display: "flex",
          alignItems: "center",
          gap: 1.5,
          flexWrap: "wrap"
        }}>
          {/* Technician */}
          <FormControl variant="outlined" size="small" sx={{ minWidth: 140, ".MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" } }}>
            <Select
              value={technician}
              onChange={e => setTechnician(e.target.value)}
              input={<OutlinedInput />}
              MenuProps={menuProps}
              sx={{ height: 36, fontSize: "14px", fontWeight: 400, color: "#232323", borderRadius: "8px" }}
            >
              {technicianOptions.map(opt => (
                <MenuItem key={opt.value} value={opt.value}>{opt.label}</MenuItem>
              ))}
            </Select>
          </FormControl>
          {/* Priority */}
          <FormControl variant="outlined" size="small" sx={{ minWidth: 130, ".MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" } }}>
            <Select
              value={priority}
              onChange={e => setPriority(e.target.value)}
              input={<OutlinedInput />}
              MenuProps={menuProps}
              sx={{ height: 36, fontSize: "14px", fontWeight: 400, color: "#232323", borderRadius: "8px" }}
            >
              {priorityOptions.map(opt => (
                <MenuItem key={opt.value} value={opt.value}>{opt.label}</MenuItem>
              ))}
            </Select>
          </FormControl>
          {/* Client */}
          <FormControl variant="outlined" size="small" sx={{ minWidth: 120, ".MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" } }}>
            <Select
              value={client}
              onChange={e => setClient(e.target.value)}
              input={<OutlinedInput />}
              MenuProps={menuProps}
              sx={{ height: 36, fontSize: "14px", fontWeight: 400, color: "#232323", borderRadius: "8px" }}
            >
              {clientOptions.map(opt => (
                <MenuItem key={opt.value} value={opt.value}>{opt.label}</MenuItem>
              ))}
            </Select>
          </FormControl>
          {/* Period */}
          <FormControl variant="outlined" size="small" sx={{ minWidth: 120, ".MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" } }}>
            <Select
              value={period}
              onChange={e => setPeriod(e.target.value)}
              input={<OutlinedInput />}
              MenuProps={menuProps}
              sx={{ height: 36, fontSize: "14px", fontWeight: 400, color: "#232323", borderRadius: "8px" }}
            >
              {periodOptions.map(opt => (
                <MenuItem key={opt.value} value={opt.value}>{opt.label}</MenuItem>
              ))}
            </Select>
          </FormControl>
        </Box>
      </Box>

      {/* Donut Chart */}
      <Box
        sx={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          py: 3,
          position: "relative",
        }}
      >
        <PieChart
          series={[
            {
              data: data.map(({ id, value, label, color }) => ({
                id,
                value,
                label,
                color,
              })),
              highlightScope: { fade: "global", highlighted: "item" },
              innerRadius: 80,
              outerRadius: 120,
              paddingAngle: 2,
              cornerRadius: 4,
        
              valueFormatter: (value) => {
                const percentage = ((value.value / total) * 100).toFixed(1);
                return `${value.value} (${percentage}%)`;
              },
            },
          ]}
          width={300}
          height={300}
          sx={{
            ".MuiChartsLegend-root": { display: "none !important" },
          }}
          slotProps={{
            legend: { hidden: true },
          }}
        />

        {/* Custom Labels positioned around the donut */}
        {data.map((item, idx) => {
          const percentage = ((item.value / total) * 100).toFixed(1);
          return (
            <Box
              key={item.id}
              sx={{
                position: "absolute",
                top: ["30%", "60%", "40%"][idx % 3],
                right: ["23%", "23%", null][idx % 3],
                left: idx === 2 ? "20%" : undefined,
                bottom: idx === 1 ? "9%" : undefined,
                display: "flex",
                alignItems: "center",
                flexDirection: idx === 2 ? "row-reverse" : "row",
              }}
            >
              <Typography
                sx={{
                  fontSize: "14px",
                  fontWeight: 600,
                  color: "#1C1C1E",
                  fontFamily: "Open Sans",
                }}
              >
                {item.label}: {item.value}
              </Typography>
            </Box>
          );
        })}
      </Box>
    </Box>
  );
};

export default OverviewPie;
