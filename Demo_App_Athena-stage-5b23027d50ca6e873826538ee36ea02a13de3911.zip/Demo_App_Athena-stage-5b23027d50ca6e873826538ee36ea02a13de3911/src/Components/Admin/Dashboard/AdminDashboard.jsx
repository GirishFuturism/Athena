import React, { useState, useEffect } from "react";
import { Grid, Box, Typography, Avatar } from "@mui/material";
import { useNavigate } from "react-router-dom"; // ✅ Import useNavigate
import TitleBreadcrumb from "../../Shared/TitleBreadcrumb";
import FeedbackPie from "./FeedbackPie";
import PriorityPie from "./PriorityPie";
import OverviewPie from "./OverviewPie";
import BreachingGrid from "./BreachingGrid";
import RecentActivity from "./RecentActivity";
import CustomerSatisfactionGauge from "./CustomerSatisfactionGauge";
import TicketsTeamBar from "./TicketsTeamBar";
import TicketAgentBar from "./TicketsAgentBar";
import { ChartContainer } from "@mui/x-charts/ChartContainer";
import { LinePlot, lineElementClasses } from "@mui/x-charts/LineChart";
import {
  UsersIcon,
  TicketIcon,
  CubeIcon,
  ChartBarIcon,
  BookOpenIcon,
  DocumentTextIcon,
  ArrowTrendingUpIcon,
  DocumentDuplicateIcon,
  EnvelopeIcon,
  Cog6ToothIcon,
  ChartPieIcon,
  DocumentChartBarIcon,
  ClipboardDocumentCheckIcon,
  EnvelopeOpenIcon,
  ShieldCheckIcon
} from "@heroicons/react/24/outline";
import { InboxStackIcon } from "@heroicons/react/24/outline";

// Stat card with sparkline
const AnalyticsCard = ({ label, value, sparkColor, sparkData }) => (
  <Box
    sx={{
      flex: "1 1 145px",
      minWidth: 125,
      height: 120,
      p: 0,
      pt: 1,
      pb: 1.4,
      background: "#fff",
      borderRadius: "12px",
      border: "1px solid #E4E4E7",
      boxShadow: "0 2px 8px #EEF3FE70",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "flex-start",
      cursor: "pointer",
      transition: 'box-shadow 0.3s cubic-bezier(0.4, 0, 0.2, 1), transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
      '&:hover': {
        boxShadow: '0 8px 24px rgba(67, 144, 248, 0.25)',
        transform: 'translateY(-5px)',
        borderColor: '#4390F8',
      }
    }}
  >
    <Typography
      sx={{
        color: "#002257",
        fontWeight: 700,
        fontSize: { xs: 26, sm: 28 },
        mb: 0.3,
        fontFamily: "Open Sans",
      }}
    >
      {value}
    </Typography>
    <Typography
      sx={{
        color: "#AAB2C0",
        fontWeight: 400,
        fontSize: { xs: 12, sm: 15 },
        textAlign: "center",
        mb: 1,
        fontFamily: "Open Sans",
      }}
    >
      {label}
    </Typography>
    <ChartContainer
      width={410}
      height={55}
      series={[{ type: "line", data: sparkData }]}
      xAxis={[{ scaleType: "point", data: sparkData.map((_, i) => i), hideTooltip: true }]}
      yAxis={[{ hideTooltip: true }]}
      sx={{
        [`& .${lineElementClasses.root}`]: {
          stroke: sparkColor,
          strokeWidth: 3,
        },
        ".MuiChartsAxis-root": {
          display: "none",
        },
      }}
      disableAxisListener
    >
      <LinePlot />
    </ChartContainer>
  </Box>
);


// ✅ Updated StatCard with navigation link
const StatCard = ({ icon: Icon, label, count, wide, link }) => {
  const navigate = useNavigate();

  const handleClick = () => {
    if (link) {
      navigate(link);
    }
  };

  return (
    <Box
      onClick={handleClick} // ✅ Add click handler
      sx={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        minWidth: wide
          ? { xs: 220, sm: 350, md: 340, xl: 460 }
          : { xs: 170, sm: 230, md: 210, xl: 210 },
        height: 60,
        background: "linear-gradient(90deg, #DFF0FF 78%, #E2E8FF 90%)",
        borderRadius: "22px",
        boxShadow: "0px 4px 11px 0px #00000026",
        px: { xs: 2, sm: 2.2, md: 3 },
        mb: { xs: 1.2, md: 1.7 },
        position: "relative",
        cursor: "pointer",
        transition: 'box-shadow 0.3s cubic-bezier(0.4, 0, 0.2, 1), transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
        '&:hover': {
          boxShadow: '0px 8px 20px 0px #409BFF60',
          transform: 'translateY(-4px)',
        }
      }}
    >
      <Box
        sx={{ display: "flex", alignItems: "center", gap: { xs: 1, sm: 1.5 } }}
      >
        <Icon style={{ width: 27, height: 27, color: "#409BFF", strokeWidth: 2 }} />
        <Typography
          sx={{
            color: "#409BFF",
            fontWeight: 500,
            fontSize: { xs: 14, sm: 17, md: 18 },
            fontFamily: "Open Sans",
          }}
        >
          {label}
        </Typography>
      </Box>
      <Box
        sx={{
          ml: 5,
          background: "#DFF0FF",
          width: { xs: 38, sm: 42, md: 40 },
          height: 40,
          borderRadius: "16px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontWeight: 600,
          color: "#262B43",
          fontSize: { xs: 16, md: 14 },
          fontFamily: "Open Sans",
          boxShadow: "0px 2px 6px 0px #5051F929",
        }}
      >
        {count}
      </Box>
    </Box>
  );
};


const AdminDashboard = () => {
  const [currentUser, setCurrentUser] = useState({
    name: "John Williams",
    email: "JohnWilliams03@gmail.com",
  });

  const [currentTime, setCurrentTime] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    try {
      const userData = localStorage.getItem("user");
      if (userData) {
        const parsedUser = JSON.parse(userData);
        if (parsedUser?.name && parsedUser?.email) setCurrentUser(parsedUser);
      }
    } catch (error) {}
    return () => clearInterval(timer);
  }, []);

  const formattedDate = currentTime.toLocaleDateString("en-US", {
    month: "2-digit",
    day: "2-digit",
    year: "numeric",
  });
  const hours = currentTime.getHours();
  const minutes = currentTime.getMinutes();
  const seconds = currentTime.getSeconds();

  // Analytics data with sparklines
  const analyticsData = [
    {
      label: "Open Ticket",
      value: 18,
      sparkColor: "#1F90FA",
      sparkData: [6, 4, 9, 4, 7, 8],
    },
    {
      label: "Tickets on SLA Hold",
      value: 18,
      sparkColor: "#FFBD00",
      sparkData: [4, 2, 6, 3, 7, 5],
    },
    {
      label: "P1 Incidents",
      value: 4,
      sparkColor: "#30E46D",
      sparkData: [2, 4, 3, 5, 2, 6],
    },
    {
      label: "Unassigned Tickets",
      value: 8,
      sparkColor: "#FFBD00",
      sparkData: [5, 3, 6, 2, 5, 4],
    },
    {
      label: "Stale Tickets",
      value: 14,
      sparkColor: "#30E46D",
      sparkData: [3, 6, 4, 7, 3, 5],
    },
    {
      label: "Resolved Today",
      value: 0,
      sparkColor: "#A90808",
      sparkData: [4, 2, 5, 3, 6, 2],
    },
  ];

  return (
    <Grid
      container
      spacing={{ xs: 1, md: 2 }}
      columns={{ xs: 12, sm: 12, md: 12, xl: 12 }}
      sx={{
        width: "100%",
        maxWidth: "100vw",
        m: 0,
        p: { xs: 0, sm: 1 },
        justifyContent: "center",
        flexGrow: 1,
      }}
    >
      <Grid
        item
        size={{ xs: 12, sm: 12, md: 12, xl: 12 }}
        sx={{
          border: "1px solid #E4E4E7",
          backgroundColor: "#fff",
          px: { xs: 1, sm: 4, md: 6, xl: 3 },
          py: { xs: 0, sm: 3 },
          boxShadow: { xs: "none", sm: "0 2px 14px rgba(116,185,255,.08)" },
        }}
      >
        {/* Breadcrumb */}
        <Box sx={{ mb: { xs: 1, sm: 2 } }}>
          <TitleBreadcrumb
            breadcrumbsData={[{ type: "link", label: "Home", to: "/admin" }]}
          />
        </Box>

        {/* Profile / Welcome / Clock */}
        <Box
          sx={{
            width: "100%",
            mt: { xs: 1.2, sm: 2.3 },
            mb: { xs: 2, sm: 3 },
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            justifyContent: "space-between",
            alignItems: { xs: "stretch", md: "center" },
            gap: { xs: 2, md: 2.5 },
          }}
        >
          {/* Profile card */}
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: { xs: 1.5, sm: 2.5 },
              px: 3,
              py: 2.5,
              background: "#fff",
              borderRadius: "16px",
              border: "1.7px solid #409BFF",
              minWidth: 220,
              mb: { xs: 1.5, md: 2 },
              mx: { xs: "auto", md: 0 },
              boxShadow: " 8px 9px 19px 0px #409BFF4F",
              maxWidth: { xs: "100%", sm: 375, md: 340 },
              flex: { xs: "none", md: "0 0 auto" },
            }}
          >
            <Avatar
              src="https://randomuser.me/api/portraits/men/32.jpg"
              sx={{
                width: 56,
                height: 56,
                border: "2px solid #E8F4FD",
              }}
            />
            <Box>
              <Typography
                sx={{
                  fontSize: { xs: 16, sm: 19, md: 20 },
                  fontWeight: 600,
                  color: "#409BFF",
                  fontFamily: "Open Sans",
                  mb: 0.5,
                }}
              >
                {currentUser.name}
              </Typography>
              <Typography
                sx={{
                  fontSize: { xs: 12.5, sm: 13.5, md: 14 },
                  color: "#A49B9B",
                  fontWeight: 400,
                  fontFamily: "Open Sans",
                  mb: 1,
                }}
              >
                {currentUser.email}
              </Typography>
              <Box sx={{ display: "flex", alignItems: "center", gap: 7 }}>
                <Typography
                  sx={{
                    fontSize: { xs: 16, sm: 19, md: 18 },
                    fontWeight: 600,
                    color: "#409BFF",
                    fontFamily: "Open Sans",
                    mb: 0.5,
                  }}
                >
                  Admin
                </Typography>

                <Box sx={{ display: "flex", alignItems: "center", gap: 0.6 }}>
                  <Box
                    sx={{
                      width: 8,
                      height: 8,
                      backgroundColor: "#00D68F",
                      borderRadius: "50%",
                    }}
                  />
                  <Typography
                    sx={{
                      fontSize: 12,
                      color: "#00D68F",
                      fontWeight: 500,
                      fontFamily: "Open Sans",
                    }}
                  >
                    Available
                  </Typography>
                </Box>
              </Box>
            </Box>
          </Box>

          {/* Welcome message */}
          <Box
            sx={{
              textAlign: "center",
              flex: 1,
              my: { xs: 2, md: 0 },
            }}
          >
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 1.5,
              }}
            >
              <Typography
                sx={{
                  fontSize: { xs: 21, sm: 25, md: "26px" },
                  fontWeight: 400,
                  color: "#B2B2B2",
                  fontFamily: "Open Sans",
                }}
              >
                Welcome Back to PSA
              </Typography>
              <span style={{ fontSize: "27px" }}>👋</span>
            </Box>
          </Box>

          {/* Clock section */}
          <Box
            sx={{
              textAlign: "center",
              minWidth: { xs: 200, sm: 220, md: 230 },
              mb: 5,
            }}
          >
            <Typography
              sx={{
                fontSize: { xs: 15, sm: 18, md: "19px" },
                fontWeight: 600,
                color: "#409BFF",
                fontFamily: "Open Sans",
                mb: 1.2,
              }}
            >
              {formattedDate}
            </Typography>
            <Box sx={{ display: "flex", gap: 1 }}>
              <Box
                sx={{
                  textAlign: "center",
                  py: 1.1,
                  px: 2,
                  background: "#fff",
                  borderRadius: "13px",
                  border: "1px solid #409BFF",
                  minWidth: "45px",
                  boxShadow: "3px 6px 9px 0px #409BFF40",
                }}
              >
                <Typography
                  sx={{
                    fontSize: { xs: 13, sm: 15, md: 22 },
                    fontWeight: 400,
                    color: "#49A6FC",
                    fontFamily: "Open Sans",
                  }}
                >
                  {hours.toString().padStart(2, "0")}
                </Typography>
                <Typography
                  sx={{
                    fontSize: 11,
                    color: "#409BFF",
                    fontWeight: 500,
                    fontFamily: "Open Sans",
                    mt: 0.2,
                  }}
                >
                  Hours
                </Typography>
              </Box>
              <Box sx={{ mt: 3, color: "#409BFF" }}>:</Box>
              <Box
                sx={{
                  textAlign: "center",
                  py: 1.1,
                  px: 1.4,
                  background: "#fff",
                  borderRadius: "13px",
                  border: "1px solid #409BFF",
                  minWidth: "45px",
                  boxShadow: "3px 6px 9px 0px #409BFF40",
                }}
              >
                <Typography
                  sx={{
                    fontSize: { xs: 13, sm: 15, md: 22 },
                    fontWeight: 400,
                    color: "#49A6FC",
                    fontFamily: "Open Sans",
                  }}
                >
                  {minutes.toString().padStart(2, "0")}
                </Typography>
                <Typography
                  sx={{
                    fontSize: 11,
                    color: "#409BFF",
                    fontWeight: 500,
                    fontFamily: "Open Sans",
                    mt: 0.2,
                  }}
                >
                  Minutes
                </Typography>
              </Box>
              <Box sx={{ mt: 3, color: "#409BFF" }}>:</Box>
              <Box
                sx={{
                  textAlign: "center",
                  py: 1.1,
                  px: 1.4,
                  background: "#fff",
                  borderRadius: "13px",
                  border: "1px solid #409BFF",
                  minWidth: "45px",
                  boxShadow: "3px 6px 9px 0px #409BFF40",
                }}
              >
                <Typography
                  sx={{
                    fontSize: { xs: 13, sm: 15, md: 22 },
                    fontWeight: 400,
                    color: "#49A6FC",
                    fontFamily: "Open Sans",
                  }}
                >
                  {seconds.toString().padStart(2, "0")}
                </Typography>
                <Typography
                  sx={{
                    fontSize: 11,
                    color: "#409BFF",
                    fontWeight: 500,
                    fontFamily: "Open Sans",
                    mt: 0.2,
                  }}
                >
                  Seconds
                </Typography>
              </Box>
            </Box>
          </Box>
        </Box>

        {/* ✅ Stat Cards with Navigation Links */}
        <Box
          sx={{
            mt: { xs: 2, md: 3 },
            width: "100%",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: { xs: 1.3, md: 2 },
          }}
        >
          {/* Row 1 */}
          <Box
            sx={{
              display: "flex",
              gap: { xs: 1.1, sm: 1.5 },
              width: "100%",
              justifyContent: "center",
              flexWrap: "wrap",
            }}
          >
            <StatCard icon={UsersIcon} label="User Management" count="11" link="/user-management" />
            <StatCard icon={TicketIcon} label="Ticket Management" count="9" link="/ticket-management" />
            <StatCard icon={InboxStackIcon} label="Asset Management" count="4" link="/asset-management" />
            <StatCard icon={ChartPieIcon} label="Report" count="01" link="/report" />
          </Box>
          {/* Row 2 */}
          <Box
            sx={{
              display: "flex",
              gap: { xs: 1.1, sm: 1.5 },
              width: "100%",
              justifyContent: "center",
              flexWrap: "wrap",
            }}
          >
            <StatCard icon={BookOpenIcon} label="Knowledge Base" count="3" link="/knowledge-base" />
            <StatCard icon={DocumentTextIcon} label="Billing" count="2" link="/billing" />
            <StatCard
              icon={ClipboardDocumentCheckIcon}
              label="Contract Management"
              count="21"
              link="/contract-management"
            />
          </Box>
          {/* Row 3 */}
          <Box
            sx={{
              display: "flex",
              gap: { xs: 1.1, sm: 1.5 },
              width: "100%",
              justifyContent: "center",
              flexWrap: "wrap",
            }}
          >
            <StatCard icon={EnvelopeOpenIcon} label="Email Notification" count="7" link="/email-notification" />
            <StatCard icon={DocumentChartBarIcon} label="CRM" count="6" link="/crm" />
          </Box>
        </Box>

        <Grid>
          {/* Lower Analytics Cards Row with Sparklines */}
          <Box
            sx={{
              mt: { xs: 2, md: 4 },
              display: "flex",
              flexWrap: "wrap",
              gap: { xs: 1.5, sm: 2 },
              justifyContent: "center",
              width: "100%",
            }}
          >
            {analyticsData.map((card) => (
              <AnalyticsCard
                key={card.label}
                label={card.label}
                value={card.value}
                sparkColor={card.sparkColor}
                sparkData={card.sparkData}
              />
            ))}
          </Box>

          {/* widgets section */}
          <Box sx={{ mt: 3, mb: 2, width: "100%" }}>
            {/* First row: 3 widgets */}
            <Grid container spacing={1}>
              <Grid item size={{ xs: 12, sm: 12, md: 4 }}>
                <FeedbackPie />
              </Grid>
              <Grid item size={{ xs: 12, sm: 12, md: 4 }}>
                <TicketsTeamBar />
              </Grid>
              <Grid item size={{ xs: 12, sm: 12, md: 4 }}>
                <TicketAgentBar />
              </Grid>
            </Grid>

            {/* Second row: left widget spans 2 grid columns, right is single */}
            <Grid container spacing={1} sx={{ mt: 1 }}>
              <Grid item size={{ xs: 12, sm: 12, md: 8 }}>
                <OverviewPie />
              </Grid>
              <Grid item size={{ xs: 12, sm: 12, md: 4 }}>
                <PriorityPie />
              </Grid>
            </Grid>

            {/* Third row: 3 widgets */}
            <Grid container spacing={1} sx={{ mt: 1 }}>
              <Grid item size={{ xs: 12, sm: 12, md: 4 }}>
                <CustomerSatisfactionGauge />
              </Grid>
              <Grid item size={{ xs: 12, sm: 12, md: 4 }}>
                <BreachingGrid />
              </Grid>
              <Grid item size={{ xs: 12, sm: 12, md: 4 }}>
                <RecentActivity />
              </Grid>
            </Grid>
          </Box>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default AdminDashboard;
