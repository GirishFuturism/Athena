import React from "react";
import { Box, Typography, Button, IconButton } from "@mui/material";
import NorthEastIcon from "@mui/icons-material/NorthEast";
import { useNavigate } from "react-router-dom";

const activities = [
  {
    id: 1,
    ticketNumber: "#TK-0016",
    title: "Trackpad Stops Working",
    description: "Laptop screen blinking",
  },
  {
    id: 2,
    ticketNumber: "#TK-0015",
    title: "3CX Not Opening",
    description: "DataFlow - Medium Priority",
  },
  {
    id: 3,
    ticketNumber: "#TK-0014",
    title: "Printer Connectivity Issue",
    description: "ConnectCorp - Low Priority",
  },
  {
    id: 4,
    ticketNumber: "#TK-0013",
    title: "Software update failures",
    description: "ConnectCorp - Low Priority",
  },
];

const RecentActivity = () => {
  const navigate = useNavigate()
  return (
    <Box
      sx={{
        width: "100%",
        background: "#fff",
        borderRadius: "12px",
        padding: 0,
        boxShadow: "0 6px 20px rgba(238,243,254,0.44)",
        border: "1px solid #E5E7EB",
        display: "flex",
        flexDirection: "column",
         transition: 'all 0.3s ease-in-out',
        '&:hover': {
                        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.4)' ,
                        // transform:  'translateY(-2px)'
                      }
      }}
    >
      {/* Header */}
      <Box
        sx={{
          paddingY: 3,
          paddingX:3,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        //   borderBottom: "1px solid #E5E7EB",
        }}
      >
        <Typography
          variant="subtitle1"
          sx={{
            fontFamily: "Open Sans",
            fontWeight: 600,
            fontSize: "16px",
            color: "#4390F8",
          }}
        >
          Recent Activity
        </Typography>

        <IconButton
          sx={{
            width: 32,
            height: 32,
            borderRadius: "8px",
            backgroundColor: "#4390F8",
            "&:hover": {
              backgroundColor: "#3380e8",
            },
          }}
          aria-label="expand"
        >
          <NorthEastIcon sx={{ color: "#fff", fontSize: 20 }} />
        </IconButton>
      </Box>

      {/* Activity List */}
      <Box sx={{ paddingX: 2.5, paddingY: 1 }}>
        {activities.map((item, idx) => (
          <Box
            key={item.id + idx}
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              backgroundColor: "#F9FAFB",
              borderRadius: "8px",
              paddingX: 2,
              paddingY: 1.5,
              marginBottom: idx !== activities.length - 1 ? 1.5 : 0,
              boxSizing: "border-box",
            }}
          >
            <Box sx={{ flex: 1 }}>
              <Typography
                sx={{
                  fontSize: "16px",
                  fontWeight: 600,
                  fontFamily: "Open Sans",
                  color: "#111827",
                }}
              >
                {item.ticketNumber} {item.title}
              </Typography>
              <Typography
                sx={{
                  fontSize: "14px",
                  fontWeight: 400,
                  fontFamily: "Open Sans",
                  color: "#4B5563",
                  marginTop: 0.5,
                  whiteSpace: "nowrap",
                  textOverflow: "ellipsis",
                  overflow: "hidden",
                  maxWidth: "80%",
                }}
              >
                {item.description}
              </Typography>
            </Box>

            <Button
  variant="outlined"
  onClick={() => navigate("/ticket-details", { 
    state: { 
      ticketData: {
        id: item.ticketNumber.replace('#TK-', ''),
        summary: item.title,
        dateCreated: "9/17/2025 21:47",
        type: "Incident",
        status: "In Progress",
        agent: "Vinay T",
        timeTaken: "00:00",
        accountManager: "James Brown"
      }
    }
  })}
  size="small"
  sx={{
    minWidth: 54,
    height: 28,
    fontSize: "13px",
    fontWeight: 500,
    fontFamily: "Open Sans",
    color: "#374151",
    borderColor: "#E5E7EB",
    borderRadius: "6px",
    textTransform: "none",
    boxShadow: "none",
    backgroundColor:"#E5E7EB",
    "&:hover": {
      backgroundColor: "#F9FAFB",
      borderColor: "#9CA3AF",
      boxShadow: "none",
    },
  }}
>
  View
</Button>

          </Box>
        ))}
      </Box>
    </Box>
  );
};

export default RecentActivity;