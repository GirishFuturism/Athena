import * as React from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { Select, MenuItem, FormControl, OutlinedInput, IconButton } from "@mui/material";
import NorthEastIcon from "@mui/icons-material/NorthEast";
import { BarChart } from "@mui/x-charts/BarChart";

const BAR_LABELS = [
  "1st Line Support",
  "2nd Line Support",
  "3rd Line Support",
];

// Data by period
const chartData = {
  "7": {
    data1: [15],
    data2: [0, 20],
    data3: [0, 0, 14],
  },
  "30": {
    data1: [45],
    data2: [0, 65],
    data3: [0, 0, 38],
  },
};

export default function TicketsTeamBar() {
  const [period, setPeriod] = React.useState("7");
  const data = chartData[period];

  // MenuProps to hide scrollbar and disable scroll lock
  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

  return (
    <Box
      sx={{
        background: "#fff",
        borderRadius: "12px",
        boxShadow: "0 6px 20px #EEF3FE70",
        width: "100%",
        minHeight: 320,
        display: "flex",
        flexDirection: "column",
        border: "1px solid #E5E7EB",
        transition: 'all 0.3s ease-in-out',
        '&:hover': {
                        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.4)' ,
                        // transform:  'translateY(-2px)'
                      }
      }}
    >
      {/* Header */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          pt: 2.5,
          px: 2.5,
        }}
      >
        <Typography
          sx={{
            fontSize: "16px",
            fontWeight: 600,
            fontFamily: "Open Sans",
            color: "#4390F8",
          }}
        >
          Tickets by Team
        </Typography>
        <Box sx={{ display: "flex", alignItems: "center" }}>
          <FormControl
            size="small"
            sx={{
              background: "#fff",
              borderRadius: "8px",
              minWidth: 120,
              ".MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
            }}
          >
            <Select
              value={period}
              onChange={(e) => setPeriod(e.target.value)}
              input={<OutlinedInput />}
              MenuProps={menuProps}
              sx={{
                height: 32,
                fontSize: 14,
                fontWeight: 500,
                color: "#232323",
                minWidth: 120,
                borderRadius: "8px",
              }}
            >
              <MenuItem value="7">Last 7 days</MenuItem>
              <MenuItem value="30">Last 30 days</MenuItem>
            </Select>
          </FormControl>
          <IconButton
            sx={{
              ml: 1.1,
              borderRadius: "8px",
              width: 32,
              height: 32,
              background: "#4390F8",
              transition: "background 0.2s",
              cursor: "pointer",
              "&:hover": { background: "#3380e8" },
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <NorthEastIcon sx={{ color: "#fff", fontSize: 22 }} />
          </IconButton>
        </Box>
      </Box>

      {/* Bar Chart */}
      <Box
        sx={{
          flex: 1,
          pt: 2.5,
          pb: 1.5,
          pl: 1,
          pr: 2.9,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <BarChart
          height={200}
          margin={{ left: 10, right: 10, top: 10, bottom: 30 }}
          xAxis={[
            {
              scaleType: "band",
              data: BAR_LABELS,
              categoryGapRatio: 0.32,
              tickLabelStyle: {
                fontFamily: "Open Sans",
                fontWeight: 400,
                fontSize: 10,
                fill: "#9CA3AF",
              },
            },
          ]}
          yAxis={[
            {
              min: 0,
              label: "Number of Tickets",
              labelStyle: {
                fontFamily: "'Open Sans', sans-serif",
                fontWeight: 500,
                fontSize: 11,
                fill: "#6B7280",
              },
              tickLabelStyle: {
                fontFamily: "'Open Sans', sans-serif",
                fontWeight: 400,
                fontSize: 11,
                fill: "#9CA3AF",
              },
            },
          ]}
          series={[
            {
              data: data.data1,
              color: "#62B2FD",
              stack: "A",
              label: "Open",
              // ✅ Custom value formatter to show status in tooltip
              valueFormatter: (value) => value ? `${value} tickets` : 'No tickets',
            },
            {
              data: data.data2,
              color: "#9BDFC4",
              stack: "A",
              label: "In Progress",
              valueFormatter: (value) => value ? `${value} tickets` : 'No tickets',
            },
            {
              data: data.data3,
              color: "#F99BAB",
              stack: "A",
              label: "Closed",
              valueFormatter: (value) => value ? `${value} tickets` : 'No tickets',
            },
          ]}
          slotProps={{
            legend: { hidden: true },
            tooltip: { 
              trigger: 'item',
              // ✅ Style the tooltip
              sx: {
                '& .MuiChartsTooltip-root': {
                  fontFamily: 'Open Sans',
                  fontSize: 13,
                },
                '& .MuiChartsTooltip-label': {
                  fontFamily: 'Open Sans',
                  fontWeight: 600,
                },
                '& .MuiChartsTooltip-value': {
                  fontFamily: 'Open Sans',
                  fontWeight: 400,
                }
              }
            }
          }}
          sx={{
            ".MuiBarElement-root": {
              rx: 6,
            },
            ".MuiChartsAxis-label": {
              fontFamily: "'Open Sans', sans-serif !important",
              fontSize: "11px !important",
              fontWeight: "500 !important",
              fill: "#6B7280 !important",
              transform: "translateX(-1px)",
            },
            ".MuiChartsAxis-tickLabel": {
              fontFamily: "'Open Sans', sans-serif !important",
              fontSize: "11px !important",
              fontWeight: "400 !important",
            }
          }}
        />
      </Box>
    </Box>
  );
}
