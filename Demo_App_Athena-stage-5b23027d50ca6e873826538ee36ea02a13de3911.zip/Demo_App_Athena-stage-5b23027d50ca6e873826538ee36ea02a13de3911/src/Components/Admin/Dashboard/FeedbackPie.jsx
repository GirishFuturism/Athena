import React, { useState } from 'react';
import { Box, Typography, IconButton, Select, MenuItem, FormControl, OutlinedInput } from "@mui/material";
import NorthEastIcon from '@mui/icons-material/NorthEast';
import { PieChart, pieArcLabelClasses } from "@mui/x-charts/PieChart";

// Feedback datasets
const feedbackData = {
  '7': [
    { id: 1, value: 25, label: "Awesome", color: "#4390F8" },
    { id: 2, value: 10, label: "Good", color: "#3ED3C0" },
    { id: 4, value: 5, label: "Ok", color: "#BB6BD9" },
    { id: 3, value: 60, label: "Bad", color: "#6563F0" },
  ],
  '30': [
    { id: 1, value: 20, label: "Awesome", color: "#4390F8" },
    { id: 2, value: 25, label: "Good", color: "#3ED3C0" },
    { id: 3, value: 30, label: "Bad", color: "#6563F0" },
    { id: 4, value: 25, label: "Ok", color: "#BB6BD9" },
  ],
};

const FeedbackPie = () => {
  const [period, setPeriod] = useState("7");
  const data = feedbackData[period];

  // Calculate total for percentage
  const total = data.reduce((sum, item) => sum + item.value, 0);

  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

  return (
    <Box sx={{
      background: "#fff",
      borderRadius: "12px",
      p: 0,
      boxShadow: '0 6px 20px #EEF3FE70',
      // width: "100%",
      height: "320px",
      display: "flex",
      flexDirection: "column",
      position: "relative",
      border: "1px solid #E5E7EB",
      transition: 'all 0.3s ease-in-out',
       '&:hover': {
                        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.4)' ,
                        // transform:  'translateY(-2px)'
                      }
    }}>
      {/* Header */}
      <Box sx={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        pt: 2.5,
        pb: 0.5,
        px: 2.5,
      }}>
        <Typography
          sx={{
            fontSize: "16px",
            fontWeight: 600,
            fontFamily: "Open Sans",
            color: "#4390F8",
          }}>
          Feedback on Tickets
        </Typography>
        <Box sx={{ display: "flex", alignItems: "center" }}>
          <FormControl variant="outlined" size="small" sx={{
            background: "#fff",
            borderRadius: "8px",
            minWidth: 120,
            '.MuiOutlinedInput-notchedOutline': { borderColor: "#D1D5DB" },
            fontSize: 14,
          }}>
            <Select
              value={period}
              onChange={e => setPeriod(e.target.value)}
              input={<OutlinedInput />}
              MenuProps={menuProps}
              sx={{
                height: 32,
                fontSize: "14px",
                fontWeight: 500,
                color: "#232323",
                minWidth: 120,
                borderRadius: "8px"
              }}
            >
              <MenuItem value="7">Last 7 Days</MenuItem>
              <MenuItem value="30">Last 30 Days</MenuItem>
            </Select>
          </FormControl>
          <Box
            sx={{
              ml: 1.1,
              borderRadius: "8px",
              width: 32,
              height: 32,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              background: "#4390F8",
              transition: "background 0.2s",
              cursor: "pointer",
              "&:hover": { background: "#3380e8" }
            }}
          >
            <NorthEastIcon sx={{ color: "#fff", fontSize: 26, fontWeight: 400 }} />
          </Box>
        </Box>
      </Box>

      {/* Chart and Legend row */}
      <Box sx={{
        flex: 1,
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        px: 3,
        pb: 1.5,
      }}>
        {/* Pie Chart */}
        <Box sx={{ flex: "0 0 175px", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <PieChart
            series={[
              {
                data: data.map(({ id, value, label, color }) => ({ 
                  id, 
                  value, 
                  label,
                  color 
                })),
                highlightScope: { fade: "global", highlighted: "item" },
                innerRadius: 0,
                outerRadius: 80,
                paddingAngle: 1,
                cornerRadius: 3,
                endAngle: 450,
                valueFormatter: (value) => {
                  const percentage = ((value.value / total) * 100).toFixed(1);
                  return `${percentage}%`;
                },
              }
            ]}
            // width={190}
            height={190}
            // ✅ MULTIPLE WAYS TO HIDE DEFAULT LEGEND
            sx={{
              // Hide legend using CSS
              '.MuiChartsLegend-root': { 
                display: 'none !important' 
              },
            }}
            slotProps={{
              legend: { hidden: true }, // ✅ Hide via slotProps
            }}
            // ✅ Alternative: Don't render legend at all
            legend={{ hidden: true }}
          />
        </Box>

        {/* ✅ CUSTOM LEGEND - Only this shows */}
        <Box sx={{
          display: "flex",
          flexDirection: "column",
          gap: 1.45,
          // minWidth: 138,
          alignItems: "flex-start"
        }}>
          {data.map((item) => {
            const percentage = ((item.value / total) * 100).toFixed(1);
            return (
              <Box
                key={item.id}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  border: "1.25px solid #4390F8",
                  borderRadius: "8px",
                  px: 1,
                  background: "#fff",
                }}
              >
                <Box sx={{
                  width: 12,
                  height: 12,
                  borderRadius: "5px",
                  background: item.color,
                  mr: 1
                }} />
                <Typography sx={{
                  fontSize: 16,
                  color: "#1C1C1E",
                  fontWeight: 400,
                  fontFamily: "Open Sans",
                }}>
                  {item.label}
                </Typography>
              </Box>
            );
          })}
        </Box>
      </Box>
    </Box>
  );
};

export default FeedbackPie;