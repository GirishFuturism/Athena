import React, { useState, useMemo } from "react";
import {
  Box,
  Typography,
  Select,
  MenuItem,
  FormControl,
  OutlinedInput,
} from "@mui/material";
import NorthEastIcon from "@mui/icons-material/NorthEast";
import { PieChart, pieArcLabelClasses } from "@mui/x-charts/PieChart";

// Priority data by time period
const priorityData = {
  "7": [
    { id: 1, value: 45, label: "Critical", color: "#D32F2F" },
    { id: 2, value: 30, label: "High", color: "#FFA000" },
    { id: 3, value: 15, label: "Low", color: "#FFD54F" },
    { id: 4, value: 10, label: "Medium", color: "#4CAF50" },
  ],
  "30": [
    { id: 1, value: 40, label: "Critical", color: "#D32F2F" },
    { id: 2, value: 35, label: "High", color: "#FFA000" },
    { id: 3, value: 15, label: "Low", color: "#FFD54F" },
    { id: 4, value: 10, label: "Medium", color: "#4CAF50" },
  ],
};

const PriorityPie = () => {
  const [period, setPeriod] = useState("7");
  const data = priorityData[period];

  // ✅ Calculate total for percentage
  const total = useMemo(() => {
    return data.reduce((sum, item) => sum + item.value, 0);
  }, [data]);

  // MenuProps to hide scrollbar and disable scroll lock
  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

  return (
    <Box
      sx={{
        background: "#fff",
        borderRadius: "12px",
        p: 0,
        boxShadow: "0 6px 20px #EEF3FE70",
        display: "flex",
        flexDirection: "column",
        position: "relative",
        border: "1px solid #E5E7EB",
        transition: 'all 0.3s ease-in-out',
        '&:hover': {
                        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.4)' ,
                        // transform:  'translateY(-2px)'
                      }
      }}
    >
      {/* Header */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          pt: 2.5,
          pb: 0.5,
          px: 2.5,
        }}
      >
        <Typography
          sx={{
            fontSize: "16px",
            fontWeight: 600,
            fontFamily: "Open Sans",
            color: "#4390F8",
          }}
        >
          Tickets by Priority
        </Typography>
        <Box sx={{ display: "flex", alignItems: "center" }}>
          <FormControl
            variant="outlined"
            size="small"
            sx={{
              background: "#fff",
              borderRadius: "8px",
              minWidth: 120,
              ".MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
            }}
          >
            <Select
              value={period}
              onChange={(e) => setPeriod(e.target.value)}
              input={<OutlinedInput />}
              MenuProps={menuProps}
              sx={{
                height: 32,
                fontSize: "14px",
                fontWeight: 500,
                color: "#232323",
                minWidth: 120,
                borderRadius: "8px",
              }}
            >
              <MenuItem value="7">Last 7 days</MenuItem>
              <MenuItem value="30">Last 30 days</MenuItem>
            </Select>
          </FormControl>
          <Box
            sx={{
              ml: 1.1,
              borderRadius: "8px",
              width: 32,
              height: 32,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              background: "#4390F8",
              cursor: "pointer",
              transition: "background 0.2s",
              "&:hover": { background: "#3380e8" },
            }}
          >
            <NorthEastIcon sx={{ color: "#fff", fontSize: 26 }} />
          </Box>
        </Box>
      </Box>

      {/* Pie Chart */}
      <Box
        sx={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <PieChart
          series={[
            {
              data: data.map(({ id, value, label, color }) => ({
                id,
                value,
                label,
                color,
              })),
              highlightScope: { fade: "global", highlighted: "item" },
              innerRadius: 0,
              outerRadius: 80,
              paddingAngle: 1,
              cornerRadius: 3,
              endAngle: 450,
              // ✅ ADD PERCENTAGE TO TOOLTIP
              valueFormatter: (value) => {
                const percentage = ((value.value / total) * 100).toFixed(1);
                return `${percentage}%`;
              },
            },
          ]}
          width={390}
          height={290}
          sx={{
            ".MuiChartsLegend-root": { display: "none !important" },
          }}
          slotProps={{
            legend: { hidden: true },
          }}
        />
      </Box>

      {/* Legend at Bottom */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          gap: 1,
          pb: 1,
          px: 2.5,
          flexWrap: "wrap",
        }}
      >
        {data.map((item) => (
          <Box
            key={item.id}
            sx={{
              display: "flex",
              alignItems: "center",
              border: "1.25px solid #409BFF",
              borderRadius: "8px",
              px: 1,
              py: 0.4,
              background: "#fff",
            }}
          >
            <Box
              sx={{
                width: 12,
                height: 12,
                borderRadius: "3px",
                background: item.color,
                mr: 1,
                flexShrink: 0,
              }}
            />
            <Typography
              sx={{
                fontSize: "14px",
                color: "#1C1C1E",
                fontWeight: 400,
                fontFamily: "Open Sans",
                whiteSpace: "nowrap",
              }}
            >
              {item.label}: {item.value}.0%
            </Typography>
          </Box>
        ))}
      </Box>
    </Box>
  );
};

export default PriorityPie;
