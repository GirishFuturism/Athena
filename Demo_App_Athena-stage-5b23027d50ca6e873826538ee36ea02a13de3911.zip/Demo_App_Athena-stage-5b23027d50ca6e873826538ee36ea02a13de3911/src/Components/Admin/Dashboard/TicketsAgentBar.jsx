import * as React from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { Select, MenuItem, FormControl, OutlinedInput, IconButton, Chip } from "@mui/material";
import NorthEastIcon from "@mui/icons-material/NorthEast";
import { BarChart } from "@mui/x-charts/BarChart";

const AGENT_NAMES = ["Mia Taylor", "John Doe", "Mia Taylor", "Ella Lewis", "Olivia Martin"];

// Data by period
const chartData = {
  "7": {
    open: [2, 5, 3, 6, 5],
    resolved: [4, 8, 6, 8, 8],
  },
  "30": {
    open: [8, 12, 10, 15, 13],
    resolved: [15, 20, 18, 22, 20],
  },
};

export default function TicketAgentBar() {
  const [period, setPeriod] = React.useState("7");
  const data = chartData[period];

  // MenuProps to hide scrollbar and disable scroll lock
  const menuProps = {
    disableScrollLock: true,
    PaperProps: {
      sx: {
        maxHeight: 300,
        '&::-webkit-scrollbar': { display: 'none' },
        '-ms-overflow-style': 'none',
        'scrollbar-width': 'none',
      },
    },
  };

  return (
    <Box
      sx={{
        background: "#fff",
        borderRadius: "12px",
        boxShadow: "0 6px 20px #EEF3FE70",
        width: "100%",
        minHeight: 300,
        display: "flex",
        flexDirection: "column",
        border: "1px solid #E5E7EB",
        transition: 'all 0.3s ease-in-out',
        '&:hover': {
                        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.4)' ,
                        // transform:  'translateY(-2px)'
                      }
      }}
    >
      {/* Define SVG pattern for striped bars */}
      <svg width="0" height="0">
        <defs>
          <pattern
            id="diagonalStripes"
            patternUnits="userSpaceOnUse"
            width="8"
            height="8"
            patternTransform="rotate(45)"
          >
            <rect width="8" height="8" fill="#BBE7FF" />
            <line x1="0" y1="0" x2="0" y2="8" stroke="#3762D0" strokeWidth="3" />
          </pattern>
        </defs>
      </svg>

      {/* Header */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          pt: 2.5,
          px: 2.5,
          pb: 1,
        }}
      >
        <Typography
          sx={{
            fontSize: "16px",
            fontWeight: 600,
            fontFamily: "Open Sans",
            color: "#4390F8",
          }}
        >
          Tickets by Agent
        </Typography>
        <Box sx={{ display: "flex", alignItems: "center" }}>
          <FormControl
            size="small"
            sx={{
              background: "#fff",
              borderRadius: "8px",
              minWidth: 120,
              ".MuiOutlinedInput-notchedOutline": { borderColor: "#D1D5DB" },
            }}
          >
            <Select
              value={period}
              onChange={(e) => setPeriod(e.target.value)}
              input={<OutlinedInput />}
              MenuProps={menuProps}
              sx={{
                height: 32,
                fontSize: 14,
                fontWeight: 500,
                color: "#232323",
                minWidth: 110,
                borderRadius: "8px",
              }}
            >
              <MenuItem value="7">Last 7 days</MenuItem>
              <MenuItem value="30">Last 30 days</MenuItem>
            </Select>
          </FormControl>
          <IconButton
            sx={{
              ml: 1.1,
              borderRadius: "8px",
              width: 32,
              height: 32,
              background: "#4390F8",
              transition: "background 0.2s",
              cursor: "pointer",
              "&:hover": { background: "#3380e8" },
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <NorthEastIcon sx={{ color: "#fff", fontSize: 20 }} />
          </IconButton>
        </Box>
      </Box>

      {/* Legend Badges with Borders */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 1,
          px: 2.5,
        }}
      >
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 0.7,
            border: "1px solid #409BFF",
            borderRadius: "6px",
            px: 1,
            py: 0.3,
            backgroundColor: "#FFF",
          }}
        >
          <Box
            sx={{
              width: 10,
              height: 10,
              backgroundColor: "#FF6E6E",
              borderRadius: "30%",
            }}
          />
          <Typography
            sx={{
              fontFamily: "Open Sans",
              fontSize: 12,
              fontWeight: 500,
            }}
          >
            Open
          </Typography>
        </Box>

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 0.7,
            border: "1px solid #409BFF",
            borderRadius: "6px",
            px: 1,
            py: 0.3,
            backgroundColor: "#FFF",
          }}
        >
          <Box
            sx={{
              width: 10,
              height: 10,
              backgroundColor: "#BBE7FF",
              borderRadius: "30%",
            }}
          />
          <Typography
            sx={{
              fontFamily: "Open Sans",
              fontSize: 12,
              fontWeight: 500,
            }}
          >
            Resolved
          </Typography>
        </Box>
      </Box>

      {/* Bar Chart */}
      <Box
        sx={{
          flex: 1,
          pt: 0.5,
          mr: 1,
          pb: 1,
          pl: 1,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <BarChart
          height={220}
          margin={{ left: 10, right: 10, top: 10, bottom: 30 }}
          xAxis={[
            {
              scaleType: "band",
              data: AGENT_NAMES,
              categoryGapRatio: 0.4,
              barGapRatio: 0.2,
              tickLabelStyle: {
                fontFamily: "Open Sans",
                fontWeight: 400,
                fontSize: 11,
                fill: "#9CA3AF",
              },
            },
          ]}
          yAxis={[
            {
              min: 0,
              // ✅ ONLY CHANGE: Added Y-axis label
              label: "Number of Tickets",
              labelStyle: {
                fontFamily: "'Open Sans', sans-serif",
                fontWeight: 500,
                fontSize: 11,
                fill: "#6B7280",
              },
              tickLabelStyle: {
                fontFamily: "'Open Sans', sans-serif",
                fontWeight: 400,
                fontSize: 11,
                fill: "#9CA3AF",
              },
            },
          ]}
          series={[
            {
              data: data.open,
              color: "#FF6E6E",
              label: "Open",
            },
            {
              data: data.resolved,
              color: "url(#diagonalStripes)",
              label: "Resolved",
            },
          ]}
          slotProps={{
            legend: { hidden: true },
          }}
          grid={{ horizontal: true, vertical: true }}
          sx={{
            ".MuiBarElement-root": {
              rx: 4,
            },
            ".MuiChartsGrid-line": {
              stroke: "#F3F4F6",
              strokeWidth: 1,
            },
            ".MuiChartsLegend-root": {
              display: "none !important",
            },
            // ✅ Style Y-axis label
            ".MuiChartsAxis-label": {
              fontFamily: "'Open Sans', sans-serif !important",
              fontSize: "11px !important",
              fontWeight: "500 !important",
              fill: "#6B7280 !important",
              // transform: "translateX(-15px)",
            },
            ".MuiChartsAxis-tickLabel": {
              fontFamily: "'Open Sans', sans-serif !important",
              fontSize: "11px !important",
              fontWeight: "400 !important",
            }
          }}
        />
      </Box>
    </Box>
  );
}
