import React, { useState, useEffect } from "react";
import {
  Box,
  Paper,
  Typography,
  InputBase,
  Button,
  FormHelperText,
  useTheme,
  useMediaQuery,
} from "@mui/material";
import BackgroundImg from "../../../assets/Background.png"
import GroupImg from "../../../assets/Group.png"
import LogoImg from "../../../assets/logo.png"
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

import { useFormik } from "formik";
import * as Yup from "yup";
import { useNavigate } from "react-router-dom";

function ResetPass() {
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);
  const [userEmail, setUserEmail] = useState("");

  const theme = useTheme();
  const navigate = useNavigate();

  // Responsive breakpoints
  const isXs = useMediaQuery(theme.breakpoints.down("sm"));
  const isSm = useMediaQuery(theme.breakpoints.between("sm", "md"));
  const isMd = useMediaQuery(theme.breakpoints.between("md", "lg"));
  const isLg = useMediaQuery(theme.breakpoints.between("lg", "xl"));
  const isXl = useMediaQuery(theme.breakpoints.up("xl"));

  useEffect(() => {
    // Check if resetEmail exists in localStorage
    const resetEmail = localStorage.getItem("resetEmail");
    if (!resetEmail) {
      // If no email found, redirect to forgot password
      navigate("/forgot");
      return;
    }
    setUserEmail(resetEmail);

    // Add custom scrollbar styles to hide scrollbar but allow scrolling
    const style = document.createElement('style');
    style.textContent = `
      /* Hide scrollbar for Chrome, Safari and Opera */
      .custom-scroll::-webkit-scrollbar {
        display: none;
      }
      
      /* Hide scrollbar for IE, Edge and Firefox */
      .custom-scroll {
        -ms-overflow-style: none;  /* IE and Edge */
        scrollbar-width: none;  /* Firefox */
      }
      
      /* Show scrollbar only on hover or when actively scrolling */
      .custom-scroll:hover::-webkit-scrollbar {
        display: block;
        width: 6px;
      }
      
      .custom-scroll:hover::-webkit-scrollbar-track {
        background: rgba(0,0,0,0.1);
        border-radius: 3px;
      }
      
      .custom-scroll:hover::-webkit-scrollbar-thumb {
        background: rgba(0,0,0,0.3);
        border-radius: 3px;
      }
      
      .custom-scroll:hover::-webkit-scrollbar-thumb:hover {
        background: rgba(0,0,0,0.5);
      }
    `;
    document.head.appendChild(style);

    return () => {
      if (document.head.contains(style)) {
        document.head.removeChild(style);
      }
    };
  }, [navigate]);

  // Form validation with Yup and Formik - EXACTLY like your working code
  const formik = useFormik({
    initialValues: {
      newPassword: "",
      confirmPassword: "",
    },
    validationSchema: Yup.object({
      newPassword: Yup.string()
        .min(8, "May be At least 8 Characters.")
        .required("New password is required"),
      confirmPassword: Yup.string()
        .oneOf([Yup.ref("newPassword"), null], "Passwords must match")
        .required("Confirm password is required"),
    }),

    // EXACT SAME LOGIC AS YOUR WORKING CODE
    onSubmit: async (values, { setSubmitting }) => {
      try {
        const email = localStorage.getItem("resetEmail");

        if (!email) {
          alert("No email found. Please go through Forgot Password again.");
          navigate("/forgot");
          return;
        }

        // Find the user by email - EXACTLY like your working code
        const res = await fetch(
          `http://localhost:3002/users?email=${encodeURIComponent(email)}`
        );
        const users = await res.json();

        if (users.length > 0) {
          const user = users[0];

          // Update the password for this user (PATCH request) - EXACTLY like your working code
          const updateRes = await fetch(
            `http://localhost:3002/users/${user.id}`,
            {
              method: "PATCH", // use PATCH (update only password) or PUT (full replace)
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ password: values.newPassword }), // Using newPassword instead of password
            }
          );

          if (updateRes.ok) {
            localStorage.removeItem("resetEmail");
            setResetSuccess(true); // show success card
          } else {
            alert("Failed to update password. Try again.");
          }
        } else {
          alert("User not found.");
        }
      } catch (error) {
        console.error("Error updating password:", error);
        alert("Something went wrong. Please try again.");
      }
      setSubmitting(false);
    }
  });

  // Handle back to login
  const handleBackToLogin = () => {
    // Clear localStorage and navigate to login
    localStorage.removeItem("resetEmail");
    navigate("/login");
  };

  // Handle login after success
  const handleGoToLogin = () => {
    navigate("/login", { 
      // state: { 
      //   // message: "Password has been reset successfully! Please login with your new password.",
      //   email: userEmail 
      // }
    });
  };

  return (
    <Box
      className="custom-scroll"
      sx={{
        width: "100vw",
        minHeight: "100vh",
        maxHeight: "100vh",
        bgcolor: "#DFF0FF",
        overflow: "auto",
        boxSizing: "border-box",
        px: { xs: 2, sm: 4, md: 8, lg: 5, xl: 10 },
        pt: { xs: 6, sm: 6, md: 6, lg: 1, xl: 4 },
        pb: { xs: 6, sm: 6, md: 6, lg: 5, xl: 6 }, 
        display: "flex",
        flexDirection: { xs: "column", md: "row" },
        justifyContent: "space-between",
        alignItems: { xs: "center", md: "flex-start" },
        gap: { xs: 4, md: 6 },
        position: "relative",
        zIndex: 1,
      }}
    >
      {/* Left Side - Reset Password Content */}
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          maxWidth: { xs: "100%", sm: 480, md: 600, lg: 600, xl: 700 },
          width: { xs: "100%", md: "auto" },
          boxSizing: "border-box",
          ml: { xs: 0, md: 6 },
          textAlign: { xs: "center", md: "left" },
          position: "relative",
          zIndex: 2,
          flex: "0 0 auto",
        }}
      >
        <Box sx={{ mb: { xs: 3, md: 3 } }}>
          <Typography
            fontWeight={700}
            sx={{
              color: "black",
              fontFamily: "Open Sans",
              fontSize: { xs: "28px", sm: "36px", md: "50px" },
              lineHeight: 1,
              mb: 2
            }}
          >
            Welcome to
          </Typography>
          <Typography
            fontWeight={700}
            sx={{
              color: "#5C6DBE",
              fontFamily: "Open Sans",
              fontSize: { xs: "28px", sm: "36px", md: "60px" },
              mb: 2,
            }}
          >
            PSA
          </Typography>
          <Typography
            sx={{
              color: "#000000",
              fontWeight: "400",
              fontSize: { xs: "14px", sm: "15px", md: "16px" },
              fontFamily: "Open Sans",
              lineHeight: 1.7,
              maxWidth: 820,
              mx: { xs: "auto", md: "0" },
            }}
          >
             We're a trusted support platform dedicated to keeping your operations smooth and organized.
            From logging new tickets to tracking incidents, outages, or service requests, our system handles 
            it all with clarity and professionalism. Whether it's a one-time issue or ongoing support, Ticket 
            Management helps your team resolve problems faster, stay on top of SLA, and deliver a stress-
            free service experience.
          </Typography>
        </Box>
        
        <Box
          sx={{
            maxWidth: { xs: 400, sm: 450, md: 500, lg: 510 },
            width: "100%",
            position: "relative",
            userSelect: "none",
            mx: { xs: "auto", md: "0" },
            right: { xs: 0, md: 70 },
            bottom: { xs: 0, md: 40 },
          }}
        >
          <img
            src={GroupImg}
            alt="Group Images"
            style={{
              width: "100%",
              borderRadius: 12,
              boxSizing: "border-box",
              objectFit: "cover",
              pointerEvents: "auto",
            }}
            draggable={false}
          />
        </Box>
      </Box>

      {/* Right Side - Reset Password Form or Success */}
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          width: { xs: "100%", md: 550 },
          maxWidth: 550,
          mx: { xs: 0, md: 0 },
          alignItems: "center",
          position: "relative",
          zIndex: 2,
          flex: "0 0 auto",
        }}
      >
        {/* Reset Password Form or Success Screen */}
        <Paper
          sx={{
            p: { xs: 3, md: 4 },
            borderRadius: 3,
            backgroundColor: "#fff",
            width: "100%",
            maxWidth: 500,
            boxSizing: "border-box",
            mb: 4,
            mt: resetSuccess 
              ? { xs: 9, sm: 9, md: 9 } 
              : { xs: 2, sm: 2, md: 6 },
            position: "relative",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            zIndex: 2,
            minHeight: resetSuccess ? "350px" : "350px",
          }}
        >
          {/* Logo positioned in top-left corner of the form */}
          <Box 
            sx={{ 
              position: "absolute",
              top: 20,
              left: 20,
              zIndex: 3,
              display: "flex", 
              alignItems: "center",
            }}
          >
            <img
              src={LogoImg}
              alt="Logo"
              style={{
                height: "40px",
                width: "auto",
              }}
              draggable={false}
            />
          </Box>

          {/* Success Screen Content */}
          {resetSuccess ? (
            <Box 
              sx={{ 
                display: "flex", 
                flexDirection: "column", 
                alignItems: "center", 
                justifyContent: "center",
                textAlign: "center",
                width: "100%",
                mt: 5,
                py: 4,
                px: 2,
              }}
            >
              <Box sx={{display:"flex", alignItems:"center", justifyContent:"center", gap:"8px"}}>
                {/* Check Icon */}
                <CheckCircleIcon 
                  sx={{ 
                    fontSize: 40,
                    color: "#50AE82",
                    mb: 1,
                    mt: 1,
                  }}
                />
                
                {/* Success Title */}
                <Typography
                  sx={{
                    color: "#1D588B",
                    fontFamily: "Open Sans",
                    fontSize: { xs: "24px", md: "32px" },
                    fontWeight: 700,
                    textAlign: "center",
                  }}
                >
                  Successfully
                </Typography>
              </Box>
              
              {/* Success Message */}
              <Typography
                sx={{
                  color: "#1D588B",
                  fontFamily: "Open Sans",
                  fontSize: { xs: "14px", md: "16px" },
                  fontWeight: 400,
                  textAlign: "center",
                }}
              >
                Your Password has been Reset
              </Typography>
              
              {/* Login Button */}
              <Button
                onClick={handleGoToLogin}
                sx={{
                  mt: 2,
                  py: 1.5,
                  px: 4,
                  background: "#0D3659",
                  color: "#fff",
                  borderRadius: 2,
                  fontWeight: 600,
                  fontSize: "16px",
                  fontFamily: "Open Sans",
                  width: "400px",
                  height:"40px",
                  maxWidth: "100%",
                  "&:hover": { 
                    background: "#0D3659" 
                  },
                  textTransform: "none"
                }}
              >
                Login
              </Button>
            </Box>
          ) : (
            /* Reset Password Form Content */
            <form onSubmit={formik.handleSubmit} style={{ width: "100%", display: "flex", flexDirection: "column", alignItems: "center" }}>
              <Box sx={{ display: "flex", flexDirection: "column", gap: 1.5, alignItems: "center", width: "100%", pt: 3 }}>
                <Typography
                  fontWeight={700}
                  sx={{
                    color: "#1D588B",
                    fontFamily: "Open Sans",
                    fontSize: { xs: "24px", sm: "26px", md: "28px" },
                    textAlign: "center",
                    mb: 1,
                  }}
                >
                  Create New Password ?
                </Typography>
                
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontWeight: 400,
                    fontSize: { xs: "14px", sm: "15px", md: "16px" },
                    color: "#1D588B",
                    textAlign: "center",
                    mb: 1,
                  }}
                >
                  May be At least 8 Characters.
                </Typography>

                {/* Show email being reset */}
                {userEmail && (
                  <Typography
                    align="center"
                    sx={{
                      fontSize: "14px",
                      color: "#4CAF50",
                      fontWeight: 500,
                      fontFamily: "Open Sans",
                      width: { xs: "100%", sm: "350px" },
                      maxWidth: "350px",
                      mb: 1,
                    }}
                  >
                    Resetting password for: {userEmail}
                  </Typography>
                )}

                {/* New Password Field */}
                <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", width: "100%" }}>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      border: formik.touched.newPassword && formik.errors.newPassword
                        ? "1px solid #d32f2f"
                        : "1px solid #0D3659",
                      borderRadius: 2,
                      bgcolor: "#fff",
                      px: 2,
                      py: 1,
                      boxSizing: "border-box",
                      height: "40px",
                      width: "400px",
                    }}
                  >
                    <InputBase
                      id="newPassword"
                      name="newPassword"
                      placeholder="New Password"
                      type={showNewPassword ? "text" : "password"}
                      sx={{
                        fontSize: "16px",
                        fontFamily: "Open Sans",
                        color: "#0D3659",
                        pr: 1,
                        flex: 1,
                        "& input::placeholder": {
                          color: "#0D3659",
                          opacity: 1,
                          fontFamily: "Open Sans",
                        },
                      }}
                      value={formik.values.newPassword}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    <span
                      className="material-symbols-outlined"
                      style={{ color: "#0D3659", cursor: "pointer", fontWeight: "300" }}
                      onClick={() => setShowNewPassword(!showNewPassword)}
                    >
                      {showNewPassword ? "visibility" : "visibility_off"}
                    </span>
                  </Box>
                  {formik.touched.newPassword && formik.errors.newPassword && (
                    <FormHelperText error sx={{ width: "400px", maxWidth: "400px" }}>
                      {formik.errors.newPassword}
                    </FormHelperText>
                  )}
                </Box>

                {/* Confirm Password Field */}
                <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", width: "100%" }}>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      border: formik.touched.confirmPassword && formik.errors.confirmPassword
                        ? "1px solid #d32f2f"
                        : "1px solid #0D3659",
                      borderRadius: 2,
                      bgcolor: "#fff",
                      px: 2,
                      py: 1,
                      boxSizing: "border-box",
                      height: "40px",
                      width: "400px",
                    }}
                  >
                    <InputBase
                      id="confirmPassword"
                      name="confirmPassword"
                      placeholder="Confirm Password"
                      type={showConfirmPassword ? "text" : "password"}
                      sx={{
                        fontSize: "16px",
                        fontFamily: "Open Sans",
                        color: "#0D3659",
                        pr: 1,
                        flex: 1,
                        "& input::placeholder": {
                          color: "#0D3659",
                          opacity: 1,
                          fontFamily: "Open Sans",
                        },
                      }}
                      value={formik.values.confirmPassword}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    <span
                      className="material-symbols-outlined"
                      style={{ color: "#0D3659", cursor: "pointer", fontWeight: "300" }}
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    >
                      {showConfirmPassword ? "visibility" : "visibility_off"}
                    </span>
                  </Box>
                  {formik.touched.confirmPassword && formik.errors.confirmPassword && (
                    <FormHelperText error sx={{ width: "400px", maxWidth: "400px" }}>
                      {formik.errors.confirmPassword}
                    </FormHelperText>
                  )}
                </Box>

                {/* Reset Password Button */}
                <Button
                  type="submit"
                  disabled={formik.isSubmitting}
                  sx={{
                    mt: 2,
                    py: 1,
                    background: "#0D3659",
                    color: "#fff",
                    borderRadius: 2,
                    fontWeight: 600,
                    fontSize: "16px",
                    fontFamily: "Open Sans",
                    height: "40px",
                    width: "400px",
                    "&:hover": { background: "#1c4b74ff" },
                    textTransform: "none"
                  }}
                >
                  {formik.isSubmitting ? "Resetting..." : "Reset Password"}
                </Button>

                {/* Back to Login */}
                <Button
                  onClick={handleBackToLogin}
                  startIcon={<ArrowBackIcon />}
                  sx={{
                    mt: 2,
                    color: "#1D588B",
                    fontFamily: "Open Sans",
                    fontSize: "14px",
                    textTransform: "none",
                    "&:hover": {
                      bgcolor: "transparent"
                    }
                  }}
                >
                  Back to log in
                </Button>
              </Box>
            </form>
          )}
        </Paper>
      </Box>

      {/* Background image */}
      <Box
        sx={{
          position: "absolute",
          left: 0,
          top: -200,
          width: "100%",
          height: "100%", 
          zIndex: 0,
          pointerEvents: "none",
          userSelect: "none",
        }}
      >
        <img
          src={BackgroundImg}
          alt="Background"
          style={{ 
            width: "100%", 
            height: "100%",
            display: "block",
            objectFit: "cover",
            transform: "scaleX(-1)"
          }}
          draggable={false}
        />
      </Box>
    </Box>
  );
}

export default ResetPass;
