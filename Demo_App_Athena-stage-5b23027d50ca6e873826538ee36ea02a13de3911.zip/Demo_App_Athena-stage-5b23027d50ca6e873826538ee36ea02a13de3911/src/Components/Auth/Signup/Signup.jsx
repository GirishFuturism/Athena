import React, { useState, useEffect } from "react";
import {
  Box,
  Paper,
  Typography,
  InputBase,
  Button,
  Divider,
  FormHelperText,
  useTheme,
  useMediaQuery,
  Checkbox,
} from "@mui/material";
import BackgroundImg from "../../../assets/Background.png";
import GroupImg from "../../../assets/Group.png";
import LogoImg from "../../../assets/logo.png";

import { EyeIcon, EyeSlashIcon } from "@heroicons/react/24/outline";
import { CheckCircleIcon } from "@heroicons/react/24/solid";

import { useFormik } from "formik";
import * as Yup from "yup";
import { useNavigate, Link } from "react-router-dom";
import GoogleImg from "../../../assets/google.png";

function Signup() {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [signupSuccess, setSignupSuccess] = useState(false);
  const [serverError, setServerError] = useState("");
  const [agreedToTerms, setAgreedToTerms] = useState(false);

  const theme = useTheme();
  const navigate = useNavigate();

  const isXs = useMediaQuery(theme.breakpoints.down("sm"));
  const isSm = useMediaQuery(theme.breakpoints.between("sm", "md"));
  const isMd = useMediaQuery(theme.breakpoints.between("md", "lg"));
  const isLg = useMediaQuery(theme.breakpoints.between("lg", "xl"));
  const isXl = useMediaQuery(theme.breakpoints.up("xl"));

  useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      .custom-scroll::-webkit-scrollbar {
        display: none;
      }
      .custom-scroll {
        -ms-overflow-style: none;
        scrollbar-width: none;
      }
      .custom-scroll:hover::-webkit-scrollbar {
        display: block;
        width: 6px;
      }
      .custom-scroll:hover::-webkit-scrollbar-track {
        background: rgba(0,0,0,0.1);
        border-radius: 3px;
      }
      .custom-scroll:hover::-webkit-scrollbar-thumb {
        background: rgba(0,0,0,0.3);
        border-radius: 3px;
      }
      .custom-scroll:hover::-webkit-scrollbar-thumb:hover {
        background: rgba(0,0,0,0.5);
      }
    `;
    document.head.appendChild(style);
    return () => {
      if (document.head.contains(style)) {
        document.head.removeChild(style);
      }
    };
  }, []);

  const formik = useFormik({
    initialValues: {
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
    validationSchema: Yup.object({
      name: Yup.string()
        .required("Please enter your name")
        .matches(/^\w+\s+\w+/, "Please enter your full name (first and last name)"),
      email: Yup.string()
        .email("Invalid email address")
        .required("Email is required"),
      password: Yup.string()
        .min(6, "Password must be at least 6 characters")
        .required("Password is required"),
      confirmPassword: Yup.string()
        .oneOf([Yup.ref("password"), null], "Passwords must match")
        .required("Confirm password is required"),
    }),
    onSubmit: async (values, { setSubmitting }) => {
      if (!agreedToTerms) {
        setServerError("Please agree to the Terms & Conditions");
        setSubmitting(false);
        return;
      }

      try {
        const userExistsResponse = await fetch(
          `http://localhost:3002/users?email=${encodeURIComponent(values.email)}`
        );

        if (!userExistsResponse.ok) {
          throw new Error('Failed to check existing users');
        }

        const existingUsers = await userExistsResponse.json();
        if (existingUsers.length > 0) {
          setServerError("An account with this email already exists.");
          setSubmitting(false);
          return;
        }

        setServerError("");

        const newUser = {
          id: Date.now().toString(),
          name: values.name.trim(),
          email: values.email.toLowerCase().trim(),
          password: values.password,
        };

        const response = await fetch("http://localhost:3002/users", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(newUser),
        });

        if (!response.ok) {
          throw new Error('Failed to create user account');
        }

        const savedUser = await response.json();
        setSignupSuccess(true);

      } catch (error) {
        setServerError("An error occurred while creating your account. Please try again.");
      } finally {
        setSubmitting(false);
      }
    },
  });

  const handleGoToLogin = () => {
    navigate("/login");
  };

  return (
    <Box
      className="custom-scroll"
      sx={{
        width: "100vw",
        minHeight: "100vh",
        maxHeight: "100vh",
        bgcolor: "#DFF0FF",
        overflow: "auto",
        boxSizing: "border-box",
        px: { xs: 2, sm: 4, md: 8, lg: 5, xl: 10 },
        pt: { xs: 6, sm: 6, md: 6, lg: 1, xl: 4 },
        pb: { xs: 6, sm: 6, md: 6, lg: 5, xl: 6 },
        display: "flex",
        flexDirection: { xs: "column", md: "row" },
        justifyContent: "space-between",
        alignItems: { xs: "center", md: "flex-start" },
        gap: { xs: 4, md: 6 },
        position: "relative",
        zIndex: 1,
      }}
    >
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          maxWidth: { xs: "100%", sm: 480, md: 600, lg: 600, xl: 700 },
          width: { xs: "100%", md: "auto" },
          boxSizing: "border-box",
          ml: { xs: 0, md: 6 },
          textAlign: { xs: "center", md: "left" },
          position: "relative",
          zIndex: 2,
          flex: "0 0 auto",
        }}
      >
        <Box sx={{ mb: { xs: 3, md: 3 } }}>
          <Typography fontWeight={700} sx={{
            color: "black",
            fontFamily: "Open Sans",
            fontSize: { xs: "28px", sm: "36px", md: "50px" },
            lineHeight: 1,
            mb: 2
          }}>
            Welcome to
          </Typography>
          <Typography fontWeight={700} sx={{
            color: "#5C6DBE",
            fontFamily: "Open Sans",
            fontSize: { xs: "28px", sm: "36px", md: "60px" },
            mb: 2,
          }}>
            PSA
          </Typography>
          <Typography sx={{
            color: "#000000",
            fontWeight: "400",
            fontSize: { xs: "14px", sm: "15px", md: "16px" },
            fontFamily: "Open Sans",
            lineHeight: 1.7,
            maxWidth: 820,
            mx: { xs: "auto", md: "0" },
          }}>
             We're a trusted support platform dedicated to keeping your operations smooth and organized.
           From logging new tickets to tracking incidents, outages, or service requests, our system handles 
           it all with clarity and professionalism. Whether it's a one-time issue or ongoing support, Ticket 
           Management helps your team resolve problems faster, stay on top of SLA, and deliver a stress-
           free service experience. {/* shortened for clarity */}
          </Typography>
        </Box>
        <Box sx={{
          maxWidth: { xs: 400, sm: 450, md: 500, lg: 510 },
          width: "100%",
          position: "relative",
          userSelect: "none",
          mx: { xs: "auto", md: "0" },
          right: { xs: 0, md: 70 },
          bottom: { xs: 0, md: 40 },
        }}>
          <img
            src={GroupImg}
            alt="Group Images"
            style={{
              width: "100%",
              borderRadius: 12,
              boxSizing: "border-box",
              objectFit: "cover",
              pointerEvents: "auto",
            }}
            draggable={false}
          />
        </Box>
      </Box>

      {/* Right Side */}
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          width: { xs: "100%", md: 550 },
          maxWidth: 550,
          mx: { xs: 0, md: 0 },
          alignItems: "center",
          position: "relative",
          zIndex: 2,
          flex: "0 0 auto",
        }}
      >
        <Paper
          sx={{
            p: { xs: 3, md: 4 },
            borderRadius: 3,
            backgroundColor: "#fff",
            width: "100%",
            maxWidth: 500,
            boxSizing: "border-box",
            mb: 4,
            mt: signupSuccess ? { xs: 9, sm: 9, md: 19 } : { xs: 2, sm: 2, md: 1 },
            position: "relative",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            zIndex: 2,
            minHeight: signupSuccess ? "350px" : "auto",
          }}
        >
          <Box
            sx={{
              position: "absolute",
              top: 20,
              left: 20,
              zIndex: 3,
              display: "flex",
              alignItems: "center",
            }}
          >
            <img
              src={LogoImg}
              alt="Logo"
              style={{
                height: "40px",
                width: "auto",
              }}
              draggable={false}
            />
          </Box>

          {signupSuccess ? (
            <Box sx={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              textAlign: "center",
              width: "100%",
              mt: 5,
              py: 4,
              px: 2,
            }}>
              <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }}>
                {/* Heroicons Success Icon */}
                <CheckCircleIcon style={{ width: 40, height: 40, color: "#50AE82", marginBottom: 8, marginTop: 8 }} />
                <Typography sx={{
                  color: "#1D588B",
                  fontFamily: "Open Sans",
                  fontSize: { xs: "24px", md: "32px" },
                  fontWeight: 700,
                  textAlign: "center",
                }}>
                  Successfully
                </Typography>
              </Box>
              <Typography sx={{
                color: "#1D588B",
                fontFamily: "Open Sans",
                fontSize: { xs: "14px", md: "16px" },
                fontWeight: 400,
                textAlign: "center",
              }}>
                Your account has been created. Let's get started.
              </Typography>
              <Button
                onClick={handleGoToLogin}
                sx={{
                  mt: 2,
                  py: 1.5,
                  px: 4,
                  background: "#0D3659",
                  color: "#fff",
                  borderRadius: 2,
                  fontWeight: 600,
                  fontSize: "16px",
                  fontFamily: "Open Sans",
                  width: "400px",
                  height: "40px",
                  maxWidth: "100%",
                  "&:hover": {
                    background: "#0D3659"
                  },
                  textTransform: "none"
                }}
              >
                Go To Login
              </Button>
            </Box>
          ) : (
            <form onSubmit={formik.handleSubmit} style={{ width: "100%", display: "flex", flexDirection: "column", alignItems: "center" }}>
              <Box sx={{ display: "flex", flexDirection: "column", gap: 1.5, alignItems: "center", width: "100%" }}>
                <Typography
                  fontWeight={700}
                  sx={{
                    color: "#1D588B",
                    fontFamily: "Open Sans",
                    fontSize: { xs: "28px", sm: "30px", md: "32px" },
                    textAlign: "center",
                    mt: 2,
                  }}
                >
                  Create Your Account
                </Typography>
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontWeight: 400,
                    fontSize: { xs: "14px", sm: "15px", md: "16px" },
                    color: "#1D588B",
                    textAlign: "center",
                    mb: 1,
                  }}
                >
                  Let's Get Started with 15 Days Free Trial
                </Typography>

                {serverError && (
                  <Typography
                    align="center"
                    sx={{
                      fontSize: "14px",
                      color: "#FF5E5E",
                      fontWeight: 500,
                      fontFamily: "Open Sans",
                      width: { xs: "100%", sm: "400px" },
                      maxWidth: "400px",
                    }}
                  >
                    {serverError}
                  </Typography>
                )}

                {/* Name Field */}
                <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", width: "100%" }}>
                  <Box sx={{
                    display: "flex",
                    alignItems: "center",
                    border: formik.touched.name && formik.errors.name
                      ? "1px solid #d32f2f"
                      : "1px solid #0D3659",
                    borderRadius: 2,
                    bgcolor: "#fff",
                    px: 2,
                    py: 1,
                    boxSizing: "border-box",
                    height: "40px",
                    width: { xs: "100%", sm: "400px" },
                    maxWidth: "400px",
                  }}>
                    <InputBase
                      id="name"
                      name="name"
                      placeholder="Full Name"
                      type="text"
                      sx={{
                        fontSize: "16px",
                        fontFamily: "Open Sans",
                        color: "#0D3659",
                        pr: 1,
                        flex: 1,
                        "& input::placeholder": {
                          color: "#0D3659",
                          opacity: 1,
                          fontFamily: "Open Sans",
                        },
                      }}
                      value={formik.values.name}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                  </Box>
                  {formik.touched.name && formik.errors.name && (
                    <FormHelperText error sx={{ width: { xs: "100%", sm: "400px" }, maxWidth: "400px" }}>
                      {formik.errors.name}
                    </FormHelperText>
                  )}
                </Box>

                {/* Email Field */}
                <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", width: "100%" }}>
                  <Box sx={{
                    display: "flex",
                    alignItems: "center",
                    border: formik.touched.email && formik.errors.email
                      ? "1px solid #d32f2f"
                      : "1px solid #0D3659",
                    borderRadius: 2,
                    bgcolor: "#fff",
                    px: 2,
                    py: 1,
                    boxSizing: "border-box",
                    height: "40px",
                    width: { xs: "100%", sm: "400px" },
                    maxWidth: "400px",
                  }}>
                    <InputBase
                      id="email"
                      placeholder="Email Address"
                      name="email"
                      type="email"
                      sx={{
                        fontSize: "16px",
                        fontFamily: "Open Sans",
                        color: "#0D3659",
                        pr: 1,
                        flex: 1,
                        "& input::placeholder": {
                          color: "#0D3659",
                          opacity: 1,
                          fontFamily: "Open Sans",
                        },
                      }}
                      value={formik.values.email}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                  </Box>
                  {formik.touched.email && formik.errors.email && (
                    <FormHelperText error sx={{ width: { xs: "100%", sm: "400px" }, maxWidth: "400px" }}>
                      {formik.errors.email}
                    </FormHelperText>
                  )}
                </Box>

                {/* Password Field */}
                <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", width: "100%" }}>
                  <Box sx={{
                    display: "flex",
                    alignItems: "center",
                    border: formik.touched.password && formik.errors.password
                      ? "1px solid #d32f2f"
                      : "1px solid #0D3659",
                    borderRadius: 2,
                    bgcolor: "#fff",
                    px: 2,
                    py: 1,
                    boxSizing: "border-box",
                    height: "40px",
                    width: { xs: "100%", sm: "400px" },
                    maxWidth: "400px",
                  }}>
                    <InputBase
                      id="password"
                      placeholder="Password"
                      name="password"
                      type={showPassword ? "text" : "password"}
                      sx={{
                        fontSize: "16px",
                        fontFamily: "Open Sans",
                        color: "#0D3659",
                        pr: 1,
                        flex: 1,
                        "& input::placeholder": {
                          color: "#0D3659",
                          opacity: 1,
                          fontFamily: "Open Sans",
                        },
                      }}
                      value={formik.values.password}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    <span style={{ color: "#0D3659", cursor: "pointer", fontWeight: "300" }} onClick={() => setShowPassword(!showPassword)}>
                      {showPassword ? (
                        <EyeIcon style={{ width: 22, height: 22, color: "#0D3659" }} />
                      ) : (
                        <EyeSlashIcon style={{ width: 22, height: 22, color: "#0D3659" }} />
                      )}
                    </span>
                  </Box>
                  {formik.touched.password && formik.errors.password && (
                    <FormHelperText error sx={{ width: { xs: "100%", sm: "400px" }, maxWidth: "400px" }}>
                      {formik.errors.password}
                    </FormHelperText>
                  )}
                </Box>

                {/* Confirm Password Field */}
                <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", width: "100%" }}>
                  <Box sx={{
                    display: "flex",
                    alignItems: "center",
                    border: formik.touched.confirmPassword && formik.errors.confirmPassword
                      ? "1px solid #d32f2f"
                      : "1px solid #0D3659",
                    borderRadius: 2,
                    bgcolor: "#fff",
                    px: 2,
                    py: 1,
                    boxSizing: "border-box",
                    height: "40px",
                    width: { xs: "100%", sm: "400px" },
                    maxWidth: "400px",
                  }}>
                    <InputBase
                      id="confirmPassword"
                      placeholder="Confirm Password"
                      name="confirmPassword"
                      type={showConfirmPassword ? "text" : "password"}
                      sx={{
                        fontSize: "16px",
                        fontFamily: "Open Sans",
                        color: "#0D3659",
                        pr: 1,
                        flex: 1,
                        "& input::placeholder": {
                          color: "#0D3659",
                          opacity: 1,
                          fontFamily: "Open Sans",
                        },
                      }}
                      value={formik.values.confirmPassword}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    <span style={{ color: "#0D3659", cursor: "pointer", fontWeight: "300" }} onClick={() => setShowConfirmPassword(!showConfirmPassword)}>
                      {showConfirmPassword ? (
                        <EyeIcon style={{ width: 22, height: 22, color: "#0D3659" }} />
                      ) : (
                        <EyeSlashIcon style={{ width: 22, height: 22, color: "#0D3659" }} />
                      )}
                    </span>
                  </Box>
                  {formik.touched.confirmPassword && formik.errors.confirmPassword && (
                    <FormHelperText error sx={{ width: { xs: "100%", sm: "400px" }, maxWidth: "400px" }}>
                      {formik.errors.confirmPassword}
                    </FormHelperText>
                  )}
                </Box>

                {/* Terms & Conditions Checkbox */}
                <Box sx={{
                  display: "flex",
                  alignItems: "flex-start",
                  mt: 1,
                  width: { xs: "100%", sm: "400px" },
                  maxWidth: "400px",
                  justifyContent: "flex-start"
                }}>
                  <Checkbox
                    checked={agreedToTerms}
                    onChange={(e) => setAgreedToTerms(e.target.checked)}
                    sx={{
                      color: "#0D3659",
                      p: 0,
                      mr: 1.2,
                      '&.Mui-checked': {
                        color: "#0D3659",
                      },
                    }}
                    size="small"
                  />
                  <Typography sx={{
                    fontSize: "14px",
                    color: "#1D588B",
                    fontFamily: "Open Sans",
                    lineHeight: 1.4,
                  }}>
                    I Agree To The{" "}
                    <Link
                      to="/terms"
                      style={{
                        color: "#1D588B",
                        textDecoration: "none",
                        fontWeight: 500
                      }}
                    >
                      Terms & Conditions
                    </Link>
                  </Typography>
                </Box>

                {/* Sign Up Button */}
                <Button
                  type="submit"
                  disabled={formik.isSubmitting}
                  sx={{
                    mt: 1,
                    py: 1,
                    background: "#0D3659",
                    color: "#fff",
                    borderRadius: 2,
                    fontWeight: 600,
                    fontSize: "18px",
                    fontFamily: "Open Sans",
                    height: "40px",
                    width: { xs: "100%", sm: "400px" },
                    maxWidth: "400px",
                    "&:hover": { background: "#1c4b74ff" },
                    textTransform: "none"
                  }}
                >
                  {formik.isSubmitting ? "Creating Account..." : "Sign In"}
                </Button>

                {/* Continue With */}
                <Box sx={{ width: { xs: "100%", sm: "400px" }, maxWidth: "400px", display: "flex", justifyContent: "center" }}>
                  <Divider sx={{ my: 1, color: "#0D3659", fontFamily: "Open Sans", fontSize: "14px", width: "100%" }}>
                    Or Continue With
                  </Divider>
                </Box>

                {/* Google Button. You may swap icon for relevant Heroicon if needed */}
                <Button
                  sx={{
                    py: 1,
                    border: "1px solid #0D3659",
                    borderRadius: 2,
                    bgcolor: "#FFFFFF",
                    color: "#0D3659",
                    fontFamily: "Open Sans",
                    fontWeight: 500,
                    fontSize: "18px",
                    textTransform: "none",
                    height: "40px",
                    width: { xs: "100%", sm: "400px" },
                    maxWidth: "400px",
                    position: "relative",
                    "&:hover": {
                      bgcolor: "#F5F5F5"
                    }
                  }}
                >
                  <img
                    src={GoogleImg}
                    alt="Google"
                    style={{
                      position: "absolute",
                      left: "16px",
                      width: "20px",
                      height: "20px",
                      objectFit: "contain",
                    }}
                  />
                  Google
                </Button>

                {/* Login Link */}
                <Typography
                  align="center"
                  sx={{
                    mt: 1,
                    fontSize: "16px",
                    color: "#1D588B",
                    fontWeight: 500,
                    fontFamily: "Open Sans",
                    width: { xs: "100%", sm: "400px" },
                    maxWidth: "400px",
                  }}
                >
                  Already have an account?{" "}
                  <Link to="/login" style={{ color: "#1D588B", textDecoration: "none", fontWeight: 700 }}>
                    Login Here
                  </Link>
                </Typography>
              </Box>
            </form>
          )}
        </Paper>
      </Box>

      {/* Background image */}
      <Box
        sx={{
          position: "absolute",
          left: 0,
          top: -200,
          width: "100%",
          height: "100%",
          zIndex: 0,
          pointerEvents: "none",
          userSelect: "none",
        }}
      >
        <img
          src={BackgroundImg}
          alt="Background"
          style={{
            width: "100%",
            height: "100%",
            display: "block",
            objectFit: "cover",
            transform: "scaleX(-1)"
          }}
          draggable={false}
        />
      </Box>
    </Box>
  );
}

export default Signup;
