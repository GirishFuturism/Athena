import React, { useState, useEffect } from "react";
import {
  Box,
  Paper,
  Typography,
  InputBase,
  Button,
  FormHelperText,
  useTheme,
  useMediaQuery,
} from "@mui/material";
import BackgroundImg from "../../../assets/Background.png"
import GroupImg from "../../../assets/Group.png"
import LogoImg from "../../../assets/logo.png"
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

import { useFormik } from "formik";
import * as Yup from "yup";
import { useNavigate } from "react-router-dom";

function ForgotPass() {
  const [resetStep, setResetStep] = useState("initial"); // "initial", "error", "success"
  const [serverError, setServerError] = useState("");
  const [userEmail, setUserEmail] = useState("");

  const theme = useTheme();
  const navigate = useNavigate();

  // Responsive breakpoints
  const isXs = useMediaQuery(theme.breakpoints.down("sm"));
  const isSm = useMediaQuery(theme.breakpoints.between("sm", "md"));
  const isMd = useMediaQuery(theme.breakpoints.between("md", "lg"));
  const isLg = useMediaQuery(theme.breakpoints.between("lg", "xl"));
  const isXl = useMediaQuery(theme.breakpoints.up("xl"));

  useEffect(() => {
    // Add custom scrollbar styles to hide scrollbar but allow scrolling
    const style = document.createElement('style');
    style.textContent = `
      /* Hide scrollbar for Chrome, Safari and Opera */
      .custom-scroll::-webkit-scrollbar {
        display: none;
      }
      
      /* Hide scrollbar for IE, Edge and Firefox */
      .custom-scroll {
        -ms-overflow-style: none;  /* IE and Edge */
        scrollbar-width: none;  /* Firefox */
      }
      
      /* Show scrollbar only on hover or when actively scrolling */
      .custom-scroll:hover::-webkit-scrollbar {
        display: block;
        width: 6px;
      }
      
      .custom-scroll:hover::-webkit-scrollbar-track {
        background: rgba(0,0,0,0.1);
        border-radius: 3px;
      }
      
      .custom-scroll:hover::-webkit-scrollbar-thumb {
        background: rgba(0,0,0,0.3);
        border-radius: 3px;
      }
      
      .custom-scroll:hover::-webkit-scrollbar-thumb:hover {
        background: rgba(0,0,0,0.5);
      }
    `;
    document.head.appendChild(style);

    return () => {
      if (document.head.contains(style)) {
        document.head.removeChild(style);
      }
    };
  }, []);

  // Form validation with Yup and Formik
  const formik = useFormik({
    initialValues: {
      email: "",
    },
    validationSchema: Yup.object({
      email: Yup.string()
        .email("Invalid email address")
        .required("Email is required"),
    }),

    onSubmit: async (values, { setSubmitting }) => {
      try {
        // Check if user exists in JSON Server
        const response = await fetch(
          `http://localhost:3002/users?email=${encodeURIComponent(values.email)}`
        );
        
        if (!response.ok) {
          throw new Error('Failed to check user email');
        }

        const users = await response.json();
        
        if (users.length === 0) {
          // Email not found - show error state
          setServerError("No account found with this email");
          setResetStep("error");
          setUserEmail(values.email);
          setSubmitting(false);
          return;
        }

        // Email found - store in localStorage and show success state
        localStorage.setItem("resetEmail", values.email);
        setServerError("");
        setResetStep("success");
        setUserEmail(values.email);

        console.log("Password reset email would be sent to:", values.email);

      } catch (error) {
        console.error("Forgot password error:", error);
        setServerError("An error occurred. Please try again.");
        setResetStep("error");
      } finally {
        setSubmitting(false);
      }
    },
  });

  // Handle back to login
  const handleBackToLogin = () => {
    navigate("/login");
  };

  // Handle resend email - navigate to reset password
  const handleResendEmail = () => {
    // In a real app, this would trigger another API call
    console.log("Resending email to:", userEmail);
    
    // Make sure email is stored in localStorage
    if (userEmail) {
      localStorage.setItem("resetEmail", userEmail);
    }
    
    // Navigate to reset password page
    navigate("/reset");
  };

  return (
    <Box
      className="custom-scroll"
      sx={{
        width: "100vw",
        minHeight: "100vh",
        maxHeight: "100vh",
        bgcolor: "#DFF0FF",
        overflow: "auto",
        boxSizing: "border-box",
        px: { xs: 2, sm: 4, md: 8, lg: 5, xl: 10 },
        pt: { xs: 6, sm: 6, md: 6, lg: 1, xl: 4 },
        pb: { xs: 6, sm: 6, md: 6, lg: 5, xl: 6 }, 
        display: "flex",
        flexDirection: { xs: "column", md: "row" },
        justifyContent: "space-between",
        alignItems: { xs: "center", md: "flex-start" },
        gap: { xs: 4, md: 6 },
        position: "relative",
        zIndex: 1,
      }}
    >
      {/* Left Side - Forgot Password Content */}
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          maxWidth: { xs: "100%", sm: 480, md: 600, lg: 600, xl: 700 },
          width: { xs: "100%", md: "auto" },
          boxSizing: "border-box",
          ml: { xs: 0, md: 6 },
          textAlign: { xs: "center", md: "left" },
          position: "relative",
          zIndex: 2,
          flex: "0 0 auto",
        }}
      >
        <Box sx={{ mb: { xs: 3, md: 3 } }}>
          <Typography
            fontWeight={700}
            sx={{
              color: "black",
              fontFamily: "Open Sans",
              fontSize: { xs: "28px", sm: "36px", md: "50px" },
              lineHeight: 1,
              mb: 2
            }}
          >
           Welcome to
          </Typography>
          <Typography
            fontWeight={700}
            sx={{
              color: "#5C6DBE",
              fontFamily: "Open Sans",
              fontSize: { xs: "28px", sm: "36px", md: "60px" },
              mb: 2,
            }}
          >
            PSA
          </Typography>
          <Typography
            sx={{
              color: "#000000",
              fontWeight: "400",
              fontSize: { xs: "14px", sm: "15px", md: "16px" },
              fontFamily: "Open Sans",
              lineHeight: 1.7,
              maxWidth: 820,
              mx: { xs: "auto", md: "0" },
            }}
          >
            We're a trusted support platform dedicated to keeping your operations smooth and organized.
            From logging new tickets to tracking incidents, outages, or service requests, our system handles 
            it all with clarity and professionalism. Whether it's a one-time issue or ongoing support, Ticket 
            Management helps your team resolve problems faster, stay on top of SLA, and deliver a stress-
            free service experience.
          </Typography>
        </Box>
        
        <Box
          sx={{
            maxWidth: { xs: 400, sm: 450, md: 500, lg: 510 },
            width: "100%",
            position: "relative",
            userSelect: "none",
            mx: { xs: "auto", md: "0" },
            right: { xs: 0, md: 70 },
            bottom: { xs: 0, md: 40 },
          }}
        >
          <img
            src={GroupImg}
            alt="Group Images"
            style={{
              width: "100%",
              borderRadius: 12,
              boxSizing: "border-box",
              objectFit: "cover",
              pointerEvents: "auto",
            }}
            draggable={false}
          />
        </Box>
      </Box>

      {/* Right Side - Forgot Password Form */}
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          width: { xs: "100%", md: 550 },
          maxWidth: 550,
          mx: { xs: 0, md: 0 },
          alignItems: "center",
          position: "relative",
          zIndex: 2,
          flex: "0 0 auto",
        }}
      >
        {/* Forgot Password Form */}
        <Paper
          sx={{
            p: { xs: 3, md: 4 },
            borderRadius: 3,
            backgroundColor: "#fff",
            width: "100%",
            maxWidth: 500,
            boxSizing: "border-box",
            mb: 4,
            mt: { xs: 2, sm: 2, md: 6 },
            position: "relative",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            zIndex: 2,
            minHeight: "300px",
          }}
        >
          {/* Logo positioned in top-left corner of the form */}
          <Box 
            sx={{ 
              position: "absolute",
              top: 20,
              left: 20,
              zIndex: 3,
              display: "flex", 
              alignItems: "center",
            }}
          >
            <img
              src={LogoImg}
              alt="Logo"
              style={{
                height: "40px",
                width: "auto",
              }}
              draggable={false}
            />
          </Box>

          {/* Form Content based on step */}
          {resetStep === "initial" && (
            <form onSubmit={formik.handleSubmit} style={{ width: "100%", display: "flex", flexDirection: "column", alignItems: "center" }}>
              <Box sx={{ display: "flex", flexDirection: "column", gap: 1.5, alignItems: "center", width: "100%", pt: 3 }}>
                <Typography
                  fontWeight={700}
                  sx={{
                    color: "#1D588B",
                    fontFamily: "Open Sans",
                    fontSize: { xs: "24px", sm: "26px", md: "28px" },
                    textAlign: "center",
                    mb: 1,
                  }}
                >
                  Forget Password ?
                </Typography>
                
                <Typography
                  sx={{
                    fontFamily: "Open Sans",
                    fontWeight: 400,
                    fontSize: { xs: "14px", sm: "15px", md: "16px" },
                    color: "#1D588B",
                    textAlign: "center",
                    mb: 2,
                  }}
                >
                  No worries, we 'll send you reset Instruction
                </Typography>

                {/* Email Field */}
                <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", width: "100%" }}>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      border: formik.touched.email && formik.errors.email
                        ? "1px solid #d32f2f"
                        : "1px solid #0D3659",
                      borderRadius: 2,
                      bgcolor: "#fff",
                      px: 2,
                      py: 1,
                      boxSizing: "border-box",
                      height: "40px",
                      width: "400px",
                    }}
                  >
                    <InputBase
                      id="email"
                      name="email"
                      placeholder="Enter your Register Email ID"
                      type="email"
                      sx={{
                        fontSize: "16px",
                        fontFamily: "Open Sans",
                        color: "#0D3659",
                        pr: 1,
                        flex: 1,
                        "& input::placeholder": {
                          color: "#0D3659",
                          opacity: 1,
                          fontFamily: "Open Sans",
                        },
                      }}
                      value={formik.values.email}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                  </Box>
                  {formik.touched.email && formik.errors.email && (
                    <FormHelperText error sx={{ width: { xs: "100%", sm: "350px" }, maxWidth: "350px" }}>
                      {formik.errors.email}
                    </FormHelperText>
                  )}
                </Box>

                {/* Reset Password Button */}
                <Button
                  type="submit"
                  disabled={formik.isSubmitting}
                  sx={{
                    mt: 2,
                    py: 1,
                    background: "#0D3659",
                    color: "#fff",
                    borderRadius: 2,
                    fontWeight: 600,
                    fontSize: "16px",
                    fontFamily: "Open Sans",
                    height: "40px",
                    // width: { xs: "100%", sm: "350px" },
                   width: "400px",
                    "&:hover": { background: "#1c4b74ff" },
                    textTransform: "none"
                  }}
                >
                  {formik.isSubmitting ? "Checking..." : "Reset Password"}
                </Button>

                {/* Back to Login */}
                <Button
                  onClick={handleBackToLogin}
                  startIcon={<ArrowBackIcon />}
                  sx={{
                    mt: 2,
                    color: "#1D588B",
                    fontFamily: "Open Sans",
                    fontSize: "14px",
                    textTransform: "none",
                    "&:hover": {
                      bgcolor: "transparent"
                    }
                  }}
                >
                  Back to log in
                </Button>
              </Box>
            </form>
          )}

          {resetStep === "error" && (
            <Box sx={{ display: "flex", flexDirection: "column", gap: 1.5, alignItems: "center", width: "100%", pt: 3 }}>
              <Typography
                fontWeight={700}
                sx={{
                  color: "#1D588B",
                  fontFamily: "Open Sans",
                  fontSize: { xs: "24px", sm: "26px", md: "28px" },
                  textAlign: "center",
                  mb: 1,
                }}
              >
                Forget Password ?
              </Typography>
              
              <Typography
                sx={{
                  fontFamily: "Open Sans",
                  fontWeight: 400,
                  fontSize: { xs: "14px", sm: "15px", md: "16px" },
                  color: "#1D588B",
                  textAlign: "center",
                  mb: 1,
                }}
              >
                No worries, we 'll send you reset Instruction
              </Typography>

              {/* Error Message */}
              <Typography
                sx={{
                  fontFamily: "Open Sans",
                  fontWeight: 400,
                  fontSize: "14px",
                  color: "#FF5E5E",
                  textAlign: "center",
                  mb: 2,
                }}
              >
                No account found with this email
              </Typography>

              {/* Email Field - showing the entered email */}
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  border: "1px solid #d32f2f",
                  borderRadius: 2,
                  bgcolor: "#fff",
                  px: 2,
                  py: 1,
                  boxSizing: "border-box",
                  height: "40px",
                  width: { xs: "100%", sm: "350px" },
                  maxWidth: "350px",
                }}
              >
                <InputBase
                  value={userEmail}
                  readOnly
                  sx={{
                    fontSize: "16px",
                    fontFamily: "Open Sans",
                    color: "#0D3659",
                    pr: 1,
                    flex: 1,
                  }}
                />
              </Box>

              {/* Reset Password Button */}
              <Button
                onClick={() => {
                  setResetStep("initial");
                  setServerError("");
                  formik.resetForm();
                }}
                sx={{
                  mt: 2,
                  py: 1,
                  background: "#0D3659",
                  color: "#fff",
                  borderRadius: 2,
                  fontWeight: 600,
                  fontSize: "16px",
                  fontFamily: "Open Sans",
                  height: "40px",
                  width: { xs: "100%", sm: "350px" },
                  maxWidth: "350px",
                  "&:hover": { background: "#1c4b74ff" },
                  textTransform: "none"
                }}
              >
                Reset Password
              </Button>

              {/* Back to Login */}
              <Button
                onClick={handleBackToLogin}
                startIcon={<ArrowBackIcon />}
                sx={{
                  mt: 2,
                  color: "#1D588B",
                  fontFamily: "Open Sans",
                  fontSize: "14px",
                  textTransform: "none",
                  "&:hover": {
                    bgcolor: "transparent"
                  }
                }}
              >
                Back to log in
              </Button>
            </Box>
          )}

          {resetStep === "success" && (
            <Box sx={{ display: "flex", flexDirection: "column", gap: 1.5, alignItems: "center", width: "100%", pt: 3 }}>
              <Typography
                fontWeight={700}
                sx={{
                  color: "#1D588B",
                  fontFamily: "Open Sans",
                  fontSize: { xs: "24px", sm: "26px", md: "28px" },
                  textAlign: "center",
                  mb: 1,
                }}
              >
                Forget Password ?
              </Typography>
              
              <Typography
                sx={{
                  fontFamily: "Open Sans",
                  fontWeight: 400,
                  fontSize: { xs: "14px", sm: "15px", md: "16px" },
                  color: "#1D588B",
                  textAlign: "center",
                  // mb: 1,
                }}
              >
                We sent a confirmation email to:
              </Typography>

              {/* User Email Display */}
              <Typography
                sx={{
                  fontFamily: "Open Sans",
                  fontWeight: 600,
                  fontSize: "16px",
                  color: "#1D588B",
                  textAlign: "center",
                  // mb: 1,
                }}
              >
                {userEmail}
              </Typography>

              {/* Instructions */}
              <Typography
                sx={{
                  fontFamily: "Open Sans",
                  fontWeight: 400,
                  fontSize: "14px",
                  color: "#4CAF50",
                  textAlign: "center",
                  // mb: 2,
                }}
              >
                Check your email and click on the confirmation link to continue
              </Typography>

              {/* Resend Email Button */}
              <Button
                onClick={handleResendEmail}
                sx={{
                  mt: 1,
                  py: 1,
                  background: "#0D3659",
                  color: "#fff",
                  borderRadius: 2,
                  fontWeight: 600,
                  fontSize: "16px",
                  fontFamily: "Open Sans",
                  height: "40px",
                  width: { xs: "100%", sm: "350px" },
                  maxWidth: "350px",
                  "&:hover": { background: "#1c4b74ff" },
                  textTransform: "none"
                }}
              >
                Resend email
              </Button>

              {/* Back to Login */}
              <Button
                onClick={handleBackToLogin}
                startIcon={<ArrowBackIcon />}
                sx={{
                  mt: 2,
                  color: "#1D588B",
                  fontFamily: "Open Sans",
                  fontSize: "14px",
                  textTransform: "none",
                  "&:hover": {
                    bgcolor: "transparent"
                  }
                }}
              >
                Back to log in
              </Button>
            </Box>
          )}
        </Paper>
      </Box>

      {/* Background image */}
      <Box
        sx={{
          position: "absolute",
          left: 0,
          top: -200,
          width: "100%",
          height: "100%", 
          zIndex: 0,
          pointerEvents: "none",
          userSelect: "none",
        }}
      >
        <img
          src={BackgroundImg}
          alt="Background"
          style={{ 
            width: "100%", 
            height: "100%",
            display: "block",
            objectFit: "cover",
            transform: "scaleX(-1)"
          }}
          draggable={false}
        />
      </Box>
    </Box>
  );
}

export default ForgotPass;
