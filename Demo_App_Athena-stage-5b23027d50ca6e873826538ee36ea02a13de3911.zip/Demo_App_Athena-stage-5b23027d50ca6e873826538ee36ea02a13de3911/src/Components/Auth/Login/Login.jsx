import React, { useState, useEffect } from "react";
import {
  Box,
  Paper,
  Typography,
  InputBase,
  Button,
  Divider,
  FormHelperText,
  useTheme,
  useMediaQuery,
  Checkbox,
} from "@mui/material";
import BackgroundImg from "../../../assets/Background.png"
import GroupImg from "../../../assets/Group.png"
import LogoImg from "../../../assets/logo.png"
import { EyeIcon, EyeSlashIcon } from "@heroicons/react/24/outline";

import { useFormik } from "formik";
import * as Yup from "yup";
import { useNavigate, Link, useLocation } from "react-router-dom";

// Social media icons
import GoogleImg from "../../../assets/google.png"

function Login() {
  const [showPassword, setShowPassword] = useState(false);
  const [serverError, setServerError] = useState("");
  const [rememberMe, setRememberMe] = useState(false);

  const theme = useTheme();
  const navigate = useNavigate();
  const location = useLocation();

  // Responsive breakpoints
  const isXs = useMediaQuery(theme.breakpoints.down("sm"));
  const isSm = useMediaQuery(theme.breakpoints.between("sm", "md"));
  const isMd = useMediaQuery(theme.breakpoints.between("md", "lg"));
  const isLg = useMediaQuery(theme.breakpoints.between("lg", "xl"));
  const isXl = useMediaQuery(theme.breakpoints.up("xl"));

  useEffect(() => {
    // Add custom scrollbar styles to hide scrollbar but allow scrolling
    const style = document.createElement('style');
    style.textContent = `
      /* Hide scrollbar for Chrome, Safari and Opera */
      .custom-scroll::-webkit-scrollbar {
        display: none;
      }
      
      /* Hide scrollbar for IE, Edge and Firefox */
      .custom-scroll {
        -ms-overflow-style: none;  /* IE and Edge */
        scrollbar-width: none;  /* Firefox */
      }
      
      /* Show scrollbar only on hover or when actively scrolling */
      .custom-scroll:hover::-webkit-scrollbar {
        display: block;
        width: 6px;
      }
      
      .custom-scroll:hover::-webkit-scrollbar-track {
        background: rgba(0,0,0,0.1);
        border-radius: 3px;
      }
      
      .custom-scroll:hover::-webkit-scrollbar-thumb {
        background: rgba(0,0,0,0.3);
        border-radius: 3px;
      }
      
      .custom-scroll:hover::-webkit-scrollbar-thumb:hover {
        background: rgba(0,0,0,0.5);
      }
    `;
    document.head.appendChild(style);

    return () => {
      if (document.head.contains(style)) {
        document.head.removeChild(style);
      }
    };
  }, []);

  // Form validation with Yup and Formik
  const formik = useFormik({
    initialValues: {
      userId: location.state?.email || "",
      password: "",
    },
    validationSchema: Yup.object({
      userId: Yup.string()
        .required("User ID is required"),
      password: Yup.string()
        .required("Password is required"),
    }),

    onSubmit: async (values, { setSubmitting }) => {
      try {
        // Find user in JSON Server
        const response = await fetch(
          `http://localhost:3002/users?email=${encodeURIComponent(values.userId)}`
        );
        
        if (!response.ok) {
          throw new Error('Failed to check user credentials');
        }

        const users = await response.json();
        
        if (users.length === 0) {
          setServerError("User not found. Please check your User ID.");
          setSubmitting(false);
          return;
        }

        const user = users[0];
        
        // Check password
        if (user.password !== values.password) {
          setServerError("Invalid password. Please try again.");
          setSubmitting(false);
          return;
        }

        // Clear any previous errors
        setServerError("");

        // Store user session - always use localStorage for automatic persistence
        const userSession = {
          id: user.id,
          name: user.name,
          email: user.email,
          loginTime: new Date().toISOString()
        };

        // Always store in localStorage regardless of checkbox state
        localStorage.setItem('token', user.id);
        localStorage.setItem('userSession', JSON.stringify(userSession));

        console.log("Login successful:", user);

        // Small delay to ensure storage is set before navigation
        setTimeout(() => {
          navigate("/admin", { 
            replace: true,
            state: { 
              user: {
                id: user.id,
                name: user.name,
                email: user.email
              }
            }
          });
        }, 100);

      } catch (error) {
        console.error("Login error:", error);
        setServerError("An error occurred while logging in. Please try again.");
      } finally {
        setSubmitting(false);
      }
    },
  });

  return (
    <Box
      className="custom-scroll"
      sx={{
        width: "100vw",
        minHeight: "100vh",
        maxHeight: "100vh",
        bgcolor: "#DFF0FF",
        overflow: "auto",
        boxSizing: "border-box",
        px: { xs: 2, sm: 4, md: 8, lg: 5, xl: 10 },
        pt: { xs: 6, sm: 6, md: 6, lg: 1, xl: 4 },
        pb: { xs: 6, sm: 6, md: 6, lg: 5, xl: 6 }, 
        display: "flex",
        flexDirection: { xs: "column", md: "row" },
        justifyContent: "space-between",
        alignItems: { xs: "center", md: "flex-start" },
        gap: { xs: 4, md: 6 },
        position: "relative",
        zIndex: 1,
      }}
    >
      {/* Left Side - Different content for Login */}
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          maxWidth: { xs: "100%", sm: 480, md: 600, lg: 600, xl: 700 },
          width: { xs: "100%", md: "auto" },
          boxSizing: "border-box",
          ml: { xs: 0, md: 6 },
          textAlign: { xs: "center", md: "left" },
          position: "relative",
          zIndex: 2,
          flex: "0 0 auto",
        }}
      >
        <Box sx={{ mb: { xs: 3, md: 3 } }}>
          <Typography
            fontWeight={700}
            sx={{
              color: "black",
              fontFamily: "Open Sans",
              fontSize: { xs: "28px", sm: "36px", md: "50px" },
              lineHeight: 1,
              mb: 2
            }}
          >
            Welcome to
          </Typography>
          <Typography
            fontWeight={700}
            sx={{
              color: "#5C6DBE",
              fontFamily: "Open Sans",
              fontSize: { xs: "28px", sm: "36px", md: "60px" },
              mb: 2,
            }}
          >
            PSA
          </Typography>
          <Typography
            sx={{
              color: "#000000",
              fontWeight: "400",
              fontSize: { xs: "14px", sm: "15px", md: "16px" },
              fontFamily: "Open Sans",
              lineHeight: 1.7,
              maxWidth: 820,
              mx: { xs: "auto", md: "0" },
            }}
          >
           We're a trusted support platform dedicated to keeping your operations smooth and organized.
           From logging new tickets to tracking incidents, outages, or service requests, our system handles 
           it all with clarity and professionalism. Whether it's a one-time issue or ongoing support, Ticket 
           Management helps your team resolve problems faster, stay on top of SLA, and deliver a stress-
           free service experience.
          </Typography>
        </Box>
        
        <Box
          sx={{
            maxWidth: { xs: 400, sm: 450, md: 500, lg: 510 },
            width: "100%",
            position: "relative",
            userSelect: "none",
            mx: { xs: "auto", md: "0" },
            right: { xs: 0, md: 70 },
            bottom: { xs: 0, md: 40 },
          }}
        >
          <img
            src={GroupImg}
            alt="Group Images"
            style={{
              width: "100%",
              borderRadius: 12,
              boxSizing: "border-box",
              objectFit: "cover",
              pointerEvents: "auto",
            }}
            draggable={false}
          />
        </Box>
      </Box>

      {/* Right Side - Login Form */}
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          width: { xs: "100%", md: 550 },
          maxWidth: 550,
          mx: { xs: 0, md: 0 },
          alignItems: "center",
          position: "relative",
          zIndex: 2,
          flex: "0 0 auto",
        }}
      >
        {/* Login Form */}
        <Paper
          sx={{
            p: { xs: 3, md: 4 },
            borderRadius: 3,
            backgroundColor: "#fff",
            width: "100%",
            maxWidth: 500,
            boxSizing: "border-box",
            mb: 4,
            mt: { xs: 2, sm: 2, md: 1 },
            position: "relative",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            zIndex: 2,
          }}
        >
          {/* Logo positioned in top-left corner of the form */}
          <Box 
            sx={{ 
              position: "absolute",
              top: 20,
              left: 20,
              zIndex: 3,
              display: "flex", 
              alignItems: "center",
            }}
          >
            <img
              src={LogoImg}
              alt="Logo"
              style={{
                height: "40px",
                width: "auto",
              }}
              draggable={false}
            />
          </Box>

          {/* Login Form Content */}
          <form onSubmit={formik.handleSubmit} style={{ width: "100%", display: "flex", flexDirection: "column", alignItems: "center" }}>
            <Box sx={{ display: "flex", flexDirection: "column", gap: 1.5, alignItems: "center", width: "100%" }}>
              <Typography
                fontWeight={700}
                sx={{
                  color: "#1D588B",
                  fontFamily: "Open Sans",
                  fontSize: { xs: "28px", sm: "30px", md: "32px" },
                  textAlign: "center",
                  mt: 2,
                }}
              >
                Login
              </Typography>
              
              <Typography
                sx={{
                  fontFamily: "Open Sans",
                  fontWeight: 400,
                  fontSize: { xs: "14px", sm: "15px", md: "16px" },
                  color: "#1D588B",
                  textAlign: "center",
                  mb: 1,
                }}
              >
                Access your account using your User ID or social media login.
              </Typography>

              {/* Success message from signup */}
              {location.state?.message && (
                <Typography
                  align="center"
                  sx={{
                    fontSize: "14px",
                    color: "#4CAF50",
                    fontWeight: 500,
                    fontFamily: "Open Sans",
                    width: { xs: "100%", sm: "400px" },
                    maxWidth: "400px",
                    mb: 1,
                  }}
                >
                  {location.state.message}
                </Typography>
              )}

              {serverError && (
                <Typography
                  align="center"
                  sx={{
                    fontSize: "14px",
                    color: "#FF5E5E",
                    fontWeight: 500,
                    fontFamily: "Open Sans",
                    width: { xs: "100%", sm: "400px" },
                    maxWidth: "400px",
                  }}
                >
                  {serverError}
                </Typography>
              )}

              {/* User ID Field */}
              <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", width: "100%" }}>
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    border: formik.touched.userId && formik.errors.userId
                      ? "1px solid #d32f2f"
                      : "1px solid #0D3659",
                    borderRadius: 2,
                    bgcolor: "#fff",
                    px: 2,
                    py: 1,
                    boxSizing: "border-box",
                    height: "40px",
                    width: { xs: "100%", sm: "400px" },
                    maxWidth: "400px",
                  }}
                >
                  <InputBase
                    id="userId"
                    name="userId"
                    placeholder="User ID"
                    type="text"
                    sx={{
                      fontSize: "16px",
                      fontFamily: "Open Sans",
                      color: "#0D3659",
                      pr: 1,
                      flex: 1,
                      "& input::placeholder": {
                        color: "#0D3659",
                        opacity: 1,
                        fontFamily: "Open Sans",
                      },
                    }}
                    value={formik.values.userId}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                </Box>
                {formik.touched.userId && formik.errors.userId && (
                  <FormHelperText error sx={{ width: { xs: "100%", sm: "400px" }, maxWidth: "400px" }}>
                    {formik.errors.userId}
                  </FormHelperText>
                )}
              </Box>

              {/* Password Field */}
              <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", width: "100%" }}>
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    border: formik.touched.password && formik.errors.password
                      ? "1px solid #d32f2f"
                      : "1px solid #0D3659",
                    borderRadius: 2,
                    bgcolor: "#fff",
                    px: 2,
                    py: 1,
                    boxSizing: "border-box",
                    height: "40px",
                    width: { xs: "100%", sm: "400px" },
                    maxWidth: "400px",
                  }}
                >
                  <InputBase
                    id="password"
                    placeholder="Password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    sx={{
                      fontSize: "16px",
                      fontFamily: "Open Sans",
                      color: "#0D3659",
                      pr: 1,
                      flex: 1,
                      "& input::placeholder": {
                        color: "#0D3659",
                        opacity: 1,
                        fontFamily: "Open Sans",
                      },
                    }}
                    value={formik.values.password}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  <span
                    style={{ color: "#0D3659", cursor: "pointer", fontWeight: "300" }}
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeIcon style={{ width: 22, height: 22, color: "#0D3659" }} />
                    ) : (
                      <EyeSlashIcon style={{ width: 22, height: 22, color: "#0D3659" }} />
                    )}
                  </span>
                </Box>
                {formik.touched.password && formik.errors.password && (
                  <FormHelperText error sx={{ width: { xs: "100%", sm: "400px" }, maxWidth: "400px" }}>
                    {formik.errors.password}
                  </FormHelperText>
                )}
              </Box>

              {/* Remember Me and Forgot Password */}
              <Box sx={{ 
                display: "flex", 
                alignItems: "center",
                justifyContent: "space-between",
                width: { xs: "100%", sm: "400px" }, 
                maxWidth: "400px",
                mt: 1,
              }}>
                <Box sx={{ display: "flex", alignItems: "center" }}>
                  <Checkbox
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    sx={{
                      color: "#0D3659",
                      p: 0,
                      mr: 1,
                      '&.Mui-checked': {
                        color: "#0D3659",
                      },
                    }}
                    size="small"
                  />
                  <Typography
                    sx={{
                      fontSize: "14px",
                      color: "#1D588B",
                      fontFamily: "Open Sans",
                    }}
                  >
                    Remember Me
                  </Typography>
                </Box>
                
                <Link 
                  to="/forgot" 
                  style={{ 
                    color: "#1D588B", 
                    textDecoration: "none",
                    fontSize: "14px",
                    fontFamily: "Open Sans",
                    fontWeight: 500
                  }}
                >
                  Forgot Password?
                </Link>
              </Box>

              {/* Login Button */}
              <Button
                type="submit"
                disabled={formik.isSubmitting}
                sx={{
                  mt: 1,
                  py: 1,
                  background: "#0D3659",
                  color: "#fff",
                  borderRadius: 2,
                  fontWeight: 600,
                  fontSize: "18px",
                  fontFamily: "Open Sans",
                  height: "40px",
                  width: { xs: "100%", sm: "400px" },
                  maxWidth: "400px",
                  "&:hover": { background: "#1c4b74ff" },
                  textTransform: "none"
                }}
              >
                {formik.isSubmitting ? "Logging in..." : "Login"}
              </Button>

              {/* Continue With */}
              <Box sx={{ width: { xs: "100%", sm: "400px" }, maxWidth: "400px", display: "flex", justifyContent: "center" }}>
                <Divider sx={{ my: 1, color: "#0D3659", fontFamily: "Open Sans", fontSize: "14px", width: "100%" }}>
                  Or Continue With
                </Divider>
              </Box>

              {/* Google Button */}
              <Button
                sx={{
                  py: 1,
                  border: "1px solid #0D3659",
                  borderRadius: 2,
                  bgcolor: "#FFFFFF",
                  color: "#0D3659",
                  fontFamily: "Open Sans",
                  fontWeight: 500,
                  fontSize: "18px",
                  textTransform: "none",
                  height: "40px",
                  width: { xs: "100%", sm: "400px" },
                  maxWidth: "400px",
                  position: "relative",
                  "&:hover": {
                    bgcolor: "#F5F5F5"
                  }
                }}
              >
                <img
                  src={GoogleImg}
                  alt="Google"
                  style={{ 
                    position: "absolute",
                    left: "16px",
                    width: "20px", 
                    height: "20px",
                    objectFit: "contain",
                  }}
                />
                Google
              </Button>

              {/* Register Link */}
              <Typography
                align="center"
                sx={{
                  mt: 1,
                  fontSize: "16px",
                  color: "#1D588B",
                  fontWeight: 500,
                  fontFamily: "Open Sans",
                  width: { xs: "100%", sm: "400px" },
                  maxWidth: "400px",
                }}
              >
                Don't have an account?{" "}
                <Link to="/signup" style={{ color: "#1D588B", textDecoration: "none", fontWeight: 700 }}>
                  Register Here
                </Link>
              </Typography>
            </Box>
          </form>
        </Paper>
      </Box>

      {/* Background image */}
      <Box
        sx={{
          position: "absolute",
          left: 0,
          top: -200,
          width: "100%",
          height: "100%", 
          zIndex: 0,
          pointerEvents: "none",
          userSelect: "none",
        }}
      >
        <img
          src={BackgroundImg}
          alt="Background"
          style={{ 
            width: "100%", 
            height: "100%",
            display: "block",
            objectFit: "cover",
            transform: "scaleX(-1)"
          }}
          draggable={false}
        />
      </Box>
    </Box>
  );
}

export default Login;