import React from 'react'
import { Breadcrumbs, Grid, Typography } from "@mui/material";
import { Link } from "react-router-dom";

const TitleBreadcrumb = ({ currentPage, breadcrumbsData = [] }) => {

    const breadcrumbs = breadcrumbsData.map((item, index) => {
    if (item.type === "link") {
      return (
        <Link
          key={index}
          to={item.to}
          style={{
            textDecoration: "none",
            color: "#409BFF",
             fontWeight: 500,
            // fontFamily: "Poppins",
            fontSize: 14
          }}
        >
          {item.label}
        </Link>
      );
    } else {
      return (
        <Typography
          key={index}
          sx={{ 
            fontFamily:"Open Sans",
            fontWeight: 500,
            fontSize: 14, 
            color:"#409BFF"
        }}
        >
          {item.label}
        </Typography>
      );
    }
  });

  return (
    <Grid container direction="column" spacing={1}>
      <Grid item>
        <Typography
          className="title_one"
          sx={{ 
            // color: "#064525", 
            fontWeight: 600,
            fontSize: 18
        }}
        >
          {currentPage}
        </Typography>
      </Grid>
      <Grid item >
        <Breadcrumbs
          separator={<span className="material-symbols-outlined" style={{color:"#409BFF"}}>chevron_right</span>}
        >
          {breadcrumbs}
        </Breadcrumbs>
      </Grid>
    </Grid>
  )
}

export default TitleBreadcrumb