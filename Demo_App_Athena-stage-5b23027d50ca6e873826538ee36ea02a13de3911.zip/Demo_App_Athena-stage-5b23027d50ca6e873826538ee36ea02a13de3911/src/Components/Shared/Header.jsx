import React, { useState, useEffect } from "react";
import {
  AppBar,
  IconButton,
  InputBase,
  Badge,
  Avatar,
  Menu,
  MenuItem,
  Button,
  Typography,
  useTheme,
  useMediaQuery,
  Box,
} from "@mui/material";
import { useLocation, useNavigate } from "react-router-dom";
import logoImg from '../../assets/logo.png';
import { ArrowLeftStartOnRectangleIcon } from "@heroicons/react/24/outline";

const Header = ({ collapsed, onToggleSidebar, role, setRole }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const theme = useTheme();
  const isMd = useMediaQuery(theme.breakpoints.down("md"));
  const isSm = useMediaQuery(theme.breakpoints.down("sm"));

  const [anchorEl, setAnchorEl] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    try {
      const userData = localStorage.getItem("user");
      if (userData) {
        const parsedUser = JSON.parse(userData);
        setCurrentUser(parsedUser);
      }
    } catch (error) {
      console.error("Error parsing user data from localStorage:", error);
      setCurrentUser({ name: "Guest User", email: "guest@example.com" });
    }
  }, []);

  const handleProfileMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    localStorage.clear();
    handleMenuClose();
    navigate("/");
  };

  const handleToggleSidebar = () => {
    if (onToggleSidebar && typeof onToggleSidebar === 'function') {
      onToggleSidebar(!collapsed);
    }
  };

  const getDisplayName = () => {
    if (currentUser?.name) {
      return currentUser.name;
    }
    switch (role) {
      case "Super Admin":
        return "Super Admin";
      case "Manager":
        return "Field Officer";
      case "User":
        return "User";
      default:
        return "Guest User";
    }
  };

  return (
    <AppBar
      position="fixed"
      sx={{
        backgroundColor: "#FFFFFF",
        color: "#000",
        boxShadow: "0px 1px 3px rgba(0, 0, 0, 0.1)",
        zIndex: (theme) => theme.zIndex.drawer + 1,
        height: "64px",
      }}
    >
      <Box sx={{ 
        display: "flex", 
        alignItems: "center", 
        height: "64px",
        width: "100%"
      }}>
        {/* Left Section - Logo Only */}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            width: collapsed ? 72 : 240,
            height: "64px",
            borderRight: "1px solid #E5E7EB",
            backgroundColor: "#FFFFFF",
            transition: "width 0.3s ease",
            px: 2,
            justifyContent: collapsed ? "center" : "flex-start",
          }}
        >
          {/* Logo */}
          <Box sx={{ display: "flex", alignItems: "center", gap: 1}}>
            <img
              src={logoImg}
              alt="PSA Logo"
              style={{
                height: "32px",
                width: "auto",
              }}
            />
            {!collapsed && (
              <Typography
               
                sx={{
                  color: "#3B82F6",
                  fontWeight: 700,
                  fontSize: "35px",
                  fontFamily: "Open Sans",
                 
                }}
              >
                PSA
              </Typography>
            )}
          </Box>
        </Box>

        {/* Main Content Section */}
        <Box
          sx={{
            flex: 1,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            px: 3,
            height: "64px",
          }}
        >
          {/* Left Side - Menu Icon and Search */}
          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            {/* Menu Button */}
            <IconButton
              onClick={handleToggleSidebar}
              sx={{
                color: "#6B7280",
                "&:hover": {
                  backgroundColor: "rgba(59, 130, 246, 0.1)",
                },
              }}
            >
              <span className="material-symbols-outlined">menu</span>
            </IconButton>

            {/* Search Bar */}
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                // backgroundColor: "#F9FAFB",
                border: "1px solid #E5E7EB",
                borderRadius: "8px",
                height: "40px",
                width: isSm ? "200px" : "320px",
                px: 2,
                gap: 1,
             
              }}
            >
              <span 
                className="material-symbols-outlined" 
                style={{ color: "#9CA3AF", fontSize: "20px" }}
              >
                search
              </span>
              <InputBase
                placeholder="Type to search"
                sx={{
                  flex: 1,
                  fontSize: "14px",
                  color: "#374151",
                  "&::placeholder": {
                    color: "#9CA3AF",
                  },
                }}
              />
            </Box>
          </Box>

          {/* Right Section */}
<Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
  {/* Action Buttons - Hidden on small screens */}
  {!isSm && (
    <>
      {/* Get Started Button */}
      <Button
        variant="contained"
        sx={{
          backgroundColor: "#409BFF",
          color: "#FFFFFF",
          textTransform: "none",
          borderRadius: "10px",
          fontWeight: 500,
          fontSize: "14px",
          height: "44px",
          px: 3,
          fontFamily: "Open Sans",
          boxShadow: "0 2px 8px rgba(64, 155, 255, 0.3)",
          "&:hover": {
            backgroundColor: "#2563EB",
          },
        }}
      >
        Get Started
      </Button>

      {/* New Ticket Button */}
      <Button
        onClick={() => navigate('/new-ticket')}
        variant="contained"
        startIcon={
          <span className="material-symbols-outlined" style={{ fontSize: "20px", fontWeight: "500" }}>
            add
          </span>
        }
        sx={{
          backgroundColor: "#409BFF",
          color: "#FFFFFF",
          textTransform: "none",
          borderRadius: "10px",
          fontWeight: 500,
          fontSize: "14px",
          height: "44px",
          px: 3,
          fontFamily: "Open Sans",
          boxShadow: "0 2px 8px rgba(64, 155, 255, 0.3)",
          "&:hover": {
            backgroundColor: "#2563EB",
          },
        }}
      >
        New Ticket
      </Button>

      {/* New Call Button */}
      <Button
        variant="contained"
        startIcon={
          <span className="material-symbols-outlined" style={{ fontSize: "20px", fontWeight: "500" }}>
            add
          </span>
        }
        sx={{
          backgroundColor: "#409BFF",
          color: "#FFFFFF",
          textTransform: "none",
          borderRadius: "10px",
          fontWeight: 500,
          fontSize: "14px",
          height: "44px",
          px: 3,
          fontFamily: "Open Sans",
          boxShadow: "0 2px 8px rgba(64, 155, 255, 0.3)",
          "&:hover": {
            backgroundColor: "#2563EB",
          },
        }}
      >
        New Call
      </Button>
    </>
  )}

  {/* Theme Toggle */}
  <IconButton
    sx={{
      color: "#409BFF",
      width: 44,
      height: 44,
      "&:hover": {
        backgroundColor: "rgba(245, 158, 11, 0.1)",
      },
    }}
  >
    <span className="material-symbols-outlined" style={{ fontSize: "24px" }}>
      light_mode
    </span>
  </IconButton>

  {/* Notifications */}
  <IconButton
    onClick={() => navigate('/email-notification')}
    sx={{
      color: "#409BFF",
      width: 44,
      height: 44,
      // mr:1,
      position: "relative",
      "&:hover": {
        backgroundColor: "rgba(64, 155, 255, 0.1)",
      },
    }}
  >
    <Badge
      badgeContent={3}
      sx={{
        "& .MuiBadge-badge": {
          backgroundColor: "#409BFF",
          color: "#FFFFFF",
          fontSize: "11px",
          fontWeight: 700,
          height: "20px",
          minWidth: "20px",
          borderRadius: "10px",
          fontFamily: "Open Sans",
        },
      }}
    >
      <span className="material-symbols-outlined" style={{ fontSize: "24px" }}>
        notifications
      </span>
    </Badge>
  </IconButton>

  {/* Profile Avatar */}
  <IconButton
    onClick={handleProfileMenuOpen}
    sx={{
      p: 0,
      "&:hover": {
        backgroundColor: "transparent",
      },
    }}
  >
    <Avatar
      src="https://randomuser.me/api/portraits/men/32.jpg"
      alt="Profile"
      sx={{
        width: 48,
        height: 48,
        border: "2px solid #E5E7EB",
      }}
    />
  </IconButton>

  {/* Logout Button */}
  <IconButton
    onClick={handleLogout}
    sx={{
      backgroundColor: "#409BFF",
      color: "#FFFFFF",
      width: 44,
      height: 44,
      borderRadius: "10px",
      "&:hover": {
        backgroundColor: "#2563EB",
      },
    }}
  >
    <ArrowLeftStartOnRectangleIcon style={{ width: 24, height: 24 }} />
  </IconButton>

  {/* Profile Menu - Keep as is */}
  <Menu
    anchorEl={anchorEl}
    open={Boolean(anchorEl)}
    onClose={handleMenuClose}
    PaperProps={{
      sx: {
        mt: 1.5,
        borderRadius: "8px",
        boxShadow: "0 10px 25px rgba(0, 0, 0, 0.1)",
      },
    }}
  >
    <MenuItem onClick={handleMenuClose}>Profile</MenuItem>
    <MenuItem onClick={handleMenuClose}>My account</MenuItem>
    <MenuItem onClick={handleLogout}>Logout</MenuItem>
  </Menu>
</Box>
        </Box>
      </Box>
    </AppBar>
  );
};

export default Header;