import {
  Squares2X2Icon,
  FolderIcon,
  CalendarIcon,
  BellIcon,
  UserCircleIcon,
  HomeIcon,
  ClipboardDocumentListIcon,
  WrenchScrewdriverIcon,
  UsersIcon,
  TicketIcon,
  BookOpenIcon,
  DocumentTextIcon,
  InboxStackIcon,
  DocumentChartBarIcon,
  ClipboardDocumentCheckIcon,
  EnvelopeOpenIcon,
  ChartPieIcon,
  ShieldCheckIcon
} from "@heroicons/react/24/outline";

export const FieldOfficerMenuItems = [
  {
    text: "My Jobs",
    icon: <Squares2X2Icon style={{ width: 22, height: 22 }} />,
    route: "/myJobs",
  },
  {
    text: "Quote Review Panel",
    icon: <FolderIcon style={{ width: 22, height: 22 }} />,
    route: "/quotePanel",
  },
  {
    text: "Calender",
    icon: <CalendarIcon style={{ width: 22, height: 22 }} />,
    route: "/calendar",
  },
  {
    text: "Notification",
    icon: <BellIcon style={{ width: 22, height: 22 }} />,
    route: "/notification",
  },
  {
    text: "Profile",
    icon: <UserCircleIcon style={{ width: 22, height: 22 }} />,
    route: "/profile",
  },
];

export const AdminMenuItems = [
  {
    text: "Dashboard",
    icon: <Squares2X2Icon style={{ width: 22, height: 22 }} />,
    route: "/admin",
  },
  {
    text: "User Management",
    icon: <UsersIcon style={{ width: 22, height: 22 }} />,
    route: "/user-management",
  },
  {
    text: "Ticket Management",
    icon: <TicketIcon style={{ width: 22, height: 22 }} />,
    route: "/ticket-management",
  },
  {
    text: "Asset Management",
    icon: <InboxStackIcon style={{ width: 22, height: 22 }} />,
    route: "/asset-management",
  },
  {
    text: "Knowledge Base",
    icon: <BookOpenIcon style={{ width: 22, height: 22 }} />,
    route: "/knowledge-base",
  },
  {
    text: "Billing",
    icon: <DocumentTextIcon style={{ width: 22, height: 22 }} />,
    route: "/billing",
  },
  {
    text: "CRM",
    icon: <DocumentChartBarIcon style={{ width: 22, height: 22 }} />,
    route: "/crm",
  },
  {
    text: "Contract Management",
    icon: <ClipboardDocumentCheckIcon style={{ width: 22, height: 22 }} />,
    route: "/contract-management",
  },
  {
    text: "Email Notification",
    icon: <EnvelopeOpenIcon style={{ width: 22, height: 22 }} />,
    route: "/email-notification",
  },
  {
    text: "Report",
    icon: <ChartPieIcon style={{ width: 22, height: 22 }} />,
    route: "/report",
  },
  // {
  //   text: "Super Admin (Athena)",
  //   icon: <ShieldCheckIcon style={{ width: 22, height: 22 }} />,
  //   route: "/super-admin",
  // },
];

export const UserMenuItems = [
  {
    text: "Home Page",
    icon: <HomeIcon style={{ width: 22, height: 22 }} />,
    route: "/homePage",
  },
  {
    text: "Book A Service",
    icon: <ClipboardDocumentListIcon style={{ width: 22, height: 22 }} />,
    route: "/bookService",
  },
  {
    text: "My Services",
    icon: <WrenchScrewdriverIcon style={{ width: 22, height: 22 }} />,
    route: "/myService",
  },
  {
    text: "Notification",
    icon: <BellIcon style={{ width: 22, height: 22 }} />,
    route: "/notification",
  },
  {
    text: "Profile",
    icon: <UserCircleIcon style={{ width: 22, height: 22 }} />,
    route: "/userProfile",
  },
];
