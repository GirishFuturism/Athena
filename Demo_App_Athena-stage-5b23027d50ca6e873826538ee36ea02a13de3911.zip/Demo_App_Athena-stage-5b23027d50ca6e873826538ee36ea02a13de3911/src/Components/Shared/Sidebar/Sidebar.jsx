import React, { useEffect, useRef, useState } from "react";
import {
  Avatar,
  Grid,
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
  Tooltip,
  useTheme,
  useMediaQuery,
  Collapse,
  Box,
} from "@mui/material";
import { useNavigate, useLocation } from "react-router-dom";
import { AdminMenuItems, FieldOfficerMenuItems, UserMenuItems } from "./RoleListItem.jsx";
import logoImg from '../../../assets/logo.png';

const drawerWidth = 240;

const Sidebar = ({ collapsed, onToggleSidebar, role }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  const [openSubmenus, setOpenSubmenus] = useState({});
  const [selectedRoute, setSelectedRoute] = useState(location.pathname);

  const prevRoleRef = useRef(role);

  useEffect(() => {
    let defaultRoute = null;

    if (role === "Super Admin") defaultRoute = "/admin";
    else if (role === "Field Officer") defaultRoute = "/admin";
    else if (role === "User") defaultRoute = "/admin";

    if (
      prevRoleRef.current !== role || 
      location.pathname === "/" || 
      location.pathname === ""
    ) {
      if (defaultRoute && location.pathname !== defaultRoute) {
        navigate(defaultRoute, { replace: true });
      }
    }

    prevRoleRef.current = role;
  }, [role, location.pathname, navigate]);

  useEffect(() => {
    setSelectedRoute(location.pathname);
  }, [location.pathname]);

  // Helper function to check if a menu item should be selected
  const isMenuItemSelected = (item) => {
    // Direct route match
    if (item.route === selectedRoute) {
      return true;
    }

    // Check if any sub-items match
    if (item.subItems?.some((sub) => selectedRoute === sub.route)) {
      return true;
    }

    // Special case: Ticket Management routes
    if (item.route === "/ticket-management") {
      return selectedRoute === "/ticket-management" || 
             selectedRoute === "/new-ticket" || 
             selectedRoute === "/ticket-details";
    }
        if (item.route === "/asset-management") {
      return selectedRoute === "/asset-management" || 
             selectedRoute === "/asset-form" ||
             selectedRoute === "/asset-group" ||
             selectedRoute === "/asset-details"
    }
    if (item.route === "/billing") {
      return selectedRoute === "/billing" || 
             selectedRoute === "/billing-form" ||
             selectedRoute === "/billing-quote"

    }

    if (item.route === "/crm") {
      return selectedRoute === "/crm" || 
             selectedRoute === "/crm-customer" ||
             selectedRoute === "/crm-client-details"||
             selectedRoute === "/crm-user-details" ||
             selectedRoute === "/crm-contract-management"||
             selectedRoute === "/crm-new-contract-form" ||
             selectedRoute === "/crm-view" ||
             selectedRoute === "/configure-list" ||
             selectedRoute === "/configure-filter" ||
             selectedRoute === "/configure-column-profile"||
             selectedRoute === "/crm-vendors" ||
             selectedRoute === "/crm-new-vendors" ||
             selectedRoute === "/crm-opportunities" ||
             selectedRoute === "/new-opportunity-form" ||
             selectedRoute === "/crm-leads" ||
             selectedRoute === "/crm-leads-form"||
             selectedRoute === "/opportunity-details" ||
             selectedRoute === "/crm-lead-details" ||
             selectedRoute === "/crm-new-user" ||
             selectedRoute === "/crm-new-client"

    }

     if (item.route === "/contract-management") {
      return selectedRoute === "/contract-management" || 
             selectedRoute === "/new-contract-form"
    }

       if (item.route === "/knowledge-base") {
      return selectedRoute === "/knowledge-base" || 
             selectedRoute === "/new-article"
    }

  

    return false;
  };

  const handleClick = (item) => {
    const hasSubItems = item.subItems && item.subItems.length > 0;
    if (hasSubItems && !collapsed) {
      setOpenSubmenus((prev) => ({
        [item.text]: !prev[item.text], 
      }));
    } else if (item.route) {
      setOpenSubmenus((prev) => {
        const isCurrentlyOpen = !!prev[item.text];
        return isCurrentlyOpen ? {} : { [item.text]: true };
      });
      navigate(item.route);
      setSelectedRoute(item.route);
    }
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate("/");
  };

  let menuItems;
  switch (role) {
    case "Super Admin":
    default:
      menuItems = AdminMenuItems;
      break;
    case "User":
      menuItems = AdminMenuItems;
      break;
    case "Manager":
      menuItems = AdminMenuItems;
      break;
  }

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: collapsed ? (isMobile ? 0 : 72) : drawerWidth,
        flexShrink: 0,
        "& .MuiDrawer-paper": {
          width: collapsed ? (isMobile ? 0 : 72) : drawerWidth,
          boxSizing: "border-box",
          backgroundColor: "#FFFFFF",
          color: "#374151",
          height: "100vh",
          transition: "width 0.3s ease",
          borderRight: "1px solid #E5E7EB",
          overflowX: "hidden",
          top: "64px",
          zIndex: (theme) => theme.zIndex.drawer,
        },
      }}
    >
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: "100%",
          py: 2,
        }}
      >
        {/* Menu Items */}
        <Box sx={{ flex: 1, px: collapsed ? 1 : 1 }}>
          <List sx={{ p: 0 }}>
            {menuItems.map((item, index) => {
              const isSelected = isMenuItemSelected(item);
              const hasSubItems = !!item.subItems;
              const isOpen = openSubmenus[item.text];

              return (
                <React.Fragment key={item.text}>
                  <ListItem
                    disablePadding
                    sx={{ 
                      mb: 0.5,
                      px: 0,
                    }}
                  >
                    <Tooltip
                      title={collapsed ? item.text : ""}
                      placement="right"
                      arrow
                    >
                      <ListItemButton
                        onClick={() => handleClick(item)}
                        sx={{
                          minHeight: 44,
                          borderRadius: collapsed ? "8px" : "12px",
                          mx: collapsed ? 0.5 : 0,
                          px: collapsed ? 1.5 : 1.5,
                          backgroundColor: isSelected ? "#3B82F6" : "transparent",
                          color: isSelected ? "#FFFFFF" : "#0D3659",
                          "&:hover": {
                            backgroundColor: isSelected ? "#2563EB" : "#F3F4F6",
                            color: isSelected ? "#FFFFFF" : "#374151",
                          },
                          transition: "all 0.2s ease",
                        }}
                      >
                        <ListItemIcon
                          sx={{
                            color: "inherit",
                            minWidth: collapsed ? "auto" : 30,
                            mr: collapsed ? 0 : 0,
                            display: "flex",
                            alignItems: "center",
                            justifyContent: collapsed ? "center" : "flex-start",
                          }}
                        >
                          {item.icon}
                        </ListItemIcon>
                        {!collapsed && (
                          <>
                            <ListItemText
                              primary={item.text}
                              primaryTypographyProps={{
                                fontSize: 14,
                                fontWeight: 400,
                                fontFamily: "Inter, sans-serif",
                                noWrap: true,
                              }}
                              sx={{ flex: 1 }}
                            />
                            {hasSubItems && (
                              <ListItemIcon
                                sx={{
                                  minWidth: "auto",
                                  color: "inherit",
                                }}
                              >
                                <span className="material-symbols-outlined">
                                  {isOpen ? 'expand_more' : 'chevron_right'}
                                </span>
                              </ListItemIcon>
                            )}
                          </>
                        )}
                      </ListItemButton>
                    </Tooltip>
                  </ListItem>

                  {hasSubItems && (
                    <Collapse
                      in={isOpen && !collapsed}
                      timeout="auto"
                      unmountOnExit
                    >
                      <List component="div" disablePadding sx={{ pl: 1 }}>
                        {item.subItems.map((subItem) => {
                          const isSubItemSelected = selectedRoute === subItem.route;
                          return (
                            <ListItemButton
                              key={subItem.name}
                              sx={{
                                minHeight: 36,
                                pl: 4,
                                mb: 0.5,
                                borderRadius: "8px",
                                backgroundColor: isSubItemSelected ? "#3B82F6" : "transparent",
                                color: isSubItemSelected ? "#FFFFFF" : "#6B7280",
                                "&:hover": {
                                  backgroundColor: isSubItemSelected ? "#2563EB" : "#F3F4F6",
                                  color: isSubItemSelected ? "#FFFFFF" : "#374151",
                                },
                              }}
                              onClick={() => {
                                if (subItem.route) {
                                  navigate(subItem.route);
                                  setSelectedRoute(subItem.route);
                                }
                              }}
                            >
                              <ListItemIcon
                                sx={{
                                  color: "inherit",
                                  minWidth: 32,
                                  mr: 1,
                                }}
                              >
                                <span className="material-symbols-outlined" style={{ fontSize: 18 }}>
                                  {subItem.icon}
                                </span>
                              </ListItemIcon>
                              <ListItemText
                                primary={subItem.name}
                                primaryTypographyProps={{
                                  fontSize: 13,
                                  fontWeight: 400,
                                  fontFamily: "Inter, sans-serif",
                                }}
                              />
                            </ListItemButton>
                          );
                        })}
                      </List>
                    </Collapse>
                  )}
                </React.Fragment>
              );
            })}
          </List>
        </Box>
      </Box>
    </Drawer>
  );
};

export default Sidebar;
