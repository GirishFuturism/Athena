import {
  ChartBarIcon,
  DocumentChartBarIcon,
  UsersIcon,
  TicketIcon,
  CurrencyDollarIcon,
  ClockIcon,
  PresentationChartLineIcon,
} from '@heroicons/react/24/solid';
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

export const REPORT_DATA = {
  today: {
    overviewStats: [
      { title: 'Total Revenue', value: '$5,200', change: '+2.7%', trend: 'up', icon: CurrencyDollarIcon, color: '#10B981', subtitle: 'vs yesterday' },
      { title: 'Active Tickets', value: '42', change: '-1.2%', trend: 'down', icon: TicketIcon, color: '#3B82F6', subtitle: '12 resolved today' },
      { title: 'Total Customers', value: '192', change: '+0.6%', trend: 'up', icon: UsersIcon, color: '#8B5CF6', subtitle: '3 new today' },
      { title: 'Avg Response Time', value: '1.8h', change: '-10.0%', trend: 'down', icon: ClockIcon, color: '#F59E0B', subtitle: 'improved' },
    ],
    ticketsByPriority: [
      { priority: 'Critical', count: 2, percentage: 5, color: '#EF4444' },
      { priority: 'High', count: 4, percentage: 10, color: '#F59E0B' },
      { priority: 'Medium', count: 24, percentage: 57, color: '#3B82F6' },
      { priority: 'Low', count: 12, percentage: 28, color: '#10B981' }
    ],
    ticketsByStatus: [
      { status: 'Open', count: 16, percentage: 38, color: '#3B82F6' },
      { status: 'In Progress', count: 10, percentage: 24, color: '#F59E0B' },
      { status: 'On Hold', count: 4, percentage: 10, color: '#6B7280' },
      { status: 'Resolved', count: 12, percentage: 28, color: '#10B981' }
    ],
    topPerformers: [
      { name: 'Sarah Johnson', role: 'Senior Agent', resolved: 14, rating: 4.9, avatar: 'https://i.pravatar.cc/150?img=47' },
      { name: 'Michael Chen', role: 'Technical Lead', resolved: 12, rating: 4.8, avatar: 'https://i.pravatar.cc/150?img=33' },
      { name: 'David Anderson', role: 'Support Engineer', resolved: 11, rating: 4.7, avatar: 'https://i.pravatar.cc/150?img=68' },
    ],
    recentReports: [
      { id: 1, title: "Today's Ticket Activity", type: 'Ticket Report', generatedBy: 'John Williams', date: '1 hour ago', status: 'Ready', size: '0.5 MB' },
      { id: 2, title: 'Customer Feedback', type: 'CRM Report', generatedBy: 'Emily Rodriguez', date: '2 hours ago', status: 'Ready', size: '0.2 MB' }
    ]
  },
  last7days: {
    overviewStats: [
      { title: 'Total Revenue', value: '$22,350', change: '+4.5%', trend: 'up', icon: CurrencyDollarIcon, color: '#10B981', subtitle: 'vs last week' },
      { title: 'Active Tickets', value: '106', change: '+3.7%', trend: 'up', icon: TicketIcon, color: '#3B82F6', subtitle: '34 resolved in 7d' },
      { title: 'Total Customers', value: '728', change: '+2.1%', trend: 'up', icon: UsersIcon, color: '#8B5CF6', subtitle: '19 new this week' },
      { title: 'Avg Response Time', value: '2.1h', change: '-8.4%', trend: 'down', icon: ClockIcon, color: '#F59E0B', subtitle: 'improved' },
    ],
    ticketsByPriority: [
      { priority: 'Critical', count: 9, percentage: 8, color: '#EF4444' },
      { priority: 'High', count: 18, percentage: 17, color: '#F59E0B' },
      { priority: 'Medium', count: 53, percentage: 50, color: '#3B82F6' },
      { priority: 'Low', count: 26, percentage: 25, color: '#10B981' }
    ],
    ticketsByStatus: [
      { status: 'Open', count: 39, percentage: 37, color: '#3B82F6' },
      { status: 'In Progress', count: 28, percentage: 27, color: '#F59E0B' },
      { status: 'On Hold', count: 10, percentage: 9, color: '#6B7280' },
      { status: 'Resolved', count: 29, percentage: 27, color: '#10B981' }
    ],
    topPerformers: [
      { name: 'Sarah Johnson', role: 'Senior Agent', resolved: 33, rating: 4.9, avatar: 'https://i.pravatar.cc/150?img=47' },
      { name: 'David Anderson', role: 'Support Engineer', resolved: 27, rating: 4.8, avatar: 'https://i.pravatar.cc/150?img=68' },
      { name: 'Michael Chen', role: 'Technical Lead', resolved: 25, rating: 4.7, avatar: 'https://i.pravatar.cc/150?img=33' },
      { name: 'Emily Rodriguez', role: 'Support Specialist', resolved: 21, rating: 4.7, avatar: 'https://i.pravatar.cc/150?img=45' },
    ],
    recentReports: [
      { id: 1, title: 'Weekly Resolution Summary', type: 'Ticket Report', generatedBy: 'John Williams', date: 'Today', status: 'Ready', size: '2.1 MB' },
      { id: 2, title: 'Client Satisfaction Survey', type: 'CRM Report', generatedBy: 'Sarah Johnson', date: 'Yesterday', status: 'Ready', size: '1.0 MB' },
      { id: 3, title: 'Weekly Invoice Chart', type: 'Financial Report', generatedBy: 'Michael Chen', date: 'Yesterday', status: 'Ready', size: '1.8 MB' },
    ]
  },
  last30days: {
    overviewStats: [
      { title: 'Total Revenue', value: '$124,500', change: '+12.5%', trend: 'up', icon: CurrencyDollarIcon, color: '#10B981', subtitle: 'vs last month' },
      { title: 'Active Tickets', value: '248', change: '+8.2%', trend: 'up', icon: TicketIcon, color: '#3B82F6', subtitle: '32 resolved today' },
      { title: 'Total Customers', value: '1,247', change: '+15.3%', trend: 'up', icon: UsersIcon, color: '#8B5CF6', subtitle: '89 new this month' },
      { title: 'Avg Response Time', value: '2.4h', change: '-18.5%', trend: 'down', icon: ClockIcon, color: '#F59E0B', subtitle: 'improved' }
    ],
    ticketsByPriority: [
      { priority: 'Critical', count: 15, percentage: 6, color: '#EF4444' },
      { priority: 'High', count: 45, percentage: 18, color: '#F59E0B' },
      { priority: 'Medium', count: 108, percentage: 44, color: '#3B82F6' },
      { priority: 'Low', count: 80, percentage: 32, color: '#10B981' }
    ],
    ticketsByStatus: [
      { status: 'Open', count: 89, percentage: 36, color: '#3B82F6' },
      { status: 'In Progress', count: 72, percentage: 29, color: '#F59E0B' },
      { status: 'On Hold', count: 34, percentage: 14, color: '#6B7280' },
      { status: 'Resolved', count: 53, percentage: 21, color: '#10B981' }
    ],
    topPerformers: [
      { name: 'Sarah Johnson', role: 'Senior Agent', resolved: 145, rating: 4.9, avatar: 'https://i.pravatar.cc/150?img=47' },
      { name: 'Michael Chen', role: 'Technical Lead', resolved: 132, rating: 4.8, avatar: 'https://i.pravatar.cc/150?img=33' },
      { name: 'David Anderson', role: 'Support Engineer', resolved: 118, rating: 4.7, avatar: 'https://i.pravatar.cc/150?img=68' },
      { name: 'Emily Rodriguez', role: 'Support Specialist', resolved: 104, rating: 4.6, avatar: 'https://i.pravatar.cc/150?img=45' },
    ],
    recentReports: [
      { id: 1, title: 'Monthly Ticket Analysis', type: 'Ticket Report', generatedBy: 'John Williams', date: '2 hours ago', status: 'Ready', size: '2.4 MB' },
      { id: 2, title: 'Revenue & Billing Summary', type: 'Financial Report', generatedBy: 'Sarah Johnson', date: '5 hours ago', status: 'Ready', size: '1.8 MB' },
      { id: 3, title: 'Customer Satisfaction Survey', type: 'CRM Report', generatedBy: 'Michael Chen', date: 'Yesterday', status: 'Ready', size: '3.2 MB' },
      { id: 4, title: 'Asset Utilization Report', type: 'Asset Report', generatedBy: 'Emily Rodriguez', date: '2 days ago', status: 'Processing', size: '1.5 MB' }
    ]
  }
};

export const reportCategories = [
  {
    title: 'Ticket Reports',
    description: 'Analyze ticket trends and resolution times',
    icon: TicketIcon,
    color: '#3B82F6',
    count: 12,
    bgColor: '#EFF6FF'
  },
  {
    title: 'Financial Reports',
    description: 'Revenue, invoices, and billing analytics',
    icon: CurrencyDollarIcon,
    color: '#10B981',
    count: 8,
    bgColor: '#ECFDF5'
  },
  {
    title: 'Customer Reports',
    description: 'Customer satisfaction and engagement metrics',
    icon: UsersIcon,
    color: '#8B5CF6',
    count: 15,
    bgColor: '#F5F3FF'
  },
  {
    title: 'Performance Reports',
    description: 'Team performance and productivity analysis',
    icon: ChartBarIcon,
    color: '#F59E0B',
    count: 10,
    bgColor: '#FEF3C7'
  },
  {
    title: 'Asset Reports',
    description: 'Asset tracking and utilization reports',
    icon: DocumentChartBarIcon,
    color: '#EF4444',
    count: 6,
    bgColor: '#FEE2E2'
  },
  {
    title: 'Custom Reports',
    description: 'Build your own custom reports',
    icon: PresentationChartLineIcon,
    color: '#06B6D4',
    count: 4,
    bgColor: '#CFFAFE'
  }
];


export function exportToExcel(data, filename = "report.xlsx") {
  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Report");
  const wbout = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
  saveAs(new Blob([wbout], { type: "application/octet-stream" }), filename);
}

export function exportToCSV(data, filename = "report.csv") {
  const worksheet = XLSX.utils.json_to_sheet(data);
  const csv = XLSX.utils.sheet_to_csv(worksheet);
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  saveAs(blob, filename);
}

export function exportToPDF(data, columns, filename = "report.pdf", title = "Report Data") {
  const doc = new jsPDF();
  doc.setFontSize(16);
  doc.setFont(undefined, 'bold');
  doc.text(title, 14, 16);

  doc.setFontSize(10);
  doc.setFont(undefined, 'normal');
  doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 24);

  autoTable(doc, {
    head: [columns],
    body: data.map(row => columns.map(col => row[col] || '')),
    startY: 30,
    styles: { fontSize: 10, cellPadding: 3 },
    headStyles: { fillColor: [67, 144, 248], textColor: 255, fontStyle: 'bold' },
    alternateRowStyles: { fillColor: [245, 245, 245] },
    margin: { top: 30, left: 14, right: 14 }
  });

  doc.save(filename);
}
