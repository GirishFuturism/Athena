export const initialClientRows = [
  {
    id: 1,
    accountManager: {
      name: "Emily Rodriguez",
      avatar: "https://i.pravatar.cc/150?img=1",
    },
    clientName: "Tech Solutions",
    openTickets: 3,
    openOpportunities: 0,
    nextCallDate: "02 Nov 2025",
  },
  {
    id: 2,
    accountManager: {
      name: "Sarah Wilson",
      avatar: "https://i.pravatar.cc/150?img=5",
    },
    clientName: "TechSInc",
    openTickets: 2,
    openOpportunities: 0,
    nextCallDate: "01 Nov 2025",
  },
  {
    id: 3,
    accountManager: {
      name: "Michael Chen",
      avatar: "https://i.pravatar.cc/150?img=12",
    },
    clientName: "techG",
    openTickets: 3,
    openOpportunities: 1,
    nextCallDate: "31 Oct 2025",
  },
  {
    id: 4,
    accountManager: {
      name: "Daniel Williams",
      avatar: "https://i.pravatar.cc/150?img=13",
    },
    clientName: "Gts Solutions",
    openTickets: 3,
    openOpportunities: 0,
    nextCallDate: "31 Oct 2025",
  },
  {
    id: 5,
    accountManager: {
      name: "Emily Davis",
      avatar: "https://i.pravatar.cc/150?img=9",
    },
    clientName: "InnTech",
    openTickets: 4,
    openOpportunities: 0,
    nextCallDate: "05 Nov 2025",
  },
  
];