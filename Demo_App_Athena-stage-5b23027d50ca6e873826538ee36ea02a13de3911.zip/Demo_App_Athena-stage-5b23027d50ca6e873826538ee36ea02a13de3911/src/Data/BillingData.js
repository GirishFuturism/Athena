// BillingData.js

export const invoiceRows = [
  {
    id: 'INV-005',
    date: 'Oct 28, 2024',
    customer: 'Acme Corp',
    email: 'john@acme.com',
    amount: 2500,
    status: 'Paid',
    due: 'Nov 27, 2024',
  },
  {
    id: 'INV-004',
    date: 'Oct 25, 2024',
    customer: 'TechStart Inc',
    email: 'sarah@techstart.com',
    amount: 1850,
    status: 'Pending',
    due: 'Nov 24, 2024',
  },
  {
    id: 'INV-003',
    date: 'Oct 20, 2024',
    customer: 'Global Solutions',
    email: 'mike@global.com',
    amount: 3200,
    status: 'Overdue',
    due: 'Oct 19, 2024',
  },
  {
    id: 'INV-002',
    date: 'Oct 18, 2024',
    customer: 'Bright Future LLC',
    email: 'anne@brightfuture.com',
    amount: 4750,
    status: 'Paid',
    due: 'Nov 17, 2024',
  },
  {
    id: 'INV-001',
    date: 'Oct 15, 2024',
    customer: 'Innovatech Group',
    email: 'dave@innovatech.com',
    amount: 2900,
    status: 'Paid',
    due: 'Nov 14, 2024',
  },

];

export const statusConfig = {
  Paid: {
    bg: '#DCFCE7',
    color: '#166534',
    label: 'Paid',
  },
  Pending: {
    bg: '#FFEDD5',
    color: '#9A3412',
    label: 'Pending',
  },
  Overdue: {
    bg: '#FEE2E2',
    color: '#991B1B',
    label: 'Overdue',
  },
};
