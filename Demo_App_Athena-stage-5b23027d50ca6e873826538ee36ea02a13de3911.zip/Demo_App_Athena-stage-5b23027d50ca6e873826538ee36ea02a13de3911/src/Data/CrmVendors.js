// Data/CrmVendors.js

export const CrmVendors = [
  {
    id: 1,
    vendorName: 'Ingram Micro',
    contactName: 'John Smith',
    emailAddress: 'john.smith@ingrammicro.com',
    phoneNumber: '+1 (555) 123-4567',
    status: 'Active'
  },
  {
    id: 2,
    vendorName: 'HaloPSA',
    contactName: 'Sarah Johnson',
    emailAddress: 'support@halopsa.com',
    phoneNumber: '+44 (0)1449 833 111',
    status: 'Active'
  },
  {
    id: 3,
    vendorName: 'Pax8',
    contactName: 'Michael Brown',
    emailAddress: 'michael.brown@pax8.com',
    phoneNumber: '+1 (555) 234-5678',
    status: 'Active'
  },
  {
    id: 4,
    vendorName: 'Dell',
    contactName: 'Emily Davis',
    emailAddress: 'emily.davis@dell.com',
    phoneNumber: '+1 (555) 345-6789',
    status: 'Active'
  },
  {
    id: 5,
    vendorName: 'HP',
    contactName: 'Robert Wilson',
    emailAddress: 'robert.wilson@hp.com',
    phoneNumber: '+1 (555) 456-7890',
    status: 'Active'
  },
  {
    id: 6,
    vendorName: 'Tech Data',
    contactName: 'Jennifer Martinez',
    emailAddress: 'jennifer.martinez@techdata.com',
    phoneNumber: '+1 (555) 567-8901',
    status: 'Active'
  },
  {
    id: 7,
    vendorName: 'West Coast',
    contactName: 'David Anderson',
    emailAddress: 'david.anderson@westcoast.com',
    phoneNumber: '+1 (555) 678-9012',
    status: 'Active'
  },
  {
    id: 8,
    vendorName: 'Lenovo',
    contactName: 'Lisa Thompson',
    emailAddress: 'lisa.thompson@lenovo.com',
    phoneNumber: '+1 (555) 789-0123',
    status: 'Active'
  },
  {
    id: 9,
    vendorName: 'Amazon',
    contactName: 'James Garcia',
    emailAddress: 'james.garcia@amazon.com',
    phoneNumber: '+1 (555) 890-1234',
    status: 'Active'
  },
  {
    id: 10,
    vendorName: 'Microsoft',
    contactName: 'Patricia Lee',
    emailAddress: 'patricia.lee@microsoft.com',
    phoneNumber: '+1 (555) 901-2345',
    status: 'Active'
  },
];
