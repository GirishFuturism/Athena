import React, { useEffect, useState } from "react";
import { Box, Grid, Typography, useMediaQuery, useTheme } from '@mui/material';
import Sidebar from "./Components/Shared/Sidebar/Sidebar";
import Header from "./Components/Shared/header";

const Layout = ({ children }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));
  const isSm = useMediaQuery(theme.breakpoints.down("sm"));
  const [role, setRole] = useState("");

  const [collapsed, setCollapsed] = useState(isMobile);

  useEffect(() => {
    setCollapsed(isMobile);
  }, [isMobile]);

  const handleToggleSidebar = (newState) => {
    setCollapsed(newState);
  };

  useEffect(() => {
  const storedRole = localStorage.getItem("role") || "";
  setRole(storedRole);
}, []);


  return (
    <Grid 
        sx={{ 
            display: 'flex',  
            flexGrow: 1 , 
            flexDirection:'column', 
            zIndex:2,
            // minHeight: "100vh",   // ✅ full height of screen
            // width: "100%",  
            }}>
      <Header collapsed={collapsed} onToggleSidebar={handleToggleSidebar} role={role} setRole={setRole}/>
      <Grid sx={{ display: 'flex', flexDirection: 'row', flexGrow: 1, zIndex: 1}}>
        <Sidebar  collapsed={collapsed} onToggleSidebar={handleToggleSidebar} role={role} />
        <Grid
          component="main"                       
          sx={{
            flexGrow: 1,
            p: 1,
            mt: 8,
            backgroundColor: '#DFF0FF', 
            // width: '100%'
          }}
        >
          {children} 
          <Typography sx={{textAlign:"center",fontFamily:"Open Sans", fontWeight:400,fontSize:"14px", p:1}}>© 2025 PSA. All rights reserved.</Typography>
        </Grid>
       
      </Grid>
    </Grid>
  );
};

export default Layout;